'use strict';

// Node JS global scope
var fs = global.fs = global.fs || require('fs');
var path = global.path = global.path || require('path');
var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var config = common.config();
var pluralize = global.pluralize = global.pluralize || require('pluralize');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
var typo = global.typo = global.typo || require('typo-js');
var dictionary = new typo('en_US');

// Read common custom api from build
var customWords = JSON.parse(fs.readFileSync(__dirname + '/../utils/custom-words.json'));
if (config.customWords) {
    // Get component's custom api
    customWords = customWords.concat(config.customWords);
}
var fileName = null;
var invalidNames = [];
var invalidApiDetails = { spell: [], numberFirst: [], abbreviation: [], singular: [], plural: [], jsDoc: [] };
var errorCaption = {
    spell: '** SPELL ERROR ** => ',
    numberFirst: '** NUMBER FIRST ERROR ** => ',
    abbreviation: '** ABBREVIATION ERROR ** => ',
    singular: '** SINGULAR ERROR ** => ',
    plural: '** PLURAL ERROR ** => ',
    jsDoc: '** JSDOC ERROR ** => '
};
var linkRegex = /(\w)+(:\/\/|:|\.)([\w/.&=\-\+!(),?:#~%$@;<>^\\`|{}[\]]+)/g;

/** 
 * Spell check on API namings
 */
gulp.task('spell-check-ci', function (done) {
    // Read api file from component
    var apiString = fs.readFileSync(config.spellCheck, 'utf8');
    var apiJson = JSON.parse(apiString);
    checkAPIObject(apiJson.children);
    printErrors();
    var stars = '******************************************************';
    if (invalidNames.length) {
        console.log(stars + '\nError: ' + common.currentPackage + ' have some invalid API names in typedoc\n' + stars);
        // process.exit(1);
    }
    else {
        console.log(stars + '\nSuccess: ' + common.currentPackage + ' have valid API names in typedoc\n' + stars);
    }
    done();
});

gulp.task('spell-check', function (done) {
    runSequence('typedoc', 'spell-check-ci', done);
});

// Check api name from api object
function checkAPIObject(apiObject) {
    for (var i = 0; i < apiObject.length; i++) {
        var api = apiObject[i];
        var isExported = api.flags.isExported && !(api.flags.isPrivate || api.inheritedFrom);
        var isReflection = api.type && api.type.type === 'reflection';
        if ((api.flags.isPublic || isExported) && !isReflection) {
            getFileName(api);
            if (fileName && fileName.indexOf('.d.ts') === -1) {
                checkAPI(api);
                checkSingularPlural(api);
                if (api.signatures) {
                    checkSignatures(api);
                }
                checkJsDoc(api);
            }
        }
        if (api.children) {
            checkAPIObject(api.children);
        }
    }
    return invalidNames;
}
exports.checkAPIObject = checkAPIObject;

function getFileName(api) {
    if (api.originalName && api.originalName !== fileName) {
        fileName = path.basename(api.originalName);
    }
}

function checkSignatures(apiObject) {
    var signatures = apiObject.signatures;
    for (var i = 0; i < signatures.length; i++) {
        if (signatures[i].parameters) {
            checkParameters(signatures[i]);
        }
        checkJsDoc(signatures[i]);
    }
}

function checkParameters(signObject) {
    var parameters = signObject.parameters;
    for (var i = 0; i < parameters.length; i++) {
        checkAPI(parameters[i].name, parameters[i].kindString, signObject.name);
        checkJsDoc(parameters[i], signObject);
    }
}

function checkAPI(apiObject, paramType, fnName) {
    var name = fnName ? apiObject : apiObject.name;
    var apiObj = {
        fullName: name,
        type: paramType ? paramType : apiObject.kindString,
        parameter: fnName ? 'Parameter: ' : ''
    };
    var words = getWordsFromAPI(name);
    checkSpells(words, apiObj);
}

// Get splitted words from api name
function getWordsFromAPI(apiName) {
    var words = [], word = '';
    if (apiName.indexOf('`') !== -1) {
        apiName = ignoreCodeBlocks(apiName);
    }
    if (linkRegex.test(apiName)) {
        apiName = apiName.replace(linkRegex, '');
    }
    apiName = apiName.replace(/"/g, '');
    for (var i = 0; i < apiName.length; i++) {
        var currChar = apiName[i], nextChar = apiName[i + 1];
        if (checkSpecialCharacter(currChar)) {
            if (word.length) {
                words.push(ignoreEndNumbers(word));
            }
            word = '';
        }
        // Get lower letter words
        else if (currChar === currChar.toLowerCase()) {
            word = word + currChar;
            if ((nextChar && nextChar === nextChar.toUpperCase() && isNaN(nextChar)) || !nextChar) {
                words.push(ignoreEndNumbers(word));
                word = '';
            }
        }
        // Get upper letter words
        else {
            if (nextChar && nextChar === nextChar.toLowerCase() && !checkSpecialCharacter(nextChar) && !isNumber(nextChar)) {
                word = currChar;
            }
            else {
                word = word + currChar;
                var secondChar = apiName[i + 2];
                if ((secondChar && secondChar === secondChar.toLowerCase() &&
                    !isNumber(secondChar) && !checkSpecialCharacter(secondChar)) || !nextChar) {
                    words.push(ignoreEndNumbers(word));
                    word = '';
                }
            }
        }
    }
    return words;
}
exports.getWordsFromAPI = getWordsFromAPI;

// Check list of api words and return invalid api name list
function checkSpells(wordList, apiObject) {
    var invalidAPI = [];
    for (var i = 0; i < wordList.length; i++) {
        var apiWord = wordList[i];
        if (checkDoubleLetterWord(apiWord)) {
            continue;
        }
        if (!checkFirstLetter(apiWord)) {
            setInvalidNames(apiWord, apiObject, 'numberFirst');
            invalidAPI.push(apiWord);
        }
        else if (!(apiObject && apiObject.type === 'Variable') && !checkAbbreviation(apiWord)) {
            setInvalidNames(apiWord, apiObject, 'abbreviation');
            invalidAPI.push(apiWord);
        }
        else if (!checkSpell(apiWord)) {
            setInvalidNames(apiWord, apiObject, 'spell');
            invalidAPI.push(apiWord);
        }
    }
    return invalidAPI;
}
exports.checkSpells = checkSpells;

// Check api name if double letter word
function checkDoubleLetterWord(word) {
    return (word.length <= 2);
}
exports.checkDoubleLetterWord = checkDoubleLetterWord;

// Check api name and parameter name from methods
function checkSpell(api) {
    return ((dictionary.check(api) || customWords.indexOf(api.toLowerCase()) !== -1));
}
exports.checkSpell = checkSpell;

// Check abbreviation words
function checkAbbreviation(word) {
    var abbWord = '';
    if (word.indexOf('HTML') !== -1) {
        return true;
    }
    for (var i = 0; i < word.length; i++) {
        if (word[i].charCodeAt(0) >= 65 && word[i].charCodeAt(0) <= 90) {
            abbWord = abbWord + word[i];
        }
    }
    if (word === abbWord) {
        return abbWord.length <= 2;
    }
    return true;
}
exports.checkAbbreviation = checkAbbreviation;

// Check special character from api letter
function checkSpecialCharacter(char) {
    return RegExp(/[^a-zA-Z0-9]/).test(char);
}
exports.checkSpecialCharacter = checkSpecialCharacter;

// Check initial letter of api as number
function checkFirstLetter(api) {
    return !(api.charCodeAt(0) >= 48 && api.charCodeAt(0) <= 57);
}
exports.checkFirstLetter = checkFirstLetter;

// Check api is singular or plural
function checkSingularPlural(apiObject) {
    var splitted = getWordsFromAPI(apiObject.name);
    var finalWord = splitted[splitted.length - 1];
    var apiObj = {
        type: apiObject.kindString,
        fullName: apiObject.name,
        parameter: ''
    };
    if (!checkSingularIgnore(apiObject) && checkSingular(finalWord, apiObject.kindString)) {
        setInvalidNames(finalWord, apiObj, 'singular');
    }
    else if (checkPlural(finalWord, apiObject.type && apiObject.type.isArray)) {
        setInvalidNames(finalWord, apiObj, 'plural');
    }
}

function checkSingularIgnore(apiObject) {
    if (!apiObject.comment) {
        return false;
    }
    var tags = apiObject.comment.tags || [];
    for (var tagData of tags) {
        if (tagData.tag === 'ignoresingular') {
            return true;
        }
    }
}
// Check singular words
function checkSingular(word, kindString) {
    return (kindString === 'Enumeration' && word !== pluralize.singular(word));
}
exports.checkSingular = checkSingular;

// Check plural words
function checkPlural(word, isArray) {
    return (isArray && word !== pluralize.plural(word) && config.addPlurals.indexOf(word.toLowerCase()) === -1);
}
exports.checkPlural = checkPlural;

// Print all type of errors
function printErrors() {
    var keys = Object.keys(invalidApiDetails);
    for (var i = 0; i < keys.length; i++) {
        var errors = invalidApiDetails[keys[i]];
        if (errors.length) {
            console.log('\n' + errorCaption[keys[i]] + '\n');
            for (var j = 0; j < errors.length; j++) {
                if (keys[i] === 'jsDoc') {
                    console.log('Location: ' + errors[j].fileName + ' ==>> ' + errors[j].kindString + ': ' + errors[j].name + ' -> ' +
                        errors[j].errorType + ': ' + errors[j].invalidName);
                }
                else {
                    console.log('Location: ' + errors[j].fileName + ' ==>> ' + errors[j].type + ': ' + errors[j].fullName + ' -> ' +
                        errors[j].parameter + errors[j].invalidName);
                }
            }
        }
    }
}

// Method for js Doc spell check
function checkJsDoc(api, signObject) {
    if (!api.comment) {
        return;
    }

    var apiObject = signObject ? signObject : api;
    // Testing description in jsDoc;
    if (api.comment.shortText) {
        var description = getWordsFromAPI(api.comment.shortText);
        checkJsDocSpell(description, 'Description', apiObject);
    }

    // Testing returns in jsDoc
    if (api.comment.returns) {
        var returns = getWordsFromAPI(api.comment.returns);
        checkJsDocSpell(returns, 'Returns', apiObject);
    }

    // Testing params in jsDoc
    if (api.comment.text) {
        var text = getWordsFromAPI(api.comment.text);
        checkJsDocSpell(text, 'Param', apiObject);
    }

    if (api.comment.tags) {
        var tags = api.comment.tags;
        for (var i = 0; i < tags.length; i++) {
            checkJsDocSpell(getWordsFromAPI(tags[i].tag), 'Param', apiObject);
            checkJsDocSpell(getWordsFromAPI(tags[i].text), 'Param', apiObject);
            if (tags[i].param) {
                checkJsDocSpell(getWordsFromAPI(tags[i].param), 'Param', apiObject);
            }
        }
    }
}

// Set invalid jsDoc content to invalidNames 
function checkJsDocSpell(comments, type, api) {
    var inValidContent = [];
    for (var i = 0; i < comments.length; i++) {
        if (!checkDoubleLetterWord(comments[i]) && !checkSpell(comments[i]) && isNaN(comments[i])) {
            inValidContent.push(comments[i]);
            if (api) {
                var apiObject = Object.assign({}, api);
                apiObject.errorType = type;
                setInvalidNames(comments[i], apiObject, 'jsDoc');
            }
        }
    }
    return inValidContent;
}
exports.checkJsDocSpell = checkJsDocSpell;

// Set invalid names based on its type
function setInvalidNames(name, apiObj, error) {
    if (apiObj) {
        apiObj.invalidName = name;
        apiObj.fileName = fileName;
        invalidApiDetails[error].push(apiObj);

        if (invalidNames.indexOf(apiObj.fullName) === -1) {
            invalidNames.push(apiObj.fullName);
        }
    }
}

// Ignore code block content
function ignoreCodeBlocks(content) {
    // Remove all \n from the jsdoc
    content = content.replace(/\n/g, ' ');
    // Replace the code block and highlight content
    return content.replace(/ ```(.*?)```/g, '').replace(/ `(.*?)`/g, '');
}
exports.ignoreCodeBlocks = ignoreCodeBlocks;

// Ignore ends with number
function ignoreEndNumbers(word) {
    // check the last char number and remove it   
    if (word.length && !isNaN(word.slice(-1))) {
        word = ignoreEndNumbers(word.slice(0, -1));
    }
    return word;
}
exports.ignoreEndNumbers = ignoreEndNumbers;

function isNumber(char) {
    return /[0-9]/.test(char);
}
