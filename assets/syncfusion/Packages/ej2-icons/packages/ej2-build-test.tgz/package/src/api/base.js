'use strict';
//reading public APIs (properties, methods, events) form typedoc
class publicAPIReader {

    constructor() {

    }

    //initializing the reading process 
    initializeAPIReader(modulearray) {
        if (!modulearray) {
            return;
        }
        let publicAPIObj = {};
        for (let proj of modulearray) {
            //filtering the module which has class type as children
            if (proj && proj.name) {
                let modulename = proj.name.replace(/\"/g, '');
                let classchildren = proj.children ? proj.children.filter(projtype =>
                    projtype.kindString === 'Class'&& 
                    projtype.flags.isExported === true && 
                    !projtype.flags.isPrivate
                ) : [];
                let classObjects = this.readPublicAPIs(classchildren, false);
                let interfacechildren = proj.children ? proj.children.filter(projtype =>
                    projtype.kindString === 'Interface' && 
                    projtype.flags.isExported === true && 
                    !projtype.flags.isPrivate) : [];
                let interfaceObjects = this.readPublicAPIs(interfacechildren, true);
                let varchildren = proj.children ? proj.children.filter(projtype =>
                    projtype.kindString === 'Variable' && 
                    projtype.flags.isExported === true && 
                    !projtype.flags.isPrivate) : [];
                let apiObjects = this.readPropertyAPIs(varchildren, false);
                let functionchindren = proj.children ? proj.children.filter(projtype =>
                    projtype.kindString === 'Function' && 
                    projtype.flags.isExported === true && 
                    !projtype.flags.isPrivate) : [];
                let methodObjects = this.readMethodAPIs(functionchindren, false);
                publicAPIObj[modulename] = {
                    'classes': classObjects,
                    'interfaces': interfaceObjects,
                    'apis': apiObjects,
                    'methods': methodObjects
                };
            }
        }
        return publicAPIObj;
    }

    //retrieving all APIs and returning it as JSON with key as module name
    readPublicAPIs(classtypes, isinterface) {
        if (!classtypes) {
            return;
        }
        let publicClasses = {};//{apis:{}, methods: {}, events:{}};
        //filtering and retrieving public APIs from each module
        for (let classtype of classtypes) {
            if (classtype && classtype.children && classtype.name) {
                publicClasses[classtype.name] = this.readClassAPIs(classtype, isinterface);
            }
        }
        return publicClasses;
    }

    readClassAPIs(classtype, isinterface){
        if (!classtype) {
            return;
        }
        else if(!classtype.children && !classtype.name){
            return;
        }
        let classapiobj = { apis: {}, methods: {}, events: {} };
        let propchild = classtype.children.filter(cls => cls.kindString === 'Property' && 
        (isinterface ? cls.flags.isExported === true && !cls.flags.isPrivate : cls.flags.isPublic === true));
        let eventchild = classtype.children.filter(cls => cls.kindString === 'Event' && 
        (isinterface ? cls.flags.isExported === true && !cls.flags.isPrivate : cls.flags.isPublic === true));
        let methodchind = classtype.children.filter(cls => cls.kindString === 'Method' && 
        (isinterface ? cls.flags.isExported === true && !cls.flags.isPrivate : cls.flags.isPublic === true));
        let literalchild = classtype.children.filter(cls => cls.kindString === 'Object literal' && 
        (isinterface ? cls.flags.isExported === true && !cls.flags.isPrivate : cls.flags.isPublic === true));
        let objlitAPIs = this.readObjectLiteralAPIs(literalchild);
        Object.assign(classapiobj.apis, this.readPropertyAPIs(propchild));
        Object.assign(classapiobj.methods, this.readMethodAPIs(methodchind));
        Object.assign(classapiobj.events, this.readEventAPIs(eventchild));
        if (objlitAPIs !== undefined) {
            Object.assign(classapiobj.apis, objlitAPIs);
        }
        return classapiobj;
    }

    //retrieving public properties and 
    readPropertyAPIs(properties) {
        if (!properties) {
            return;
        }
        let apisObj = {};
        //building JSON object with necessary information of public properties
        for (let prop of properties) {
            if (prop && prop.name) {
                apisObj[prop.name] = {
                    type: prop.type ? this.getType(prop.type) : ``,
                    defaultvalue: prop.defaultValue ?
                        prop.defaultValue :
                        prop.comment ? this.getDefaultValue(prop.comment) : null
                };
            }
        }
        return apisObj;
    }

    //getting default vlaue of the property
    getDefaultValue(propcomment) {
        if (!propcomment) {
            return;
        }
        let defaulttags = [];
        if (propcomment.tags) {
            defaulttags = propcomment.tags.filter(t => t.tag === 'default');
        }
        return defaulttags.length === 1 ? defaulttags[0].text : null;
    }

    //retrieving public events
    readEventAPIs(events) {
        if (!events) {
            return;
        }
        let eventsObj = {};
        //building JSON object with necessary information of public events
        for (let event of events) {
            if (event && event.name) {
                eventsObj[event.name] = {
                    type: event.type ? this.getType(event.type) : ``
                };
            }
        }
        return eventsObj;
    }

    //retrieving public methods
    readMethodAPIs(methods) {
        if (!methods) {
            return;
        }
        let methodsObj = {};
        //building JSON object with necessary information of public methods
        for (let method of methods) {
            if (method && method.name && Array.isArray(method.signatures)) {
                let signatures = {};
                for (let signature of method.signatures) {
                    let generatedSign = {
                        type: signature.type ? this.getType(signature.type) : '',
                        parameters: signature.parameters ? this.getMethodParameters(signature.parameters) : {}
                    };
                    if(method.signatures.length === 1){
                        signatures = generatedSign;
                    }
                    else{
                        signatures[`signature-${method.signatures.indexOf(signature)+1}`] = generatedSign;
                    }
                }
                methodsObj[method.name] = signatures;
            }
        }
        return methodsObj;
    }

    //getting methods parameters
    getMethodParameters(parameters) {
        if (!parameters) {
            return;
        }
        let parametersObj = {};
        for (let parameter of parameters) {
            if (parameter && parameter.name) {
                parametersObj[parameter.name] = {
                    type: parameter.type ? this.getType(parameter.type) : ``
                };
            }
        }
        return parametersObj;
    }

    //retrieving public properties form objectliterals 
    readObjectLiteralAPIs(objectliterals) {
        if (!objectliterals || objectliterals.length <= 0) {
            return;
        }
        let objlitObj = {};
        for (let objlit of objectliterals) {
            if (objlit && objlit.name) {
                objlitObj[objlit.name] = {
                    type: objlit.type ? this.getType(objlit.type) : ``,
                    defaultvalue: objlit.defaultValue ?
                        objlit.defaultValue :
                        objlit.comment ? this.getDefaultValue(objlit.comment) : null
                };
            }
            if (objlit && objlit.children) {
                for (let child of objlit.children) {
                    objlitObj[`${objlit.name}.${child.name}`] = {
                        type: child.type ? this.getType(child.type) : ``,
                        defaultvalue: child.defaultValue ?
                            child.defaultValue :
                            child.comment ? this.getDefaultValue(child.comment) : null
                    };
                }
            }
        }
        return objlitObj;
    }

    getType(typeObj) {
        if (!typeObj) {
            return;
        }
        if (typeObj.type && typeObj.type === 'reference') {
            this.getReferenceType(typeObj);
        }
        if (typeObj.type && typeObj.type === 'union') {
            this.getUnionType(typeObj);
        }
        if (typeObj.type && typeObj.type === 'array') {
            this.getArrayType(typeObj);
        }
        if (typeObj.type && typeObj.type === 'reflection') {
            this.getReflectionType(typeObj);
        }
        return typeObj;
    }

    getReferenceType(refObj) {
        if (!refObj) {
            return;
        }
        if (refObj.hasOwnProperty('id')) {
            delete refObj.id;
        }
        if (refObj.hasOwnProperty('typeArguments') && refObj.typeArguments) {
            for (let typeargument of refObj.typeArguments) {
                if (typeargument && typeargument.hasOwnProperty('id')) {
                    delete typeargument.id;
                }
            }
        }
    }

    getUnionType(unionObj) {
        if (!unionObj) {
            return;
        }
        if (unionObj.hasOwnProperty('types') && unionObj.types) {
            for (let typ of unionObj.types) {
                this.getType(typ);
            }
        }
    }

    getArrayType(arrayObj) {
        if (!arrayObj) {
            return;
        }
        if (arrayObj.hasOwnProperty('elementType') && arrayObj.elementType) {
            this.getType(arrayObj.elementType);
        }
    }

    getReflectionType(reflectionObj) {
        if (!reflectionObj) {
            return;
        }
        if (reflectionObj.hasOwnProperty('declaration') && reflectionObj.declaration) {
            if (reflectionObj.declaration.hasOwnProperty('id')) {
                delete reflectionObj.declaration.id;
            }
            if (reflectionObj.declaration.hasOwnProperty('indexSignature') && reflectionObj.declaration.indexSignature) {
                var indexsig = reflectionObj.declaration.indexSignature;
                if (indexsig.hasOwnProperty('id')) {
                    delete indexsig.id;
                }
                if (indexsig.hasOwnProperty('type') && indexsig.type) {
                    this.getType(indexsig.type);
                }
                if (indexsig.hasOwnProperty('parameters') && indexsig.parameters) {
                    for (let param of indexsig.parameters) {
                        if (param && param.hasOwnProperty('id')) {
                            delete param.id;
                        }
                        if (param && param.hasOwnProperty('type')) {
                            this.getType(param.type);
                        }
                    }
                }
            }
            if (reflectionObj.declaration.hasOwnProperty('signatures') && reflectionObj.declaration.signatures) {
                for (let signature of reflectionObj.declaration.signatures) {
                    if (signature.hasOwnProperty('id')) {
                        delete signature.id;
                    }
                    if (signature.hasOwnProperty('type') && signature.type) {
                        this.getType(signature.type);
                    }
                    if (signature.hasOwnProperty('parameters') && signature.parameters) {
                        for (let param of signature.parameters) {
                            if (param && param.hasOwnProperty('id')) {
                                delete param.id;
                            }
                            if (param && param.hasOwnProperty('type')) {
                                this.getType(param.type);
                            }
                        }
                    }
                }
            }
            if (reflectionObj.declaration.hasOwnProperty('sources')) {
                delete reflectionObj.declaration.sources;
            }
        }
    }

}

module.exports = publicAPIReader;
