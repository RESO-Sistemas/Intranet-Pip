'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var thirdParty = global.thirdParty = global.thirdParty || require('./third-party.js');

gulp.task('vue-publish', function (done) {
    thirdParty.publish('vue', 'npm install &&  gulp build  && gulp ci-compile && ' +
        'gulp vue-global-script && gulp es-scripts && gulp esm-scripts && gulp umd-scripts &&' +
        'gulp add-pure-webpack rm-temp && gulp license && gulp vue-api', done);
});