'use strict';

module.exports = function(configFile) {
    var fs = require('fs');
    var gutil = require('gulp-util');
    var through = require('through2');
    var htmllint = require('htmllint');

    var hasErrors = false;
    var lintOptions = JSON.parse(fs.readFileSync(configFile, 'utf8'));
    return through.obj(function(file, enc, callback) {
        if (file.isNull()) {
			callback(null, file);
			return;
		}
        var lint = htmllint(file.contents.toString(), lintOptions);

        lint.then(function(issues) {
            issues.forEach(function(issue) {
                issue.msg = issue.msg || htmllint.messages.renderIssue(issue);
            });

            if (issues.length) {
                hasErrors = true;
            }

            for (var i = 0; i < issues.length; i++) {
                var error = gutil.colors.cyan('[html-lint] ==> ') + gutil.colors.white(file.path + ' [' + issues[i].line +
                    ',' + issues[i].column + ']:') + gutil.colors.red('(' + issues[i].code + ')' + issues[i].msg);
                gutil.log(error);
            }

            callback(null, file);
        }).catch(function(e) {
            gutil.log(gutil.colors.cyan('[html-lint] ==> ') + gutil.colors.red(e));
            callback(null, file);
        });
    }, function(cb) {
        if (hasErrors) {
            this.emit('end');
            process.exit(1);
        }
        cb();
    });
};