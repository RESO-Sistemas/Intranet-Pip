'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
var fs = global.fs = global.fs || require('fs');
var shelljs = require('shelljs');

gulp.task('blazor-checkout', function (done) {
    common.checkout('blazor', 'blazor', function () {
        var branchname = common.isMasterBranch ? 'master' : 'development';
        branchname = common.isReleaseBranch ? process.env.githubSourceBranch : branchname;
        branchname = common.isHotfixBranch ? process.env.githubSourceBranch : branchname;
        shelljs.cd('./third-party/blazor/');
        shelljs.exec('git checkout ' + branchname);
        shelljs.cd('../../');
        done();
    });
});

gulp.task('clean', function (done) {
    shelljs.rm('-rf', './src/bin/');
    shelljs.rm('-rf', './src/obj/');
    shelljs.rm('-rf', './bin/');
    done();
});

gulp.task('blazor-generate', function (done) {
    var aspSrcGen = require('../third-party/blazor/src-generator.js');
    var propGen = require('../third-party/blazor/property-reader');
    var propCollection = propGen(JSON.parse(fs.readFileSync('./public/api/file.json')));
    aspSrcGen(JSON.parse(fs.readFileSync('./third-party/config.json')), propCollection, done);
});

gulp.task('blazor-compile', function (done) {
    shelljs.cd('./third-party/blazor/');
    shelljs.exec('npm install');
    shelljs.exec('dotnet build "Syncfusion.Blazor/Syncfusion.Blazor.csproj"' +
        ' --verbosity "m" --configuration  "Debug"',
        function (exitCode) {
            shelljs.cd('../../');
            done();
            common.shellDone(exitCode);
        });
});

/* jshint ignore:start */
gulp.task('blazor-component-scripts', function (done) {
    if (!fs.existsSync('./third-party/')) {
        return;
    }
    try {
        return;
        // Generating dependencies.json in Blazor wwwroot file.
        var blazorPath = './third-party/blazor/Syncfusion.Blazor';
        var depsJson = common.config().dependable;
        var depsKeys = Object.keys(depsJson);
        depsKeys.map(dep => depsJson[dep].package = common.currentPackage);
        var depFile = `${blazorPath}/wwwroot/dependencies.json`;
        if (fs.existsSync(depFile)) {
            var dependencies = JSON.parse(fs.readFileSync(depFile, 'utf8'));
            Object.assign(depsJson, dependencies);
        }
        shelljs.mkdir('-p', `${blazorPath}/wwwroot/`);
        fs.writeFileSync(depFile, JSON.stringify(depsJson, null, '\t'));
        // Generating SyncfusionScripts.cs file in Blazor source
        var template = fs.readFileSync(`${__dirname}/../third-party/blazor/scripts.template`, 'utf8');
        var keys = Object.keys(depsJson);
        var compScripts = '';
        for (var i = 0; i < keys.length; i++) {
            var compObj = depsJson[keys[i]];

            var tPComps = JSON.parse(fs.readFileSync('./third-party/config.json', 'utf8')).components;
            var tPCompObj = tPComps.filter(comp => comp.baseClass === compObj.classname);
            if (tPCompObj.length && tPCompObj.blazorType === 'none') {
                continue;
            }
            var space = '\n        ';
            var propertyList = `${space}internal List<string> ${compObj.classname}Scripts { get; set; } = new List<string>() { `;
            var depScripts = '';
            var depArray = [];
            var isSamePackage = compObj.package === common.currentPackage;
            for (var j = 0; j < compObj.dependencies.length; j++) {
                var isExistDep = depArray.filter(pack => compObj.dependencies[j].indexOf(pack) !== -1);
                if (compObj.dependencies[j] === 'ej2-base' || isExistDep.length || (isSamePackage && compObj.dependencies[j].indexOf(common.currentPackage.split('/')[0]) !== -1)) {
                    continue;
                }
                // var dependency = compObj.dependencies[j].replace(/-/g, '').replace(/ej2/, '').toLowerCase();
                var dependency = compObj.dependencies[j].replace(/ej2-/, '');
                if (dependency.indexOf('/') !== -1) {
                    // individual component dependency
                    // var subDeps = dependency.split('/')[1];
                    // subDeps.split(',').map((comp) => { depScripts += `"${comp}.min.js", `; });
                    var depPack = compObj.dependencies[j].split('/')[0];
                    depArray.push(depPack);
                    depScripts += `"${dependency.split('/')[0]}.min.js", `;
                }
                else {
                    depArray.push(compObj.dependencies[j]);
                    depScripts += `"${dependency}.min.js", `;
                }
            }
            var currentPack = isSamePackage ? common.currentPackage.replace(/ej2-/, '') : compObj.package.replace(/ej2-/, '');
            if (isSamePackage) {
                depScripts += `"${currentPack}.min.js"`;
            }
            else if (!isSamePackage && (depScripts.indexOf(`"${currentPack}.min.js"`) === -1 || !depScripts.length)) {
                depScripts += `"${currentPack}.min.js"`;
            }
            if (depScripts.endsWith(', ')) {
                depScripts = depScripts.slice(0, -2);
            }
            propertyList += `${depScripts} };`;
            compScripts += propertyList;
        }
        template = template.replace(/{{ComponentDependencies}}/, compScripts);
        blazorPath = './third-party/blazor/Scripts/modules/';
        // fs.writeFileSync(`${blazorPath}/Base/SyncfusionScripts.cs`, template);
        shelljs.mkdir('-p', blazorPath);
        shelljs.cp('-rf', './dist/blazor/*.js', blazorPath);
        // var ej2Scripts = glob.sync(`${blazorPath}//ej2-*.js`);
        // for (var k = 0; k < ej2Scripts.length; k++) {
        //     var destFile = ej2Scripts[k].replace(/ej2-/, '');
        //     fs.renameSync(ej2Scripts[k], destFile);
        //     var scriptContent = fs.readFileSync(destFile, 'utf8');
        //     scriptContent = scriptContent.replace(/filename: ej2-/, 'filename: ');
        //     scriptContent = scriptContent.replace(/\/\/# (.*).map/, '');
        //     fs.writeFileSync(destFile, scriptContent);
        // }
    }
    catch (e) {
        console.log(e);
    }
    done();
});

gulp.task('blazor-scripts', function (done) {
    try {
        var wrapperScripts = common.config().blazorWrapperScripts;
        var glob = global.glob = global.glob || require('glob');
        var blazorScriptPath = `./third-party/blazor/Scripts`;

        // copy global file to blazor source
        var globalScripts = glob.sync('./dist/global/blazor/*.js');
        var invalidScripts = []; // Track invalid scripts

        globalScripts.forEach(globalScript => {
            var scriptName = globalScript.split('blazor/')[1].replace('.js', '');
            var isWrapperScript = wrapperScripts.indexOf(scriptName) !== -1;
            var isSfScript = scriptName.indexOf('sf-') !== -1;

            if (isWrapperScript || isSfScript) {
                shelljs.cp('-f', globalScript, `${blazorScriptPath}/modules/`);
            } else {
                // Collect invalid scripts
                invalidScripts.push(scriptName);
            }
        });

        // Fail CI if there are invalid scripts
        if (invalidScripts.length > 0) {
            console.log(`Invalid scripts found: ${invalidScripts.join(', ')}. Scripts must be either in wrapperScripts or contain 'sf-' prefix.`);
        }
    }
    catch (e) {
        console.log(e);
        done(e); // Pass error to done callback to fail the task
    }
    done();
});
/* jshint ignore:end */

gulp.task('blazor-build', function (done) {
    runSequence('blazor-checkout', 'blazor-scripts', done);
});  