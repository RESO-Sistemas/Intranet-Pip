'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var common = global.config = global.config || require('../utils/common.js');
var simpleGit = global.simpleGit = global.simpleGit || require('simple-git');
var fs = global.fs = global.fs || require('fs');
var cdn = require('./cdn.js');
var gzip = require('gulp-gzip');
var config = common.config();
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');

var gitignore =
    `.gitignore
!/**/*.ts
/*.ts
**/*.d.ts
!src/**/*-model.d.ts
!src/**/*-builder.d.ts
!src/**/*-interface.d.ts
dist/global/*.js
!dist/global/` + common.currentPackage + `*
`;

/**
 * Publish current package in github
 */
gulp.task('publish-github-source', function (done) {
    runSequence('publish-coverage');
    if (!(common.isMasterBranch || common.isReleaseBranch || common.isHotfixBranch || process.env.githubSourceBranch === 'development')) {
        done();
        return;
    }
    var platform = '';
    var packagename = '';
    var pack = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
    var packName = pack.name.replace('@syncfusion/', '').split('-');
    packagename = packName[packName.length - 1];
    if (pack.name.replace('@syncfusion/', '') === 'ej2') {
        packName = 'ej2';
    }
    else {
        var type = packName[1];
        var platforms = ['angular', 'react', 'vue'];
        if (platforms.indexOf(type) > -1) {
            platform = type + '-';
        }
        packName = platform === '' ? packName.slice(1).join('') : packName.slice(2).join('');
    }
    // check github repository
    var user = 'SyncfusionAutomation';
    var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
    // clone github repository 
    if (process.env.githubSourceBranch === 'development' && platform.indexOf('angular') === -1) {
        done();
        return;
    }
    var gitPath = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-' + platform + 'github-source';
    var localPath = './github-repo/src/' + packName;
    if (!fs.existsSync(localPath)) {
        shelljs.mkdir('-p', localPath);
    }
    var branch = process.env.githubSourceBranch;
    var gitLocalPath = './github-repo/ej2-' + platform + 'github-source';
    var clone = shelljs.exec('git clone ' + gitPath + ' -b ' + branch + ' ' + gitLocalPath, {
        silent: false
    });
    if (clone.code !== 0) {
        done();
        return;
    } else {
        if (fs.existsSync(gitLocalPath + '/' + packName)) {
            // remove all files in the current github repository
            shelljs.rm('-r', gitLocalPath + '/' + packName);
        }
        if (fs.existsSync(gitLocalPath + '/' + packagename)) {
            // remove all files in the current github repository
            shelljs.rm('-r', gitLocalPath + '/' + packagename);
        }
        if (fs.existsSync(gitLocalPath + '/src/' + packName)) {
            // remove all files in the current github repository
            shelljs.rm('-rf', gitLocalPath + '/src/' + packName + '/*');
        }
        if (fs.existsSync(gitLocalPath + '/' + pack.name.replace('@syncfusion/', ''))) {
            // remove all files in the current github repository
            shelljs.rm('-r', gitLocalPath + '/' + pack.name.replace('@syncfusion/', ''));
        }
        if (pack.name.replace('@syncfusion/', '') === 'ej2-base') {
            config.github.push('!./e2e{,/**}', '!./demos{,/**}', '!./demo{,/**}',
                '!./themestudio{,/**}', '!./node_modules{,/**}', '!./ej2-docs{,/**}', '!./umd-deploy{,/**}');
        } else {
            config.github.push('./demos/**/*.html', './demo/**/*.ts', '!./demos/**/*.js', '!./demo/**/*.js',
                '!./themestudio{,/**}', '!./node_modules{,/**}', '!./ej2-docs{,/**}', '!./umd-deploy{,/**}');
        }
        // add all needed files in github repository
        gulp.src(config.github, {
            base: '.',
            allowEmpty: true
        })
            .pipe(gulp.dest(localPath))
            .on('end', function () {
                if (config.samplesRepo.indexOf(common.currentRepo) !== -1) {
                    addSampleDependencies(localPath);
                } else {
                    addDependencies(localPath);
                }
                if (!fs.existsSync(gitLocalPath + '/src')) {
                    shelljs.mkdir('-p', gitLocalPath + '/src');
                }
                shelljs.cp('-R', './github-repo/src/' + packName + '/', gitLocalPath + '/src');
                if (!fs.existsSync(gitLocalPath + '/license')) {
                    var license = fs.readFileSync('./github-repo/src/' + packagename + '/license', 'utf8');
                    fs.writeFileSync(gitLocalPath + '/license', license);
                }
                var latestCommit = shelljs.exec('git log -1 --pretty=%B', {
                    silent: true
                }).stdout;
                var commitMessage = latestCommit.match(/\n([\s\S]*?)See merge request/);
                commitMessage = commitMessage ? commitMessage[1] : latestCommit;
                var githubRepo = 'https://' + user + ':' + token +
                    '@gitea.syncfusion.com/essential-studio/ej2-' + platform + 'github-source.git';
                // commit the changes in github repository
                simpleGit(gitLocalPath + '/').init()
                    .add('./*')
                    .commit(commitMessage)
                    .push(githubRepo, branch, function () {
                        console.log(common.currentPackage + ' - package published in github');
                        done();
                    });
            });
    }
});


var buildDependencies = {
    'es6-promise': '^3.2.1',
    'gulp': '^3.9.1',
    'gulp-sass': '^3.1.0',
    'gulp-typescript': '^3.1.6',
    'requirejs': '^2.3.3',
    'typescript': '2.3.4'
};

var testDependencies = {
    'canteen': '^1.0.5',
    'jasmine-ajax': '^3.3.1',
    'jasmine-core': '^2.6.1',
    'karma': '6.4.2',
    'karma-chrome-launcher': '^2.2.0',
    'karma-generic-preprocessor': '^1.1.0',
    'karma-htmlfile-reporter': '^0.3.5',
    'karma-jasmine': '^1.1.0',
    'karma-jasmine-ajax': '^0.1.13',
    'karma-requirejs': '^1.1.0',
    'nedb': '^1.8.0',
    'simple-odata-server': '^0.3.1'
};

var samplesDependencies = {
    'browser-sync': '2.11.2',
    'jasmine-ajax': '^3.3.1',
    'jasmine-core': '^2.6.1',
    'karma': '6.4.2',
    'karma-chrome-launcher': '^2.2.0',
    'karma-generic-preprocessor': '^1.1.0',
    'karma-htmlfile-reporter': '^0.3.5',
    'karma-jasmine': '^1.1.0',
    'karma-jasmine-ajax': '^0.1.13',
    'karma-requirejs': '^1.1.0',
    'run-sequence': '^1.2.2',
    'webpack': '2.5.1',
    'webpack-stream': '^3.2.0'
};

// var buildReadme = '\n\n## Installing\n\nTo install all dependent packages, use the below command\n\n' +
//     '```\nnpm install\n```\n\n## Building\n\nTo compile the source files, use the below command' +
//     '\n\n```\nnpm run build\n```';

// var testReadme = '\n\n## Testing\n\nTo test the source files, use the below command\n\n' +
//     '```\nnpm run test\n```';

// var serveReadme = '\n\n## Running\n\nTo run the samples, use the below command\n\n' +
//     '```\nnpm run serve\n```';

// var gitAttribute = `
// * linguist-vendored
// *.js linguist-vendored=false
// `;

function calculateCoverage() {
    var result = '';
    if (fs.existsSync('./coverage/report.txt')) {
        var report = fs.readFileSync('./coverage/report.txt', 'utf8');
        var statements = Number(report.match('Statements(.*)%')[1].replace(': ', '').trim());
        var branches = Number(report.match('Branches(.*)%')[1].replace(': ', '').trim());
        var functions = Number(report.match('Functions(.*)%')[1].replace(': ', '').trim());
        var lines = Number(report.match('Lines(.*)%')[1].replace(': ', '').trim());
        result = Math.round((statements + branches + functions + lines) / 4);
    }
    return result;
}

function createSVG(process, result, isPositive) {
    if (!process && result && isPositive) {
        return;
    }
    var color = isPositive ? '#97CA00' : '#e05d44';
    return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="94" height="20">
    <linearGradient id="b" x2="0" y2="100%">
        <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
        <stop offset="1" stop-opacity=".1"/>
    </linearGradient>
    <clipPath id="a">
        <rect width="94" height="20" rx="3" fill="#fff"/>
    </clipPath>
    <g clip-path="url(#a)">
        <path fill="#555" d="M0 0h59v20H0z"/>
        <path fill="${color}" d="M59 0h35v20H59z"/>
        <path fill="url(#b)" d="M0 0h94v20H0z"/>
    </g>
    <g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="11">
        <text x="29.5" y="15" fill="#010101" fill-opacity=".3">${process}</text>
        <text x="29.5" y="14">${process}</text>
        <text x="75.5" y="15" fill="#010101" fill-opacity=".3">${result}%</text>
        <text x="75.5" y="14">${result}%</text>
    </g>
</svg>`;
}

function addCoverageBadge() {
    var hostedSvg = `http://${process.env.AWS_PUBLIC_BUCKET}/badges/${common.currentPackage}/coverage.svg`;
    var badge = `[![coverage](${hostedSvg})](http://${process.env.AWS_PUBLIC_BUCKET}/badges/${common.currentPackage})\n\n`;
    var path = fs.existsSync('./ReadMe.md') ? './ReadMe.md' : './README.md';
    var oldContent = fs.readFileSync(path);
    var newContent = badge + oldContent;
    fs.writeFileSync(path, newContent, 'utf-8');
}

function addDependencies(localPath) {
    shelljs.cd(localPath);
    fs.writeFileSync('./.gitignore', gitignore);
    //fs.writeFileSync('./.gitattribute', gitAttribute);
    var packageJson = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
    delete packageJson.devDependencies['@syncfusion/ej2-build-test'];
    if (fs.existsSync('../../../coverage')) {
        addCoverageBadge();
    }
    //fs.appendFileSync('./ReadMe.md', buildReadme);
    fs.writeFileSync('./gulpfile.js', fs.readFileSync(__dirname + '/../github/build.js', 'utf8'));
    packageJson.scripts = {
        'build': 'gulp build'
    };
    Object.assign(packageJson.devDependencies, buildDependencies);
    if (!fs.existsSync('./spec/')) {
        fs.writeFileSync('./package.json', JSON.stringify(packageJson, null, '\t'));
        shelljs.cd('../../../');
        return packageJson.version;
    } else {
        packageJson.scripts.test = 'gulp test';
        Object.assign(packageJson.devDependencies, testDependencies);
        //fs.appendFileSync('./ReadMe.md', testReadme);
        fs.appendFileSync('./gulpfile.js', fs.readFileSync(__dirname + '/../github/test.js', 'utf8'));
    }
    if (packageJson.dependencies['@syncfusion/ej2-data'] || packageJson.name === '@syncfusion/ej2-data') {
        fs.mkdirSync('./spec/services');
        fs.writeFileSync('./spec/services/V4service.js', fs.readFileSync(__dirname + '/../../services/V4service.js', 'utf8'));
    }
    // if (fs.existsSync('./CHANGELOG.md')) {
    //     var packName = packageJson.name.replace('@syncfusion/', '');
    //     var changelog = '\n## Changelog\n\nCheck the changelog [here](https://gitea.syncfusion.com/syncfusion/' + packName +
    //         '/blob/master/CHANGELOG.md)';
    //     fs.appendFileSync('./ReadMe.md', changelog);
    // }
    delete packageJson.config;
    fs.writeFileSync('./package.json', JSON.stringify(packageJson, null, '\t'));
    shelljs.cd('../../../');
    return packageJson.version;
}

function addSampleDependencies(localPath) {
    shelljs.cd(localPath);
    var packageJson = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
    delete packageJson.config;
    delete packageJson.devDependencies['@syncfusion/ej2-build-test'];
    //fs.writeFileSync('./ReadMe.md', buildReadme);
    var build = common.currentRepo === 'ej2-ng-samples' ?
        'gulp styles && ngc -p tsconfig-aot.json && gulp bundle' : 'gulp build';
    var serve = common.currentRepo === 'ej2-ng-samples' ?
        'npm run build && gulp serve' : 'gulp serve';
    packageJson.scripts = {
        'build': build,
        'serve': serve
    };
    Object.assign(packageJson.devDependencies, buildDependencies);
    if (fs.existsSync('./spec/')) {
        packageJson.scripts.test = 'gulp test';
        //fs.appendFileSync('./ReadMe.md', testReadme);
        Object.assign(packageJson.devDependencies, samplesDependencies);
    } else {
        Object.assign(packageJson.devDependencies, {
            'browser-sync': '2.11.2',
            'webpack': '2.5.1'
        });
    }
    if (packageJson.dependencies) {
        Object.keys(packageJson.dependencies).map(function (key) {
            if (!/@syncfusion/.test(key)) {
                delete packageJson.dependencies[key];
            }
        });
    }
    if (packageJson.devDependencies) {
        Object.keys(packageJson.devDependencies).map(function (key) {
            if (/@syncfusion/.test(key)) {
                delete packageJson.devDependencies[key];
            }
        });
    }
    if (packageJson.name === '@syncfusion/ej2') {
        packageJson.devDependencies['rollup'] = '2.79.2';
    }
    //fs.appendFileSync('./ReadMe.md', serveReadme);
    var samples = common.currentRepo === 'ej2-ng-samples' ? 'angular-samples' : 'samples';
    fs.writeFileSync('./gulpfile.js', fs.readFileSync(__dirname + '/../github/' + samples + '.js', 'utf8'));
    fs.writeFileSync('./package.json', JSON.stringify(packageJson, null, '\t'));
    shelljs.cd('../../../');
}

gulp.task('publish-coverage', function (done) {
    if (!common.isMasterBranch && !common.isReleaseBranch && !common.isHotfixBranch || !fs.existsSync('./coverage/')) {
        done();
        return;
    }
    var coverage = calculateCoverage();
    var coveragesvg = createSVG('coverage', coverage, coverage > 90);
    console.log('CoveragePath :', fs.existsSync('./coverage/headlesschrome'));
    var coveragePath = fs.existsSync('./coverage/headlesschrome') ? './coverage/headlesschrome/lcov-report' : './coverage/chrome/lcov-report';
    fs.writeFileSync(coveragePath + '/coverage.svg', coveragesvg);
    var location = `badges/${common.currentPackage}`;
    var destpath = './coverage-cdn';
    gulp.src([coveragePath + '/**'])
        .pipe(gzip({
            append: false
        }))
        .pipe(gulp.dest(destpath))
        .on('end', function () {
            cdn.publish(destpath, true, location, done);
        })
        .on('error', function (e) {
            done(e);
        });
});