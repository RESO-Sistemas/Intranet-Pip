'use strict';
var fs = global.fs = global.fs || require('fs');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var pack = JSON.parse(fs.readFileSync('./third-party/config.json', 'utf8'));

const handledTypes = {
    'string': 'string',
    'boolean': 'bool',
    'bool': 'bool',
    'number': 'double',
    'double': 'double',
    'int': 'int',
    'char': 'char'
};
var builderIgnoreTypes = ['string', 'bool', 'double', 'double[]', 'string[]', 'int', 'int[]'];
var handledTypesKeys = Object.keys(handledTypes);
var restrictedProperties = {
    'readonly': 'readOnly',
    'model': 'modelValue',
    'checked': 'check',
    'switch': 'switchObj',
    'public': 'publicObj',
    'event': 'eventObj',
    'lock': 'lockObj'
};
var restrictedKeys = Object.keys(restrictedProperties);
class AspSourceGen {

    constructor(json, propCollection, pJson, done) {
        this.tClass = 'where T : class';
        var propList = this.propertyList = propCollection;
        this.interfaces = propList.interfaces;
        this.classes = propList.allClasses;
        if (json) {
            this.render(json, propList, done);
        }
        return this;
    }

    namespaceCheck(name) {
        var temp = name.split('-');
        if (temp.length > 0) {
            for (var i = 0; i < temp.length; i++) {
                temp[i] = this.toInitCap(temp[i]);
            }
            return (temp.join()).replace(/\,/g, '');
        } else {
            return name;
        }
    }

    render(json, propList, done) {
        var files = {};
        var enums = [];

        for (var i = 0; i < json.components.length; i++) {
            var comp = json.components[i];
	    // Ignored smart components			
            if (comp.baseClass === 'SmartPasteButton' || comp.baseClass === 'SmartTextArea') {
                continue;
            }			
            this.curProcessingComponent = comp;
            shelljs.rm('-rf', './third-party/asp-core/src/' + comp.baseClass + '/*');
            var cnt = fs.readFileSync(__dirname + '/' + 'component.template').toString();
            var options = {
                enums: enums
            };
            var returnVal = this.generateComponent(cnt, propList, comp, json, options);
            shelljs.mkdir('-p', './third-party/asp-core/src/' + comp.baseClass);
            files[comp.baseClass] = returnVal;
            fs.writeFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + comp.baseClass.trim() + '.cs', returnVal);

            var helper = fs.readFileSync(__dirname + '/' + 'helper.template').toString();
            var helperVal = this.generateHelper(helper, comp);
            fs.writeFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + comp.baseClass.trim() + 'Helper.cs', helperVal);

            var builder = fs.readFileSync(__dirname + '/' + 'builder.template').toString();
            var builderVal = this.generateBuilder(builder, propList, comp, options);

            fs.writeFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + comp.baseClass.trim() + 'Builder.cs', builderVal);

            var childTag = fs.readFileSync(__dirname + '/' + 'collection.template').toString();
            this.collectionProcessor(childTag, comp.tagDirective, comp, comp, options, propList);

            var complexTag = fs.readFileSync(__dirname + '/' + 'complex.template').toString();
            this.complexProcessor(complexTag, comp.complexDirective, comp, comp, options, propList);
        }

        this.generateEnum(enums);
        done();
    }

    complexProcessor(tString, complexDirectives, pObj, compObj, options, propList) {
        tString = fs.readFileSync(__dirname + '/' + 'complex.template').toString();
        if (complexDirectives) {
            for (var l = 0; complexDirectives && l < complexDirectives.length; l++) {
                var complexDirective = complexDirectives[l];
                if (complexDirective.isBlazorOnly) {
                    continue;
                }
                this.tClass = complexDirective.isTModel === true ? 'where T : class' : '';
                this.tModelObj = complexDirective.isTModel === true ? '<Object>' : '';
                this.generateComplexTag(tString, compObj, pObj, complexDirective, options, propList);
                var complexBuilderTag = fs.readFileSync(__dirname + '/' + 'complexbuilder.template').toString();
                this.generateComplexBuilder(complexBuilderTag, compObj, pObj, complexDirective, propList, options);

                //complex inside complex navigation
                if (complexDirective.complexDirective && complexDirective.complexDirective.length) {
                    var parentTagname = options.parentTagName;
                    options.parentTagName = this.getTagSelector(pObj, complexDirective, true).complexTagName;
                    this.complexProcessor(tString, complexDirective.complexDirective, complexDirective, compObj, options, propList);
                    options.parentTagName = parentTagname;
                }

                //collection inside complex navigation 
                if (complexDirective.tagDirective && complexDirective.tagDirective.length) {
                    var cParentTagname = options.parentTagName;
                    options.parentTagName = this.getTagSelector(pObj, complexDirective, true).complexTagName;
                    this.collectionProcessor(tString, complexDirective.tagDirective, complexDirective, compObj, options, propList);
                    options.parentTagName = cParentTagname;
                }
            }
        }
    }

    collectionProcessor(tString, tagDirective, pObj, compObj, options, propList) {
        tString = fs.readFileSync(__dirname + '/' + 'collection.template').toString();
        for (var k = 0; tagDirective && k < tagDirective.length; k++) {
            var curTagDirective = tagDirective[k];
            if (curTagDirective.isBlazorOnly) {
                continue;
            }
            this.tClass = curTagDirective.isTModel === true ? 'where T : class' : '';
            this.tModelObj = curTagDirective.isTModel === true ? '<Object>' : '';
            this.generateCollectionTag(tString, compObj, pObj, curTagDirective, options, propList);
            this.generateCollectionBuilder(compObj, this.propertyList, pObj, curTagDirective, options);

            // collection inside collection 
            if (curTagDirective.tagDirective && curTagDirective.tagDirective.length && !curTagDirective.ignoreTagDirective) {
                var parentTagname = options.parentTagName;
                options.parentTagName = this.getTagSelector(pObj, curTagDirective).complexTagName;
                this.collectionProcessor(tString, curTagDirective.tagDirective, curTagDirective, compObj, options, propList);
                options.parentTagName = parentTagname;
            }

            //complex inside complex navigation
            if (curTagDirective.complexDirective && curTagDirective.complexDirective.length) {
                var cParentTagname = options.parentTagName;
                options.parentTagName = this.getTagSelector(pObj, curTagDirective).complexTagName;
                this.complexProcessor(tString, curTagDirective.complexDirective, curTagDirective, compObj, options, propList);
                options.parentTagName = cParentTagname;
            }
        }
    }

    /* jshint ignore:start */
    // here we have used options parameter
    generateComplexTag(comtag, comp, parent, complexDirective, options, propList) {
        var restrictedChild = [];
        var tag;
        if (parent.directiveSelector) {
            tag = parent.aspDirectiveSelector ? parent.aspDirectiveSelector : ('e-' +
                comp.baseClass.toLowerCase() + '-' + parent.directiveClassName.toLowerCase());
        } else if (parent.SelectorName || parent.selectorName) {
            tag = parent.SelectorName || parent.selectorName;
        } else if (comp.baseClass.toLowerCase() === parent.baseClass.toLowerCase()) {
            tag = 'ejs-' + comp.baseClass.toLowerCase();
        } else if (options.parentTagName) {
            tag = options.parentTagName;
        } else {
            tag = 'e-' + comp.baseClass.toLowerCase() + '-' + parent.propertyName.toLowerCase();
        }
        comtag = comtag.replace(/{{collectionTagName}}/g, tag);
        if (comp.removeDuplicateClassName) {
            var baseClassName = this.toInitCap(complexDirective.directiveClassName || complexDirective.baseClass);
            comtag = comtag.replace(/{{complexClassName}}/g, (complexDirective.aspClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName)));
        } else {
            comtag = comtag.replace(/{{complexClassName}}/g, (complexDirective.aspClassName || comp.baseClass + this.toInitCap(complexDirective.directiveClassName || complexDirective.baseClass)));
        }
        comtag = comtag.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
        comtag = comtag.replace(/{{ParentPropertyName}}/g, this.toInitCap(complexDirective.propertyName));
        var complexProp = this.getCollectionClassProperties(
            comp, parent, complexDirective, {
            restrictedChild: restrictedChild,
            enums: options.enums
        }, propList
        )
        complexProp += `\n        /// <summary> 
        /// To get or set value for ContentTemplate.  
        /// </summary>
        [JsonIgnore]
        [Browsable(false)]

        public MvcTemplate<object> ContentTemplate { get; set; } = new MvcTemplate<object>();`;
        if (restrictedChild.indexOf('e-content-template') === -1) {
            restrictedChild.push('e-content-template');
        }
        comtag = comtag.replace(/{{Properties}}/g, complexProp);
        var selector = '"e-' + parent.baseClass.toLowerCase() + '-' + complexDirective.propertyName.toLowerCase() + '",';
        if (complexDirective.aspSelectorName) {
            selector = '"' + (complexDirective.aspSelectorName) + '", ';
        }
        this.getRestrictChilds(complexDirective, restrictedChild);
        var restChild = this.getRestrictChild(restrictedChild);
        comtag = comtag.replace(/{{RestrictChildren}}/g, restChild);
        comtag = comtag.replace(/{{Selector}}/g, selector);
        if (fs.existsSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + complexDirective.baseClass + '.cs')) {
            var csFile = fs.readFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + complexDirective.baseClass + '.cs', 'utf8');
            var value = csFile.match(/\[HtmlTargetElement.*]/g);
            var createClass = csFile.match(/namespace.*\r\n{/g) || csFile.match(/namespace.*\n{/g);
            var customClassName = complexDirective.aspClassName || this.toInitCap(parent.baseClass +
                this.toInitCap(complexDirective.propertyName)) + this.toInitCap(parent.propertyName || parent.baseClass);
            if (comp.removeDuplicateClassName) {
                var baseClassName = this.toInitCap(complexDirective.arrayDirectiveClassName || complexDirective.baseClass);
                var temp = `[HtmlTargetElement({{Selector}} ParentTag = "{{collectionTagName}}"){{RestrictChildren}}]
                    public partial class ${customClassName} : ${baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName}
                    {
                    }`;
            } else {
                var temp = `[HtmlTargetElement({{Selector}} ParentTag = "{{collectionTagName}}"){{RestrictChildren}}]
                    public partial class ${customClassName} : ${comp.baseClass}${this.toInitCap(complexDirective.arrayDirectiveClassName || complexDirective.baseClass)}
                    {
                    }`;
            }
            temp = temp.replace(/{{collectionTagName}}/g, tag);
            temp = temp.replace(/{{Selector}}/g, selector);
            temp = temp.replace(/{{RestrictChildren}}/g, restChild);
            if (csFile.indexOf(temp) === -1) {
                csFile = csFile.replace(createClass[0], createClass[0] + '\n    ' + temp);
            }
            if (value[0].match(/".*,/g)[0].replace(',', '').replace(/"/g, "").split(' ')[0] !==
                selector.replace(',', '').replace(/"/g, "")) {
                if (csFile.indexOf('IsComplex') === -1) {
                    var isChild = csFile.match(/protected override bool IsChild .*/g);
                    var isComplex = '        protected override bool IsComplex { get { return true; } }';
                    csFile = csFile.replace(isChild, isChild + '\n' + isComplex);
                    var collectionParent = csFile.match(/\/\/ appendProperties.*/);
                    var string = 'protected override string ParentPropertyName { get { return "{{parentPropertyName}}"; } }'
                    string = string.replace(/{{parentPropertyName}}/g, selector.replace(',', '').replace(/"/g, '') + '>' + this.toInitCap(complexDirective.propertyName))
                    csFile = csFile.replace(collectionParent, string);
                    fs.writeFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + complexDirective.baseClass.trim() + '.cs', csFile);
                    return;
                }
                var parentValue = csFile.match(/protected override string ParentPropertyName.*/g);
                parentValue = parentValue[0].match(/".*"/g);
                var startVal = '';
                if (!(parentValue[0].startsWith('"e-') || parentValue[0].startsWith('"ejs-'))) {
                    startVal = value[0].match(/"(.*?)"/g)[0].replace(',', '') + '>';
                }
                var lastval = startVal + parentValue[0] + ',' + selector.replace(',', '') + '>' + this.toInitCap(complexDirective.propertyName);
                csFile = csFile.replace(parentValue[0], '"' + lastval.replace(/"/g, '') + '"');
                fs.writeFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + complexDirective.baseClass.trim() + '.cs', csFile);
            }
        } else {
            fs.writeFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + complexDirective.baseClass.trim() + '.cs', comtag);
        }
    }
    /* jshint ignore:end */

    getRestrictChilds(comp, result) {
        var _this = this;
        if (comp.tagDirective && comp.tagDirective.length) {
            comp.tagDirective.forEach(function (curComp) {
                if (!curComp.isBlazorOnly) {
                    result.push(_this.getTagSelector(comp, curComp).collectionTagName);
                }
            });
        }
        if (comp.complexDirective && comp.complexDirective.length) {
            comp.complexDirective.forEach(function (curComp) {
                if (!curComp.isBlazorOnly) {
                    result.push(_this.getTagSelector(comp, curComp, true).complexTagName);
                }
            });
        }
    }

    generateComponent(cnt, propList, comp, json, options) {
        var element = 'ejs-' + comp.baseClass.toLowerCase();
        options.parentTagName = element;
        var tagName = comp.preferredTag ? comp.preferredTag : 'div';
        var namespace = 'ejs.' + ((json.name).replace(/\-/g, '')).toLowerCase();
        var className = comp.baseClass;
        var restrictedChild = [];
        var enums = options.enums;
        var returnvalue = this.getAllpropertiesFromClass(
            propList[comp.baseClass],
            comp, {
            enums: enums
        }
        );
        if (comp.type === 'container' || comp.aspContentTemplate) {
            returnvalue = returnvalue +
                `        /// <summary> 
        /// To get or set value for ContentTemplate.  
        /// </summary>
        [JsonIgnore]
        [Browsable(false)]

        public MvcTemplate<object> ContentTemplate { get; set; } = new MvcTemplate<object>();`;
            if (restrictedChild.indexOf('e-content-template') === -1) {
                restrictedChild.push('e-content-template');
            }
        }
        this.getRestrictChilds(comp, restrictedChild);
        if (propList[comp.baseClass]._allProperties.indexOf('dataSource') !== -1) {
            if (restrictedChild.indexOf('e-data-manager') === -1) {
                restrictedChild.push('e-data-manager');
            }

        }
        var restChild = this.getRestrictChild(restrictedChild);
        this.tClass = comp.isTModel === true ? 'where T : class' : '';
        this.tModelObj = comp.isTModel === true ? '<Object>' : '';
        cnt = cnt.replace(/{{elementName}}/g, element);
        cnt = cnt.replace(/{{RestrictChildren}}/g, restChild);
        cnt = cnt.replace(/{{tModel}}/g, (comp.isTModel === true ? '<T>' : ''));
        cnt = cnt.replace(/{{className}}/g, className);
        cnt = cnt.replace(/{{tagName}}/g, tagName);
        cnt = cnt.replace(/{{isFor}}/g, (tagName === 'input' || tagName === 'textarea'));
        cnt = cnt.replace(/{{nameSpace}}/g, namespace);
        cnt = cnt.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
        returnvalue = this.generateForControlExtension(tagName, comp, className, returnvalue, propList);
        cnt = cnt.replace(/{{properties}}/g, returnvalue);
        return cnt;
    }

    generateForControlExtension(tagName, comp, className, returnvalue, propList) {
        if (tagName === 'input' || tagName === 'textarea') {
            var isfor = `\n        #if !EJ2_DNX
        [HtmlAttributeName("ejs-for")]
        public override ModelExpression For { get; set; }
        #endif`;
            returnvalue = returnvalue.concat(isfor);
            var compProperties = propList[className];
            var forControl = fs.readFileSync(__dirname + '/' + 'for.template').toString();
            shelljs.mkdir('-p', './third-party/asp-core/src/' + comp.baseClass);
            forControl = forControl.replace(/{{BaseClass}}/g, this.namespaceCheck(pack.name));
            forControl = forControl.replace(/{{className}}/g, className);
            forControl = forControl.replace(/{{tModelObj}}/g, this.tModelObj);
            if (comp.preferredTag === 'textarea') {
                forControl = forControl.replace(/TextBoxFor/g, 'TextAreaFor');
                forControl = forControl.replace(/InputExtensions/g, 'TextAreaExtensions');
            }
            if (className === 'RadioButton') {
                forControl = forControl.replace(/completeBuilder.ID.*/g, 'completeBuilder.ID = id + Guid.NewGuid().ToString();');
            }
            if (compProperties.htmlAttribute) {
                var obj = 'Dictionary<string, object> HtmlAttr = ForControl.GetHtmlAttributes((IDictionary<string,' +
                    'object>)model.HtmlAttributes, new RouteValueDictionary(objHtmlAttr), htmlAttributes);\n' +
                    '            if (HtmlAttr.ContainsKey("id")) id = HtmlAttr["id"].ToString();';
                var htmlBuilder = ` if (HtmlAttr.Count != 0) completeBuilder.HtmlAttributes(HtmlAttr);`;
                var htmlAttrVal = `if (HtmlAttr.ContainsKey("value")) val = HtmlAttr["value"].ToString();`;
                forControl = forControl.replace(/{{htmlAttrID}}/g, obj);
                forControl = forControl.replace(/{{htmlAttrBuilder}}/g, htmlBuilder);
                forControl = forControl.replace(/{{htmlAttrVal}}/g, htmlAttrVal);
            } else {
                forControl = forControl.replace(/{{htmlAttrID}}/g, '');
                forControl = forControl.replace(/{{htmlAttrBuilder}}/g, '');
                forControl = forControl.replace(/{{htmlAttrVal}}/g, '');
            }
            var type, valType, forProps = '', valProp = '',
                value = `if (val != null)
            {
               {{forProps}} 
            }`;
            if (className === 'RadioButton') {
                value = `if(objHtmlAttr != null) {  
                {{forProps}}
            }`;
                forProps += `completeBuilder.Value(objHtmlAttr.ToString()); 
            }
            else {
                completeBuilder.Value(val.ToString());`;
            } else {
                if (compProperties.checked) {
                    type = this.getPropertyType(compProperties.checked.obj);
                    if (type === 'boolean' || type === 'bool') {
                        valType = '(Boolean)val';
                    }
                    if (type === 'boolean' || type === 'bool') {
                        forProps = `completeBuilder.Checked(${valType});\n               `;
                    }
                }
                if (compProperties.value) {
                    type = this.getPropertyType(compProperties.value.obj);
                    if (className === 'CheckBox' || className === 'Switch') {
                        valType = '"true"';
                        valProp = `completeBuilder.Value(${valType});`;
                    } else if (type === 'string') {
                        valType = 'val.ToString()';
                    } else if (type === 'double') {
                        valType = 'Convert.ToDouble(val.ToString())';
                    } else if (type === 'string[]') {
                        valType = 'new [] { val }';
                    } else if (type === 'object[]') {
                        valType = 'new object[] { val }';
                    } else {
                        valType = '(object)val';
                    }
                    if (className !== 'CheckBox' && className !== 'Switch') {
                        forProps += `completeBuilder.Value(${valType});`;
                    }
                }
            }
            forProps = forProps.length ? value.replace(/{{forProps}}/g, forProps) : '';
            if (className === 'RadioButton') {
                var condition = `bool isChecked = objHtmlAttr.GetType() == typeof(string) ? (string)val == (string)objHtmlAttr : (bool)val == (bool)objHtmlAttr;`;
                var check = `if (HtmlAttr.ContainsKey("checked") || isChecked)
            {
                    completeBuilder.Checked(true);
            }`;
                forProps = condition + '\n' + '\n            ' + check + '\n            ' + forProps;
            }
            forControl = forControl.replace(/{{updateModelValue}}/g, forProps);
            forControl = forControl.replace(/{{valProps}}/g, valProp);
            forControl = forControl.replace(/{{modelID}}/g, className === 'RadioButton' ? '+ Guid.NewGuid().ToString()' : '');
            fs.writeFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + comp.baseClass.trim() + 'ForExtension.cs',
                forControl);
        }
        return returnvalue;
    }

    generateComplexBuilder(comtag, comp, parent, complexDirective, propList, options) {
        var complexClassName; var baseClassName; var fileName;
        if (comp.removeDuplicateClassName) {
            baseClassName = this.toInitCap(complexDirective.directiveClassName || complexDirective.baseClass);
            complexClassName = complexDirective.aspClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName);
            fileName = (complexDirective.baseClass.includes(comp.baseClass) ? complexDirective.baseClass.trim() : comp.baseClass + complexDirective.baseClass.trim());
            comtag = comtag.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
            comtag = comtag.replace(/{{complexClassName}}/g, (complexDirective.aspBuilderName || complexClassName));
        } else {
            complexClassName = (complexDirective.aspClassName || comp.baseClass +
                this.toInitCap(complexDirective.directiveClassName || complexDirective.baseClass));
            comtag = comtag.replace(/{{complexClassName}}/g, (complexDirective.aspBuilderName || complexDirective.aspClassName ||
                comp.baseClass + this.toInitCap(complexDirective.directiveClassName || complexDirective.baseClass)));
        }
        comtag = comtag.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
        comtag = comtag.replace(/{{builderClassName}}/g, complexClassName + 'Builder' + (complexDirective.isTModel === true ? '<T>' : ''));
        comtag = comtag.replace(/{{className}}/g, complexClassName);
        comtag = comtag.replace(/{{tModel}}/g, (complexDirective.isTModel === true ? '<T>' : ''));
        comtag = comtag.replace(/{{tClass}}/g, this.tClass);
        var prop = this.generateComplexBuilderProperties(comp, complexDirective, propList, options);
        if (prop.indexOf('TemplateCollections') !== -1 && comp.type === 'container') {
            comtag = comtag.replace(/{{templateCollections}}/g, 'List<object> ' + comp.baseClass.toLowerCase() +
                'TemplateCollections = new List<object>();');
        } else {
            comtag = comtag.replace(/{{templateCollections}}/g, '');
        }
        comtag = comtag.replace(/{{properties}}/g, prop);
        var filePath;
        if (comp.removeDuplicateClassName) {
            filePath = './third-party/asp-core/src/' + comp.baseClass + '/' + fileName + 'Builder.cs';
        }
        else {
            filePath = './third-party/asp-core/src/' + comp.baseClass + '/' + comp.baseClass +
                complexDirective.baseClass.trim() + 'Builder.cs';
        }
        if (fs.existsSync(filePath)) {
            var builderFile = fs.readFileSync(filePath, 'utf8');
            var value = builderFile.match(/\/\/complexbuilder/g);
            if (value && value.length) {
                var cDirTModel = (complexDirective.isTModel === true ? '<T>' : '');
                var complexstring = `\n        public {{complexClassName}}Builder` + cDirTModel + `({{complexClassName}} model)
        {
                this.model = model;
        } \n`;
                if (comp.removeDuplicateClassName) {
                    complexClassName = baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName;
                    complexstring = complexstring.replace(/{{complexClassName}}/g, complexClassName);
                } else {
                    complexstring = complexstring.replace(/{{complexClassName}}/g, comp.baseClass +
                        this.toInitCap(complexDirective.directiveClassName || complexDirective.baseClass));
                }
                builderFile = builderFile.replace(value[0], complexstring);
                fs.writeFileSync(filePath, builderFile);
            } else {
                return;
            }
        } else {
            fs.writeFileSync(filePath, comtag);
        }
    }

    generateHelper(helper, comp) {
        var className = comp.baseClass;
        var objName = className.toLowerCase();
        if (restrictedKeys.indexOf(objName) !== -1) {
            objName = restrictedProperties[objName];
        }
        var comment = '';
        if (comp.comment) {
            comment = '\n        ///<summary>\n        ///' +
                comp.comment.join('\n').replace(/(\/|)(\*)(\/|)|(```[^`]*```)|(\n(\n| ))/g, '').split('\n').join('\n        ///') +
                '\n        ///</summary>\n        /// <exclude />';
        }
        helper = helper.replace(/{{comment}}/g, comment);
        helper = helper.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
        helper = helper.replace(/{{className}}/g, className);
        helper = helper.replace(/{{builderClassName}}/g, className + 'Builder' + (comp.isTModel && comp.isTModel === true ? '<T>' : ''));
        helper = helper.replace(/{{obj}}/g, objName);
        helper = helper.replace(/{{tModel}}/g, comp.isTModel === true ? '<T>' : '');
        helper = helper.replace(/{{tClass}}/g, comp.isTModel === true ? 'where T : class' : '');
        var tModelHelper = '';
        if (comp.isTModel && comp.isTModel === true) {
            var IDictionary = '(String id, Syncfusion.EJ2.{{namespace}}.{{className}} Model, IDictionary<string,object> htmlAttr)';
            tModelHelper = `/// <exclude />\n        public {{className}}Builder<Object> {{className}}(String id)
        {
            var {{obj}} = new {{className}}Builder<Object>();
            {{obj}}.ID = id;
            {{obj}}.Output = this.Output;
            {{obj}}.Context = this.Context;
            this.getContext();
            return {{obj}};
        }
        /// <exclude />
        public {{className}}Builder<Object> {{className}}(String id, Syncfusion.EJ2.{{namespace}}.{{className}} Model) 
        {
            var {{obj}} = new {{className}}Builder<Object>(Model);
            {{obj}}.ID = id;
            {{obj}}.Output = this.Output;
            {{obj}}.Context = this.Context;
            this.getContext();
            return {{obj}};
        }
        /// <exclude />
        public {{className}}Builder<Object> {{className}}${IDictionary}
        {
            var {{obj}} = new {{className}}Builder<Object>(Model);
            {{obj}}.ID = id;
            var attrID = EJSUtil.GetHtmlId(htmlAttr as Dictionary<string, object>);
            if (attrID != null)
            {
                {{obj}}.model.Id = {{obj}}.ID = attrID;
            }
            else
            {
                {{obj}}.model.Id = {{obj}}.ID = id;
            }
            {{obj}}.model.GetType().GetProperty("HtmlAttributes").SetValue({{obj}}.model, htmlAttr, null);
            {{obj}}.Output = this.Output;
            {{obj}}.Context = this.Context;
            this.getContext();  
            return  {{obj}};
        }`;
            tModelHelper = tModelHelper.replace(/{{className}}/g, className);
            tModelHelper = tModelHelper.replace(/{{obj}}/g, objName);
            tModelHelper = tModelHelper.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
        }
        helper = helper.replace(/{{tModelHelper}}/g, tModelHelper);
        return helper;
    }

    generateEnum(enums) {
        var helper = fs.readFileSync(__dirname + '/' + 'enumurations.template').toString();
        if (enums.length) {
            var tab = '    ';
            var enumProp = '';
            var newLine = '\n';
            for (var i = 0; i < enums.length; i++) {
                var curObj = enums[i];
                var typeName = Object.keys(curObj)[0];
                if (this.propertyList[typeName]._propShortComments[typeName]) {
                    var comment = this.propertyList[typeName]._propShortComments[typeName].split('\n').join(newLine + tab);
                    enumProp = enumProp + tab + comment + newLine;
                }
                enumProp = enumProp + tab + 'public enum ' + this.toInitCap(typeName) + newLine;
                enumProp = enumProp + tab + '{' + newLine;
                for (var j = 0; j < curObj[typeName].length; j++) {
                    var value = curObj[typeName];
                    if (curObj[typeName].numberEnum && curObj[typeName].numberEnum.length) {
                        var quotes = curObj[typeName].numberEnum.length - 1 === j ? '' : ',';
                        if (curObj[typeName].numberEnum[j].replace(/\W/g, '') === 'null') {
                            enumProp = enumProp + tab + tab + value[j] + quotes + newLine;
                        } else {
                            var numEnumComment = curObj[typeName].numComments ? ('\n' + tab + tab + '/// <summary>\n' + tab + tab + '/// ' +
                                curObj[typeName].numComments[curObj[typeName].numberEnum[j]].replace(/\n/g, '\n' + tab + '/// ') +
                                '\n' + tab + tab + '/// </summary>\n' + tab + tab + '') : '';
                            enumProp = enumProp + numEnumComment + value[j] + ' = ' + curObj[typeName].numberEnum[j] + quotes + newLine;
                        }
                    } else {
                        var typeComment = value.propComments ? ('\n        /// <summary>\n        /// ' +
                            value.propComments[value[j]].replace(/\n/g, '\n        /// ') +
                            '\n        /// </summary>\n        ') : '';
                        enumProp = enumProp + tab + tab + typeComment + '[EnumMember(Value ="' + value[j] + '")]' + newLine;
                        enumProp = enumProp + tab + tab + this.toInitCap(value[j].replace(/\s/g, '')) + ',' + newLine;
                    }
                }
                enumProp = enumProp + tab + '}' + newLine + newLine;
            }
            var packName = this.namespaceCheck(pack.name);
            shelljs.mkdir('-p', './third-party/asp-core/src/Enumuration/' + packName);
            helper = helper.replace(/{{namespace}}/g, this.toInitCap(packName));
            helper = helper.replace(/{{enumurations}}/g, enumProp);
            fs.writeFileSync('./third-party/asp-core/src/Enumuration/' + packName + '/' + packName.trim() + 'Enumurations.cs', helper);
        }

    }
    /* jshint ignore:start */
    // here we have used options parameter

    generateCollectionTag(helper, comp, parent, tagDirective, options, propList, isComplexColllection) {
        var restrictedChild = []; var baseClassName;
        var tag = this.getTagSelector(parent, tagDirective, isComplexColllection);
        helper = helper.replace(/{{complexTagName}}/g, tag.complexTagName);
        helper = helper.replace(/{{collectionTagName}}/g, tag.collectionTagName);
        if (comp.removeDuplicateClassName) {
            baseClassName = this.toInitCap(tagDirective.directiveClassName || tagDirective.baseClass);
            var complexClassName = tagDirective.aspArrayClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName);
            helper = helper.replace(/{{complexClassName}}/g, (complexClassName));
            helper = helper.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
            helper = helper.replace(/{{namespace}}/g, comp.baseClass);
            baseClassName = this.toInitCap(tagDirective.arrayDirectiveClassName || tagDirective.baseClass + 's');
            complexClassName = tagDirective.aspCollectionClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName);
            helper = helper.replace(/{{collectionClassName}}/g, complexClassName);
        } else {
            helper = helper.replace(/{{complexClassName}}/g, (tagDirective.aspArrayClassName || comp.baseClass +
                this.toInitCap(tagDirective.directiveClassName || tagDirective.baseClass)));
            helper = helper.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
            helper = helper.replace(/{{namespace}}/g, comp.baseClass);
            helper = helper.replace(/{{collectionClassName}}/g, tagDirective.aspCollectionClassName || comp.baseClass +
                this.toInitCap(tagDirective.arrayDirectiveClassName || tagDirective.baseClass + 's'));
        }
        helper = helper.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
        helper = helper.replace(/{{namespace}}/g, comp.baseClass);
        helper = helper.replace(/{{collectionClassName}}/g, tagDirective.aspCollectionClassName || comp.baseClass +
            this.toInitCap(tagDirective.arrayDirectiveClassName || tagDirective.baseClass + 's'));
        helper = helper.replace(/{{parentPropertyName}}/g, tag.collectionTagName + '>' +
            this.toInitCap(tagDirective.propertyName));
        if (tagDirective.removeParent) {
            helper = helper.replace(/, ParentTag = "{{parentTagName}}"/g, '');
        } else {
            helper = helper.replace(/{{parentTagName}}/g, options.parentTagName);
        }
        var colProp = this.getCollectionClassProperties(
            comp, parent, tagDirective, {
            restrictedChild: restrictedChild,
            enums: options.enums
        },
            propList);
        if (comp.type === 'container') {
            colProp +=
                `\n        /// <summary> 
        /// To get or set value for ContentTemplate.  
        /// </summary>
        [JsonIgnore]
        [Browsable(false)]
    
        public MvcTemplate<object> ContentTemplate { get; set; } = new MvcTemplate<object>();`;
        }
        if (restrictedChild.indexOf('e-content-template') === -1) {
            restrictedChild.push('e-content-template');
        }
        helper = helper.replace(
            /{{properties}}/g, colProp
        );
        this.getRestrictChilds(tagDirective, restrictedChild);
        var restChild = this.getRestrictChild(restrictedChild);
        helper = helper.replace(/{{RestrictChildren}}/g, restChild);
        if (fs.existsSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + tagDirective.baseClass.trim() + '.cs')) {
            var csFile = fs.readFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + tagDirective.baseClass.trim() + '.cs', 'utf8');
            var value = csFile.match(/\[HtmlTargetElement.*]/g);
            var createClass = csFile.match(/namespace.*\r\n{/g) || csFile.match(/namespace.*\n{/g);
            var customClassName = tagDirective.aspCollectionClassName || tagDirective.aspArrayClassName || this.toInitCap(tagDirective.propertyName) + this.toInitCap(parent.propertyName);
            var temp = `[HtmlTargetElement("{{Selector}}", ParentTag = "{{collectionTagName}}"){{RestrictChildren}}]`
            temp = temp.replace(/{{collectionTagName}}/g, tag.collectionTagName);
            temp = temp.replace(/{{Selector}}/g, tag.complexTagName);
            temp = temp.replace(/{{RestrictChildren}}/g, restChild);
            if (csFile.indexOf(temp) === -1) {

                if (comp.removeDuplicateClassName) {
                    baseClassName = this.toInitCap(tagDirective.directiveClassName || tagDirective.propertyName);
                    temp = temp + '\n' + `        public partial class ${customClassName} : ${baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName}
                {
                }` + '\n';
                } else {
                    temp = temp + '\n' + `        public partial class ${customClassName} : ${comp.baseClass}${this.toInitCap(tagDirective.directiveClassName || tagDirective.propertyName)}
            {
            }` + '\n';
                }
                temp = temp + `[HtmlTargetElement("{{collectionTagName}}", ParentTag = "{{parentTagName}}")]
                public partial class {{collectionClassName}} : EJTagHelper
                {
                    protected override bool IsCollection { get { return true; } }
            
                    protected override object GetList() {
            
                        return new List<{{complexClassName}}>();
                    }
            
                    protected override string ParentPropertyName { get { return "{{parentPropertyName}}"; } }
            
                }`;
                temp = temp.replace(/{{parentPropertyName}}/g, tag.collectionTagName + '>' +
                    this.toInitCap(tagDirective.propertyName));
                temp = temp.replace(/{{parentTagName}}/g, options.parentTagName);
                temp = temp.replace(/{{collectionClassName}}/g, customClassName + 'Extends');
                if (comp.removeDuplicateClassName) {
                    var baseClassName = this.toInitCap(tagDirective.directiveClassName || tagDirective.baseClass);
                    temp = temp.replace(/{{complexClassName}}/g, (tagDirective.aspArrayClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName)));
                } else {
                    temp = temp.replace(/{{complexClassName}}/g, (tagDirective.aspArrayClassName ||
                        comp.baseClass + this.toInitCap(tagDirective.directiveClassName || tagDirective.baseClass)));
                }
                temp = temp.replace(/{{complexClassName}}/g, (tagDirective.aspArrayClassName ||
                    comp.baseClass + this.toInitCap(tagDirective.directiveClassName || tagDirective.baseClass)));
                temp = temp.replace(/{{collectionTagName}}/g, tag.collectionTagName);
                csFile = csFile.replace(createClass[0], createClass[0] + '\n    ' + temp);
                fs.writeFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + tagDirective.baseClass.trim() + '.cs', csFile);
            }
            return;
        }
        fs.writeFileSync('./third-party/asp-core/src/' + '/' + comp.baseClass + '/' + tagDirective.baseClass.trim() + '.cs', helper);
    }


    generateCollectionBuilder(comp, propList, parentObj, currentTagDirective, options) {
        var builder = fs.readFileSync(__dirname + '/' + 'collectionbuilder.template').toString();
        if (comp.removeDuplicateClassName) {
            var baseClassName = this.toInitCap(currentTagDirective.directiveClassName || currentTagDirective.baseClass);
            var className = currentTagDirective.aspArrayClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName);
            var fileName = (currentTagDirective.baseClass.includes(comp.baseClass) ? currentTagDirective.baseClass.trim() : comp.baseClass + currentTagDirective.baseClass.trim());
        } else {
            var className = (currentTagDirective.aspArrayClassName || comp.baseClass + this.toInitCap(currentTagDirective.directiveClassName ||
                currentTagDirective.baseClass));
        }
        var returnvalue = this.generateBuilderProperties(comp, currentTagDirective, propList, options);
        if (returnvalue.indexOf('TemplateCollections') !== -1 && comp.type === 'container') {
            builder = builder.replace(/{{templateCollections}}/g, 'List<object> ' + comp.baseClass.toLowerCase() +
                'TemplateCollections = new List<object>();');
        }
        else {
            builder = builder.replace(/{{templateCollections}}/g, '');
        }
        builder = builder.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
        builder = builder.replace(/{{tModel}}/g, (currentTagDirective.isTModel === true ? '<T>' : ''));
        builder = builder.replace(/{{tClass}}/g, this.tClass);
        builder = builder.replace(/{{className}}/g, className);
        builder = builder.replace(/{{aspBuildName}}/g, (currentTagDirective.aspBuilderName || className));
        builder = builder.replace(/{{builderClassName}}/g, className + 'Builder' + (currentTagDirective.isTModel === true ? '<T>' : ''));
        builder = builder.replace(/{{namespaceName}}/g, comp.baseClass);
        builder = builder.replace(/{{builderProperties}}/g, returnvalue);
        var filePath;
        if (comp.removeDuplicateClassName) {
            filePath = './third-party/asp-core/src/' + comp.baseClass + '/' + fileName + 'Builder.cs';
        } else {
            filePath = './third-party/asp-core/src/' + comp.baseClass + '/' + comp.baseClass +
                currentTagDirective.baseClass.trim() + 'Builder.cs';
        }
        if (fs.existsSync(filePath)) {
            var builderFile = fs.readFileSync(filePath, 'utf8');
            var value = builderFile.match(/\/\/collectionbuilder/g);
            if (value && value.length) {
                var complexstring = `\n        List<{{aspBuildName}}> collection = new List<{{aspBuildName}}>();
        public {{className}}Builder(List<{{aspBuildName}}> collection)
        {
            this.collection = collection;
        } \n
        public void Add()
        {
            collection.Add(model);
            model = new {{className}}();
        }`
                complexstring = complexstring.replace(/{{className}}/g, className);
                complexstring = complexstring.replace(/{{aspBuildName}}/g, (currentTagDirective.aspBuilderName || className));
                builderFile = builderFile.replace(value[0], complexstring);
                fs.writeFileSync('./third-party/asp-core/src/' + comp.baseClass + '/' + comp.baseClass +
                    currentTagDirective.baseClass.trim() + 'Builder.cs', builderFile);
            } else {
                var createClass = builderFile.match(/namespace.*\r\n{/g) || builderFile.match(/namespace.*\n{/g);
                var temp = `    public partial class {{builderClassName}} : ControlBuilder {{tClass}}`
                temp = temp.replace(/{{tModel}}/g, (currentTagDirective.isTModel === true ? '<T>' : ''));
                temp = temp.replace(/{{tClass}}/g, this.tClass);
                temp = temp.replace(/{{builderClassName}}/g, className + 'Builder' + (currentTagDirective.isTModel === true ? '<T>' : ''));
                if (builderFile.indexOf(temp) === -1) {
                    temp = temp + '\n' + `        {
        List<{{aspBuildName}}> collection = new List<{{aspBuildName}}>();
        {{aspBuildName}} model = new {{aspBuildName}}();       
        public {{className}}Builder()
        {
        }        
        public {{className}}Builder(List<{{aspBuildName}}> collection)
        {
            this.collection = collection;
        }
        //complexbuilder
        {{builderProperties}}
        public void Add()
        {
            collection.Add(model);
            model = new {{className}}();
        }        
        }`;
                    temp = temp.replace(/{{className}}/g, className);
                    temp = temp.replace(/{{aspBuildName}}/g, (currentTagDirective.aspBuilderName || className));
                    temp = temp.replace(/{{builderProperties}}/g, returnvalue);
                    builderFile = builderFile.replace(createClass[0], createClass[0] + '\n    ' + temp);
                    fs.writeFileSync(filePath, builderFile);
                } else {
                    return;
                }
            }
        } else {
            fs.writeFileSync(filePath, builder);
        }
    }


    generateBuilderProperties(comp, tagDirective, propList, options) {
        var curClassName; var baseClassName;
        var curInterface1 = this.interfaces[tagDirective.baseClass + 'Model'];
        var isModT = false;
        isModT = tagDirective.isTModel ? true : isModT;
        var builderPropType, content = '';
        if (curInterface1) {
            var innerProperties = curInterface1.children || [];
            for (var i = 0; i < innerProperties.length; i++) {
                var curBuilderProperty = innerProperties[i];
                var builderPropTypes = [];
                if (this.isExported(curBuilderProperty)) {
                    builderPropTypes.push(this.getPropertyType(curBuilderProperty, comp, undefined, tagDirective));
                    builderPropTypes = this.getNestedTypes(comp, builderPropTypes, curBuilderProperty, tagDirective, options);
                    var flag = true;
                    for (var k = 0; k < builderPropTypes.length; k++) {
                        builderPropType = builderPropTypes[k];
                        if (comp.removeDuplicateClassName) {
                            baseClassName = this.toInitCap(tagDirective.directiveClassName || tagDirective.baseClass);
                            curClassName = tagDirective.aspArrayClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName);
                        } else {
                            curClassName = (tagDirective.aspArrayClassName || comp.baseClass +
                                this.toInitCap(tagDirective.directiveClassName || tagDirective.baseClass));
                        }
                        var propName = curBuilderProperty.name;
                        if (restrictedKeys.indexOf(propName) !== -1) {
                            propName = restrictedProperties[propName];
                        }
                        var cusPropName = propName;
                        if (builderPropTypes[0] === 'string' && builderPropType !== builderPropTypes[0]) {
                            cusPropName += '.ToString()';
                        }
                        var comment = this.getComments(propList, tagDirective, curBuilderProperty);
                        var ignoreCollectionProperty = curBuilderProperty.comment && curBuilderProperty.comment.tags &&
                            curBuilderProperty.comment.tags.filter(function (v) {
                                return v.tag === 'aspignore';
                            });
                        if (!(ignoreCollectionProperty && ignoreCollectionProperty.length)) {
                            content = content + '        ' + comment + '        public ' + curClassName + 'Builder' + (tagDirective.isTModel === true ? '<T> ' : ' ') +
                                this.toInitCap(propName) + '(' + builderPropType + ' ' +
                                propName + ')\n' +
                                '        {\n' +
                                '            model.' + this.toInitCap(curBuilderProperty.name) + ' = ' + cusPropName + ';\n' +
                                '            return this;\n' +
                                '        }\n\n';
                        }
                        if (!comp.aspIgnoreDefaultDataSource && curBuilderProperty.name === 'dataSource') {
                            content = content +
                                '        public ' + curClassName + 'Builder' + (tagDirective.isTModel === true ? '<T>' : '') + ' DataSource(Action<DataManagerBuilder> dataSource)\n' +
                                '        {\n' +
                                '           var resultObject = new DataManager();\n' +
                                '           model.DataSource = resultObject;\n' +
                                '           var builder = new DataManagerBuilder(resultObject);\n' +
                                '           if (dataSource != null)\n' +
                                '               {\n' +
                                '                   dataSource.Invoke(builder);\n' +
                                '               }\n' +
                                '           return this;\n' +
                                '        }\n\n';
                        }
                        if (flag) {
                            var getBuilder = tagDirective.tagDirective && tagDirective.tagDirective.length &&
                                tagDirective.tagDirective.filter(function (v) {
                                    return v.propertyName === propName;
                                });
                            var getComplexBuilder = tagDirective.complexDirective && tagDirective.complexDirective.length &&
                                tagDirective.complexDirective.filter(function (v) {
                                    return v.propertyName === propName;
                                });
                            content = this.generateNestedBuilder(content, getBuilder, getComplexBuilder, comp, curBuilderProperty.name, curClassName, isModT);
                            if (comp.aspTModelProperties && comp.aspTModelProperties.length &&
                                comp.aspTModelProperties.indexOf(propName) !== -1) {
                                content = content + '        ' + comment + '        public ' + curClassName + 'Builder' + (tagDirective.isTModel === true ? '<T> ' : ' ') +
                                    this.toInitCap(propName) + '<TProperty>(Expression<Func<T, TProperty>> ' +
                                    propName + ')\n' +
                                    '        {\n' +
                                    '            string fieldName = "";\n' +
                                    '            MemberExpression member = ' + propName + '.Body as MemberExpression;\n' +
                                    '            if (member != null && member.Expression.NodeType != ExpressionType.MemberAccess)\n' +
                                    '                {\n' +
                                    '                   fieldName = member.Member.Name;\n' +
                                    '                }\n' +
                                    '            model.' + this.toInitCap(curBuilderProperty.name) + ' = fieldName;\n' +
                                    '            return this;\n' +
                                    '        }\n\n';
                            }
                            flag = false;
                        }
                    }
                }
            }
        }
        if (comp.type === 'container' || comp.aspContentTemplate) {
            var bPropT = (comp.isTModel === true ? '<T> ' : ' ');
            content += `       public ` + curClassName + `Builder` + bPropT + `ContentTemplate(Func<object, object> template)
        {
            this.model.ContentTemplate.RazorViewTemplate = template;
            return this;
        }\n\n       public ` + curClassName + `Builder` + bPropT + `ContentTemplate(Action<object> template)
        {
            this.model.ContentTemplate.ActionTemplate = template;
            return this;
        }`;
        }
        return content;
    }

    generateComplexBuilderProperties(comp, tagDirective, propList, options) {
        var baseClassName; var curClassName;
        var complexCurInterface = this.interfaces[tagDirective.baseClass + 'Model'];
        var isModT = false;
        isModT = tagDirective.isTModel ? true : isModT;
        var builderPropType, content = '';
        if (complexCurInterface) {
            var innerProperties = complexCurInterface.children;
            for (var i = 0; i < innerProperties.length; i++) {
                var curProperty = innerProperties[i];
                var builderPropTypes = [];
                if (this.isExported(curProperty)) {
                    builderPropTypes.push(this.getPropertyType(curProperty, comp, undefined, tagDirective));
                    builderPropTypes = this.getNestedTypes(comp, builderPropTypes, curProperty, tagDirective, options);
                    var flag = true;
                    for (var k = 0; k < builderPropTypes.length; k++) {
                        builderPropType = builderPropTypes[k];
                        if (comp.removeDuplicateClassName) {
                            baseClassName = this.toInitCap(tagDirective.directiveClassName || tagDirective.baseClass);
                            curClassName = tagDirective.aspClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName);
                        } else {
                            curClassName = (tagDirective.aspClassName || comp.baseClass +
                                this.toInitCap(tagDirective.directiveClassName || tagDirective.baseClass));
                        }
                        var propName = curProperty.name;
                        if (restrictedKeys.indexOf(curProperty.name) !== -1) {
                            propName = restrictedProperties[curProperty.name];
                        }
                        var cusPropName = 'value';
                        if (builderPropTypes[0] === 'string' && builderPropType !== builderPropTypes[0]) {
                            cusPropName += '.ToString()';
                        }
                        var comment = this.getComments(propList, tagDirective, curProperty);
                        var ignoreComplexProperty = curProperty.comment && curProperty.comment.tags &&
                            curProperty.comment.tags.filter(function (v) {
                                return v.tag === 'aspignore';
                            });
                        if (!(ignoreComplexProperty && ignoreComplexProperty.length)) {
                            content = content + '        ' + comment + '        public ' + curClassName + 'Builder' + (tagDirective.isTModel === true ? '<T> ' : ' ') +
                                this.toInitCap(curProperty.name) + '(' + builderPropType + ' ' +
                                'value' + ')\n' +
                                '        {\n' +
                                '            model.' + this.toInitCap(curProperty.name) + ' = ' + cusPropName + ';\n' +
                                '            return this;\n' +
                                '        }\n\n';
                        }
                        if (flag) {
                            var getComplexBuilder = tagDirective.complexDirective && tagDirective.complexDirective.length &&
                                tagDirective.complexDirective.filter(function (v) {
                                    return v.propertyName === propName;
                                });
                            var getBuilder = tagDirective.tagDirective && tagDirective.tagDirective.length &&
                                tagDirective.tagDirective.filter(function (v) {
                                    return v.propertyName === propName;
                                });
                            if (!tagDirective.ignoreTagDirective) {
                                content = this.generateNestedBuilder(content, getBuilder, getComplexBuilder, comp, curProperty.name, curClassName, isModT);
                            }
                            if (!comp.aspIgnoreDefaultDataSource && curProperty.name === 'dataSource') {
                                content = content +
                                    '        public ' + curClassName + 'Builder' + (tagDirective.isTModel ? '<T>' : '') + ' DataSource(Action<DataManagerBuilder> dataSource)\n' +
                                    '        {\n' +
                                    '           var resultObject = new DataManager();\n' +
                                    '           model.DataSource = resultObject;\n' +
                                    '           var builder = new DataManagerBuilder(resultObject);\n' +
                                    '           if (dataSource != null)\n' +
                                    '               {\n' +
                                    '                   dataSource.Invoke(builder);\n' +
                                    '               }\n' +
                                    '           return this;\n' +
                                    '        }\n\n';
                            }
                            flag = false;
                        }
                    }
                }
            }
        }
        return content;
    }

    /* jshint ignore:end */

    getNestedTypes(comp, builderPropTypes, curBuilderProperty, tagDirective, options) {
        var builderPropType;
        if ((builderIgnoreTypes.indexOf(builderPropTypes[0]) === -1 || builderPropTypes[0] === 'string') && curBuilderProperty.type &&
            curBuilderProperty.type.types) {
            var propType = curBuilderProperty.type.types;
            for (var j = 0; j < propType.length; j++) {
                builderPropType = this.getPropertyType(curBuilderProperty, comp, undefined, tagDirective, true, propType[j]);
                if (this.isStringLitrals(propType[j], true) || this.isEnumType(propType[j], true)) {
                    if (this.propertyList.enumAliases && !(this.propertyList.typeAliases[propType[j].type.name])) {
                        this.addEnums(this.propertyList.enumAliases[propType[j].type.name], comp, undefined, options.enums);
                    } else {
                        this.addEnums(this.propertyList.typeAliases[propType[j].type.name], comp, undefined, options.enums);
                    }
                }
                if (builderPropTypes[0] === 'string' && builderPropTypes.indexOf(builderPropType) === -1 &&
                    builderIgnoreTypes.indexOf(builderPropType) !== -1) {
                    builderPropTypes.push(builderPropType);
                } else if (builderPropTypes[0] === 'object' && builderPropTypes.indexOf(builderPropType) === -1) {
                    builderPropTypes.push(builderPropType);
                }
            }
        }
        return builderPropTypes;
    }

    getRestrictChild(restrictedChild) {
        var rest = '';
        if (restrictedChild.length) {
            if (restrictedChild.length > 1) {
                rest = ', RestrictChildren("' + restrictedChild.splice(0, 1).toString() +
                    '", new string[] {"' + restrictedChild.join('","') + '"})';
            } else if (restrictedChild.length) {
                rest = ', RestrictChildren("' + restrictedChild.toString() + '")';
            }
        }
        return rest;
    }

    getCollectionClassProperties(comp, parent, tagDirective, options, propList) {
        var curInterface = this.interfaces[tagDirective.baseClass + 'Model'];
        var content = '';
        if (curInterface) {
            var innerProperties = curInterface.children || [];
            for (var j = 0; j < innerProperties.length; j++) {
                var curProperty = innerProperties[j];
                if (this.isExported(curProperty)) {
                    content = content + this.createPropertySyntax(curProperty, comp, parent, tagDirective, options,
                        propList[tagDirective.baseClass]._propShortComments);
                    if (curProperty.name === 'dataSource' && options.restrictedChild) {
                        options.restrictedChild.push('e-data-manager');
                    }
                }
            }
        }
	if(tagDirective.baseClass.trim() === "AggregateColumn" && comp.baseClass.trim() == "Grid"){
	    content += `
	/// <summary>
	/// Defines the aggregate type of a particular column.
	/// To use multiple aggregates for single column, specify the \`types\` as array.
	/// Types of aggregate are,
	/// sum
	/// average
	/// max
	/// min
	/// count
	/// truecount
	/// falsecount
	/// custom
	/// > Specify the \`types\` value as \`custom\` to use custom aggregation.
	/// </summary>
	/// <value>
	/// The default value is null
	/// </value>
	
	[DefaultValue(null)]
	[HtmlAttributeName("types")]
	[JsonProperty("types")]
	public object Types { get; set; }
		`;
	    }
        return content;
    }

    createPropertySyntax(obj, comp, parent, tagDirective, options, comment) {
        var cnt = '';
        var tab = '    ';
        var newLine = '\n';
        var ignoreProperty = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
            return v.tag === 'aspignore';
        });
        if (!(ignoreProperty && ignoreProperty.length)) {
            if (comment && comment[obj.name] !== undefined) {
                if (comment[obj.name].indexOf(' & ') !== -1) {
                    comment[obj.name] = comment[obj.name].replace(' & ', ' and ');
                }
                var summary = comment[obj.name];
                var apiCodePath = summary.match(/{% codeBlock([\s\S]*?)<\/summary>/g);
                let path = apiCodePath ? apiCodePath[0].match(/src=['"]([^'"]+)['"]/) : '';
                let codeBlockPath = path ? `./api-code-blocks/aspcore/${path[1]}` : '';
                let codeBlock = fs.existsSync(codeBlockPath) ? '\n' + fs.readFileSync(codeBlockPath, 'utf-8') : '';
                codeBlock = codeBlock.replace(/\n/g, '\n/// ');
                summary = summary.replace(apiCodePath, `<code><![CDATA[${codeBlock}\n/// ]]></code>\n/// </summary>`);
                var urlPattern = comment[obj.name].match(/\/\/\/.*\[.*\]\(..\/..\/.*\).*\n/g);
                if (urlPattern) {
                    var coreSummary = comment[obj.name];
                    var mvcSummary = comment[obj.name];
                    for (var u = 0; u < urlPattern.length; u++) {
                        var coreUrl = urlPattern[u].replace(/..\/..\//g, 'https://ej2.syncfusion.com/aspnetcore/documentation/');
                        var mvcUrl = urlPattern[u].replace(/..\/..\//g, 'https://ej2.syncfusion.com/aspnetmvc/documentation/');
                        coreSummary = coreSummary.replace(urlPattern[u], coreUrl);
                        mvcSummary = mvcSummary.replace(urlPattern[u], mvcUrl);
                    }
                    summary = '#if EJ2_DNX' + newLine + mvcSummary + newLine + '#else' + newLine + coreSummary + newLine + '#endif' + newLine;
                }
                cnt += comment[obj.name] ? (tab + tab + summary.split('\n').join(newLine + tab + tab) + newLine) : cnt;
            }
            var ignoreDefaultValue = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                return v.tag === 'aspdefaultvalueignore';
            });
            var aspValueTag = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                return v.tag === 'aspvaluetag';
            });
            var numberEnum = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                return v.tag === 'aspnumberenum';
            });
            var Enumerable = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                return v.tag === 'isenumeration';
            });
            var ignoreDataSourceNull = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                return v.tag === 'aspdatasourcenullignore';
            });
            var populateDefaultValue = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                return v.tag === 'asppopulatedefaultvalue';
            });
	    var obsoleteValue = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                return v.tag === 'aspobsolete';
            });
            var ignoreJsonConverter = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                return v.tag === 'aspjsonconverterignore';
            });
            var defaultValue = this.getDefaultPropertyValue(obj, comp, options, tagDirective);
            if (aspValueTag && aspValueTag[0]) {
                cnt = cnt + tab + tab + '/// <value>' + newLine + tab + tab + '/// ' + aspValueTag[0].text + tab + tab + '/// </value>' + newLine;
            }
            else {
                cnt = cnt + tab + tab + '/// <value>' + newLine + tab + tab + '/// The default value is ' + defaultValue + newLine + tab + tab + '/// </value>' + newLine;
            }
            if (!(ignoreDefaultValue && ignoreDefaultValue.length)) {
                cnt = cnt + tab + tab + '[DefaultValue(' + defaultValue + ')]' + newLine;
            }
            cnt = cnt + tab + tab + '[HtmlAttributeName("' + obj.name + '")]' + newLine;
            if (populateDefaultValue && populateDefaultValue.length) {
                cnt = cnt + tab + tab + '[JsonProperty("' + obj.name + '", DefaultValueHandling = DefaultValueHandling.Populate)]' + newLine;
            } else {
                cnt = cnt + tab + tab + '[JsonProperty("' + obj.name + '")]' + newLine;
            }
            if (!(ignoreJsonConverter && ignoreJsonConverter.length)) {
                if (obj.kindString === 'Event') {
                    cnt = cnt + tab + tab + '[JsonConverter(typeof(EventTypeConverter))]' + newLine;
                } else if (this.isStringLitrals(obj)) {
                    cnt = cnt + tab + tab + '[JsonConverter(typeof(StringEnumConverter))]' + newLine;
                    this.addEnums(this.propertyList.typeAliases[obj.type.name], comp, cnt, options.enums);
                } else if (this.isEnumType(obj)) {
                    if (!(numberEnum && numberEnum.length)) {
                        cnt = cnt + tab + tab + '[JsonConverter(typeof(StringEnumConverter))]' + newLine;
                    }
                    this.addEnums(this.propertyList.enumAliases[obj.type.name], comp, cnt, options.enums);
                } else if (Enumerable && Enumerable.length) {
                    cnt = cnt + tab + tab + '[JsonConverter(typeof(StringEnumConverter))]' + newLine;
                } else if (obj.name === 'query') {
                    cnt = cnt + tab + tab + '[JsonConverter(typeof(QueryTypeConverter))]' + newLine;
                } else if (!comp.aspIgnoreDefaultDataSource && (obj.name === 'dataSource' || obj.name === 'fileSystemData')) {
                    if (ignoreDataSourceNull && ignoreDataSourceNull.length) {
                        cnt = cnt + tab + tab + '[JsonConverter(typeof(DataSourceIgnoreNullTypeConverter))]' + newLine;
                    } else {
                        cnt = cnt + tab + tab + '[JsonConverter(typeof(DataSourceTypeConverter))]' + newLine;
                    }
                }
            }
	    if (obsoleteValue && obsoleteValue.length) {
                cnt = cnt + tab + tab + `[ObsoleteAttribute("${obsoleteValue[0].text.split('\n')[0].trim()}")]` + newLine;
            }
            var pType = 'public ';
            if (obj.name === 'id') {
                pType = 'public override ';
            }
            if (obj.name === 'order') {
                pType = 'public new ';
            }
            if (defaultValue !== 'null' && defaultValue !== null && !(ignoreDefaultValue && ignoreDefaultValue.length)) {
                cnt = cnt + tab + tab + pType + this.getPropertyType(obj, comp, options, tagDirective) + ' ' +
                    this.toInitCap(obj.name) + ' { get; set; } = ' + defaultValue + ';' + newLine + newLine;
            } else {
                cnt = cnt + tab + tab + pType + this.getPropertyType(obj, comp, options, tagDirective) + ' ' +
                    this.toInitCap(obj.name) + ' { get; set; }' + newLine + newLine;
            }
        }
        return cnt;
    }

    addEnums(obj, comp, cnt, array) {
        var res = {};
        var values = [];
        var textValues = {};
        var numValues = [];
        var numComments = {};
        var numberEnum = obj && obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
            return v.tag === 'aspnumberenum';
        });
        if (obj.kindString === 'Enumeration') {
            for (var i = 0; i < obj.children.length; i++) {
                if (numberEnum && numberEnum.length) {
                    numValues.push(obj.children[i].defaultValue);
                    numComments[obj.children[i].defaultValue] = obj.children[i].comment.shortText;
                }
                if (obj.children[i].name) {
                    values.push(this.toInitCap(obj.children[i].name));
                    if (obj.children[i].comment) {
                        textValues[obj.children[i].name] = obj.children[i].comment.shortText;
                    }
                }
            }
        } else {
            for (var j = 0; obj.type && obj.type.types && j < obj.type.types.length; j++) {
                if (obj.type.types[j].value) {
                    values.push(this.toInitCap(obj.type.types[j].value));
                }
            }
        }
        if (values.length && !array.filter(function (ob) {
            return !!ob[obj.name];
        }).length) {
            res[obj.name] = values;
            if (Object.keys(textValues).length > 0) {
                res[obj.name].propComments = textValues;
            }
            if (numberEnum && numberEnum.length) {
                res[obj.name].numberEnum = numValues;
            }
            if (Object.keys(numComments).length > 0) {
                res[obj.name].numComments = numComments;
            }
            array.push(res);
        }
    }
    isStringLitrals(obj, isNestedType) {
        if (obj && obj.type) {
            if (isNestedType) {
                obj.type = obj;
            }
            return !!(this.propertyList.typeAliases[obj.type.name] && this.propertyList.typeAliases[obj.type.name].type &&
                this.propertyList.typeAliases[obj.type.name].type.types);
        }
    }

    isEnumType(obj, isNestedType) {
        if (obj && obj.type) {
            if (isNestedType) {
                obj.type = obj;
            }
            return this.propertyList.enumAliases[obj.type.name];
        }
    }

    getDefaultPropertyValue(obj, comp, options, tagDirective) {
        var cnt = 'null';
        var curType = this.getPropertyType(obj, comp, options, tagDirective);
        var Enumerable = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
            return v.tag === 'isenumeration';
        });
        if (handledTypesKeys.indexOf(curType) !== -1 || this.isStringLitrals(obj) || this.isEnumType(obj) ||
            (Enumerable && Enumerable.length)) {
            var cntVal = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                return v.tag === 'default';
            });
            var aspdefaultVal = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                return v.tag === 'aspdefaultvalue';
            });
            if (aspdefaultVal && aspdefaultVal[0] && aspdefaultVal[0].text && !(/undefined|null/g.test(aspdefaultVal))) {
                cntVal = aspdefaultVal;
            }
            if (cntVal && cntVal[0] && cntVal[0].text && !(/undefined|null/g.test(cntVal))) {
                cntVal = cntVal[0].text.split('\n')[0];
                if (curType === 'bool') {
                    cnt = cntVal.replace(/[^\w\s]|\n|/gi, '');
                    return cnt;
                }
                if (curType === 'double') {
                    if (cntVal.replace(/\W/g, '') === 'null') {
                        return 'Double.NaN';
                    }
                    else if (cntVal === '20.0') {
                        return cntVal;
                    }
                    cnt = parseFloat(cntVal.replace(/\n|\:|\s|\'|/gi, ''));
                    return cnt;
                }
                if (curType === 'int') {
                    if (cntVal.replace(/\W/g, '') === 'null') {
                        return 'null';
                    }
                    cnt = parseInt(cntVal.replace(/\n|\:|\s|\'|/gi, ''));
                    return cnt;
                }
                if (this.isStringLitrals(obj)) {
                    if (cntVal.replace(/\W/g, '') === 'null') {
                        return 'null';
                    }
                    cnt = this.toInitCap(curType) + '.' + this.toInitCap(cntVal.replace(/[^\w\s]|\n|/gi, ''));
                    return cnt;
                }
                if (this.isEnumType(obj)) {
                    if (cntVal.replace(/\W/g, '') === 'null') {
                        return 'null';
                    }
                    cnt = this.toInitCap(curType) + '.' + this.toInitCap(cntVal.replace(/[^\w\s]|\n|/gi, ''));
                    return cnt;
                }
                if (curType === 'string') {
                    if (cntVal.replace(/\W/g, '') === 'null') {
                        return 'null';
                    }
                    cnt = cntVal.replace(/^'|'$/g, '"');
                    /* jshint ignore:start */
                    if (cntVal === "undefined" || cntVal === "'undefined'") {
                        cnt = null;
                    }
                    /* jshint ignore:end */
                } else {
                    if (cntVal.replace(/\W/g, '') === 'null') {
                        return 'null';
                    }
                    return cntVal;
                }
            }
        }
        return cnt;
    }

    getActualPropertyType(obj) {
        if (this.isStringLitrals(obj) || this.isEnumType(obj)) {
            return this.toInitCap(obj.type.name);
        }
    }

    getUnionType(obj) {
        var combination = [];
        obj.type.types.filter(function (value) {
            if (value.name) {
                combination.push(value.name);
            } else if (value.type === 'array') {
                combination.push(value.type);
            }
            return value;
        });
        var combinations = combination.join(' ').replace(/number|string|Date|HTMLElement|Element|Node/g, 1);
        combinations = combinations.replace(/[a-z-A-Z]/g, 0);
        if (/0/g.test(combinations)) {
            return 'object';
        }
        return 'string';
    }

    getPropertyType(obj, comp, options, tagDirective, isMultiType, MultiTypeObj) {
        var cusTagDirective, cusComplexDirective; var baseClassName; var className;
        if (comp) {
            cusTagDirective = comp.tagDirective;
            cusComplexDirective = comp.complexDirective;
        }
        var defaultValue = obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
            return v.tag === 'asptype';
        });
        if (defaultValue && defaultValue[0] && defaultValue[0].text) {
            return defaultValue[0].text.split('\n')[0].trim();
        }
        if (obj.kindString === 'Event' || obj.name === 'query') {
            return 'string';
        } else {
            var res = 'object';
            if (isMultiType) {
                obj.type = MultiTypeObj;
            }
            if (this.isStringLitrals(obj) || this.isEnumType(obj)) {
                if (tagDirective && tagDirective.baseClass &&
                    this.propertyList[tagDirective.baseClass]._allProperties.indexOf(obj.type.name.toLowerCase()) !== -1) {
                    return 'Syncfusion.EJ2.' + this.namespaceCheck(pack.name) + '.' + this.toInitCap(obj.type.name);
                } else {
                    return this.toInitCap(obj.type.name);
                }
            }
            if (tagDirective) {
                cusTagDirective = tagDirective.tagDirective;
            }
            if (tagDirective) {
                cusComplexDirective = tagDirective.complexDirective;
            }
            if (obj.type && obj.type.type === 'union') {
                return this.getUnionType(obj);
            }

            if (cusTagDirective) {
                for (var i = 0; i < cusTagDirective.length; i++) {
                    if (!cusTagDirective[i].isBlazorOnly && cusTagDirective[i].propertyName === obj.name) {
                        if (comp.removeDuplicateClassName) {
                            baseClassName = this.toInitCap(cusTagDirective[i].directiveClassName || cusTagDirective[i].baseClass);
                            res = 'List<' + (cusTagDirective[i].aspArrayClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName)) + '>';
                        } else {
                            res = 'List<' + (cusTagDirective[i].aspArrayClassName || comp.baseClass +
                                this.toInitCap(cusTagDirective[i].directiveClassName || cusTagDirective[i].baseClass)) + '>';
                        }
                    }
                }
            }

            if (cusComplexDirective) {
                for (var j = 0; j < cusComplexDirective.length; j++) {
                    if (!cusComplexDirective[j].isBlazorOnly && cusComplexDirective[j].propertyName === obj.name) {
                        if (comp.removeDuplicateClassName) {
                            className = this.toInitCap(cusComplexDirective[j].baseClass);
                            res = cusComplexDirective[j].aspClassName || (className.includes(comp.baseClass) ? className : comp.baseClass + className);
                        } else {
                            res = (cusComplexDirective[j].aspClassName || comp.baseClass + this.toInitCap(cusComplexDirective[j].baseClass));
                        }
                    }
                }
            }

            if (obj.type && typeof obj.type.name === 'string') {
                var type = handledTypes[obj.type.name];
                return type ? type : res;
            }

            if (obj.type && obj.type.type === 'array' && obj.type.elementType && /string|number/g.test(obj.type.elementType.name)) {
                return handledTypes[obj.type.elementType.name] + '[]';
            }
            return res;
        }
    }

    isExported(obj) {
        if (obj.flags && obj.flags.isPrivate) {
            return false;
        } else {
            return obj.flags && obj.flags.isExported;
        }
    }

    getTagSelector(comp, data, isComplex) {
        var complexTagName, collectionTagName, parentTagName;

        if (isComplex) {
            complexTagName = data.aspSelectorName ? data.aspSelectorName : ('e-' +
                comp.baseClass.toLowerCase() + '-' + data.propertyName.toLowerCase());
        } else {
            collectionTagName = data.aspArrayDirectiveSelector ? data.aspArrayDirectiveSelector : 'e-' +
                comp.baseClass.toLowerCase() + '-' + data.arrayDirectiveClassName.toLowerCase();
            complexTagName = data.aspDirectiveSelector ? data.aspDirectiveSelector : ('e-' +
                comp.baseClass.toLowerCase() + '-' + data.directiveClassName.toLowerCase());
        }

        return {
            complexTagName: complexTagName,
            collectionTagName: collectionTagName,
            parentTagName: parentTagName
        };
    }

    generateBuilder(builder, propList, comp, options) {
        var className = comp.baseClass;
        var tag;
        var htmlString = '';
        var tagType = (comp.defaultTag !== undefined && (comp.defaultTag).match(/type=\'.*\'/g) !== null) ?
            ((comp.defaultTag).match(/type=\'.*\'/g)[0].match(/\'(.+)\'/g)[0].replace(/^'|'$/g, '')) : '';
        var returnvalue = this.getBuilderProperties(propList, comp, options);
        builder = builder.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
        builder = builder.replace(/{{className}}/g, className);
        builder = builder.replace(/{{builderClassName}}/g, className + 'Builder' + (comp.isTModel === true ? '<T>' : ''));
        builder = builder.replace(/{{tClass}}/g, (comp.isTModel === true ? this.tClass : ''));
        builder = builder.replace(/{{tagType}}/g, tagType);
        builder = builder.replace(/{{tModel}}/g, (comp.isTModel === true ? '<T>' : ''));
        builder = builder.replace(/{{builderProperties}}/g, returnvalue);
        if (comp.type === 'container' || comp.aspContentTemplate) {
            htmlString = `\n            this.Output.WriteLine("<` +
                (comp.preferredTag ? comp.preferredTag : 'div') +
                ` id=" + model.Id + " " + tagName + ">");
            if (this.model.ContentTemplate.builder != null) {
                this.model.ContentTemplate.builder(this.Context, this.Output);
            }
            foreach (MvcTemplate<object> col in ${comp.baseClass.toLowerCase()}TemplateCollections)
            {
                col.builder(this.Context, this.Output);
            }
            this.Output.WriteLine("</` +
                (comp.preferredTag ? comp.preferredTag : 'div') + `>");`;
            if (comp.type === 'form') {
                htmlString = `\n            if (!tagName.ToString().Contains("ejs-for"))
            {` +
                    htmlString + `
            }`;
            }
            builder = builder.replace(/{{defaultTag}}/g, '');
        } else if (comp.defaultTag) {
            if (comp.defaultTag.indexOf('id=')) {
                tag = comp.defaultTag;
                tag = tag.replace(/id='\w*'|id="\w*"/g, 'id =\'" + model.Id + "\'" + tagName + "');
            } else {
                tag = comp.defaultTag.replace(/id='\w*'|id="\w*"/g, 'id =\'" + model.Id + "\'" + tagName + "');
            }
            tag = tag.replace(/id='\w*'|id="\w*"/g, 'id =\'" + model.Id + "\'" + tagName + "');
            builder = builder.replace(/{{defaultTag}}/g, tag);
        } else if (comp.preferredTag) {
            tag = '<' + comp.preferredTag + ' id=\\"" + model.Id + "\\"" + tagName + "></' + comp.preferredTag + '>';
            builder = builder.replace(/{{defaultTag}}/g, tag);
        } else {
            tag = '<div id=" + model.Id + " " + tagName + "></div>';
            builder = builder.replace(/{{defaultTag}}/g, tag);
        }
        if ((returnvalue.indexOf('TemplateCollections') !== -1 || htmlString.indexOf('TemplateCollections') !== -1) && (comp.type === 'container' || comp.aspContentTemplate)) {
            builder = builder.replace(/{{templateCollections}}/g, 'List<object> ' + comp.baseClass.toLowerCase() +
                'TemplateCollections = new List<object>();');
        }
        else {
            builder = builder.replace(/{{templateCollections}}/g, '');
        }
        builder = builder.replace(/{{htmlString}}/g, htmlString);
        return builder;
    }

    getBuilderProperties(propList, comp, options) {
        var props = propList[comp.baseClass];
        var buildprop = '';
        var restrictedChild = [];
        buildprop = this.getAllPropEvents(props, comp, buildprop, restrictedChild, '_allProperties', options);
        buildprop = this.getAllPropEvents(props, comp, buildprop, restrictedChild, '_allEvents', options);

        if (comp.type === 'container' || comp.aspContentTemplate) {
            var bPropT = (comp.isTModel === true ? '<T> ' : ' ');
            buildprop += `       public ` + comp.baseClass + `Builder` + bPropT + `ContentTemplate(Func<object, object> template)
        {
            this.model.ContentTemplate.RazorViewTemplate = template;
            return this;
        }\n\n       public ` + comp.baseClass + `Builder` + bPropT + `ContentTemplate(Action<object> template)
        {
            this.model.ContentTemplate.ActionTemplate = template;
            return this;
        }`;
        }
        return buildprop;
    }

    getAllPropEvents(props, comp, buildprop, restrictedChild, propEvent, options) {
        var builderPropType, className = comp.baseClass;
        var isModT = false;
        isModT = comp.isTModel ? true : isModT;
        if (propEvent === '_allProperties' && props[propEvent].indexOf('htmlAttributes') === -1) {
            buildprop += `/// <summary>
       /// Allows additional HTML attributes such as title, name, etc., and
       /// accepts n number of attributes in a key-value pair format.
       /// </summary>

       public ${className}Builder` + (comp.isTModel === true ? '<T> ' : ' ') + `HtmlAttributes(object htmlAttributes)
       {
            model.HtmlAttributes = htmlAttributes;
            return this;
       }\n`;
        }
        for (var i = 0; i < props[propEvent].length; i++) {
            var curProperty = props[propEvent][i];
            var builderPropTypes = [];
            var classfirst = this.toInitCap(curProperty);
            if ((props._propObjects[curProperty]) && ((props._propObjects[curProperty]).flags.isPrivate === undefined)) {
                var initialProp = this.toInitCap(curProperty);
                builderPropTypes.push(this.getPropertyType(props._propObjects[curProperty], comp, {
                    restrictedChild: restrictedChild
                }));
                builderPropTypes = this.getNestedTypes(comp, builderPropTypes, props._propObjects[curProperty], undefined, options);
                var flag = true;
                for (var k = 0; k < builderPropTypes.length; k++) {
                    builderPropType = builderPropTypes[k];
                    var boolProp = '';
                    if (restrictedKeys.indexOf(curProperty) !== -1) {
                        curProperty = restrictedProperties[curProperty];
                    }
                    if (builderPropType === 'bool') {
                        boolProp = ' = true';
                    }
                    var cusPropName = curProperty;
                    if (builderPropTypes[0] === 'string' && builderPropType !== builderPropTypes[0]) {
                        cusPropName += '.ToString()';
                    }
                    var shortComments = props[(propEvent === '_allProperties') ? '_propShortComments' : '_eventShortComments'];
                    var obj = props._propObjects[curProperty];
                    var ignoreProperty = obj && obj.comment && obj.comment.tags && obj.comment.tags.filter(function (v) {
                        return v.tag === 'aspignore';
                    });
                    if (!(ignoreProperty && ignoreProperty.length)) {
                        if (shortComments[curProperty]) {
                            buildprop = buildprop + '\n       ' + shortComments[curProperty].split('\n').join('\n       ') + '\n';
                        }
                        buildprop = buildprop + '\n       public ' + className + 'Builder' + (comp.isTModel === true ? '<T> ' : ' ') +
                            initialProp + '(' + builderPropType +
                            ' ' + curProperty + boolProp + ')\n' + '       {\n' + '            model.' + classfirst +
                            ' = ' + cusPropName + ';\n' +
                            '            return this;\n' + '       }\n\n';
                        if (flag) {
                            if (!comp.aspIgnoreDefaultDataSource && curProperty === 'dataSource') {
                                buildprop = buildprop + '       public ' + className + 'Builder' + (comp.isTModel === true ? '<T>' : '') +
                                    ' DataSource(Action<DataManagerBuilder> dataSource)\n' +
                                    '       {\n' +
                                    '           var resultObject = new DataManager();\n' +
                                    '           model.DataSource = resultObject;\n' +
                                    '           var builder = new DataManagerBuilder(resultObject);\n' +
                                    '           if (dataSource != null)\n' +
                                    '               {\n' +
                                    '                   dataSource.Invoke(builder);\n' +
                                    '               }\n' +
                                    '           return this;\n' +
                                    '       }\n';
                            }
                            /* jshint ignore:start */
                            var getBuilder = comp.tagDirective && comp.tagDirective.length &&
                                comp.tagDirective.filter(function (v) {
                                    return !v.isBlazorOnly && (v.propertyName === curProperty);
                                });
                            var getComplexBuilder = comp.complexDirective && comp.complexDirective.length &&
                                comp.complexDirective.filter(function (v) {
                                    return !v.isBlazorOnly && (v.propertyName === curProperty);
                                });
                            buildprop = this.generateNestedBuilder(buildprop, getBuilder, getComplexBuilder, comp, curProperty, className, isModT);
                            /* jshint ignore:end */
                            flag = false;
                        }
                    }
                }
            }
        }
        return buildprop;
    }

    generateNestedBuilder(buildprop, getBuilder, getComplexBuilder, comp, curProperty, className, isModT) {
        var initialProp = this.toInitCap(curProperty);
        var vClassName;
        var baseClassName;
        var templateCol = `          foreach (var innertemplate in this.model.{{:prop}})
          {
                if (innertemplate.ContentTemplate.builder != null)
                {
                    ${comp.baseClass.toLowerCase()}TemplateCollections.Add(innertemplate.ContentTemplate);
                }
          }\n`;
        var templateCom = `           if (this.model.{{:prop}}.ContentTemplate.builder != null)
               {
                   ${comp.baseClass.toLowerCase()}TemplateCollections.Add(this.model.{{:prop}}.ContentTemplate);
               }\n`;
        templateCol = comp.type === 'container' ? templateCol : '';
        templateCom = comp.type === 'container' ? templateCom : '';
        var propName = curProperty;
        if (restrictedKeys.indexOf(propName) !== -1) {
            propName = restrictedProperties[propName];
        }
        var ignoreCollectionProperty = getBuilder && getBuilder.length &&
            getBuilder[0].comment && getBuilder[0].comment.tags && getBuilder[0].comment.tags.filter(function (v) {
                return v.tag === 'aspignore';
            });
        var ignoreComplexProperty = getComplexBuilder && getComplexBuilder.length && getComplexBuilder[0].comment &&
            getComplexBuilder[0].comment.tags && getComplexBuilder[0].comment.tags.filter(function (v) {
                return v.tag === 'aspignore';
            });
        if (!(ignoreCollectionProperty && ignoreCollectionProperty.length || ignoreComplexProperty && ignoreComplexProperty.length)) {
            if (getBuilder && getBuilder.length === 1) {
                if (getBuilder[0]) {
                    if (comp.removeDuplicateClassName) {
                        baseClassName = this.toInitCap(getBuilder[0].directiveClassName || getBuilder[0].baseClass);
                        vClassName = getBuilder[0].aspArrayClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName);
                    } else {
                        vClassName = (getBuilder[0].aspArrayClassName || comp.baseClass + this.toInitCap(getBuilder[0].directiveClassName ||
                            getBuilder[0].baseClass));
                    }
                    var mapStmtReplace = 'MapAnnotation(this.model.' + initialProp + ' as List<' + vClassName + '>);';
                    var mapStmt = (getBuilder[0].isTModel === true ? mapStmtReplace : '');
                    var vBProp = '       public ' + className + 'Builder' + (isModT === true ? '<T> ' : ' ');
                    buildprop = buildprop + vBProp + initialProp +
                        '(Action<' + (getBuilder[0].aspBuilderName || vClassName) + 'Builder' +
                        (getBuilder[0].isTModel === true ? '<T>' : '') + '> ' + propName + ')\n' +
                        '       {\n' +
                        '           List<' + vClassName + '> result = new List<' + vClassName + '>();\n' +
                        '           model.' + initialProp + ' = result;\n' +
                        '           ' + vClassName + 'Builder' + (getBuilder[0].isTModel === true ? '<T>' : '') + ' builder = new ' +
                        (getBuilder[0].aspBuilderName || vClassName) + 'Builder' + (getBuilder[0].isTModel === true ? '<T>' : '') +
                        '(result);\n' + '           if (' + propName + ' != null)\n' +
                        '               {\n' +
                        '                   ' + propName + '.Invoke(builder);\n' +
                        '               }\n' +
                        templateCol.replace(/{{:prop}}/g, initialProp) +
                        '           ' + mapStmt + '\n' +
                        '           return this;\n' +
                        '       }\n';
                }
            } else if (getComplexBuilder && getComplexBuilder.length === 1) {
                if (getComplexBuilder[0]) {
                    if (comp.removeDuplicateClassName) {
                        baseClassName = this.toInitCap(getComplexBuilder[0].directiveClassName || getComplexBuilder[0].baseClass);
                        vClassName = getComplexBuilder[0].aspClassName || (baseClassName.includes(comp.baseClass) ? baseClassName : comp.baseClass + baseClassName);
                    } else {
                        vClassName = (getComplexBuilder[0].aspClassName || comp.baseClass +
                            this.toInitCap(getComplexBuilder[0].directiveClassName || getComplexBuilder[0].baseClass));
                    }
                    var isTMod = (getComplexBuilder[0].isTModel === true ? '<T>' : '');
                    var bProp = '       public ' + className + 'Builder' + (comp.isTModel === true ? '<T> ' : ' ');
                    buildprop = buildprop + bProp + initialProp +
                        '(Action<' + (getComplexBuilder[0].aspBuilderName || vClassName) + 'Builder' + isTMod + '> ' + propName + ')\n' +
                        '       {\n' +
                        '           var modelValue = new ' + vClassName + '();\n' +
                        '           model.' + initialProp + ' = modelValue;\n' +
                        '           var builder = new ' + (getComplexBuilder[0].aspBuilderName || vClassName) + 'Builder' + isTMod +
                        '(modelValue);\n' + '           if (' + propName + ' != null)\n' +
                        '               {\n' +
                        '                   ' + propName + '.Invoke(builder);\n' +
                        '               }\n' +
                        templateCom.replace(/{{:prop}}/g, initialProp) +
                        '           return this;\n' +
                        '       }\n';
                }
            }
        }
        return buildprop;
    }

    getAllpropertiesFromClass(propList, comp, options) {
        var props = propList;
        var prop = '';
        if (props._allProperties.indexOf('htmlAttributes') === -1) {
            prop += `        /// <summary>
        /// Allows additional HTML attributes such as title, name, etc., and
        /// accepts n number of attributes in a key-value pair format.
        /// </summary>
        [DefaultValue(null)]
        [HtmlAttributeName("htmlAttributes")]
        [JsonProperty("htmlAttributes")]
        public object HtmlAttributes { get; set; }\n\n`;
        }
        if (comp.baseClass === 'NumericTextBox') {
            prop += `        /// <summary> 
        /// Specifies the server-side defined decimal separator.
        /// </summary>
        [DefaultValue(null)]
        [JsonProperty("serverDecimalSeparator")]
        private string ServerDecimalSeparator { get; set; } = System.Globalization.NumberFormatInfo.CurrentInfo.NumberDecimalSeparator;\n\n`;
        }
        for (var i = 0; i < props._allProperties.length; i++) {
            var curProperty = props._allProperties[i];
            if ((props._propObjects[curProperty]) && ((props._propObjects[curProperty]).flags.isPrivate === undefined)) {
                prop = prop + this.createPropertySyntax(
                    props._propObjects[curProperty], comp, comp, undefined, options, propList._propShortComments);
            }
        }
        for (var j = 0; j < props._allEvents.length; j++) {
            var curEvent = props._allEvents[j];
            if (props[curEvent]) {
                prop = prop + this.createPropertySyntax(
                    props[curEvent].obj, comp, comp, comp.tagDirective, options, propList._eventShortComments);
            }
        }
        if (comp.baseClass === 'Grid') {
            prop += `        /// <inheritdoc /> 
        internal override void MapDataAnnotation()
        {
	    if (this.Columns == null)
            {
                List<GridColumn> result = new List<GridColumn>();
                this.Columns = result;
            }
            MapAnnotation(this.Columns as List<GridColumn>);
        }\n\n
	/// <summary>
        /// The data source value can be of any type
        /// </summary>
        [DefaultValue(null)]
        [HtmlAttributeName("tvalue")]
        [JsonProperty("tvalue")]
        public Type TValue { get; set; }\n\n
        /// <summary>
        /// Triggers for each cell while exporting while exporting to Excel file in server.
        /// You can also customize the Excel cells.
        /// </summary>
        [DefaultValue(null)]
        [HtmlAttributeName("serverExcelQueryCellInfo")]
        [JsonProperty("serverExcelQueryCellInfo")]
        [JsonConverter(typeof(EventTypeConverter))]
        public Action<object> ServerExcelQueryCellInfo { get; set; }\n\n
        /// <summary>
        /// Triggers for each header cell while exporting to Excel file in server.
        /// You can also customize the Excel cells.
        /// </summary>
        [DefaultValue(null)]
        [HtmlAttributeName("serverExcelHeaderQueryCellInfo")]
        [JsonProperty("serverExcelHeaderQueryCellInfo")]
        [JsonConverter(typeof(EventTypeConverter))]
        public Action<object> ServerExcelHeaderQueryCellInfo { get; set; }\n\n
        /// <summary>
        /// Triggers for each aggregate cell while exporting to Excel document in server.
        /// You can also customize the Excel cells.
        /// </summary>
        [DefaultValue(null)]
        [HtmlAttributeName("serverExcelAggregateQueryCellInfo")]
        [JsonProperty("serverExcelAggregateQueryCellInfo")]
        [JsonConverter(typeof(EventTypeConverter))]
        public Action<object> ServerExcelAggregateQueryCellInfo { get; set; }\n\n
        /// <summary>
        /// Triggers for each cell while exporting while exporting to Pdf file in server.
        /// You can also customize the Pdf cells.
        /// </summary>
        [DefaultValue(null)]
        [HtmlAttributeName("serverPdfQueryCellInfo")]
        [JsonProperty("serverPdfQueryCellInfo")]
        [JsonConverter(typeof(EventTypeConverter))]
        public Action<object> ServerPdfQueryCellInfo { get; set; }\n\n
        /// <summary>
        /// Triggers for each header cell while exporting to Pdf file in server.
        /// You can also customize the Pdf header cells.
        /// </summary>
        [DefaultValue(null)]
        [HtmlAttributeName("serverPdfHeaderQueryCellInfo")]
        [JsonProperty("serverPdfHeaderQueryCellInfo")]
        [JsonConverter(typeof(EventTypeConverter))]
        public Action<object> ServerPdfHeaderQueryCellInfo { get; set; }\n\n
        /// <summary>
        /// Triggers for each aggregate cell while exporting to Pdf document in server.
        /// You can also customize the Pdf Aggregate cells.
        /// </summary>
        [DefaultValue(null)]
        [HtmlAttributeName("serverPdfAggregateQueryCellInfo")]
        [JsonProperty("serverPdfAggregateQueryCellInfo")]
        [JsonConverter(typeof(EventTypeConverter))]
        public Action<object> ServerPdfAggregateQueryCellInfo { get; set; }\n\n`;
        }
        if (comp.baseClass === 'TreeGrid') {
            prop += `        /// <summary>
            /// Triggers for each cell while exporting while exporting to Excel file in server. 
            /// You can also customize the Excel cells.
            /// </summary>\n\n
            [DefaultValue(null)]
            [HtmlAttributeName("excelCellRendering")]
            [JsonProperty("excelCellRendering")]
            [JsonConverter(typeof(EventTypeConverter))]
            public Action<object> ExcelCellRendering { get; set; }\n\n
            /// <summary>
            /// Triggers for each header cell while exporting to Excel file in server.
            /// You can also customize the Excel cells.
            /// </summary>
            [DefaultValue(null)]
            [HtmlAttributeName("excelHeaderCellRendering")]
            [JsonProperty("excelHeaderCellRendering")]
            [JsonConverter(typeof(EventTypeConverter))]
            public Action<object> ExcelHeaderCellRendering { get; set; }\n\n
            /// <summary>
            /// Triggers for each aggregate cell while exporting to Excel document in server.
            /// You can also customize the Excel cells.
            /// </summary>
            [DefaultValue(null)]
            [HtmlAttributeName("excelAggregateCellRendering")]
            [JsonProperty("excelAggregateCellRendering")]
            [JsonConverter(typeof(EventTypeConverter))]
            public Action<object> ExcelAggregateCellRendering  { get; set; }\n\n
            /// <summary>
            /// Triggers for each cell while exporting while exporting to Pdf file in server.
            /// You can also customize the Pdf cells.
            /// </summary>
            [DefaultValue(null)]
            [HtmlAttributeName("pdfCellRendering")]
            [JsonProperty("pdfCellRendering")]
            [JsonConverter(typeof(EventTypeConverter))]
            public Action<object> PdfCellRendering { get; set; }\n\n
            /// <summary>
            /// Triggers for each header cell while exporting to Pdf file in server.
            /// You can also customize the Pdf header cells.
            /// </summary>
            [DefaultValue(null)]
            [HtmlAttributeName("pdfHeaderCellRendering")]
            [JsonProperty("pdfHeaderCellRendering")]
            [JsonConverter(typeof(EventTypeConverter))]
            public Action<object> PdfHeaderCellRendering { get; set; }\n\n
            /// <summary>
            /// Triggers for each aggregate cell while exporting to Pdf document in server.
            /// You can also customize the Pdf Aggregate cells.
            /// </summary>
            [DefaultValue(null)]
            [HtmlAttributeName("pdfAggregateCellRendering")]
            [JsonProperty("pdfAggregateCellRendering")]
            [JsonConverter(typeof(EventTypeConverter))]
            public Action<object> PdfAggregateCellRendering { get; set; }\n\n`;
        }
        return prop;
    }

    toInitCap(str) {
        return str.charAt(0).toUpperCase() + str.substr(1);
    }

    getComments(propList, tagDirective, curBuilderProperty) {
        var comment = '';
        if (curBuilderProperty.comment) {
            var newLine = '\n';
            var tab = '    ';
            comment = propList[tagDirective.baseClass]._propShortComments[curBuilderProperty.name] ||
                propList[tagDirective.baseClass]._eventShortComments[curBuilderProperty.name];
            comment = comment.split('\n').join(newLine + tab + tab) + newLine;
        }
        if (comment.indexOf(' & ') !== -1) {
            comment = comment.replace(' & ', ' and ');
        }
        return comment;
    }
}

module.exports = function (json, propList, done) {
    var pJson = JSON.parse(fs.readFileSync('./package.json'));
    return new AspSourceGen(json, propList, pJson, done);
};
