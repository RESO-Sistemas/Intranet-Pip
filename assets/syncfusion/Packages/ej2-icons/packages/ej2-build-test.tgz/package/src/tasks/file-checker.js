'use strict';
var gulp = require('gulp');
var Typo = require('typo-js');
var dictionary = new Typo('en_US');
var path = require('path');
var common = global.config.config();
var fs = require('fs');

var checkedFiles = {
  folders: [],
  files: [],
  upperCase: []
};
gulp.task('file-checker', function(done) {
  var glob = require('glob');
  var folderNames = fs.readdirSync('./src/', 'utf-8');
  for (var i = 0; i < folderNames.length; i++) {
    checkFileNames(folderNames[i]);
  }
  var fileNames = glob.sync('./src/**/*.*', {
    ignore: ['./src/**/*.png', './src/**/*.svg', './src/**/*.json', './src/**/*.eot',
     './src/**/*.ttf', './src/**/*.woff', './src/**/*.gif', './src/**/*.jpg', './src/common/**/*.*']
  });
  for ( var k = 0; k < fileNames.length; k++) {
    checkFileNames(fileNames[k], true);
  }
  printError(done);
});

function checkFileNames(filePath, isFiles) {
  var type = isFiles ? 'files' : 'folders';
  var fileName = isFiles ? path.basename(filePath).split('.')[0] : filePath;
  var splitted = fileName.split('-');
  var isValid = true;
  var isUpperCase = false;
  
  common.customNames = common.customNames ? common.customNames : [];
  for (var j = 0; j < splitted.length; j++) {
    if (!dictionary.check(splitted[j]) && common.customNames.indexOf(splitted[j]) === -1) {
      isValid = false;      
    }
    if(splitted[j].match(new RegExp(/^[A-Z]/)) !== null){
        isUpperCase = true;
    }
  }
  if (!isValid) {
    checkedFiles.isFailed = true;
    checkedFiles[type].push(filePath);
  }
  if(isUpperCase) {
    checkedFiles.isFailed = true;
    checkedFiles.upperCase.push(filePath);
  }
  
}

function printError(done) {
  if (!checkedFiles.isFailed) {
    console.log('All Files Have Valid Names\n');
    done();
    return;
  }
  console.log('\n******* The Below Folder Names Are Invalid *******\n');
  console.log(checkedFiles.folders.toString().split(',').join('\n'));

  console.log('\n******* The Below File Names Are Invalid *******\n');
  console.log(checkedFiles.files.toString().split(',').join('\n'));

  console.log('\n******* The Below File Names  Have The UpperCase letters *******\n');
  console.log(checkedFiles.upperCase.toString().split(',').join('\n'));
  
  done();
  // process.exit(1);
}
