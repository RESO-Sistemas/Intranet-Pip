'use strict';
var fs = global.fs = global.fs || require('fs');
var shelljs = require('shelljs');
var gulp = global.gulp = global.gulp || require('gulp');
global.config = global.config || require('../utils/common.js');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');

var print;
var common = global.config;
var config = global.config.config();
// var tsConfig = __dirname + config.tslintConfig;
var htmlConfig = __dirname + config.htmllintConfig;
var mdlintConfig = __dirname + config.mdlintConfig;
var currentRepo = common.currentRepo;
var sampleList;

if (fs.existsSync('./controlWiseSample.json')) {
    sampleList = JSON.parse(fs.readFileSync('./controlWiseSample.json'));
}

/**
 * Lint source files using microsoft contributed tslint
 */

gulp.task('es-lint-config', function (done) {
    shelljs.exec('npm i tslint');
    shelljs.cp('-r',__dirname + '/../../tslint.json','./tslint.json');
    var packJson = JSON.parse(fs.readFileSync('./package.json','utf8'));
    packJson.scripts['es-lint-config'] = `npx tslint-to-eslint-config --config .eslintrc.json --tslint ./tslint.json`;
    packJson.scripts['es-lint'] = `eslint -c .eslintrc.json --ext .ts ./src/**`;
    /*jshint -W069 */
    if (packJson.dependencies['tslint']) {
        delete packJson.dependencies['tslint'];
    }
    /*jshint +W069 */
    fs.writeFileSync('./package.json', JSON.stringify(packJson, null,4), 'utf8');
    shelljs.exec('npm run es-lint-config');
    var eslintConfig = fs.readFileSync(__dirname + '/../../templates/eslint').toString();
    fs.writeFileSync('./.eslintrc.json', eslintConfig, 'utf8');
    done();
});

gulp.task('es-lint', function (done) {
    let ignoreRepos = [];
    let baseRepos = ['ej2-base-library', 'ej2-angular-base', 'ej2-react-base', 'ej2-vue-base'];
    let components = [];
    let ESLint = shelljs.exec('npm run es-lint');
    let output = ESLint.stdout;
    fs.writeFileSync('./eslint-report.log', output);
    if (fs.existsSync(__dirname + '/../../templates/eslint')) {
        // Read the ESLint security rules configured in the eslint.json file.
        let securityRules = Object.keys(JSON.parse(fs.readFileSync(__dirname + '/../../templates/eslint')).rules).filter((key) => key.includes('security/'));
        if (securityRules.length && output.length) {
            // Check whether the ESLint report has security issues and throw an error.
            let error = securityRules.some((key) => output.includes(key)) ?
            'The component code does not satisfy the ESLint security rules. Resolve the ESLint security errors.' : null;
            if (error) { throw error; }
        }
    }
    if ((baseRepos.indexOf(currentRepo) !== -1 || components.some((item) => output.includes(`src/${item}`))) && ESLint.code !== 0) { process.exit(1); }
    let logContent = fs.readFileSync('./eslint-report.log', 'utf8');
    // Check if the current repo is a ignore repo
    if (ignoreRepos.indexOf(currentRepo) !== -1) {
        return done();
    }
    // const warningRegex = /^\s*\d+:\d+\s+warning\s+/gm;
    const errorRegex = /^\s*\d+:\d+\s+error\s+/gm;
    let errorCount = (logContent.match(errorRegex) || []).length;
    // let warningCount = (logContent.match(warningRegex) || []).length;
    // If there are errors or warnings, fail the CI
    if (errorCount > 0) {
        let error = `CI-Error: ESLint found ${errorCount} error(s). Resolve the ESLint issues.`;
        throw error;
    }
    done();
});

/*
Lint scss files using gulp-stylelint
 */
// gulp.task('stylelint-scss', function () {
//     var file = fs.readFileSync('./node_modules/@syncfusion/ej2-build-test/.stylelintrc.json', 'utf8');
//     fs.writeFileSync('./.stylelintrc.json', file, 'utf8');
//     var gulpStylelint = require('gulp-stylelint');
//     return gulp.src(config.stylelintSass)
//         .pipe(gulpStylelint({
//             failAfterError: true,
//             reporters: [
//                 { formatter: 'string', console: true }
//             ]
//         }));
// });

/**
 * Lint sample html files using html lint
 */
gulp.task('html-lint', function (done) {
    print = print || require('gulp-print').default;
    var htmllint = require('./htmllint.js');
    if (sampleList && sampleList.length && currentRepo === 'ej2-samples') {
        config.htmllint = getControlWisehtmllint();
    }
    return gulp.src(config.htmllint)
        .pipe(print())
        .pipe(htmllint(htmlConfig))
        .on('end', done);
});

function getControlWisehtmllint() {
    var htmllintcontrols = JSON.parse(fs.readFileSync('./sampleList.json'));
    config.htmllint = [];
    for (var i = 0; i < htmllintcontrols.length; i++) {
        config.htmllint.push('./src/' + htmllintcontrols[i] + '/*.html');
    }
    return config.htmllint;
}

gulp.task('md-lint', function (done) {
    runSequence('typo', 'md-header');
    var markdownlint = require('markdownlint');
    var glob = require('glob');
    var options = {
        files: glob.sync('{./CHANGELOG.md,./third-party/changelog/*.md}'),
        config: require(mdlintConfig)
    };
    markdownlint(options, function (result, err) {
        if (err.toString().length) {
            console.error(err.toString());
            fs.appendFileSync('./gulp_error.log', err.toString());
            done();
            process.exit(1);
        } else {
            console.log('\n*** Markdown Lint Succeeded ***\n');
            done();
        }
    });
});
gulp.task('typo', function (done) {
    var shelljs = require('shelljs');
    shelljs.exec('npm i markdown-spellcheck');
    var buildConfig = JSON.parse(fs.readFileSync('./node_modules/@syncfusion/ej2-build-test/config.json'));
    var compConfig = require(fs.realpathSync('./config.json'));
    var changelogTypo = buildConfig.changelogTypo;
    if (compConfig.changelogTypo) {
        changelogTypo = buildConfig.changelogTypo.concat(compConfig.changelogTypo);
    }
    fs.writeFileSync('./node_modules/.bin/.spelling', changelogTypo.join('\n'));
    // goto .bin location
    shelljs.cd('./node_modules/.bin/');
    // run mdspell command
    var mdspellcmd = 'mdspell ../../CHANGELOG.md ../../third-party/changelog/*.md -r -n -a -x --color';
    var output = shelljs.exec(mdspellcmd);
    // return root location
    shelljs.cd('../../');
    if (output.code !== 0) {
        console.error('\n** changelog file  have typo issues ***');
        fs.appendFileSync('./gulp_error.log', '\n** changelog file  have typo issues ***');
        done();
        process.exit(1);
    }
    done();
});


/**
 * Lint js files using jslint
 */
gulp.task('js-hint', function (done) {
    runSequence('dedupe');
    print = print || require('gulp-print').default;
    var jshint = require('gulp-jshint');
    var dir = './cireports/jslint';
    if (!fs.existsSync(dir)) {
        shelljs.mkdir('-p', dir);
    }
    var jshintXMLReporter = require('gulp-jshint-xml-file-reporter');
    return gulp.src(config.jshint)
        .pipe(print())
        .pipe(jshint())
        .pipe(jshint.reporter('default'))
        .pipe(jshint.reporter(jshintXMLReporter))
        .on('end', jshintXMLReporter.writeFile({
            format: 'checkstyle',
            filePath: './cireports/jslint/'+currentRepo+'.JSLintAnalysis.xml'
        }))
        .pipe(jshint.reporter('fail'))
        .on('end', done);
});

gulp.task('blazor-es-lint-config', function (done) {
    console.log(">>>>>>>>>>>>>>>>>>>>>>>Blazor Lint Validation Started>>>>>>>>>>>>>>>>>>>>>>>");
    shelljs.exec('npm i tslint');
    shelljs.cp('-r',__dirname + '/../../tslint.json','./tslint.json');
    var packJson = JSON.parse(fs.readFileSync('./package.json','utf8'));
    packJson.scripts['es-lint-config'] = `npx tslint-to-eslint-config --config .eslintrc.json --tslint ./tslint.json`;
    // packJson.scripts['es-lint'] = `eslint -c .eslintrc.json --ext .ts ./src/**`;
    if(packJson.name == "@syncfusion/ej2-pdfviewer"){
        packJson.scripts['es-lint'] = `eslint -c .eslintrc.json --ext .ts ./blazor/sfpdfviewer/**`;
    }
    else{
        packJson.scripts['es-lint'] = `eslint -c .eslintrc.json --ext .ts ./blazor/**`;
    }
    /*jshint -W069 */
    if (packJson.dependencies['tslint']) {
        delete packJson.dependencies['tslint'];
    }
    /*jshint +W069 */
    fs.writeFileSync('./package.json', JSON.stringify(packJson, null,4), 'utf8');
    shelljs.exec('npm run es-lint-config');
    var eslintConfig = fs.readFileSync(__dirname + '/../../templates/eslint').toString();
    fs.writeFileSync('./.eslintrc.json', eslintConfig, 'utf8');
    done();
});

gulp.task('blazor-es-lint', function (done) {
    let baseRepos = ['ej2-base-library', 'ej2-angular-base', 'ej2-react-base', 'ej2-vue-base'];
    let components = [];
    let ESLint = shelljs.exec('npm run es-lint');
    let output = ESLint.stdout;
    fs.writeFileSync('./eslint-report.log', output);
    if (fs.existsSync(__dirname + '/../../templates/eslint')) {
        // Read the ESLint security rules configured in the eslint.json file.
        let securityRules = Object.keys(JSON.parse(fs.readFileSync(__dirname + '/../../templates/eslint')).rules).filter((key) => key.includes('security/'));
        if (securityRules.length && output.length) {
            // Check whether the ESLint report has security issues and throw an error.
            let error = securityRules.some((key) => output.includes(key)) ? 
            'The component code does not satisfy the ESLint security rules. Resolve the ESLint security errors.' : null;
             if (error) { throw error; }
        }
    }
    if ((baseRepos.indexOf(currentRepo) !== -1 || components.some((item) => output.includes(`src/${item}`))) && ESLint.code !== 0) {
        done();
        process.exit(1);
    }
    console.log(">>>>>>>>>>>>>>>>>>>>>>>Blazor Lint Validation Completed>>>>>>>>>>>>>>>>>>>>>>>");
    done();
});

gulp.task('blazor-lint', function(done) {
    var packJson = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
    if (packJson.name != "@syncfusion/ej2-base" && packJson.name != "@syncfusion/ej2-angular-base" && packJson.name != "@syncfusion/ej2-react-base" && packJson.name != "@syncfusion/ej2-vue-base") {
        gulp.series('blazor-es-lint-config', 'blazor-es-lint')(done);
    } else {
        done();
    }
});

gulp.task('csp-validation', function (done) {
    const path = require('path');
    const { globSync } = require('glob');
    const ignoreComps = ['ej2-pdfviewer-library', 'ej2-documenteditor-components', 'ej2-base-library'];
    const isException = ignoreComps.includes(currentRepo);
    if (isException) {
        console.log('csp validation skipped');
        return done();
    }

    const files = globSync('./src/**/*.ts');
    const cspIssues = [];

    files.forEach(file => {
        const content = fs.readFileSync(file, 'utf8');

        const lines = content.split('\n');
        lines.forEach((line, index) => {
             // Skip commented lines
            const isComment = /^\s*\/\//.test(line);
            if (isComment) return;
            
            // Check for inline style assignments in innerHTML
            const innerHTMLInlineStyle = /innerHTML\s*=\s*['"`].*style\s*=\s*["'`][^"'`]*["'`]/i.test(line);
            // Check for setAttribute with 'style'
            const setAttributeStyle = /setAttribute\(\s*['"]style['"]\s*,/i.test(line);
            // Check for <style> element creation and assignments
            const createStyleElement = /document\.createElement\(\s*['"]style['"]\s*\)/i.test(line);

            if (innerHTMLInlineStyle || setAttributeStyle || createStyleElement) {
                cspIssues.push(`${path.relative(process.cwd(), file)}:${index + 1}`);
            }
        });
    });

    if (cspIssues.length > 0) {
        console.error('\n🚫 CSP Compliance Error: Detected unsafe inline styles in the following files:');
        cspIssues.forEach(f => console.error(` - ${f}`));
    } else {
        console.log('✅ CSP validation passed: No unsafe inline styles found.');
    }

    done();
});

gulp.task('lint', gulp.series('dedupe', 'es-lint-config', 'es-lint', 'csp-validation', 'blazor-lint', 'md-lint', 'html-lint', 'tree-shaking'));
