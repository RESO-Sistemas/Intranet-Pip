'use strict';
//comparing two JSON object
class compareJSON {

    constructor(oldjson, newjson) {
        this.oldJson = oldjson;
        this.newJson = newjson;
    }

    //Initializing the comparison
    initializeComparison() {
        let removedModules = this.getModuleDetails(this.detectRemovedKeys(this.oldJson, this.newJson));
        let addedModules = this.getModuleDetails(this.detectAddedKeys(this.oldJson, this.newJson));
        let changedModules = this.getModuleChanges(this.detectValueChange(this.oldJson, this.newJson));
        return {
            added: addedModules,
            removed: removedModules,
            updated: changedModules
        };
    }

    //detecting removed keys of JSON object
    detectRemovedKeys(oldjson, newjson) {
        if (!oldjson && !newjson) {
            return;
        }
        let oldKeys = Object.keys(oldjson);
        let newKeys = Object.keys(newjson);
        let removedKeys = oldKeys.filter((k) => !newKeys.includes(k));
        return removedKeys ? removedKeys.map(rk => { return { key: rk, value: oldjson[rk] }; }) : undefined;
    }

    //detecting added keys of JSON object
    detectAddedKeys(oldjson, newjson) {
        if (!oldjson && !newjson) {
            return;
        }
        let oldKeys = Object.keys(oldjson);
        let newKeys = Object.keys(newjson);
        let addedKeys = newKeys.filter((k) => !oldKeys.includes(k));
        return addedKeys ? addedKeys.map(ak => { return { key: ak, value: newjson[ak] }; }) : undefined;
    }

    //detecting value change of JSON object
    detectValueChange(oldjson, newjson) {
        if (!oldjson && !newjson) {
            return;
        }
        let ja = require('json-assert');
        let oldValues = Object.keys(oldjson).map(k => ({ key: k, obj: oldjson[k] }));
        let newValues = Object.keys(newjson).map(k => ({ key: k, obj: newjson[k] }));
        let changedValues = oldValues.filter((k) => {
            let newobj = newValues.filter(nv => nv.key === k.key);
            return newobj && newobj.length === 1 ? !ja.isEqual(k.obj, newobj[0].obj, true) : {};
        });
        return changedValues ? changedValues.map(cv => {
            let newobj = newValues.filter(nv => nv.key === cv.key);
            return newobj && newobj.length === 1 ? { key: cv.key, oldvalue: cv.obj, newvalue: newobj[0].obj } : undefined;
        })
            : [];
    }

    //get module details for add/remove 
    getModuleDetails(modules) {
        if (!modules) {
            return;
        }
        let moduleDetails = [];
        for (let modul of modules) {
            let modulobj = modul.value;
            let moduleDetail = {
                ModuleName: modul.key,
                Classes: modulobj && modulobj.classes ? this.getClassDetails(modulobj.classes) : [],
                Interfaces: modulobj && modulobj.interfaces ? this.getInterfaceDetails(modulobj.interfaces) : [],
                Properties: modulobj && modulobj.apis ? this.getAPIDetails(modulobj.apis) : [],
                Methods: modulobj && modulobj.methods ? this.getMethodDetails(modulobj.methods) : []
            };
            moduleDetails.push(moduleDetail);
        }
        return moduleDetails;
    }

    //get class details for add/remove
    getClassDetails(classes) {
        if (!classes) {
            return;
        }
        let classDetails = [];
        let classobjs = !Array.isArray(classes) ? Object.keys(classes) : classes;
        for (let classname of classobjs) {
            let classobj = !Array.isArray(classes) ? classes[classname] : classname.value;
            let classDetail = {
                ClassName: !Array.isArray(classes) ? classname : classname.key,
                Properties: classobj && classobj.apis ? this.getAPIDetails(classobj.apis) : [],
                Methods: classobj && classobj.methods ? this.getMethodDetails(classobj.methods) : [],
                Events: classobj && classobj.events ? this.getEventDetails(classobj.events) : []
            };
            classDetails.push(classDetail);
        }
        return classDetails;
    }

    //get interface details for add/remove
    getInterfaceDetails(interfaces) {
        if (!interfaces) {
            return;
        }
        let interfaceDetails = [];
        let interfaceobjs = !Array.isArray(interfaces) ? Object.keys(interfaces) : interfaces;
        for (let interfacename of interfaceobjs) {
            let interfaceobj = !Array.isArray(interfaces) ? interfaces[interfacename] : interfacename.value;
            let interfaceDetail = {
                InterfaceName: !Array.isArray(interfaces) ? interfacename : interfacename.key,
                Properties: interfaceobj && interfaceobj.apis ? this.getAPIDetails(interfaceobj.apis) : [],
                Methods: interfaceobj && interfaceobj.methods ? this.getMethodDetails(interfaceobj.methods) : [],
                Events: interfaceobj && interfaceobj.events ? this.getEventDetails(interfaceobj.events) : [],
            };
            interfaceDetails.push(interfaceDetail);
        }
        return interfaceDetails;
    }

    //get api details for add/remove
    getAPIDetails(apis) {
        if (!apis) {
            return;
        }
        let apiDetails = [];
        let apiobjs = !Array.isArray(apis) ? Object.keys(apis) : apis;
        for (let apiname of apiobjs) {
            let property = !Array.isArray(apis) ? apis[apiname] : apiname.value;
            let apiDetail = {
                PropertyName: !Array.isArray(apis) ? apiname : apiname.key,
                PropertyType: property && property.type ? property.type : null,
                DefaultValue: property && property.defaultvalue ? property.defaultvalue : null
            };
            apiDetails.push(apiDetail);
        }
        return apiDetails;
    }

    //get method details for add/remove
    getMethodDetails(methods) {
        if (!methods) {
            return;
        }
        let methodDetails = [];
        let methodobjs = !Array.isArray(methods) ? Object.keys(methods) : methods;
        for (let methodname of methodobjs) {
            let method = !Array.isArray(methods) ? methods[methodname] : methodname.value;
            let methodDetail = {
                MethodName: !Array.isArray(methods) ? methodname : methodname.key,
                ReturnType: method && method.type ? method.type : null,
                Parameters: method && method.parameters ? method.parameters : null
            };
            methodDetails.push(methodDetail);
        }
        return methodDetails;
    }

    //get event details for add/remove
    getEventDetails(events) {
        if (!events) {
            return;
        }
        let eventDetails = [];
        let eventobjs = !Array.isArray(events) ? Object.keys(events) : events;
        for (let eventname of eventobjs) {
            let event = !Array.isArray(events) ? events[eventname] : eventname.value;
            let eventDetail = {
                EventName: !Array.isArray(events) ? eventname : eventname.key,
                EventType: event && event.type ? event.type : null
            };
            eventDetails.push(eventDetail);
        }
        return eventDetails;
    }

    getModuleChanges(modules) {
        if (!modules) {
            return;
        }
        let moduleChanges = [];
        for (let modul of modules) {
            if (modul) {
                let modulename = modul.key ? modul.key : '';
                let oldvalue = modul.oldvalue ? modul.oldvalue : {};
                let newvalue = modul.oldvalue ? modul.newvalue : {};
                let classChange = oldvalue.classes && newvalue.classes ?
                    this.getClassChanges(oldvalue.classes, newvalue.classes) : {};
                let interfaceChange = oldvalue.interfaces && newvalue.interfaces ?
                    this.getInterfaceChanges(oldvalue.interfaces, newvalue.interfaces) : {};
                let apiChange = oldvalue.apis && newvalue.apis ?
                    this.getAPIChanges(oldvalue.apis, newvalue.apis) : {};
                let methodChange = oldvalue.methods && newvalue.methods ?
                    this.getMethodChanges(oldvalue.methods, newvalue.methods) : {};
                let eventChange = oldvalue.events && newvalue.events ?
                    this.getEventChanges(oldvalue.events, newvalue.events) : {};
                moduleChanges.push({
                    ModuleName: modulename,
                    Classes: classChange,
                    Interfaces: interfaceChange,
                    Properties: apiChange,
                    Methods: methodChange,
                    Events: eventChange
                });
            }
        }
        return moduleChanges;
    }

    getClassChanges(oldclasses, newclasses) {
        if (!oldclasses || !newclasses) {
            return;
        }
        return {
            added: this.getClassDetails(this.detectAddedKeys(oldclasses, newclasses)),
            removed: this.getClassDetails(this.detectRemovedKeys(oldclasses, newclasses)),
            updated: this.getUpdatedObj(oldclasses, newclasses, false)
        };
    }

    getUpdatedObj(oldobj, newobj, isinterface) {
        if (!oldobj || !newobj || isinterface === null || isinterface === undefined) {
            return;
        }
        let updatedClasses = [];
        for (let objchange of this.detectValueChange(oldobj, newobj)) {
            if (objchange) {
                let objname = objchange.key ? objchange.key : '';
                let oldvalue = objchange.oldvalue ? objchange.oldvalue : {};
                let newvalue = objchange.newvalue ? objchange.newvalue : {};
                let changes = {
                    Properties: oldvalue.apis && newvalue.apis ? this.getAPIChanges(oldvalue.apis, newvalue.apis) : {},
                    Methods: oldvalue.methods && newvalue.methods ? this.getMethodChanges(oldvalue.methods, newvalue.methods) : {},
                    Events: oldvalue.events && newvalue.events ? this.getEventChanges(oldvalue.events, newvalue.events) : {}
                };
                let namekey = isinterface ? 'InterfaceName' : 'ClassName';
                changes[namekey] = objname;
                updatedClasses.push(changes);
            }
        }
        return updatedClasses;
    }

    getInterfaceChanges(oldvalue, newvalue) {
        if (!oldvalue || !newvalue) {
            return;
        }
        return {
            added: this.getInterfaceDetails(this.detectAddedKeys(oldvalue, newvalue)),
            removed: this.getInterfaceDetails(this.detectRemovedKeys(oldvalue, newvalue)),
            updated: this.getUpdatedObj(oldvalue, newvalue, true)
        };
    }

    getAPIChanges(oldvalue, newvalue) {
        if (!oldvalue || !newvalue) {
            return;
        }
        return {
            added: this.getAddedProperties(this.detectAddedKeys(oldvalue, newvalue)),
            removed: this.getRemovedProperties(this.detectRemovedKeys(oldvalue, newvalue)),
            updated: this.getUpdatedProperties(this.detectValueChange(oldvalue, newvalue))
        };
    }

    getMethodChanges(oldvalue, newvalue) {
        if (!oldvalue || !newvalue) {
            return;
        }
        return {
            added: this.getAddedMethods(this.detectAddedKeys(oldvalue, newvalue)),
            removed: this.getRemovedMethods(this.detectRemovedKeys(oldvalue, newvalue)),
            updated: this.getUpdatedMethods(this.detectValueChange(oldvalue, newvalue))
        };
    }

    getEventChanges(oldvalue, newvalue) {
        if (!oldvalue || !newvalue) {
            return;
        }
        return {
            added: this.getAddedEvents(this.detectAddedKeys(oldvalue, newvalue)),
            removed: this.getRemovedEvents(this.detectRemovedKeys(oldvalue, newvalue)),
            updated: this.getUpdatedEvents(this.detectValueChange(oldvalue, newvalue))
        };
    }

    //getting removed properties of module object
    getRemovedProperties(removed) {
        if (!removed) {
            return;
        }
        let removedProperties = [];
        for (let remove of removed) {
            removedProperties.push({
                PropertyName: remove && remove.key ? remove.key : '',
                PropertyType: remove && remove.value ? remove.value.type : null,
                DefaultValue: remove && remove.value && remove.value.defaultvalue ? remove.value.defaultvalue : null
            });
        }
        return removedProperties;
    }

    //getting added properties of module object
    getAddedProperties(added) {
        if (!added) {
            return;
        }
        let addedProperties = [];
        for (let add of added) {
            addedProperties.push({
                PropertyName: add && add.key ? add.key : '',
                PropertyType: add && add.value ? add.value.type : null,
                DefaultValue: add && add.value && add.value.defaultvalue ? add.value.defaultvalue : null
            });
        }
        return addedProperties;
    }

    //getting updated properties of module object
    getUpdatedProperties(updates) {
        if (!updates) {
            return;
        }
        let updatedProperties = [];
        for (let update of updates.filter(u => u)) {
            let oldvalue = update && update.oldvalue ? update.oldvalue : {};
            let newvalue = update && update.newvalue ? update.newvalue : {};
            let updatedelements = this.detectValueChange(oldvalue, newvalue);
            for (let updatedelement of updatedelements) {
                updatedProperties.push({
                    PropertyName: update && update.key ? update.key : '',
                    UpdateElement: updatedelement && updatedelement.key ? updatedelement.key : '',
                    OldValue: updatedelement && updatedelement.oldvalue ? updatedelement.oldvalue : {},
                    NewValue: updatedelement && updatedelement.newvalue ? updatedelement.newvalue : {}
                });
            }
        }
        return updatedProperties;
    }

    //getting removed methods of module object
    getRemovedMethods(removed) {
        if (!removed) {
            return;
        }
        let removedMethods = [];
        for (let remove of removed) {
            removedMethods.push({
                MethodName: remove && remove.key ? remove.key : '',
                ReturnType: remove && remove.value ? remove.value.type : null,
                Parameters: remove && remove.value && remove.value.parameters ? remove.value.parameters : null
            });
        }
        return removedMethods;
    }

    //getting added methods of module object
    getAddedMethods(added) {
        if (!added) {
            return;
        }
        let addedMethods = [];
        for (let add of added) {
            addedMethods.push({
                MethodName: add && add.key ? add.key : '',
                ReturnType: add && add.value ? add.value.type : null,
                Parameters: add.value && add.value.parameters ? add.value.parameters : []
            });
        }
        return addedMethods;
    }

    //getting upated methods of module object
    getUpdatedMethods(updates) {
        if (!updates) {
            return;
        }
        let updatedMethods = [];
        for (let update of updates.filter(u => u)) {
            let oldvalue = update && update.oldvalue ? update.oldvalue : {};
            let newvalue = update && update.newvalue ? update.newvalue : {};
            let changes = this.detectValueChange(oldvalue, newvalue);
            for (let change of changes) {
                updatedMethods.push({
                    MethodName: update && update.key ? update.key : '',
                    UpdateElement: change && change.key ? change.key : '',
                    OldValue: change && change.oldvalue ? change.oldvalue : {},
                    NewValue: change && change.newvalue ? change.newvalue : {}
                });
            }
        }
        return updatedMethods;
    }

    //getting removed events of module object
    getRemovedEvents(removed) {
        if (!removed) {
            return;
        }
        let removedEvents = [];
        for (let remove of removed) {
            removedEvents.push({
                EventName: remove && remove.key ? remove.key : '',
                EventType: remove && remove.value && remove.value.type ? remove.value.type : null
            });
        }
        return removedEvents;
    }

    //getting added events of module object
    getAddedEvents(removed) {
        if (!removed) {
            return;
        }
        let addedEvents = [];
        for (let remove of removed) {
            addedEvents.push({
                EventName: remove && remove.key ? remove.key : '',
                EventType: remove && remove.value && remove.value.type ? remove.value.type : null
            });
        }
        return addedEvents;
    }

    //getting updated events of module object
    getUpdatedEvents(updates) {
        if (!updates) {
            return;
        }
        let updatedEvent = [];
        for (let update of updates.filter(u => u)) {
            let oldeventvalue = update && update.oldvalue ? update.oldvalue : {};
            let neweventvalue = update && update.newvalue ? update.newvalue : {};
            let updatedelements = this.detectValueChange(oldeventvalue, neweventvalue);
            for (let updatedelement of updatedelements) {
                updatedEvent.push({
                    EventName: update && update.key ? update.key : '',
                    UpdateElement: updatedelement && updatedelement.key ? updatedelement.key : '',
                    OldValue: updatedelement && updatedelement.oldvalue ? updatedelement.oldvalue : {},
                    NewValue: updatedelement && updatedelement.newvalue ? updatedelement.newvalue : {}
                });
            }
        }
        return updatedEvent;
    }

}

module.exports = compareJSON;
