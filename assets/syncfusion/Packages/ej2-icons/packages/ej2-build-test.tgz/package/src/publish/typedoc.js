'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var common = global.config = global.config || require('../utils/common.js');
var currentPackage = common.currentPackage;
var cdn = require('./cdn.js');
var gzip = require('gulp-gzip');
var fs = require('fs');

/**
 * publish typedoc contents
 */
gulp.task('publish-typedoc', function (done) {
    var api = common.isMasterBranch ? './production/api/' : './development/api/';
    var apiPath = api + currentPackage;
    var prefixName = apiPath.split('./')[1];
    shelljs.mkdir('-p', apiPath);
    var content = '<h1> 404 - Not Found </h1>';
    fs.writeFileSync('./public/api/error.html', content);
    // update api doc location with latest api changes
    gulp.src(['./public/api/**/*'])
        .pipe(gzip({ append: false }))
        .pipe(gulp.dest(apiPath))
        .on('end', function () {
            cdn.publish(apiPath, false, prefixName, done);
        })
        .on('error', function (e) {
            done(e);
        });
});