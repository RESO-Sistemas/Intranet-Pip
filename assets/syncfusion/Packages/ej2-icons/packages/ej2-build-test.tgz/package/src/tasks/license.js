/* jshint ignore:start */
let gulp = global.gulp = global.gulp || require('gulp');
let common = global.config = global.config || require('../utils/common.js');

// Task to hide the license banner in the base library files
gulp.task('hide-license', function (done) {
  try{
    let patternArray = ['//# sourceMappingURL=ej2-base.umd.min.js.map','it.validate()', 'licenseValidator.validate()', 'licenseValidator.validate()', 'licenseValidator.validate()'];
    let replacePatternData = [`var bypassKey = [115, 121, 110, 99, 102, 117, 115, 105, 111, 110, 46, 105, 115, 76, 105, 99, 86, 97, 108, 105, 100, 97, 116, 101, 100];
    function convertToChar(cArr) { var ret = ''; for (var _i = 0, cArr_1 = cArr; _i < cArr_1.length; _i++) { var arr = cArr_1[_i]; ret += String.fromCharCode(arr); } return ret; }
    window[convertToChar(bypassKey).split('.')[0]] = {}; window[convertToChar(bypassKey).split('.')[0]][convertToChar(bypassKey).split('.')[1]] = true;
    //# sourceMappingURL=ej2-base.umd.min.js.map`, 'true', 'true', 'true', 'true']
    let pathArray = [
      require.resolve('@syncfusion/ej2-base/dist/ej2-base.umd.min.js'),
      require.resolve('@syncfusion/ej2-base/dist/ej2-base.umd.min.js'),
      require.resolve('@syncfusion/ej2-base/dist/es6/ej2-base.es5.js'),
      require.resolve('@syncfusion/ej2-base/dist/es6/ej2-base.es2015.js'),
      require.resolve('@syncfusion/ej2-base/src/validate-lic.js')
    ];

    for (let i in pathArray) { replaceStringInFile(pathArray[i], patternArray[i], replacePatternData[i]); }

  } catch (error) { if (error) console.log('Gulp task to hide license ', error); }
  done();
});

// Task to hide the license banner in the native-react base library files
gulp.task('react-hide-license', function (done) {
    if (common.currentRepo !== "ej2-native-react-base") {
        try {
            let pattern = 'licenseValidator.validate()';
            let replacePattern = 'true'
            let filePath = require.resolve('@syncfusion/react-base/src/validate-lic.js');

            replaceStringInFile(filePath, pattern, replacePattern);

        } catch (error) { if (error) console.log('Gulp task to hide license ', error); }
    }
    done();
});

/**
 * Replace the first occurence of the pattern in the inputFile
 * @param {string} filePath - Input file path
 * @param {string} pattern - String pattern that to be replaced in inputFile
 * @param {string} replaceString - String that need to replace inputFile
 */
function replaceStringInFile(filePath, pattern, replaceString) {
  try {
    if (fs.existsSync(filePath)) { const data = fs.readFileSync(filePath, 'utf8');
      if (data && pattern && replaceString && data.includes(pattern)) {
        fs.writeFileSync(filePath, data.replace(pattern, replaceString), 'utf8');
      }
    }
  } catch (error) { if (error) console.log('replaceStringInFile function: ', error); }
}
exports.replaceStringInFile = replaceStringInFile;
/* jshint ignore:end */
