'use strict';

var fs = global.fs = global.fs || require('fs');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var gulp= global.gulp = global.gulp || require('gulp');

gulp.task('code-leaks-analysis', function (done) {
if(fs.existsSync('./GitLeaksReport.json')) {
    var codeLeaksReport = JSON.parse(fs.readFileSync('GitLeaksReport.json'));
    if (Object(codeLeaksReport).length <= 0) {
        console.log('<- No Leaks Found ->');
        shelljs.exec('rm GitLeaksReport.json');
    } 
}
    // commented this line temprovarily once component team completed changes we will uncomment the changes
    //else {
      //  throw "Please clear the Git Leaks reported issues";
    //}
    done();
});
