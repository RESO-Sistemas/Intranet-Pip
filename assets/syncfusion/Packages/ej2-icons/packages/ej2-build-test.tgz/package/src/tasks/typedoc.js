'use strict';

// Node JS global scope
var gulp = global.gulp = global.gulp || require('gulp');
global.config = global.config || require('../utils/common.js');
var config = global.config.config();

gulp.task('typedoc', function (done) {
    var typedoc = require('gulp-typedoc');
    gulp.src(config.typedoc)
        .pipe(typedoc({
            // TypeScript options (see typescript docs) 
            module: 'amd',
            target: 'es5',
            moduleResolution: 'node',
            includeDeclarations: true,
            emitDecoratorMetadata: true,
            experimentalDecorators: true,


            // Output options (see typedoc docs) 
            out: './public/api',
            json: './public/api/file.json',

            // TypeDoc options (see typedoc docs) 
            name: 'Syncfusion TypeScript',
            ignoreCompilerErrors: true,
            version: true,
            theme: 'minimal',
            excludeExternals: true,
            excludeNotExported: true,
            stripInternal: true
        }))
        .on('end', function () {
            gulp.src('./readme/*.*')
                .pipe(gulp.dest('./public/api/readme'))
                .on('end', function () { done(); })
                .on('error', function (e) { done(e); });
        })
        .on('error', function (e) {
            done(e);
        });
});
