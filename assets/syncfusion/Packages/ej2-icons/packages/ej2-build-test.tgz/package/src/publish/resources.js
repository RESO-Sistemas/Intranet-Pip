'use strict';

var fs = global.fs = global.fs || require('fs');
var gulp = global.gulp = global.gulp || require('gulp');
var path = global.path = global.path || require('path');
var common = global.config = global.config || require('../utils/common.js');
var config = common.config();
var build = require('../tasks/build.js');
var packageName, resourcePath;
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var resourcesPackages = ['ej2-charts', 'ej2-circulargauge', 'ej2-lineargauge', 'ej2-maps', 'ej2-markdown-converter'];
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');

gulp.task('publish-resources', function (done) {
    runSequence('resource-compile');
    if (!fs.existsSync('./styles/') && resourcesPackages.indexOf(common.currentPackage) === -1) {
        done();
        return;
    }

    shelljs.rm('-rf', './ej2-resources');
    var branchName = process.env.githubSourceBranch;
    var simpleGit = require('simple-git');
    if (!fs.existsSync('./ej2-resources')) {
        fs.mkdirSync('./ej2-resources');

        // clone components repository  
        var user = 'SyncfusionAutomation';
        var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
        var ej2Resources = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-resources.git';
        simpleGit().clone(ej2Resources, './ej2-resources', function (err) {
            if (err) {
                done(err);
                return;
            }
        }).exec(function () {
            simpleGit('./ej2-resources').checkout(branchName, function (err) {
                if (err) {
                    done(err);
                    return;
                }
                /**
                 * publish locale object to ej2-resource
                 */

                if (fs.existsSync('./config.json')) {
                    if (config.locale) {
                        if (!fs.existsSync('./ej2-resources/locale.json')) {
                            fs.writeFile('./ej2-resources/locale.json', JSON.stringify(config.locale, null, 4));
                        }
                        else {
                            var localeJson = JSON.parse(fs.readFileSync('./ej2-resources/locale.json'));
                            var obj = Object.assign(localeJson, config.locale);
                            fs.writeFileSync('./ej2-resources/locale.json', JSON.stringify(obj, null, 4));
                        }
                    }

                }
                //CRG Resources

                var dynamicModules = {};
                var dComps = [];
                var blazorConfigs = {};
                if (fs.existsSync('./third-party/config.json')) {
                    var dynamicComps = JSON.parse(fs.readFileSync('./third-party/config.json', 'utf8')).components;
                    for (var dynamicComp of dynamicComps) {
                        var baseClass = dynamicComp.baseClass;
                        var blazorConfig = {};
                        if (baseClass && dynamicComp.dynamicModules) {
                            dComps.push(baseClass);
                            dynamicModules[baseClass] = dynamicComp.dynamicModules;
                        }
                        if (dynamicComp.blazorType) {
                            blazorConfig.blazorType = dynamicComp.blazorType;
                        }
                        if (dynamicComp.blazorDependency) {
                            blazorConfig.blazorDependency = dynamicComp.blazorDependency;
                        }
                        if (Object.keys(blazorConfig).length) {
                            blazorConfigs[baseClass] = blazorConfig;
                        }
                    }
                }

                var dependables = config.dependable;
                var resources = {};
                if (dependables) {
                    if (fs.existsSync('./ej2-resources/resources.json')) {
                        resources = JSON.parse(fs.readFileSync('./ej2-resources/resources.json'));
                    }
                    var depComps = Object.keys(dependables);
                    for (var depComp of depComps) {
                        var comp = dependables[depComp];
                        comp.package = common.currentPackage;
                        if (dComps.indexOf(comp.classname) !== -1) {
                            comp.injectables = dynamicModules[comp.classname];
                        }
                        if (blazorConfigs[comp.classname]) {
                            Object.assign(comp, blazorConfigs[comp.classname]);
                            if (config.blazorNamespace) {
                                comp.blazorNamespace = config.blazorNamespace;
                            }
                        }
                        resources[depComp] = comp;
                    }
                    var retResources = {};
                    for (var res of Object.keys(resources).sort()) {
                        retResources[res] = resources[res];
                    }
                    fs.writeFileSync('./ej2-resources/resources.json', JSON.stringify(retResources, null, 4), 'utf8');
                }

                shelljs.rm('-rf', './ej2-resources/scripts/' + common.currentPackage);
                shelljs.cp('-R', './ej2-resources-scripts/' + common.currentPackage, './ej2-resources/scripts');
                shelljs.rm('-rf', './ej2-resources-scripts/');

                // Generating styles for ej2-resources

                var styleConfig = './styles/*.scss';
                var ignoreConfig = './styles/**/_*.scss';
                if (config.styleDependency !== 'none' && config.styleDependency.length) {
                    styleConfig = './styles/**/*.scss';
                    ignoreConfig = ['./styles/**/_*.scss', './styles/*.scss'];
                }
                if (common.currentPackage === 'ej2-base') {
                    ignoreConfig = './styles/**/_*.scss';
                }
                packageName = common.currentPackage.replace('ej2-', '');
                var glob = global.glob = global.glob || require('glob');
                glob.sync('./styles/*/!(*-lite|_*).scss').forEach((file) => {
                    var liteContent = fs.readFileSync(file, 'utf8');
                    liteContent = liteContent.replace(`@import 'bigger.scss';`, '');
                    fs.writeFileSync(file.replace('.scss', '-lite.scss'), liteContent, 'utf8');
                });
                var styleFiles = glob.sync('./styles/**/*.scss', { ignore: ignoreConfig });
                resourcePath = './ej2-resources/styles/' + common.currentPackage.replace('ej2-', '') + '/';
                shelljs.mkdir('-p', resourcePath);
                for (var i = 0; i < styleFiles.length; i++) {
                    var styles = getStyles(styleFiles[i]);
                    var destPath = '';
                    if (config.styleDependency.length) {
                        var dirName = path.dirname(styleFiles[i]);
                        var dirSplitted = dirName.split('/');
                        var component = dirSplitted[dirSplitted.length - 1];
                        shelljs.mkdir('-p', resourcePath + component);
                        destPath = resourcePath + component + '/' + path.basename(styleFiles[i]);
                    } else {
                        destPath = resourcePath + path.basename(styleFiles[i]);
                    }
                    fs.writeFileSync(destPath, styles);
                }

                // // Copy ES6 files in the ej2-resources
                // var es6Path = './ej2-resources/src/' + common.currentPackage.replace('ej2-', '') + '/';
                // var es6DestPath = './dist/es6/' + common.currentPackage + '.es5.js';
                // shelljs.mkdir('-p', es6Path);
                // if (fs.existsSync(es6DestPath)) {
                //     shelljs.cp('-f', es6DestPath, es6Path + common.currentPackage + '.es5.js');
                //     shelljs.cp('-f', es6DestPath, es6Path + common.currentPackage + '.es5.js.map');
                // }

                shelljs.cd('./ej2-resources/');
                var jsonpath = './styles.json';
                var deps = {};
                if (fs.existsSync(jsonpath)) {
                    deps = JSON.parse(fs.readFileSync(jsonpath, 'utf8'));
                }
                deps[packageName] = config.styleDependency;
                fs.writeFileSync(jsonpath, JSON.stringify(deps, null, 4));
                shelljs.exec('git add .', { silent: true });
                var changes = shelljs.exec('git diff ' + branchName).stdout;
                if (!changes.length) {
                    shelljs.cd('../');
                    console.log('There are no changes in ' + common.currentPackage + ' styles');
                    done();
                    return;
                }

                shelljs.cd('../');
                // push updated component src and styles to components repository            
                simpleGit('./ej2-resources').init()
                    .add('./*')
                    .commit(common.currentPackage + ' - styles refreshed in ej2-resources')
                    .pull(branchName)
                    .push(ej2Resources, branchName, function () {
                        console.log(common.currentPackage + ' - styles refreshed in ej2-resources');
                        done();
                    });
            });
        });
    }

});

gulp.task('resource-compile', function (done) {
    if (!fs.existsSync('./tsconfig.json')) {
        done();
        return;
    }
    var tsConfigs = {
        target: 'es5',
        module: 'es6',
        lib: ['es5', 'es6', 'es2015.collection', 'es2015.core', 'dom'],
        types: ['jasmine', 'jasmine-ajax', 'requirejs', 'chai'],
        removeComments: true
    };
    console.log('tsConfig: ' + JSON.stringify(tsConfigs));
    var gulpObj = {
        src: ['./src/**/*.ts', './src/**/*.tsx', '!./**/*model.d.ts'],
        dest: './ej2-resources-scripts/' + common.currentPackage + '/',
        base: 'src'
    };
    console.log('tsConfig: ' + JSON.stringify(gulpObj));
    build.compileTSFiles(tsConfigs, gulpObj, function () {
        console.log('Compile TS Files Build function completed');
        if (fs.existsSync('./blazor/')) {
            gulpObj = {
                src: ['./blazor/**/*.ts'],
                dest: './ej2-resources-scripts/' + common.currentPackage + '/blazor/',
                base: 'blazor'
            };
            build.compileTSFiles(tsConfigs, gulpObj, done);
            console.log('Compile TS Files Build function completed for Blazor');
        } else {
            done();
        }
    });
});
function getStyles(filePath) {
    var styles = '';
    var importedPath = '';
    var depImported = '';
    var nextdepImported = '';
    var styleContent = fs.readFileSync(filePath, 'utf8');
    var regex = new RegExp('@import \'(.*).scss\';', 'g');
    var importedStyles = styleContent.match(regex);
    if (!importedStyles) {
        return styleContent;
    }
    for (var i = 0; i < importedStyles.length; i++) {
        var importedFile = importedStyles[i].replace('@import \'', '').replace('\';', '');
        if (importedFile.startsWith('ej2-') || importedFile.startsWith('../')) {
            continue;
        }
        var dirName = path.dirname(filePath) + '/';
        if (!fs.existsSync(dirName + importedFile)) {
            var splitted = importedFile.split('/');
            var lastIndex = splitted.length - 1;
            splitted[lastIndex] = '_' + splitted[lastIndex];
            importedFile = splitted.join('/');
        }
        var definitionpath = importedFile.split('/')[0];
        var filename = importedFile.split('/')[1];
        if (packageName === 'base' && definitionpath === 'definition') {
            importedPath = dirName + importedFile;
            depImported = fs.readFileSync(importedPath, 'utf8').trim();
            var filepath = resourcePath + '/definition';
            shelljs.mkdir('-p', filepath);
            filename = filepath + '/' + filename;
            fs.writeFileSync(filename, depImported);
        } else {
            importedPath = dirName + importedFile;
            depImported = fs.readFileSync(importedPath, 'utf8').trim();
            if (depImported.match(regex)) {
                nextdepImported = depImported.replace(depImported.match(regex)[0], '').trim();
                depImported = getStyles(dirName + importedFile);
                if (nextdepImported.match(regex)) {
                    nextdepImported = '';
                }
                if (nextdepImported !== null) {
                    depImported += '\n' + nextdepImported;
                }
            }
            styles += '\n' + depImported;

        }

    }
    return styles;
}
