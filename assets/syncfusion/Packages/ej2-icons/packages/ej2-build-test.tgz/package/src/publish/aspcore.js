'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var path = require('path');
var fs = global.fs = global.fs || require('fs');
var common = global.config = global.config || require('../utils/common.js');
var simpleGit = global.simpleGit = global.simpleGit || require('simple-git');
var currentPackage = common.currentPackage;
var glob = require('glob');

gulp.task('aspcore-publish', function (done) {
    if (fs.existsSync('./third-party/asp-core')) {
        var user = 'SyncfusionAutomation';
        var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
        var stageBranch = common.isMasterBranch ? 'master' : 'development';
        stageBranch = common.isReleaseBranch ? process.env.githubSourceBranch : stageBranch;
        stageBranch = common.isHotfixBranch ? process.env.githubSourceBranch : stageBranch;
        var ej2aspRepo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-asp-core.git';
        simpleGit('./third-party/asp-core').init()
            .add('.')
            .commit('(EJ2-000): ' + currentPackage + ' aspcore properties published')
            .push(ej2aspRepo, stageBranch, function () {
                console.log(currentPackage + ' - source published into ej2-asp-core repo - ' + stageBranch);
                done();
            });

    } else {
        done();
    }
});

gulp.task('asp-generate-projectfile', function (done) {
    var str = '';
    var csFiles = glob.sync('./third-party/asp-core/src/**/*.cs', {
        silent: true, ignore: ['third-party/asp-core/src/Base/ContentTemplate.cs',
            'third-party/asp-core/src/Base/HtmlExtention.cs', 'third-party/asp-core/src/obj/**/*.cs',
            'third-party/asp-core/src/bin/**/*.cs', 'third-party/asp-core/src/*.cs', 'third-party/asp-core/src/SmartComponents/**/*.cs', 'third-party/asp-core/src/Base/SmartComponents/*.cs']
    });
    for (var m = 0; m < csFiles.length; m++) {
        var normalizedFileName = path.normalize(csFiles[m]);
        var fileName = normalizedFileName.replace(path.normalize('third-party/asp-core/src/'), '');
        //console.log("FileName ---> " + fileName);
        str = str + '<Compile Include="' + fileName.replace(/\//g, '\\') + '" />\n';
        //console.log("Str ---> " + str);
    }
    //var mvc4csproj = fs.readFileSync('./third-party/asp-core/src/Syncfusion.EJ2_MVC4.csproj', 'utf8');
    //mvc4csproj = mvc4csproj.replace(/<!--#START-->([^]*)<!--#STOP-->/g, '<!--#START-->\n' + str + '<!--#STOP-->');
   // fs.writeFileSync('./third-party/asp-core/src/Syncfusion.EJ2_MVC4.csproj', mvc4csproj);
    //console.log("Str ---> " + str);
    var mvc5csproj = fs.readFileSync('./third-party/asp-core/src/Syncfusion.EJ2_MVC5.csproj', 'utf8');
    mvc5csproj = mvc5csproj.replace(/<!--#START-->([^]*)<!--#STOP-->/g, '<!--#START-->\n' + str + '<!--#STOP-->');
    fs.writeFileSync('./third-party/asp-core/src/Syncfusion.EJ2_MVC5.csproj', mvc5csproj);
    //console.log("Str ---> " + str);
    done();
});
