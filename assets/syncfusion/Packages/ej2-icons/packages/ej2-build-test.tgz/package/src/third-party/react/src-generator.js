'use strict';
var packJson;
var fs = global.fs = global.fs || require('fs');
var directiveTemplate = '\n    public directivekeys: { [key: string]: Object } = {{directiveValue}};';
var attrTemplate = '\n    private controlAttributes: string[] = {cattrs};';
var compTemplate = '\n    public static complexTemplate: Object = {{complexprop}};';
var skipTemplate = '\n    private skipRefresh: string[] = {{skipattr}};';
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var defautRenderer = `React.createElement('{{tagName}}', this.getDefaultAttributes(),[].concat(this.props.children,this.portals))`;
var inputRenderer  = `React.createElement((React as any).Fragment, null,[].concat(React.createElement("{{tagName}}", this.getDefaultAttributes()),this.portals))`;
var hasTemplate;
/**
 * util functions
 */

function toInitCap(str) {
    return str.replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1);
    });
}

function toInitLower(str) {
    return str.replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toLowerCase() + txt.substr(1);
    });
}

function getJsonString(obj) {
    return JSON.stringify(obj).replace(/\"/g, '\'').replace(/,/g, ', ').replace(/:/g, ': ');
}

function setComplexTemplate(ioptions) {
    if (ioptions.changedKeys) {
        return compTemplate.replace(/{{complexprop}}/g, ioptions.changedKeys).replace(/"/g, '\'');
    }
    return '';
}
/**
 * React source generator class
 */
class ReactSourceGen {

    constructor(config, packInfo, done) {
        this.allIndex = [];
        this.comIndex = [];
        this.srcIndex = [];
        this.allComponents = [];
        this.hasInjected = false;
        packJson = packInfo;
        this.srcPath = './third-party/react/src/';
        this.render(config, done);
        return this;
    }

    render(config, done) {
        for (var comp of config.components) {
            if (comp.isBlazorOnly) {
                continue;
            }
            var cnt;
            if(comp.reactType === 'hybrid') {
                cnt = fs.readFileSync(__dirname + '/' + 'component-template-hybrid').toString();
            }
            else {
                cnt = fs.readFileSync(__dirname + '/' + 'component-template').toString();
            }
            var dirName = comp.directoryName || '';
            var diVal;
            var retVal;
            var fileName = comp.baseClass.toLowerCase() + '.component';
            this.pushValueToArray(this.allIndex, 'export * from \'./' + dirName + '\';');
            retVal = this.generateComponent(cnt, comp, dirName);
            diVal = this.generateComponent(cnt, comp, dirName);
            this.writeFile(this.srcPath + dirName + '/' + fileName + '.tsx', retVal.content);
            for (var com of retVal.refLocalIndex) {
                this.comIndex.push(com);
            }
            for (var diIndex of retVal.diLocalIndex) {
                this.srcIndex.push(diIndex);
            }
            this.pushValueToArray(retVal.localIndex, 'export * from \'./' + fileName + '\';');
            this.writeFile(this.srcPath + dirName + '/index.ts', retVal.localIndex.join('\n').replace(/{{dir}}/g, ''));
        }
        if (this.hasInjected) {
            this.allIndex.push('export { Inject } from \'@syncfusion/ej2-react-base\';');
        }
        this.allIndex.push('export * from \'' + packJson.name + '\';');
        this.comIndex.push('export { Inject } from \'@syncfusion/ej2-react-base\';');
        this.srcIndex.push('export { Inject } from \'@syncfusion/ej2-react-base\';');
        this.writeFile(this.srcPath + 'index.ts', this.allIndex.join('\n').replace(/{{dir}}/g, ''));
        var readConfig = fs.readFileSync('./third-party/config.json', 'utf8');
        this.writeFile('./third-party/react/diConfig.json', readConfig);
        done();
    }



    generateComponent(cnt, comp, directoryName) {
        var localIndex = [];
        var refLocalIndex = [];
        var diLocalIndex = [];
        var comment = '';
        var customkeys = '';
        var hasInjected = false;
        hasTemplate = false;
        var customAttributes = {};
        var dirObject = {};
        var dirkey = '';
        var preventRefresh = '';
        if (comp.reactComment) {
            comment = comp.reactComment.join('\n');
        }

        if (comp.dynamicModules) {
            this.hasInjected = true;
            hasInjected = true;
        }
        if (comp.controlAttributes) {
            customAttributes = this.generateInterface(comp.controlAttributes, comp.baseClass);
        }
        var overrideInterface = {};
        if (comp.templateProperties) {
            hasTemplate = true;
            overrideInterface = this.getTemplateTypeOverRide(comp.templateProperties, comp.baseClass);

        }
        cnt = cnt.replace(/{{templateinterface}}/g, overrideInterface.iface || '');
        cnt = cnt.replace(/{{templateOverride}}/g, overrideInterface.iname || '');
        cnt = cnt.replace(/{{controlAttributes}}/g, customAttributes.iface || '');
        cnt = cnt.replace(/{{attributeInterface}}/g, customAttributes.iname ? ' & ' + customAttributes.iname : '');
        if (customAttributes.iKeys) {
            customkeys = attrTemplate.replace(/{cattrs}/g, customAttributes.iKeys);
        }
        var renderer = (!['input', 'textarea'].includes(comp.reactPreferredTag || comp.preferredTag) ? defautRenderer : inputRenderer);
      
        cnt = cnt.replace(/{{renderer}}/g, renderer);
        cnt = cnt.replace(/{{tagName}}/g, (comp.reactPreferredTag || comp.preferredTag || 'div'));
        cnt = cnt.replace(/{{attributemapper}}/g, customkeys);
        cnt = cnt.replace(/{{hasInjected}}/g, hasInjected);
        cnt = cnt.replace(/{{baseClass}}/g, comp.baseClass);
        cnt = cnt.replace(/{{componentComments}}/g, comment);
        cnt = cnt.replace(/{{packageName}}/g, packJson.name);
        // The 'statelessTemplateProps' value is updated from the component config file
        cnt = cnt.replace(/{{statelessTemplateProps}}/g, comp.statelessTemplateProps ? JSON.stringify(comp.statelessTemplateProps) : 'null');
        // The 'templateProps' property values were updated from the component config file
        cnt = cnt.replace(/{{templateProps}}/g, comp.templateProps ? JSON.stringify(comp.templateProps) : 'null');
        if (comp.preventRefresh) {
            preventRefresh = skipTemplate.replace(/{{skipattr}}/g,
                JSON.stringify(comp.preventRefresh).replace(/\"/g, '\'').replace(/,/g, ', '));
        }
        cnt = cnt.replace(/{{skipRefresh}}/g, preventRefresh);
        if (comp.tagDirective) {
            this.generateDirective(comp.tagDirective, dirObject, localIndex, refLocalIndex, diLocalIndex, directoryName);
        }
        if (Object.keys(dirObject).length) {
            var dirVal = getJsonString(dirObject);
            dirkey = directiveTemplate.replace(/{{directiveValue}}/g, dirVal);
        }
        cnt = cnt.replace(/{{directiveKeys}}/g, dirkey);
        cnt = cnt.replace(/{{immediateRender}}/g, !hasTemplate);
        return {
            content: cnt,
            localIndex: localIndex,
            refLocalIndex: refLocalIndex,
            diLocalIndex: diLocalIndex
        };
    }

    generateDirective(configCollection, dirObject, localMapper, refLocalMapper, diLocalMapper, dirName) {
        for (var config of configCollection) {
            var tagCnt = fs.readFileSync(__dirname + '/' + 'directive-template').toString();
            var comment = '';
            if (config.reactComment) {
                comment = config.reactComment.join('\n');
            }
            var fName = (config.fileName || config.propertyName.toLowerCase()) + '-directive';
            var directory = config.directoryName || dirName;
            var dirTypeOverride = {};
            if (config.templateProperties) {
                hasTemplate = true;
                dirTypeOverride = this.getTemplateTypeOverRide(config.templateProperties, config.baseClass + 'Dir');
            }
            tagCnt = tagCnt.replace(/{{complexTemplate}}/g, setComplexTemplate(dirTypeOverride));
            tagCnt = tagCnt.replace(/{{templateDirinterface}}/g, dirTypeOverride.iface || '');
            tagCnt = tagCnt.replace(/{{dirTemplateOverride}}/g, dirTypeOverride.iname || '');
            tagCnt = tagCnt.replace(/{{className}}/g, config.baseClass);
            tagCnt = tagCnt.replace(/{{packageName}}/g, packJson.name);
            tagCnt = tagCnt.replace(/{{arrClassName}}/g, toInitCap(config.arrayDirectiveClassName));
            tagCnt = tagCnt.replace(/{{directiveName}}/g, toInitCap(config.directiveClassName));
            tagCnt = tagCnt.replace(/{{propName}}/g, config.propertyName);
            tagCnt = tagCnt.replace(/{{tagComment}}/g, comment);
            var arrDir = toInitLower(config.arrayDirectiveClassName);
            var dir = toInitLower(config.directiveClassName);
            tagCnt = tagCnt.replace(/{{ModuleName}}/g, dir);
            tagCnt = tagCnt.replace(/{{arrayModuleName}}/g, arrDir);
            this.writeFile(this.srcPath + directory + '/' + fName + '.tsx', tagCnt);
            this.pushValueToArray(localMapper, 'export * from \'./' + fName + '\';');
            this.pushValueToArray(refLocalMapper, 'export * from \'./' + dirName + '/' + fName + '\';');
            this.pushValueToArray(diLocalMapper, 'export * from \'./src/' + dirName + '/' + fName + '\';');
            if (config.tagDirective) {
                dirObject[arrDir] = {};
                dirObject[arrDir][dir] = {};
                this.generateDirective(config.tagDirective, dirObject[arrDir][dir], localMapper, refLocalMapper, diLocalMapper, dirName);
            } else {
                dirObject[arrDir] = dir;
            }
        }

    }
    getTemplateTypeOverRide(templates, name) {
        var iTemplate = templates.filter(function (val) {
            return (typeof val === 'string');
        });
        var res = this.generateInterface(iTemplate, name + 'Typecast', true);
        res.iname = '| ' + res.iname;
        return res;
    }
    generateInterface(attrs, className, isoverride) {
        let ret = {};
        let keys = isoverride ? attrs : Object.keys(attrs);
        let iface = '';
        let localKeys = [];
        let nestedKeys = [];
        let changedKeys = {};
        var iskeyChanged = false;
        for (let key of keys) {
            var aKey = key;
            if (/\./g.test(aKey)) {
                iskeyChanged = true;
                aKey = toInitLower(aKey.split('.')[0]);
                changedKeys[key] = key;
                if (nestedKeys.indexOf(aKey) === -1) {
                    iface += '    ' + aKey + '?: ' + (isoverride ? 'any' : attrs[aKey].replace(/"/g, '')) + ';\n';
                    nestedKeys.push(aKey);
                }
            } else {
                iface += '    ' + aKey + '?: ' + (isoverride ? 'string | Function | any' : attrs[aKey].replace(/"/g, '')) + ';\n';
            }
            localKeys.push('\'' + key + '\'');
        }
        if (iskeyChanged) {
            ret.changedKeys = getJsonString(changedKeys);
        }
        ret.iname = isoverride ? className : (className + 'HtmlAttributes');
        ret.iface = 'export interface ' + ret.iname + ' {\n' + iface + '}';
        ret.iKeys = '[' + localKeys.join(', ') + ']';
        return ret;
    }

    writeFile(path, content) {
        var arPath = path.split('/');
        arPath.pop();
        shelljs.mkdir('-p', arPath.join('/'));
        fs.writeFileSync(path, content, 'utf8');
    }

    pushValueToArray(array, value) {
        if (array.indexOf(value) === -1) {
            array.push(value);
        }
    }
}

module.exports = function (config, packInfo, done) {
    return new ReactSourceGen(config, packInfo, done);
};
