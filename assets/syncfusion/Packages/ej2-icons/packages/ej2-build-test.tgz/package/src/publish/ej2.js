'use strict';

var registry = require('../tasks/registry.js');
var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var fs = global.fs = global.fs || require('fs');
var glob = global.glob || require('glob');
var shelljs = global.shelljs = global.shelljs || require('shelljs');

var localpath = './ej2-repo/';
var config = common.config();
var themes = config.themes;
var currentRepo = common.currentRepo;
var currentPackage = common.currentPackage;
var packageName;
var newFiles = [];

/**
 * Components auto update in ej2 repository
 */
gulp.task('publish-ej2', function (done) {
    shelljs.rm('-rf', './ej2-repo');
    if (new RegExp(config.thirdPartyWords.join('|')).test(currentRepo)) {
        done();
        return;
    }
    var branchName = common.isMasterBranch ? 'master' : common.stagingBranch;
    branchName = common.isReleaseBranch ? process.env.githubSourceBranch : branchName;
    branchName = common.isHotfixBranch ? process.env.githubSourceBranch : branchName;
    var simpleGit = require('simple-git');
    if (!fs.existsSync('./ej2-repo')) {
        fs.mkdirSync('./ej2-repo');

        // clone components repository  
        var user = 'SyncfusionAutomation';
        var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
        var ej2Repo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2.git';
        simpleGit().clone(ej2Repo, './ej2-repo', function (err) {
            if (err) {
                done(err);
                return;
            }
        }).exec(function () {
            simpleGit('./ej2-repo').checkout(branchName, function (err) {
                if (err) {
                    done(err);
                    return;
                }
                // create components
                createComponents();
                //styles dependency issue
                shelljs.cd('./ej2-repo/');
                var jsonpath = './styles.json';
                packageName = common.currentPackage.replace('ej2-', '');
                var deps = {};
                if (fs.existsSync(jsonpath)) {
                    deps = JSON.parse(fs.readFileSync(jsonpath, 'utf8'));
                }
                deps[packageName] = config.styleDependency;
                fs.writeFileSync(jsonpath, JSON.stringify(deps, null, 4));
                var dynamicModule = {};
                var dComp = [];
                var thirdPartyComponent;
                if (fs.existsSync('../third-party/config.json')) {
                    thirdPartyComponent = JSON.parse(fs.readFileSync('../third-party/config.json', 'utf8')).components;
                    for (var dynamic of thirdPartyComponent) {
                        var baseClass = dynamic.baseClass;
                        if (baseClass && dynamic.dynamicModule) {
                            dComp.push(baseClass);
                            dynamicModule[baseClass] = dynamic.dynamicModule;
                        }
                    }
                }
                var dependable = config.dependable;
                var resource = {};
                if (dependable) {
                    if (fs.existsSync('./resource.json')) {
                        resource = JSON.parse(fs.readFileSync('./resource.json'));
                    }
                    var depComp = Object.keys(dependable);
                    for (var dep of depComp) {
                        var comp = dependable[dep];
                        /* jshint ignore:start */
                        var thirdPartyConfig = thirdPartyComponent && thirdPartyComponent.filter(tComp => tComp.directoryName === dep);
                        if (thirdPartyConfig && thirdPartyConfig.length) {
                            comp.blazorType = thirdPartyConfig[0].blazorType ? thirdPartyConfig[0].blazorType : 'wrapper';
                        }
                        /* jshint ignore:end */
                        comp.package = common.currentPackage;
                        if (dComp.indexOf(comp.classname) !== -1) {
                            comp.injectables = dynamicModule[comp.classname];
                        }
                        resource[dep] = comp;
                    }
                    fs.writeFileSync('./resource.json', JSON.stringify(resource, null, 4), 'utf8');
                }


                // get commit message
                simpleGit().log(function (err, log) {
                    var logs = common.getCommitDetails(log);
                    var commitMessage = logs.lastCommit;
                    var commitId = logs.commitId;

                    // check current component in package.json
                    shelljs.cd(localpath);

                    // update npmrc contents
                    registry.setNpmrc();

                    var packages = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
                    var dependencies = Object.keys(packages.dependencies);

                    if (dependencies.indexOf('@syncfusion/' + currentPackage) === -1) {
                        shelljs.exec('npm install @syncfusion/' + currentPackage + ' --save');

                        // Get updated package
                        packages = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
                        dependencies = Object.keys(packages.dependencies);
                    }

                    if (newFiles.length) {
                        var files = newFiles.toString().split(',').join(' ');
                        shelljs.exec('git add ' + files);
                    }

                    var changes = shelljs.exec('git diff ' + branchName).stdout;
                    if (changes.length !== 0) {
                        shelljs.cd('../');
                        done();
                        return;
                    }
                    // update npm package dependencies
                    for (var i = 0; i < dependencies.length; i++) {
                        if (dependencies[i].indexOf('@syncfusion') !== -1) {
                            packages.dependencies[dependencies[i]] = '*';
                        }
                    }
                    fs.writeFileSync('./package.json', JSON.stringify(packages, null, '\t'));
                    if (!common.isMasterBranch) {
                        shelljs.exec('npm version -f ' + logs.release + ' --no-git-tag-version --no-verify');
                    }
                    shelljs.cd('../');
                    // push updated component src and styles to components repository            
                    simpleGit('./ej2-repo').init()
                        .add('./*')
                        .commit(commitMessage)
                        .pull(branchName)
                        .push(ej2Repo, branchName, function () {
                            console.log(currentPackage + ' - source and styles updated in ej2');
                            done();
                        });
                });
            });
        });
    }
});

function createComponents() {
    // create component in ej2
    if (fs.existsSync('./src')) {
        exportComponents();
    }
    var styleDeps = config.styleDependency;
    if (styleDeps && styleDeps !== 'none' && styleDeps.length !== 0 && currentPackage !== 'ej2-base') {
        for (let styleDep of styleDeps) {
            let componentname = Object.keys(styleDep)[0];
            let styleOptions = {
                compDir: localpath + componentname,
                component: componentname
            };
            exportStyles(styleOptions);
        }
    }
    else if (fs.existsSync('./styles')) {
        let componentname = common.currentPackage.replace('ej2-', '');
        let styleOptions = {
            compDir: localpath + componentname
        };
        exportStyles(styleOptions);
    }

    // get all components ts file
    // var compName = fs.readdirSync(localpath).filter(function (file) {
    //     if (file !== '.git') {
    //         return fs.statSync(localpath + file).isDirectory();
    //     }
    // });

    // update index.ts with all components
    var components = '/**\n * ej2 source\n */\n';
    var files = glob.sync('./ej2-repo/**.ts', { ignore: ['ej2-repo/index.ts'] });
    var exportContent = 'export { ';
    var lastpack = files[files.length - 1];
    for (let file of files) {
        var isLast = lastpack === file ? ' };\n' : ', ';
        var packName = file.replace(/\\/g, '/').replace('ej2-repo/', '').replace('.ts', '');
        components = components + `import * as ${packName.replace(/-/g, '')} from './${packName}';\n`;
        exportContent = exportContent + packName.replace(/-/g, '') + isLast;
    }
    addFiles(localpath + '/index.ts');
    fs.writeFileSync(localpath + '/index.ts', components + exportContent);

    //update themes at root                    
    // for (var k = 0; k < themes.length; k++) {
    //     var styles = '/**\n * ej2 styles\n */\n@import "base/' + themes[k] + '.scss";\n';
    //     for (var l = 0; l < compName.length; l++) {
    //         if (compName[l] !== 'base') {
    //             var importPath = compName[l] + '/' + themes[k] + '.scss';
    //             if (fs.existsSync(localpath + importPath)) {
    //                 styles = styles + '@import "' + importPath + '";\n';
    //             }
    //         }
    //     }
    //     addFiles(localpath + themes[k] + '.scss');
    //     fs.writeFileSync(localpath + themes[k] + '.scss', styles);
    // }

    // create EJ1 compatibility styles
    // exportCompatibility();
}
exports.createComponents = createComponents;

function exportComponents() {
    // typescript export
    var filename = currentPackage.replace('ej2-', '').trim() + '.ts';
    var content = 'export * from \'@syncfusion/' + currentPackage + '\';\n';
    if (!fs.existsSync('./third-party/config.json')) {
        addFiles(localpath + filename);
        fs.writeFileSync(localpath + filename, content);
        return;
    }
    var thirdPartyConfig = JSON.parse(fs.readFileSync('./third-party/config.json', 'utf-8'));
    var hasDynamicModules = thirdPartyConfig.components &&
        thirdPartyConfig.components.filter(com => com.dynamicModules &&
            Array.isArray(com.dynamicModules) &&
            com.dynamicModules.length > 0).length > 0 ? true : false;
    if (!hasDynamicModules) {
        addFiles(localpath + filename);
        fs.writeFileSync(localpath + filename, content);
        return;
    }
    content = 'import * as index from \'@syncfusion/' + currentPackage + '\';\n';
    for (let thirdPartyComponent of thirdPartyConfig.components) {
        var dyModuleCount = thirdPartyComponent.dynamicModules ? thirdPartyComponent.dynamicModules.length : 0;
        if (dyModuleCount <= 0) {
            continue;
        }
        var dynamicContent = 'index.' + thirdPartyComponent.baseClass + '.Inject( ';
        for (let dyModule of thirdPartyComponent.dynamicModules) {
            var isLastModule = dyModuleCount > 0 && thirdPartyComponent.dynamicModules[dyModuleCount - 1] === dyModule ? ');\n' : ',';
            dynamicContent = dynamicContent + 'index.' + dyModule + isLastModule;
        }
        content = content + dynamicContent;
    }
    content = content + 'export * from \'@syncfusion/' + currentPackage + '\';\n';
    addFiles(localpath + filename);
    fs.writeFileSync(localpath + filename, content);
}
exports.exportComponents = exportComponents;

function exportStyles(info) {
    if (!fs.existsSync(info.compDir)) {
        fs.mkdirSync(info.compDir);
    }
    if (fs.existsSync('./styles')) {
        for (var i = 0; i < themes.length; i++) {
            var style = info.component ?
                '@import "' + currentPackage + '/styles/' + info.component + '/' + themes[i] + '.scss";' :
                '@import "' + currentPackage + '/styles/' + themes[i] + '.scss";';
            addFiles(info.compDir + '/' + themes[i] + '.scss');
            fs.writeFileSync(info.compDir + '/' + themes[i] + '.scss', style);
        }
    }
}

exports.exportStyles = exportStyles;

function addFiles(filePath) {
    if (!fs.existsSync(filePath)) {
        newFiles.push(filePath.replace(localpath, './'));
    }
}

var template = `$css: '.e-css' !default;
$imported-modules: () !default;
.e-lib {
    @at-root
    {
        @import "{path}{theme}";
    }

    & .e-js [class^='e-'], & .e-js [class*=' e-'] {
        box-sizing: content-box;
    }
}`;
function exportCompatibility() {
    var path = require('path');
    var ignoreFiles = ['./ej2-repo/*.scss', './ej2-repo/**/compatibility/**/*.scss', './ej2-repo/styles/**/*.scss'];
    var files = glob.sync('./ej2-repo/**/*.scss', { ignore: ignoreFiles });
    for (var i = 0; i < files.length; i++) {
        var dir = path.dirname(files[i]);
        var fileName = path.basename(files[i]);
        var compatibleDir = dir + '/compatibility/';
        var dirPath = '../';
        if (fs.existsSync(compatibleDir)) {
            if (fs.existsSync(compatibleDir + fileName)) {
                continue;
            }
            else {
                var styleContent = template.replace('{path}', dirPath).replace('{theme}', fileName);
                addFiles(compatibleDir + fileName);
                fs.writeFileSync(compatibleDir + fileName, styleContent);
            }
        }
        else {
            fs.mkdirSync(compatibleDir);
            var content = template.replace('{path}', dirPath).replace('{theme}', fileName);
            addFiles(compatibleDir + fileName);
            fs.writeFileSync(compatibleDir + fileName, content);
        }
    }
    var file = glob.sync('./ej2-repo/*.scss');
    for (var k = 0; k < file.length; k++) {
        var rootFile = path.basename(file[k]);
        var directoryPath = './ej2-repo/styles/compatibility/';
        shelljs.mkdir('-p', directoryPath);
        if (!fs.existsSync(directoryPath + rootFile)) {
            var contentPath = '../../';
            var styles = template.replace('{path}', contentPath).replace('{theme}', rootFile);
            addFiles(directoryPath + rootFile);
            fs.writeFileSync(directoryPath + rootFile, styles);
        }
    }
}

gulp.task('style-dependency', function (done) {
    var simpleGit = require('simple-git');
    var repoPath = './ej2-resources-repo';
    var branchName = 'development';//common.isMasterBranch ? 'master' : common.stagingBranch;
    if (!fs.existsSync(repoPath)) {
        fs.mkdirSync(repoPath);
        // clone components repository  
        var user = 'SyncfusionAutomation';
        var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
        var ej2ResourcesRepo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-resources.git';
        simpleGit().clone(ej2ResourcesRepo, repoPath, function (err) {
            if (err) {
                done(err);
                return;
            }
        }).exec(function () {
            simpleGit(repoPath).checkout(branchName, function (err) {
                if (err) {
                    done(err);
                    return;
                }
                done();
            });
        });
    }
});

gulp.task('yeoman-es6-automation', function (done) {
    var repoPath = './es6-generator-repo';
    var branchName = common.isMasterBranch ? 'master' : common.stagingBranch;
    if (!fs.existsSync(repoPath)) {
        fs.mkdirSync(repoPath);
        // clone components repository  
        var user = 'SyncfusionAutomation';
        var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
        var es6GeneratorRepo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-generator-es6.git';
        automateGenerator(es6GeneratorRepo, repoPath, branchName, done);
    }
});

gulp.task('yeoman-ts-automation', function (done) {
    var repoPath = './ts-generator-repo';
    var branchName = common.isMasterBranch ? 'master' : common.stagingBranch;
    if (!fs.existsSync(repoPath)) {
        fs.mkdirSync(repoPath);
        // clone components repository  
        var user = 'SyncfusionAutomation';
        var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
        var tsGeneratorRepo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-generator-typescript.git';
        automateGenerator(tsGeneratorRepo, repoPath, branchName, done);
    }
});

function automateGenerator(repo, repopath, branch, done) {
    var simpleGit = require('simple-git');
    simpleGit().clone(repo, repopath, function (err) {
        if (err) {
            done(err);
            return;
        }
    }).exec(function () {
        simpleGit(repopath).checkout(branch, function (err) {
            if (err) {
                done(err);
                return;
            }
            var autodata = generatorScripts(repopath);
            if (fs.existsSync(repopath) && autodata) {
                //System Config file automation
                if (fs.existsSync('./node_modules/@syncfusion/ej2-build-test/src/publish/sys-config.txt')) {
                    var configText = fs.readFileSync('./node_modules/@syncfusion/ej2-build-test/src/publish/sys-config.txt', 'utf-8');
                    configText = configText.replace('${sysConfig}', autodata.systemConfig);
                    fs.writeFileSync(repopath + '/app/templates/system.config.js', configText, 'utf-8');
                }

                //package.json dependency automation
                var packagePath = `${repopath.indexOf('es6') !== -1 ? 'es6-package' : 'ts-package'}.txt`;
                if (fs.existsSync('./node_modules/@syncfusion/ej2-build-test/src/publish/' + packagePath)) {
                    var packageContent = fs.readFileSync('./node_modules/@syncfusion/ej2-build-test/src/publish/' + packagePath, 'utf-8');
                    fs.writeFileSync(repopath + '/app/templates/package.json',
                        packageContent.replace('${dependencies}', autodata.dependency), 'utf-8');
                }

                //SCSS files for different themes automation
                themes.forEach((theme) => {
                    fs.writeFileSync(repopath + `/app/templates/${theme}.scss`, autodata.sassThemes[theme], 'utf-8');
                });

                //Prompting component list automation
                fs.writeFileSync(repopath + '/app/index.js', autodata.prompting, 'utf-8');

                //CSS files for different themes automation
                themes.forEach((theme) => {
                    var csstheme = fs.readFileSync(`./${theme}.css`, 'utf-8');
                    fs.writeFileSync(repopath + `/app/templates/${theme}.css`, csstheme, 'utf-8');
                });

                simpleGit(repopath)
                    .init((err) => {
                        let smessage = err ? 'init: -' + err : 'git init success.';
                        console.log(smessage);
                    })
                    .add('./*', (err) => {
                        let smessage = err ? 'add: -' + err : 'git add success.';
                        console.log(smessage);
                    })
                    .commit('config(EJ2-000): Automated the generator', (err) => {
                        let smessage = err ? 'commit: -' + err : 'git commit success.';
                        console.log(smessage);
                    })
                    .pull(branch, (err) => {
                        let smessage = err ? 'pull: -' + err : 'git pull success.';
                        console.log(smessage);
                    })
                    .push(repo, branch, function (err) {
                        let smessage = err ? 'push: -' + err : 'git push success.';
                        console.log(smessage);
                        console.log(repo + ' - generator dependencies update automated');
                        done();
                        shelljs.rm('-rf', repopath);
                    });
            }
            else {
                done();
            }
        });
    });
}

function getPackageName(dname) {
    if (!dname) {
        return;
    }
    var packageName = dname.replace('@syncfusion/ej2-', '');
    packageName = packageName.indexOf('-') === -1 ? packageName.charAt(0).toUpperCase() + packageName.slice(1) :
        packageName.split('-').reduce((p, c) => p.charAt(0).toUpperCase() + p.slice(1) + c.charAt(0).toUpperCase() + c.slice(1));
    return packageName;
}

exports.getPackageName = getPackageName;

function generatorScripts(repopath) {
    if (!fs.existsSync('./package.json') || !fs.existsSync('./ej2-resources-repo/styles.json')) {
        return;
    }
    var packages = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
    var dependencies = Object.keys(packages.dependencies);
    var styles = JSON.parse(fs.readFileSync('./ej2-resources-repo/styles.json', 'utf-8'));
    var sysConfig = `"@syncfusion/ej2-base": "syncfusion:ej2-base/dist/ej2-base.umd.min.js"`;
    var choiceConfig = ``;
    var sassThemes = {};
    var packageDependency = `"@syncfusion/ej2-base": "*"`;
    themes.forEach((theme) => {
        var sassTheme = `@import "./node_modules/@syncfusion/ej2-base/styles/${theme}.scss";`;
        sassThemes[theme] = sassTheme;
    });
    var promptjs = '';

    dependencies.forEach((dname) => {
        var packagename = getPackageName(dname);
        var packagefullname = dname.replace('@syncfusion/', '');
        if (dname.indexOf('ej2-base') === -1 &&
            dname.indexOf('tslib') === -1) {
            sysConfig = sysConfig + `<% if (controls.indexOf("${packagename}")!==-1){ %>,
        "${dname}": "syncfusion:${packagefullname}/dist/${packagefullname}.umd.min.js",<% } %>`;
            if (styles[packagename.charAt(0).toLowerCase() + packagename.slice(1)] !== undefined) {
                themes.forEach((theme) => {
                    sassThemes[theme] = sassThemes[theme] + `<% if (controls.indexOf("${packagename}")!==-1){ %>,
@import "./node_modules/${dname}/styles/${theme}.scss";<% } %>`;
                });
            }
            choiceConfig = choiceConfig + `${choiceConfig.length === 0 ? '' : ','}{
                name : ${packagename},
                value : ${packagename},
                checked : false
            }`;
            packageDependency = packageDependency + `<% if (controls.indexOf("${packagename}")!==-1){ %>,
    "${dname}": "*",<% } %>`;
        }
    });
    var promptText = repopath.indexOf('es6') === -1 ? 'prompt-es6-index' : 'prompt-ts-index';
    if (fs.existsSync(`./node_modules/@syncfusion/ej2-build-test/src/publish/${promptText}.txt`)) {
        promptjs = fs.readFileSync(`./node_modules/@syncfusion/ej2-build-test/src/publish/${promptText}.txt`, 'utf-8');
        promptjs = promptjs.replace('${choiceConfig}', choiceConfig);
    }
    return {
        systemConfig: sysConfig,
        prompting: promptjs,
        sassThemes: sassThemes,
        dependency: packageDependency
    };
}

exports.generatorScripts = generatorScripts;

gulp.task('yeoman-generator-automation', function (done) {
    var runSequence = require('gulp4-run-sequence');
    runSequence('style-dependency', 'yeoman-es6-automation', 'yeoman-ts-automation', done);
});
