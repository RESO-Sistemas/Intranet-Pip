'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var thirdParty = global.thirdParty = global.thirdParty || require('./third-party.js');

gulp.task('react-publish', function (done) {
    thirdParty.publish('react', 'npm install &&  gulp es-build  && gulp ci-compile && ' +
            'gulp es-scripts && gulp esm2015-scripts umd-scripts &&' +
            'gulp rm-temp && gulp license && gulp react-api && gulp cdn-scripts', done);
});
