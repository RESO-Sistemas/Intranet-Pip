const gulp = require('gulp');
const { run } = require('@memlab/api');
const fs = require('fs-extra');
const path = require('path');
const browserSync = require('browser-sync').create();

let hasLeaks = false;
let leaksDetected = false;

const checkMemoryLeak = (filename) => {
    return async function () {
        const workDir = `./memory-leak-reports/${filename.replace('.html', '')}`;
        const samplePath = `memory-leak-samples/${filename}`;
        fs.mkdirsSync(workDir);
        const scenario = {
            url: () => `http://localhost:${browserSync.port}/${samplePath}`,
            action: async (page) => {
                await page.click('button[id="render"]');
            },
            back: async (page) => {
                await page.click('button[id="destroy"]');
            }
        };
        
        try {
            const result = await run({ scenario, workDir });
            if (result.hasLeaks) {
                hasLeaks = true;
            }
        } catch (err) {
            console.error(`Error running MemLab for ${filename}.`);
            hasLeaks = true;
        }

        if (hasLeaks) {
            leaksDetected = true;
            console.log(`Memory leak detected in ${filename}.`);
        }
    };
};
gulp.task('serveSamples', function (done) {
    browserSync.init({
        server: {
            baseDir: './'
        },
        open: false
    }, function (err, bs) {
        if (err) return done(err);
        browserSync.port = bs.options.get('port'); 
        done();
    });
});

gulp.task('memoryLeak-detect', async function (done) {
    const directoryPath = 'memory-leak-samples';
    if (!fs.existsSync(directoryPath)) {
        console.log(`Directory "${directoryPath}" not found. Skipping memory leak detection.`);
        return done();
    }
    fs.readdir(directoryPath, (err, files) => {
        if (err) {
            return done(err);
        }
        const tasks = files.filter(file => path.extname(file) === '.html')
            .map(file => checkMemoryLeak(file));
        if (tasks.length === 0) {
            console.log('No sample files found for memory leak detection.');
            return done();
        }
        gulp.series('serveSamples', ...tasks, function (done) {
            browserSync.exit();
            if (leaksDetected) {
                console.log('Memory leaks were detected.');
                process.exit(1);
            } else {
                console.log('No memory leaks detected.');
            }
            done();
        })(done);
    });
});
