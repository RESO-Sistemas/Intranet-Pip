'use strict';

var modList, classList = {},
    interfaceList = [],
    interfacesNames =[],
    methodLists = {},
    classProperties = {},
    interfaceProperties = {},
    typeAliases = {},
    enumAliases = {};

/**
 * Property Reader
 */
class PropertyReader {

    constructor(json) {
        return this.render(json.children);
    }

    readClasses(cntMod) {
        for (var j = 0; j < cntMod.length; j++) {
            var curItem = cntMod[j];
            if (curItem.kindString === 'Class') {
                classList[curItem.name] = curItem;
                classProperties[curItem.name] = {
                    _allProperties: [], _allEvents: [], _allMethods: [], _allAccessors: [], _propComments: {}, 
                    _methodComments: {}, _eventComments: {},  _accessorComments: {_getComments: {}, _setComments: {}}, 
                    _propObjects: {}, _propShortComments: {}, _eventShortComments: {}, _methodShortComments: {},
                    _accessorShortComments: { _getComments: {}, _setComments: {} }
                };
                if (curItem.children && curItem.children.length) {
                    this.readDecoratorProperties(curItem.children, classProperties[curItem.name]);
                    this.readMethods(curItem.children, classProperties[curItem.name]);
                }
            }
            if (curItem.kindString === 'Interface' && interfacesNames.indexOf(curItem.name) === -1) {
                interfaceList.push(curItem);
                interfacesNames.push(curItem.name);
                interfaceProperties[curItem.name] = curItem;
            }
            if (curItem.kindString === 'Type alias') {
                typeAliases[curItem.name] = curItem;
                classProperties[curItem.name] = {
                    _allProperties: [], _allEvents: [], _allMethods: [], _propComments: {}, _methodComments: {}, _eventComments: {},
                    _propObjects: {}, _propShortComments: {}, _eventShortComments: {}, _methodShortComments: {}
                };
            }
            if(curItem.kindString === 'Enumeration'){
                enumAliases[curItem.name] = curItem;
                classProperties[curItem.name] = {
                    _allProperties: [], _allEvents: [], _allMethods: [], _propComments: {}, _methodComments: {}, _eventComments: {},
                    _propObjects: {}, _propShortComments: {}, _eventShortComments: {}, _methodShortComments: {}
                };
            }
        }
        return classList;
    }

    readMethods(properties) {
        var keys = Object.keys(classProperties);
        for (var i = 0; i < keys.length; i++) {
            for (var m = 0; m < properties.length; m++) {
                var method = properties[m];
                if (method.kindString === 'Method' && method.flags.isPublic === true) {
                    methodLists[method.name] = method;
                }
            }
        }
    }

    readDecoratorProperties(properties, desObj) {
        for (var k = 0; k < properties.length; k++) {
            var prop = properties[k];
            var comment = {};
            if ((prop.kindString === 'Property' || prop.kindString === 'Event') &&  prop.decorators) {
                comment = this.getComments(prop.comment);
            }
            if (prop.kindString === 'Property' && prop.decorators) {
                var type = prop.decorators[0].name.toLowerCase();
                desObj[prop.name] = { type: { name: type }, obj: prop, comment: comment.comment, shortComment: comment.shortComment };
            }
            if (prop.kindString === 'Event' && prop.decorators) {
                var eType = prop.decorators[0].name.toLowerCase();
                desObj[prop.name] = { type: { name: eType }, obj: prop, comment: comment.comment, shortComment: comment.shortComment };
            }
            if (prop.kindString === 'Method' && prop.flags.isPublic === true) {
                var mType = prop.signatures[0].type.type.toLowerCase();
                if (prop.signatures[0].comment && prop.signatures[0].comment.shortText) {
                    comment = this.getComments(prop.signatures[0].comment);
                    desObj[prop.name] = { type: { name: mType }, obj: prop, comment: comment.comment, shortComment: comment.shortComment };
                } else {
                    desObj[prop.name] = { type: { name: mType }, obj: prop };
                }
            }
            if(prop.kindString === 'Accessor' && prop.flags.isPublic) {                
                var accessorType = prop.getSignature.type.type.toLowerCase();
                if(prop.getSignature.comment && prop.getSignature.comment.shortText){
                    comment = this.getComments(prop.getSignature.comment);
                    desObj[prop.name] = { type: { name: accessorType }, obj: prop , comment:  comment.comment,
                                            shortComment: comment.shortComment };
                } else {
                    desObj[prop.name] = {type: { name: accessorType }, obj: prop };
                }
            }
        }
    }

    isCollectionDecorator(prop) {
        if (prop.kindString === 'Property' && prop.decorators) {
            return prop.decorators[0].name === 'Collection';
        } else {
            return false;
        }

    }

    createInputArray() {
        var keys = Object.keys(classProperties);
        var comment = {};
        for (var i = 0; i < keys.length; i++) {
            var prop = classProperties[keys[i]];
            var subKeys = Object.keys(prop);

            var interFaceProps = interfaceProperties[keys[i] + 'Model'];
            var alais = enumAliases[keys[i]] || typeAliases[keys[i]];
            if (interFaceProps) {
                var modelProps = interFaceProps.children;
                for (var k = 0; modelProps && k < modelProps.length; k++) {
                    var curModel = modelProps[k];
                    comment = this.getComments(curModel.comment);
                    if (curModel.type && curModel.type.name === 'EmitType') {
                        prop._allEvents.push(curModel.name);
                        prop._eventComments[curModel.name] = comment.comment;
                        prop._eventShortComments[curModel.name] = comment.shortComment;
                        prop._propObjects[curModel.name] = curModel;

                    } else {
                        prop._allProperties.push(curModel.name);
                        prop._propComments[curModel.name] = comment.comment;
                        prop._propShortComments[curModel.name] = comment.shortComment;
                        prop._propObjects[curModel.name] = curModel;
                    }
                }
            }

            else if(alais && alais.comment && alais.comment.shortText){
                comment = this.getComments(alais.comment);
                prop._propShortComments[alais.name] = comment.shortComment;
            }
            for (var j = 0; j < subKeys.length; j++) {
                var subKey = subKeys[j];
                var curProp = prop[subKey].obj;
                if (!(/(_)/g).test(subKey)) {
                    if (curProp.kindString === 'Method' && curProp.flags.isPublic === true) {
                        curProp = curProp.signatures[0];
                        prop._allMethods.push(curProp.name);
                        if (curProp.comment && curProp.comment.shortText) {
                            comment = this.getComments(curProp.comment);
                            prop._methodShortComments[curProp.name] = comment.shortComment;
                            prop._methodComments[curProp.name] = comment.comment;
                        }
                        prop[subKey].aspProperties = this.aspParseInputArray(curProp, prop[subKey].aspProperties, '', prop[subKey]);
                    }
                    if(curProp.kindString === 'Accessor' && curProp.flags.isPublic === true) {          
                        if(curProp.getSignature && curProp.getSignature.comment) {
                            comment = this.getComments(curProp.getSignature.comment);
                            prop._accessorComments._getComments[curProp.name] = comment.comment;
                            prop._accessorShortComments._getComments[curProp.name] = comment.shortComment;
                        }
                        if(curProp.setSignature && curProp.setSignature.comment) {
                            comment = this.getComments(curProp.setSignature.comment);
                            prop._accessorComments._setComments[curProp.name] = comment.comment;
                            prop._accessorShortComments._setComments[curProp.name] = comment.shortComment;
                        }
                        prop._allAccessors.push(curProp.name);
                        prop._propObjects[curProp.name] = curProp;
                    }
                }
            }
        }
    }
    
    getPascalComment(cmt) {
        var getAccentString = cmt.match('`[a-zA-Z`]+');
        // variable name will be change laterly
        var txt3 = cmt;
        if (getAccentString !== null) {
            for (var i = 0; i < getAccentString.length; i++) {
                var txt = getAccentString[i];
                var txt1 = txt[1].toUpperCase() + txt.slice(2);
                txt3 = cmt.replace(getAccentString[i], '`' + txt1);
            }
        }
        return txt3;
    }
    
    getMethodArgsComment(cmt) {
        // variable name will be change laterly
        var cmt1 = cmt;
        var isCmt = true;
        for (var i = 0; i < cmt1.length; i++) {
            var txt = cmt1[i].match(/@\b(param)\b.*$/g);
            if (txt !== null && txt !== undefined) {
                isCmt = false;
                var txt1 = txt[0].split('}')[1].split('-');
                var t1 = txt1[0].replace(/\s/g, '');
                var t2 = txt1[1].replace(' ', '');
                var up = '<param name = "' + t1 + '">' + t2 + '</param>';
                var index = cmt1.indexOf(' ' + txt);
                if (index !== -1) {
                    cmt1[index] = up;
                }
            }
        }
        if (!isCmt) {
            return cmt1.join('\n/// ') + '\n';
         }
        else {
            return cmt.join('\n/// ').replace(/(\*|<[^]*>)/g, '') + '\n';
        }
    }

    getComments(comment) {
        if (!comment) { return { comment:'', shortComment: ''}; }
        var shortComment = '';
        var result = '    /** \n     * ';
        comment.shortText = comment.shortText.replace(/```([^]+)```/g, '');
        var pascalComment = this.getPascalComment(comment.shortText);
        var commentArray = pascalComment.split('\n');
        shortComment = this.getMethodArgsComment(commentArray);
        result = result + commentArray.join(' \n     * ') + '\n';
        if (comment.text) {
            var commentTextArray = comment.text.split('\n');
            result = result + '     * \n     * ' + commentTextArray.join('\n     *') + '     \n';
        }
        for (var i = 0; comment.tags && i < comment.tags.length; i++) {
            var curTag = comment.tags[i];
            result = result + '     * @' + curTag.tag + ' ' + curTag.text.replace('\n', '') + '\n';
        }
        result = result + '     */';
        return { comment: result, shortComment: '/// <summary>\n/// ' + shortComment + '/// </summary>' };
    }

    aspParseInputArray(prop, resultAr, prevObj, classObj) {
        var result = resultAr;
        var type = '';
        if (this.isPropArray(prop.type)) {
            type = this.getReferenceType([prop.type]);
        } else if (this.isUnionArray(prop.type.types)) {
            type = this.getReferenceType(prop.type.types);
        }
        if (type !== '') {
            var obj = this.getTypeObject(type);
            if (obj && prevObj !== obj && obj.children) {
                result = this.readProperties(obj.children, [], obj, classObj);
            }
        }
        return result;
    }

    isUnionArray(types) {
        for (var i = 0; types && i < types.length; i++) {
            var type = types[i];
            if (type.isArray || type.type === 'array') {
                return true;
            }
        }
        return false;
    }

    isPropArray(type) {
        if (type.isArray || type.type === 'array') {
            return true;
        }
        return false;
    }

    pushToArray(resultAr, val, ignorePush) {
        if (ignorePush !== true) {
            resultAr.push(val);
        }
    }

    readProperties(properties, desObj, prevObj, classObj) {
        for (var k = 0; k < properties.length; k++) {
            var prop = properties[k];
            var comment = {};
            if (prop.kindString === 'Property') {
                if (this.isPropArray(prop.type) || this.isUnionArray(prop.type.types)) {
                    desObj[prop.name] = this.aspParseInputArray(prop, desObj, prevObj, {});
                }
                comment = this.getComments(prop.comment);
                if (prop.type.type === 'instrinct') {
                    classObj[prop.name] = { type: prop.type.name, comment: comment.comment, shortComment: comment.shortComment };
                } else {
                    classObj[prop.name] = { type: 'any', comment: comment.comment, shortComment: comment.shortComment };
                }
                desObj.push(prop.name);
            }
        }
        return desObj;
    }

    getTypeObject(type) {
        return interfaceProperties[type];
    }

    getReferenceType(types) {
        if (types) {
            for (var i = 0; i < types.length; i++) {
                var type = types[i];

                if (type.type === 'array' && type.elementType.type === 'reference' && (/Model/).test(type.elementType.name)) {
                    return type.elementType.name;
                }
            }
        }

        return '';
    }

    render(mods) {
        modList = mods;
        for (var i = 0; i < mods.length; i++) {
            if (modList[i].children) {
                this.readClasses(modList[i].children);
            }
        }
        this.createInputArray();
        classProperties.__this = this;
        classProperties.interfaces = interfaceProperties;
        classProperties.allClasses = classList;
        classProperties.typeAliases = typeAliases;
        classProperties.enumAliases = enumAliases;
        classProperties.methodLists = methodLists;
        classProperties.interfacesNames = interfacesNames;
        return classProperties;
    }

}

module.exports = function(json) {
    return new PropertyReader(json);
};