'use strict';

/* globals browser */
/* globals document */
/* globals HTMLCS_RUNNER */

exports.config = {
    allScriptsTimeout: 600000,

    getPageTimeout: 60000,

    framework: 'jasmine',

    jasmineNodeOpts: {
        defaultTimeoutInterval: 100000,
    },

    multiCapabilities: [],

    specs: ['../../../../../accessibility/**/*.accessibility.test.js'],

    onComplete: function () {
        browser.driver.quit();
        console.log(browser.browserName + ' driver closed!');
    },

    onPrepare: function () {
        browser.ignoreSynchronization = true;
        browser.waitForAngularEnabled = false;
        browser.basePath = require('../../../../../protractor.browser.json').basePath;
        browser.standards = ['WCAG2A', 'WCAG2AA', 'Section508'];

        browser.getCapabilities().then(function (cap) {
            browser.browserName = cap.get('browserName');

            browser.test = function (path, done) {
                browser.get(browser.basePath + path);
                browser.executeAsyncScript(function (path, standardsList) {
                    var callback = arguments[arguments.length - 1];
                    var head = document.getElementsByTagName('head')[0];
                    var script = document.createElement('script');
                    script.type = 'text/javascript';
                    script.onload = function () {
                        var errors = [];
                        HTMLCS_RUNNER.run('WCAG2A', document.body, function (errorList) {
                            if (standardsList.indexOf('WCAG2A') !== -1) {
                                errors = errors.concat(errorList);
                            }
                            HTMLCS_RUNNER.run('WCAG2AA', document.body, function (errorList) {
                                if (standardsList.indexOf('WCAG2AA') !== -1) {
                                    errors = errors.concat(errorList);
                                }
                                HTMLCS_RUNNER.run('WCAG2AAA', document.body, function (errorList) {
                                    if (standardsList.indexOf('WCAG2AAA') !== -1) {
                                        errors = errors.concat(errorList);
                                    }
                                    HTMLCS_RUNNER.run('Section508', document.body, function (errorList) {
                                        if (standardsList.indexOf('Section508') !== -1) {
                                            errors = errors.concat(errorList);
                                        }
                                        callback(errors);
                                    });
                                });
                            });
                        });
                    };
                    script.src = path + '/node_modules/@syncfusion/ej2-build-test/src/accessibility-runner/HTMLCS.js';
                    head.appendChild(script);

                }, browser.basePath, browser.standards).then(function (error) {
                    for (var i = 0; error.length > i; i++) {
                        var msg = error[i];
                        console.log(msg.typeName + ' Standard :' + msg.standard + '\nElement : ' +
                            msg.nodeName + msg.elementId + '\nMessage : ' + msg.message + '\n');
                    }
                    console.log('Total Found :' + error.length);
                    expect('Error count :' + 0).toBe('Error count :' + error.length);
                    done();
                });

            };
        });

    },
};


exports.config.multiCapabilities.push({
    'browserName': 'chrome',
    'chromeOptions': {
        'args': ['--headless', '--disable-gpu', '--window-size=800x600']
    }
});