'use strict';

var gulp = global.gulp = global.gulp || require('gulp');

gulp.task('local-pack', function(done) {
    global.isLocal = true;
    var shelljs = global.shelljs || require('shelljs');
    var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
    runSequence('ci-test', 'ci-compile', 'release-scripts', 'npmignore', function() {
        shelljs.exec('npm pack', function() {
            shelljs.exec('gulp clean-pack');
            global.isLocal = false;
            done();
        });
    });
});

gulp.task('local-vue-pack', function(done) {
    global.isLocal = true;
    var shelljs = global.shelljs || require('shelljs');
    var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
    runSequence('scripts', 'es-scripts', 'esm-scripts', 'umd-scripts', 'rm-temp', 'npmignore', function() {
        shelljs.exec('npm pack', function() {
            shelljs.exec('gulp clean-pack');
            global.isLocal = false;
            done();
        });
    });
});

gulp.task('clean-pack', function(done) {
    var rimraf = require('rimraf');
    var glob = global.glob || require('glob');
    var syntax = '{./**/*.d.ts,./*.ts,./*js,./dist/,./public/,./coverage/,./test-report/,./.npmignore}';
    var ignore = ['./node_modules/**/*.d.ts', './gulpfile.js', './karma.conf.js', './test-main.js'];
    var files = glob.sync(syntax, { ignore: ignore });

    for (var i = 0; i < files.length; i++) {
        rimraf(files[i], function(){ });
    }
    done();
});