/* jshint ignore:start */
"use strict";
var fs = (global.fs = global.fs || require("fs"));
var glob = global.glob = global.glob || require("glob");
var shelljs = (global.shelljs = global.shelljs || require("shelljs"));
var pack = JSON.parse(fs.readFileSync("./third-party/config.json", "utf8"));
var restrictCommonMethods = ["destroy", "refresh", "Destroy", "Refresh"];
var baseClass = '';
var baseParentObj = null;
var isParametersSet = false;
var isGenericClass = false;
var isDomArgs = [], annotationName = [], annotationType = [], twoWays = [], renderFragmentType = [];
var isdataAnnotation, isTwoway;
var newLine = "\n";
var tab = "    ";
var childProperties = {};
var genericEventModels = [], validatedEventModels = [];
var reservedWords = ['event']
const commonMethodTypes = {
    string: "string",
    number: "double",
    double: "double",
    int: "int",
    Boolean: "boolean",
    boolean: "boolean",
    bool: "boolean",
    Date: "DateTime",
    DateTime: "DateTime"
};

const ignoreNull = [
    "double",
    "int",
    "boolean",
    "bool",
    "DateTime"
]

const handledTypes = {
    string: "string",
    Boolean: "bool",
    boolean: "bool",
    bool: "bool",
    number: "double",
    double: "double",
    int: "int",
    Event: "EventArgs",
    Date: "DateTime",
    DateTime: "DateTime"
};
var templates = [];
var templateFile = fs.readFileSync(__dirname + '/template.template', 'utf8');
var handledTypesKeys = Object.keys(handledTypes);
var commonMethodTypesKeys = Object.keys(commonMethodTypes);
class BlazorSourceGen {
    constructor(json, propCollection, pJson, done) {
        this.tClass = "where T : class";
        var propList = (this.propertyList = propCollection);
        this.interfaces = propList.interfaces;
        this.types = propList.typeAliases;
        this.enums = propList.enumAliases;
        this.classes = propList.allClasses;
        if (json) {
            this.render(json, propList, done);
        }
        return this;
    }

    namespaceCheck(name) {
        var temp = name.split("-");
        if (temp.length > 0) {
            for (var i = 0; i < temp.length; i++) {
                temp[i] = this.toInitCap(temp[i]);
            }
            return temp.join().replace(/\,/g, "");
        } else {
            return name;
        }
    }

    isClassFile(comp) {
        return (comp && comp.blazorType == "hybrid") || comp.isCustomBlazor || comp.isPartialClass || comp.isCommon;
    }

    render(json, propList, done) {
        if (json.blazorType === "none" || json.blazorType === "native") {
            done();
            return;
        }
        var files = {};
        var enums = [];
        var curCompName = this.namespaceCheck(pack.name);
        var filePath = "./third-party/blazor/Syncfusion.Blazor/" + curCompName + "/";
        var oldFiles = glob.sync(filePath + "/*", { ignore: [filePath + "Internal/**"] });
        shelljs.rm("-rf", oldFiles);
        this.generateEventModels();
        //this.generateLocale(json);
        for (var i = 0; i < json.components.length; i++) {
            var comp = json.components[i];
            if (comp.blazorType === "none" || comp.blazorType === "native") {
                continue;
            }
            var restrict = true;
            var isClassFile = this.isClassFile(comp);
            this.sComp = comp;
            var templateName = pack.isServerComponent ? "io.template" : (isClassFile ? "hybrid.template" : "blazor.template");
            templateName = comp.isBlazorDerivedTemplate ? "hybrid-derived.template" : templateName;
            var cnt = fs.readFileSync(__dirname + "/" + templateName).toString();
            var options = {
                enums: enums
            };
            var curType = this.getClassName(comp, comp);
            var returnVal = this.generateComponent(cnt, propList, comp, json, options, restrict);
            returnVal = returnVal.replace(/{{AnnotationSettings}}/, this.getAnnotationSettings(comp, propList));
            returnVal = isClassFile ? returnVal.replace(/{{CommonClassName}}/, curType) : returnVal;
            files[comp.baseClass] = returnVal;
            shelljs.mkdir("-p", "./third-party/blazor/Syncfusion.Blazor/" + curCompName);
            var fileName = pack.isServerComponent ? comp.baseClass + "Base.cs" : curType + (isClassFile ? ".razor.cs" : ".razor");
            fs.writeFileSync("./third-party/blazor/Syncfusion.Blazor/" + "/" + curCompName + "/" + fileName, returnVal);
            if ((comp.tagDirective && comp.tagDirective.length) || (comp.migratedTagDirective && comp.migratedTagDirective.length)) {
                var context = fs.readFileSync(__dirname + "/" + "collection.template").toString();
                var tagDirectiveObj = comp.migratedTagDirective || comp.tagDirective;
                this.collectionProcessor(context, tagDirectiveObj, comp, comp, options, propList, curType);
            }
            if (comp.complexDirective && comp.complexDirective.length) {
                var templateFile = comp.isPartialClass ? "hybrid-complex.template" : "complex.template";
                var context = fs.readFileSync(`${__dirname}/${templateFile}`).toString();
                this.complexProcessor(context, comp.complexDirective, comp, comp, options, propList, curType);
            }
            if (pack.isServerComponent) {
                this.generateModules(propList, comp, options, restrict, curCompName);
                if (pack.isRequiredRazor) {
                    cnt = fs.readFileSync(__dirname + "/pdfviewer.template").toString();
                    fs.writeFileSync("./third-party/blazor/Syncfusion.Blazor/" + "/" + curCompName + "/" + curType + ".razor", cnt);
                }
            }
        }
        enums = this.generateAllEnums(enums, this.types);
        enums = this.generateAllEnums(enums, this.enums);
        this.generateEnum(enums, this.types, this.enums);
        done();
    }

    generateLocale(json) {
        var mainConfig = JSON.parse(fs.readFileSync("./config.json", "utf8"));
        var baseClasses = json.components.map(component => component.baseClass);
        if (!mainConfig.locale) {
            return;
        }
        var localeContent = fs.readFileSync(`${__dirname}/locale.template`, 'utf8');
        var components = Object.keys(mainConfig.locale);
        var componentsObj = {}
        components.filter((component) => {
            var comp = component.replace(/-/g, '').toLowerCase();
            var baseClass = baseClasses.filter(baseClass => baseClass.toLowerCase() == comp);
            componentsObj[component] = baseClass.length ? baseClass[0] : component;
        });
        var localeProperties = "";
        var localeComponents = "";
        for (var i = 0; i < components.length; i++) {
            var localeProps = mainConfig.locale[components[i]];
            var component = this.toInitCap(componentsObj[components[i]]);
            localeComponents += newLine + tab + tab + `[JsonPropertyName("${components[i]}")]` +
                newLine + tab + tab + `[EditorBrowsable(EditorBrowsableState.Never)]` +
                newLine + tab + tab + `public ${component}Locale ${component} { get; set; } = new ${component}Locale();`;
            localeProperties += newLine + tab + `[EditorBrowsable(EditorBrowsableState.Never)]` +
                newLine + tab + `public class ${component}Locale {`;
            var localePropKeys = Object.keys(localeProps);
            for (var j = 0; j < localePropKeys.length; j++) {
                var firstChar = localePropKeys[j][0];
                if (firstChar === firstChar.toLowerCase() || localePropKeys[j].indexOf('-') !== -1) {
                    localeProperties += newLine + tab + tab + `[JsonPropertyName("${localePropKeys[j]}")]`;
                }
                var localeValue = localeProps[localePropKeys[j]].replace(/\"/g, "\\\"").replace(/\/[^a-zA-Z\/\s]/g, "\\\/:");
                localeProperties += newLine + tab + tab + `public string ${this.getLocaleProperty(localePropKeys[j])} { get; set; } = "${localeValue}";`;
            }
            localeProperties += newLine + tab + "}";
        }
        localeContent = localeContent.replace(/{{LocaleProperties}}/, localeProperties);
        localeContent = localeContent.replace(/{{LocaleComponents}}/, localeComponents);
        localeContent = localeContent.replace(/{{NameSpace}}/, this.namespaceCheck(pack.name));
        var fileName = json.name.split(/-/g).join('');
        fs.writeFileSync(`./third-party/blazor/Syncfusion.Blazor/${fileName}/${fileName}Locale.cs`, localeContent);
    }

    getLocaleProperty(keyword) {
        keyword = keyword.split(/ /g).map(word => `${word.substring(0, 1).toUpperCase()}${word.substring(1)}`).join('');
        return keyword.split(/-/g).map(word => `${word.substring(0, 1).toUpperCase()}${word.substring(1)}`).join('');
    }

    getAnnotationSettings(comp, propList) {
        var annotation = "";
        var tabIndend = this.isClassFile(comp) ? tab + tab + tab : tab + tab;
        var annotationProps = comp.annotationProperties;
        if (annotationProps) {
            var props = propList[comp.baseClass];
            annotation = newLine + newLine;
            for (var i = 0; i < annotationProps.length; i++) {
                var propObj = props._propObjects[annotationProps[i]];
                var propType = this.getPropertyType(propObj, comp, null, null, comp);
                if (propType === "object" && comp.tagDirective) {
                    var propFilteredList = comp.tagDirective.filter((tagObj) => {
                        if (tagObj.propertyName === annotationProps[i]) {
                            return true;
                        }
                    });
                    var propTagObj = propFilteredList[0];
                    if (propTagObj.isGenericClass) {
                        propType = "List<" + this.getGenericParentType(propTagObj) + ">";
                    }
                    else {
                        propType = "List<" + this.getClassName(comp, propTagObj, "complexType", comp) + ">";
                    }
                }
                var csProp = this.toInitCap(annotationProps[i]);
                annotation += tabIndend + `${propType} ${annotationProps[i]} = (${propType})this.${csProp};` +
                    newLine + tabIndend + `${comp.baseClass}Annotation.MapAnnotation(ref ${annotationProps[i]}, typeof(TValue));` +
                    newLine + tabIndend + `this.${csProp} = ${annotationProps[i]};`;
            }
        }
        return annotation;
    }

    getCustomProperties(comp) {
        var content = "";
        var indend = this.isClassFile(comp) ? newLine + tab + tab : newLine + tab;
        if (comp.customProperties) {
            for (var i = 0; i < comp.customProperties.length; i++) {
                content = indend + `/// <summary>` +
                    indend + `/// ${comp.customProperties[i].comments}` +
                    indend + `/// </summary>` +
                    indend + `[Parameter]` +
                    indend + `[DefaultValue(${comp.customProperties[i].defaultValue})]` +
                    indend + `[JsonProperty("${comp.customProperties[i].name}")]` +
                    indend + `public ` + comp.customProperties[i].type + ` ` + this.toInitCap(comp.customProperties[i].name) + ` { get; set; } = ${comp.customProperties[i].defaultValue};` +
                    indend + `private ` + comp.customProperties[i].type + ` _${comp.customProperties[i].name}` + ` { get; set; }` + newLine + newLine;
            }
        }
        return content;
    }

    generateAllEnums(enums, allEnums) {
        var typeEnums = [];
        var typeKeys = Object.keys(allEnums);
        for (var i = 0; i < typeKeys.length; i++) {
            var enumList = [], newObj = {};
            var enumObj = allEnums[typeKeys[i]];
            var isPresent = false;
            if (enumObj.kindString !== "Enumeration") {
                var enumTypes = enumObj.type.types;
                if (enumTypes) {
                    for (var j = 0; j < enumTypes.length; j++) {
                        if (enumTypes[j].value) {
                            enumList.push(enumTypes[j].value);
                        }
                        else {
                            enumList.push(enumTypes[j].name);
                        }
                    }
                }
                else {
                    continue;
                }
            } else {
                var enumTypes = enumObj.children;
                var numEnums = [];
                if (enumTypes) {
                    for (var l = 0; l < enumTypes.length; l++) {
                        if (enumTypes[l].defaultValue) {
                            numEnums.push(enumTypes[l].defaultValue);
                            enumList.push(enumTypes[l].name);
                        }
                    }
                    enumList["numberEnum"] = numEnums;
                }
            }
            var enumName = this.toInitCap(enumObj.name);
            newObj[enumName] = enumList;
            for (var k = 0; k < enums.length; k++) {
                if (enums[k][enumName] || enums[k][enumObj.name]) {
                    isPresent = true;
                    break;
                }
            }
            if (!isPresent) {
                typeEnums.push(newObj);
            }
        }
        return enums = enums.concat(typeEnums);
    }

    complexProcessor(context, curCompList, pObj, superComp, options, propList, parentType) {
        for (var l = 0; l < curCompList.length; l++) {
            var newCurComp = curCompList[l];
            if (!newCurComp.isDeprecated) {
                options.isArrayParentType = false;
                this.generateComplexSource(newCurComp, pObj, superComp, options, propList, parentType);
                renderFragmentType.length = 0;

                var curParentType = this.getClassName(superComp, newCurComp);
                // //complex inside complex navigation
                if (newCurComp.complexDirective && newCurComp.complexDirective.length) {
                    this.complexProcessor(context, newCurComp.complexDirective, newCurComp, superComp, options, propList, curParentType);
                }

                //collection inside complex navigation
                if ((newCurComp.tagDirective && newCurComp.tagDirective.length) || (newCurComp.migratedTagDirective && newCurComp.migratedTagDirective.length)) {
                    var tagDirectiveObj = newCurComp.migratedTagDirective || newCurComp.tagDirective;
                    this.collectionProcessor(context, tagDirectiveObj, newCurComp, superComp, options, propList, curParentType);
                }
            }
        }
    }

    rmRepeatedName(addingName, baseName) {
        if (baseName.indexOf(addingName) >= 0) {
            return baseName;
        } else {
            return addingName + baseName;
        }
    }

    processType(curComp, comp, tagDirective) {
        var name;
        if (curComp.directoryName && comp && comp.baseClass && comp.baseClass.toLowerCase() === curComp.directoryName.replace("-", "").toLowerCase()) {
            name = comp.baseClass;
        } else if (curComp.directoryName && tagDirective && tagDirective.baseClass && tagDirective.baseClass.toLowerCase() === curComp.directoryName.replace("-", "").toLowerCase()) {
            name = tagDirective.baseClass;
        } else if (curComp.directoryName) {
            name = curComp.directoryName;
        } else {
            name = curComp.baseClass;
        }

        if (name && name.indexOf("-") !== -1) {
            var sName = name.split("-");
            for (var i = 0; i < sName.length; i++) {
                sName[i] = this.toInitCap(sName[i]);
            }
            return sName.join().replace(",", "");
        }
        return this.toInitCap(name);

    }

    getClassName(comp, curComp, isArray, tagDirective) {
        var compBaseClass = comp ? comp.baseClass : curComp.baseClass;
        if (comp && isArray === "complexType") {
            compBaseClass = this.processType(curComp, comp, tagDirective);
        }
        if (comp == curComp) {
            baseClass = "Sf" + comp.baseClass;
            return baseClass;
        }
        if (isArray === true) {
            return (curComp.blazorArrayClassName || curComp.aspArrayClassName || (curComp.arrayDirectiveClassName ? this.rmRepeatedName(compBaseClass, this.toInitCap(curComp.arrayDirectiveClassName)) : this.rmRepeatedName(this.sComp.baseClass, curComp.baseClass + 's')));
        }
        return (
            curComp.blazorClassName || curComp.aspClassName || (curComp.directiveClassName ? this.rmRepeatedName(compBaseClass, this.toInitCap(curComp.directiveClassName)) : this.rmRepeatedName(this.sComp.baseClass, curComp.baseClass))
        );
    }

    getGenericParentType(parent, parentType, isBaseParent) {
        var type = parentType;
        if (isGenericClass && parentType && parentType.indexOf("Sf") !== -1) {
            type = "I" + baseClass.replace('Sf', '');
        }
        else if (parent && parent.baseClass !== baseParentObj.baseClass && parent.isGenericClass && !isBaseParent) {
            type = "I" + baseClass.replace('Sf', '') + parent.baseClass;
        }
        return type;
    }

    generateComplexSource(curComp, parent, superComp, options, propList, parentType) {
        var templateFile = curComp.isPartialClass ? "hybrid-complex.template" : "complex.template";
        var context = fs.readFileSync(`${__dirname}/${templateFile}`).toString();
        context = context.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
        var parentType = parentType || this.getClassName(superComp, parent);
        parentType = curComp.blazorArrayClassName ? parentType : this.getGenericParentType(parent, parentType);
        var baseParentType = this.getGenericParentType(parent, baseClass, true);
        var currentType = this.getClassName(superComp, curComp);
        var currentGenericType = this.getGenericParentType(curComp, currentType);
        var curPropertyName = this.toInitCap(curComp.propertyName);
        var genericInterface;
        if (curComp.isGenericClass) {
            var circularInterface = curComp.isCircularBlazorComponent ? ', ICircularComponent' : '';
            genericInterface = curComp.isPartialClass ? `, ${currentGenericType}${circularInterface}` : `@implements ${currentGenericType}${circularInterface};${newLine}`;
        }
        else {
            genericInterface = curComp.isPartialClass ? (curComp.isCircularBlazorComponent ? ', ICircularComponent' : '') :
                (curComp.isCircularBlazorComponent ? `@implements ICircularComponent;${newLine}` : newLine);
        }
        isGenericClass = baseParentObj.isGenericClass || curComp.isGenericClass;
        var contextProperty = this.getCollectionClassProperties(curComp, parent, curComp, { restrictedChild: [], enums: options.enums }, propList);
        var indend = this.isClassFile(curComp) ? newLine + tab + tab + tab : newLine + tab + tab;
        if (curComp.isGenericClass) {
            this.generateInterface(curComp, contextProperty.interface);
        }
        var contextProperties = contextProperty.content;
        var paremetersSet = "";
        if (isParametersSet) {
            paremetersSet = newLine + tab + tab + `if (this.DelegateList.Count() > 0)` +
                newLine + tab + tab + "{" +
                newLine + tab + tab + tab + `foreach (var eventList in this.DelegateList)` +
                newLine + tab + tab + tab + "{" +
                newLine + tab + tab + tab + tab + `EventData data = this.DelegateList[eventList.Key];` +
                newLine + tab + tab + tab + tab + `this.baseParent.InvokeGenericMethod("SetEvent", data.ArgumentType, this.baseParent.GetType(), this.GetJSNamespace() + "." + eventList.Key, data.Handler);` +
                newLine + tab + tab + tab + '}' +
                newLine + tab + tab + '}';
            isParametersSet = false;
        }

        var typeParam = curComp.isGenericClass ? (curComp.isPartialClass ? "<TValue>" : newLine + "@typeparam TValue;") : (curComp.isPartialClass ? "" : newLine);
        if (curComp.isCommon) {
            if (curComp.isCustomBlazor) {
                return this.generateCustomClass(curComp, curComp.blazorClassName || curComp.blazorCommonClassName, contextProperties);
            }
            var commonClassFilePath = `./third-party/blazor/Syncfusion.Blazor/${this.namespaceCheck(pack.name)}/${curComp.blazorCommonClassName}.cs`;
            var genericType = curComp.isGenericClass ? "<TValue>" : "";
            if (!fs.existsSync(commonClassFilePath)) {
                var genericInterface = curComp.isGenericClass ? ", " + this.getGenericParentType(curComp) : "";
                templateFile = curComp.isPartialClass ? "hybrid-complex.template" : "commonclass.template";
                var commonContent = fs.readFileSync(`${__dirname}/${templateFile}`, 'UTF8');
                commonContent = commonContent.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
                commonContent = commonContent.replace(/{{GenericInterface}}/g, genericInterface);
                commonContent = commonContent.replace(/{{CommonClassName}}/g, curComp.blazorCommonClassName + genericType);
                commonContent = commonContent.replace(/{{Properties}}/g, contextProperties);
                commonContent = commonContent.replace(/{{InitializeProperties}}/g, contextProperty.initProps);
                commonContent = commonContent.replace(/{{JSNamespace}}/g, curComp.propertyName);
                commonContent = commonContent.replace(/{{GenericType}}/g, typeParam);
                commonContent = commonContent.replace(/{{Interface}}/g, genericInterface);
                commonContent = commonContent.replace(/{{ParentType}}/g, parentType);
                commonContent = commonContent.replace(/{{BaseParentType}}/g, baseParentType);
                commonContent = commonContent.replace(/{{SetParameterChanges}}/g, contextProperty.propChanges);
                commonContent = commonContent.replace(/{{UpdateChildProperties}}/g, this.generateChildProperties(curComp, parent));
                if (curComp.isPartialClass) {
                    commonContent = commonContent.replace(/{{InvokeEvents}}/, "");
                    commonContent = commonContent.replace(/{{OnInitContext}}/, "");
                    commonContent = commonContent.replace(/{{OnInitTemplate}}/, "");
                    commonContent = commonContent.replace(/{{RenderTemplate}}/, "");
                    commonContent = commonContent.replace(/{{TemplateParameter}}/, "");
                    commonContent = commonContent.replace(/{{PartialClass}}/g, curComp.blazorCommonClassName);
                    commonContent = commonContent.replace(/{{InitComplexProperty}}/g, this.getInitComplex(curComp, parent, parentType, baseParentType, currentType));
                }
                fs.writeFileSync(commonClassFilePath, commonContent);
            }
            typeParam = curComp.isGenericClass ? newLine + "@typeparam TValue;" : newLine;
            var updateParentProperty = `System.Type parentType = this.dynamicParent.GetType();` +
                newLine + tab + tab + `MethodInfo methodInfo = parentType.GetMethod("updateChildProperties");` +
                newLine + tab + tab + `methodInfo?.Invoke(this.dynamicParent, new object[] { "{{JSNamespace}}", this });`;
            if (options.isArrayParentType) {
                updateParentProperty = `System.Type parentType = this.dynamicParent.GetType();` +
                    newLine + tab + tab + `MethodInfo methodInfo = parentType.GetMethod("updateChildProperty", BindingFlags.Instance | BindingFlags.NonPublic);` +
                    newLine + tab + tab + `this._sfTagIndex = (int)methodInfo?.Invoke(this.dynamicParent, new object[] { this });`;
            }
            var commonrazorContent = fs.readFileSync(__dirname + "/" + './commonrazor.template', 'UTF8');
            commonrazorContent = commonrazorContent.replace(/{{UpdateParentProperty}}/, updateParentProperty);
            commonrazorContent = this.generateComplexTemplates(curComp, commonrazorContent, parent, true);
            commonrazorContent = commonrazorContent.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
            commonrazorContent = commonrazorContent.replace(/{{CommonClassName}}/g, curComp.blazorCommonClassName + genericType);
            commonrazorContent = commonrazorContent.replace(/{{propertyName}}/g, '"' + curPropertyName + '"');
            commonrazorContent = commonrazorContent.replace(/{{JSNamespace}}/g, curComp.propertyName);
            commonrazorContent = commonrazorContent.replace(/{{GenericType}}/g, typeParam);
            commonrazorContent = commonrazorContent.replace(/{{Interface}}/g, genericInterface);
            commonrazorContent = commonrazorContent.replace(/{{ParentType}}/g, baseParentType);
            commonrazorContent = commonrazorContent.replace(/{{BaseParentType}}/g, baseParentType);
            commonrazorContent = commonrazorContent.replace(/{{InvokeEvents}}/g, paremetersSet);
            commonrazorContent = commonrazorContent.replace(/{{InitComplexProperty}}/g, this.getInitComplex(curComp, parent, parentType, baseParentType, currentType, true));
            fs.writeFileSync("./third-party/blazor/Syncfusion.Blazor/" + "/" + this.namespaceCheck(pack.name) + "/" + currentType + ".razor", commonrazorContent);
        }
        else {
            if (curComp.isCustomBlazor) {
                return this.generateCustomClass(curComp, currentType, contextProperties);
            }
            var pType = pack.isServerComponent ? (pack.name + "Base") : parentType;
            var bpType = pack.isServerComponent ? (pack.name + "Base") : baseParentType;
            context = context.replace(/{{GenericType}}/g, typeParam);
            context = context.replace(/{{Interface}}/g, genericInterface);
            context = context.replace(/{{ParentType}}/g, pType);
            context = context.replace(/{{BaseParentType}}/g, bpType);
            context = context.replace(/{{PropertyName}}/g, curPropertyName);
            context = context.replace(/{{Properties}}/g, contextProperties);
            context = context.replace(/{{JSNamespace}}/g, curComp.propertyName);
            context = context.replace(/{{InvokeEvents}}/g, paremetersSet);
            var initContext = '';
            if (options.isArrayParentType) {
                initContext = indend + `this._sfTagIndex = this.parent.updateChildProperty(this);`;
            } else {
                initContext = indend + `this.parent.updateChildProperties("${curComp.propertyName}", this);`;
            }
            context = context.replace(/{{OnInitContext}}/g, initContext);
            context = this.generateComplexTemplates(curComp, context, parent);
            context = context.replace(/{{InitializeProperties}}/g, contextProperty.initProps);
            context = context.replace(/{{SetParameterChanges}}/g, contextProperty.propChanges);
            context = context.replace(/{{UpdateChildProperties}}/g, this.generateChildProperties(curComp, parent));
            context = context.replace(/{{InitComplexProperty}}/g, this.getInitComplex(curComp, parent, pType, bpType, currentType));
            context = context.replace(/{{PartialClass}}/g, currentType);
            var isClassFile = this.isClassFile(curComp);
            if (isdataAnnotation) {
                var dataVal = this.dataAnnotation(annotationName, annotationType, isClassFile);
                context = context.replace(/{{DataAnnotationAttributes}}/g, dataVal);
                isdataAnnotation = false;
            } else {
                context = context.replace(/{{DataAnnotationAttributes}}/g, "");
            }
            var fileType = curComp.isPartialClass ? ".cs" : ".razor";
            fs.writeFileSync(`./third-party/blazor/Syncfusion.Blazor/${this.namespaceCheck(pack.name)}/${currentType}${fileType}`, context);
        }
        isGenericClass = baseParentObj.isGenericClass;
        return { currentType: currentType };
    }

    generateComplexTemplates(curComp, context, parent, isRazor) {
        var templateRender = "";
        var templateParameter = "";
        var templateOnInit = "";
        var templateOnAfterRender = "";
        var isInstanceCreation = "";
        var templateDispose = "";
        var templateIndend = this.isClassFile(curComp) && !isRazor ? newLine + tab + tab  : newLine + tab  ;
        var complexInstance = "";
        var complexDispose = "";
        if (templates.length) {
            for (var i = 0; i < templates.length; i++) {
                var currentTempalte = this.getTemplateProperty(curComp, templates[i]);
                var templateName = this.toInitCap(currentTempalte.blazorProperty);
                var orSeparator = templateDispose != '' ? '|| ':'';
                templateDispose +=  orSeparator + templateName + ' != null ';
                var isContainerTemplate = currentTempalte.isContainerTemplate;
                var isActualParamRendered = currentTempalte.actualProperty === currentTempalte.blazorProperty;
                var modelClass = curComp.blazorTemplateModels && curComp.blazorTemplateModels[templates[i]] ? curComp.blazorTemplateModels[templates[i]] : null;
                templateRender += this.getTemplateRender(templateName, false, isContainerTemplate, modelClass);
                templateOnInit += this.getTemplateOnInit(false, this.toInitCap(currentTempalte.actualProperty), templateName, i, true, parent.type);
                templateParameter += this.getTemplateParameters(templateName, isActualParamRendered, isContainerTemplate, templateIndend);
                templateOnAfterRender += this.getTemplateOnAfterRender(templateName, isContainerTemplate, curComp.blazorContainerTemplates, templateIndend + tab);
            }
            complexInstance = 'internal DotNetObjectReference<object> DotnetInstance { get; set; }' + templateIndend;
            complexDispose = 'this.DotnetInstance?.Dispose();' + templateIndend + 'this.DotnetInstance = null;'+templateIndend;
            templateOnAfterRender = !curComp.blazorContainerTemplates ? templateOnAfterRender + templateIndend + tab + 'TemplateClientChanges = false;' : templateOnAfterRender;
            templates = [];
            templateOnInit += this.getTemplateHashTable(true, this.isClassFile(curComp) && !isRazor);
            isInstanceCreation = templateIndend + tab + 'if(('+ templateDispose + ') && this.DotnetInstance == null) {'+ templateIndend + tab + tab + 'this.DotnetInstance = DotNetObjectReference.Create<object>(this);' +templateIndend+ tab + '}';
        }
        context = context.replace(/{{OnInitTemplate}}/, templateOnInit);
        context = context.replace(/{{TemplateRender}}/, templateRender);
        context = context.replace(/{{TemplateParameter}}/, complexInstance + templateParameter);
        context = context.replace(/{{RenderTemplate}}/, isInstanceCreation + templateOnAfterRender);
        context = context.replace(/{{ComplexDispose}}/, complexDispose);
       // context = context.replace(/{{disposeDotnetInstances}}/, templateDispose);
        return context;
    }

    generateCustomClass(comp, currentType, contextProperties) {
        var propertyName = comp.propertyName;
        var fileName = `${baseParentObj.baseClass.toLowerCase()}-partial.template`;
        var complexProperties = "";
        if (comp.complexDirective) {
            var complexProps = this.getComplexProperties(comp.complexDirective);
            for (var i = 0; i < complexProps.length; i++) {
                var childProp = childProperties[complexProps[i]];
                if (childProp && !childProp.startsWith('ObservableCollection')) {
                    complexProperties += newLine + tab + tab + tab + `this.${this.toInitCap(complexProps[i])}.Parent = this;`;
                }
            }
        }
        var customTemplate = fs.readFileSync(`${__dirname}/${fileName}`, 'UTF8');
        var customClassFilePath = `./third-party/blazor/Syncfusion.Blazor/${this.namespaceCheck(pack.name)}/${currentType}.cs`;
        customTemplate = customTemplate.replace(/{{ClassName}}/g, currentType);
        customTemplate = customTemplate.replace(/{{JSNamespace}}/g, propertyName);
        customTemplate = customTemplate.replace(/{{Properties}}/, contextProperties);
        customTemplate = customTemplate.replace(/{{ComplexChildren}}/, complexProperties);
        fs.writeFileSync(customClassFilePath, customTemplate);
    }

    getComplexProperties(complexDirective) {
        var props = complexDirective.map(value => value.propertyName);
        return [...new Set(props)];
    }

    collectionProcessor(context, curCompList, pObj, superComp, options, propList, parentType) {
        for (var k = 0; k < curCompList.length; k++) {
            var newCurComp = curCompList[k];
            if (!newCurComp.isDeprecated) {
                options.isArrayParentType = true;
                var curParentType = this.getClassName(superComp, newCurComp, true);
                var complexType = this.getClassName(superComp, newCurComp);
                this.generateCollectionSource(newCurComp, pObj, superComp, options, propList, parentType);
                // console.log(complexType);
                this.generateComplexSource(newCurComp, pObj, superComp, options, propList, curParentType);
                renderFragmentType.length = 0;

                // collection inside collection
                if ((newCurComp.tagDirective && newCurComp.tagDirective.length) || (newCurComp.migratedTagDirective && newCurComp.migratedTagDirective.length)) {
                    var tagDirectiveObj = newCurComp.migratedTagDirective || newCurComp.tagDirective;
                    this.collectionProcessor(context, tagDirectiveObj, newCurComp, superComp, options, propList, complexType);
                }

                //complex inside collection navigation
                if (newCurComp.complexDirective && newCurComp.complexDirective.length) {
                    this.complexProcessor(context, newCurComp.complexDirective, newCurComp, superComp, options, propList, complexType);
                }
            }
        }
    }

    generateCollectionSource(curComp, parent, superComp, options, propList, parentType) {
        if (curComp.isCustomBlazor) {
            return;
        }
        var context = fs.readFileSync(__dirname + "/" + "collection.template").toString();
        var context = context.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
        var parentType = this.getClassName(superComp, parent);
        parentType = this.getGenericParentType(parent, parentType);
        parentType = curComp.isCircularBlazorComponent ? 'object' : parentType;
        var complexType = this.getClassName(superComp, curComp);
        complexType = this.getGenericParentType(curComp, complexType);
        var curType = this.getClassName(superComp, curComp, true);
        var curPropertyName = this.toInitCap(curComp.propertyName);
        var contextProperty = this.getCollectionClassProperties(curComp, parent, curComp, { restrictedChild: [], enums: options.enums }, propList);
        var contextProperties = contextProperty.content;
        var baseParentType = this.getGenericParentType(parent, baseClass, true);
        if (curComp.isCommon) {
            var commonContent = fs.readFileSync(__dirname + "/" + './commonclass.template', 'UTF8');
            var commonrazorContent = fs.readFileSync(__dirname + "/" + './commoncollection.template', 'UTF8');
            var commonClassFilePath = `./third-party/blazor/Syncfusion.Blazor/${this.namespaceCheck(pack.name)}/${curComp.blazorCommonClassName}.cs`;
            var genericType = curComp.isGenericClass ? "<TValue>" : "";
            if (!fs.existsSync(commonClassFilePath)) {
                var genericInterface = curComp.isGenericClass ? ", " + this.getGenericParentType(curComp) : "";
                commonContent = commonContent.replace(/{{GenericInterface}}/g, genericInterface);
                commonContent = commonContent.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
                commonContent = commonContent.replace(/{{CommonClassName}}/g, curComp.blazorCommonClassName + genericType);
                commonContent = commonContent.replace(/{{Properties}}/g, contextProperties);
                commonContent = commonContent.replace(/{{BaseParentType}}/g, baseParentType);
                commonContent = commonContent.replace(/{{InitializeProperties}}/, contextProperty.initProps);
                commonContent = commonContent.replace(/{{SetParameterChanges}}/, contextProperty.propChanges);
                commonContent = commonContent.replace(/{{UpdateChildProperties}}/g, this.generateChildProperties(curComp, parent));
                fs.writeFileSync(commonClassFilePath, commonContent);
            }
            commonrazorContent = commonrazorContent.replace(/{{namespace}}/g, this.namespaceCheck(pack.name));
            commonrazorContent = commonrazorContent.replace(/{{JSNamespace}}/g, curComp.propertyName);
            commonrazorContent = commonrazorContent.replace(/{{PropertyName}}/g, curPropertyName);
            commonrazorContent = commonrazorContent.replace(/{{ComplexType}}/g, complexType);
            fs.writeFileSync("./third-party/blazor/Syncfusion.Blazor/" + "/" + this.namespaceCheck(pack.name) + "/" + curType + ".razor", commonrazorContent);
        } else {
            context = context.replace(/{{ParentType}}/g, parentType);
            context = context.replace(/{{JSNamespace}}/g, curComp.propertyName);
            context = context.replace(/{{BaseParentType}}/g, baseParentType);
            context = context.replace(/{{ComplexType}}/g, complexType);
            context = context.replace(/{{PropertyName}}/g, this.toInitCap(curComp.propertyName));
            context = context.replace(/{{CircularParent}}/g, curComp.isCircularBlazorComponent ? '(ICircularComponent)' : '');
            fs.writeFileSync("./third-party/blazor/Syncfusion.Blazor/" + "/" + this.namespaceCheck(pack.name) + "/" + curType + ".razor", context);
        }
        return { curType: curType };
    }

    getCollectionClassProperties(comp, parent, tagDirective, options, propList) {
        var curInterface = this.interfaces[tagDirective.baseClass + "Model"];
        var content = "";
        var propInterface = "";
        var initProps = "";
        var propChanges = "";
        var isDataSource, isData, curProp;
        if (curInterface) {
            var innerProperties = curInterface.children;
            for (var j = 0; j < innerProperties.length; j++) {
                var curProperty = innerProperties[j];
                var isDeprecate = false;
                // if (curProperty.name === "data") {
                isDataSource = this.isDataSource(curProperty);
                if (isDataSource !== undefined) {
                    isData = isDataSource.dataSource;
                    curProp = isDataSource.propName;
                }
                // }

                if (curProperty.comment.tags && curProperty.comment.tags.length > 0) {
                    for (var k = 0; k < curProperty.comment.tags.length; k++) {
                        if (curProperty.comment.tags[k].tag === "deprecated") {
                            isDeprecate = true;
                        }
                    }
                }

                if (!isDeprecate && this.isExported(curProperty)) {
                    var firstIndend = j === 0;
                    var currentProperty = this.createPropertySyntax(firstIndend, curProperty, comp, parent, tagDirective, options, propList[tagDirective.baseClass]._propShortComments);
                    content += currentProperty.content;
                    initProps += currentProperty.initProps;
                    propChanges += currentProperty.propChanges;
                    propInterface += currentProperty.interface;
                    if (curProperty.name === "dataSource" && options.restrictedChild) {
                        options.restrictedChild.push("e-data-manager");
                    }
                }
            }
        }
        content += this.getCustomProperties(comp);
        return {
            content: content,
            isData: isData,
            curProp: curProp,
            interface: propInterface,
            initProps: initProps,
            propChanges: propChanges
        };
    }

    generateEventModels() {
        var proxy = this;
        var helper = fs.readFileSync(__dirname + "/" + "eventmodel.template").toString();
        var prop = "\n";
        var folderName = this.namespaceCheck(pack.name);
        if (this.propertyList.interfacesNames && this.propertyList.interfacesNames.length) {
            this.propertyList.interfacesNames.forEach(function (eventargs) {
                shelljs.mkdir("-p", "./third-party/blazor/Syncfusion.Blazor/" + folderName + "/EventModels/");
                prop += proxy.generateEventModelProperties(eventargs);
            });
            helper = helper.replace(/{{:interfaces}}/g, prop);
            helper = helper.replace(/{{:nameSpace}}/g, this.namespaceCheck(pack.name));
            fs.writeFileSync("./third-party/blazor/Syncfusion.Blazor/" + this.namespaceCheck(pack.name) + "/EventModels/" + this.namespaceCheck(pack.name) + ".cs",
                helper, "UTF8");
        }
    }

    getModelPropComments(obj, isModel) {
        if (obj.comment && obj.comment.shortText && obj.comment !== null) {
            var comment = obj.comment.shortText;
            var commentArray = comment.split('\n');
            comment = commentArray.join('\n'+ tab+ tab + '/// ').replace(/(\*|<[^]*>)/g, '') + '\n' + tab + tab ;
            var modelComment = commentArray.join('\n'+ tab+ tab + '/// ').replace(/(\*|<[^]*>)/g, '') + '\n' + tab ;
            comment = !isModel ? '\n'+ tab + tab +'/// <summary>\n'+ tab + tab + '/// ' + comment + '/// </summary>\n' : '\n'+
                tab +'/// <summary>\n'+ tab + '/// ' + modelComment + '/// </summary>\n' ;
            return comment;
        } else {
            return '';
        }
    }

    generateEventModelProperties(eventargs) {
        var proxy = this;
        var currentInterface = this.propertyList.interfaces[eventargs];
        var isDeprecated = proxy.getBlazorTagValue(currentInterface, "deprecated");
        // For ignore the interfaces/models which are mentaioned as @deprecated
        if (isDeprecated) {
            return "";
        }
        var isPrivate = currentInterface.flags.isPrivate;
        if (currentInterface.flags.isExported && (!isPrivate || (isPrivate && this.getBlazorTagValue(currentInterface, "isblazorinterface")))) {
            var isGenericTypeEvent = false;
            var interfaceComment = this.getModelPropComments(currentInterface, true);
            var syntax = tab + interfaceComment + tab + `public class ${eventargs}{{GenericType}} : IEquatable<${eventargs}{{GenericType}}>` + newLine + tab + '{' + newLine;
            var args = "";
            var domArgs = "";
            var domArgsOnly = "";
            var domProps = {};
            if (currentInterface && currentInterface.children && currentInterface.children.length) {
                currentInterface.children.forEach(function (obj, index, array) {
                    var defaultValue;
                    var isDeprecated = proxy.getBlazorTagValue(obj, "deprecated");
                    var getModelPropComments = proxy.getModelPropComments(obj);
                    var ignoreDefaultValue = obj.comment && obj.comment.tags &&
                        obj.comment.tags.filter(function (v) {
                            return v.tag === "blazordefaultvalueignore";
                        });
                    if (obj.comment && obj.comment.tags && !(ignoreDefaultValue && ignoreDefaultValue.length)) {
                        defaultValue = proxy.getDefaultPropertyValue(obj, null, null, null, null, true);
                    }
                    if (!isDeprecated) {
                        if (obj.flags && obj.flags.isPrivate) {
                            return;
                        }
                        else {
                            var currPropType, listProp;
                            var isGenericTypeArg = proxy.isGenericType(obj);
                            var customInterfaceType = proxy.getBlazorTagValue(obj, "blazortype");
                            if (customInterfaceType) {
                                currPropType = customInterfaceType;
                                listProp = currPropType.match(/List<(.*)>/);
                                isGenericTypeArg = !isGenericTypeArg ? proxy.isChildGenericType(listProp ? listProp[1] : currPropType) : isGenericTypeArg;
                            } else {
                                currPropType = proxy.getType(obj, "interface");
                                listProp = currPropType.match(/List<(.*)>/);
                                isGenericTypeArg = !isGenericTypeArg ? proxy.isChildGenericType(listProp ? listProp[1] : currPropType) : isGenericTypeArg;
                            }
                            if (currPropType === "DOM" || currPropType === "CellDOM" || currPropType === "List<DOM>") {
                                domProps[obj.name] = currPropType;
                            }
                            if (currPropType.indexOf("Syncfusion.") >= 0) {
                                if (currPropType.indexOf("Syncfusion.Blazor.") === -1) {
                                    var splitType = currPropType.split(".");
                                    if (currPropType.indexOf("Syncfusion.EJ2.Blazor.") === -1) {
                                        splitType.splice(1, 1, "Blazor");
                                    } else {
                                        splitType.splice(1, 1);
                                    }
                                    currPropType = splitType.join().replace(/\,/g, ".");
                                }
                                currPropType = currPropType.replace('<TValue>', '<T>');
                            }
                            if (!isGenericTypeEvent && isGenericTypeArg) {
                                isGenericTypeEvent = true;
                            }
                            var isDateValue = defaultValue && defaultValue.toString().indexOf("DateTime") !== -1;
                            var enumConvert = proxy.enums[currPropType] || proxy.types[currPropType] ? newLine + tab + tab + '[JsonConverter(typeof(StringEnumConverter))]' : '';
                            var interfaceType = proxy.enums[currPropType] || proxy.types[currPropType] ? proxy.toInitCap(currPropType) : currPropType;
                            var genInterfaceType = listProp ? interfaceType.replace(/.$/, "{{GenericType}}>") : interfaceType + "{{GenericType}}";
                            interfaceType = ((interfaceType === eventargs || isGenericTypeArg) && interfaceType !== "T" && interfaceType !== "List<T>") ? genInterfaceType : interfaceType;
                            var isEnumAcceptable = defaultValue && enumConvert.length && defaultValue !== "null";
                            var isPrimitiveAcceptable = ignoreNull.indexOf(currPropType) !== -1 && defaultValue !== "null";
                            var isGenericAcceptable = ignoreNull.indexOf(currPropType) === -1 && !isGenericTypeArg && !enumConvert.length && currPropType.indexOf("EventCallback") === -1;
                            var acceptDefault = defaultValue && (isGenericAcceptable || isPrimitiveAcceptable || isEnumAcceptable);
                            var dateValue = isDateValue ? `${defaultValue.replace(/"/g, "")}` : "";
                            var defaultVal = acceptDefault ? ` = ${dateValue ? dateValue : defaultValue};` : "";
                            var isNullableInterface = interfaceType.endsWith("?");
                            defaultVal = isNullableInterface ? " = null;" : defaultVal;
                            defaultValue = (acceptDefault || defaultValue === 0) && !isDateValue ? `[DefaultValue(${defaultValue !== "default" ? defaultValue : (isNullableInterface ? "null" : defaultValue + "(" + interfaceType + ")")})]` + newLine + tab + tab : "";
                            var jsonIgnore = currPropType.indexOf("EventCallback") !== -1 || currPropType.indexOf("RenderFragment") !== -1 ? "[JsonIgnore]" + newLine + tab + tab : "";
                            args += getModelPropComments + tab + tab + defaultValue + jsonIgnore + `[JsonProperty("${obj.name}")]` + enumConvert + newLine + tab + tab +
                                `public ${interfaceType} ${proxy.toInitCap(obj.name)} { get; set; }${defaultVal}` + (index === array.length - 1 ? '' : '\n');
                        }
                    }
                });
                domArgsOnly = newLine + tab + tab + "[JsonIgnore]" + newLine + tab + tab +
                    "internal IJSRuntime JsRuntime { get { return _jsRuntime; } " + newLine + tab + tab + tab +
                    "set  {" + newLine + tab + tab + tab + tab +
                    "{{domArgs}}" + newLine + tab + tab + tab + tab +
                    "_jsRuntime = value;" + newLine + tab + tab + tab +
                    "}" + newLine + tab + tab +
                    "}" + newLine + tab + tab +
                    "internal IJSRuntime _jsRuntime { get; set; }";
                var domPropKeys = Object.keys(domProps);
                for (var d = 0; d < domPropKeys.length; d++) {
                    var tabContent = d !== 0 ? tab + tab + tab + tab : '';
                    var newLineContent = d === domPropKeys.length - 1 ? '' : newLine;
                    domArgs += tabContent + "if(this." + this.toInitCap(domPropKeys[d]) + " != null) {" + newLine + tab + tab + tab + tab + tab;
                    var domProp = this.toInitCap(domPropKeys[d]);
                    if (domProps[domPropKeys[d]] === "List<DOM>") {
                        domArgs += `foreach(DOM _${domPropKeys[d]} in this.${domProp})` + newLine + tab + tab + tab + tab + tab +
                            "{" + newLine + tab + tab + tab + tab + tab + tab +
                            `_${domPropKeys[d]}.JsRuntime = value;` + newLine + tab + tab + tab + tab + tab +
                            "}" + newLine + tab + tab + tab + tab;
                    }
                    else {
                        domArgs += "this." + domProp + ".JsRuntime = value;" + newLine + tab + tab + tab + tab;
                    }
                    domArgs += "}" + newLineContent;
                }
                syntax += args;
                if (domArgs.length) {
                    isDomArgs.push(eventargs);
                    domArgsOnly = domArgsOnly.replace(/{{domArgs}}/g, domArgs);
                    syntax += domArgsOnly;
                }
                else {
                    syntax += newLine + tab + tab + "[JsonIgnore]" +
                        newLine + tab + tab + "internal IJSRuntime JsRuntime { get; set; }" + newLine;
                }
                syntax += newLine + tab + tab + `[EditorBrowsable(EditorBrowsableState.Never)]` +
                    newLine + tab + tab + `public bool Equals(${eventargs}{{GenericType}} ${this.toInitSmall(eventargs)})` +
                    newLine + tab + tab + `{` +
                    newLine + tab + tab + tab + `return SfBase.Equals(this, ${this.toInitSmall(eventargs)});` +
                    newLine + tab + tab + "}" + newLine;
                var genericType = "";
                if (isGenericTypeEvent) {
                    genericType = "<T>";
                    genericEventModels.indexOf(eventargs) == -1 ? genericEventModels.push(eventargs) : true;
                }
                syntax = syntax.replace(/{{GenericType}}/g, genericType);
                return syntax + newLine + tab + "}" + newLine;
            }
            return "";
        } else {
            return "";
        }
    }

    isChildGenericType(interfaceName) {
        var childInterface = this.propertyList.interfaces[interfaceName];
        var isGenericType = genericEventModels.indexOf(interfaceName) !== -1;
        if (!isGenericType && childInterface) {
            for (var i = 0; i < childInterface.children.length; i++) {
                var obj = childInterface.children[i];
                if (obj.flags && !obj.flags.isPrivate) {
                    var childInterfaceName = this.getType(obj, "interface", true);
                    var listProp = childInterfaceName.match(/List<(.*)>/);
                    childInterfaceName = listProp ? listProp[1] : childInterfaceName;
                    isGenericType = this.isGenericType(obj);
                    isGenericType = !isGenericType ? genericEventModels.indexOf(childInterfaceName) !== -1 : isGenericType;
                    var nestedInterface = this.propertyList.interfaces[childInterfaceName];
                    if (!isGenericType && nestedInterface && validatedEventModels.indexOf(childInterfaceName) === -1) {
                        validatedEventModels.push(childInterfaceName);
                        isGenericType = this.isChildGenericType(childInterfaceName);
                    }
                }
                if (isGenericType) {
                    genericEventModels.indexOf(interfaceName) == -1 ? genericEventModels.push(interfaceName) : true;
                    break;
                }
            }
        }
        return isGenericType;
    }

    generateComponent(cnt, propList, comp, json, options, restrict) {
        baseParentObj = comp;
        var packName = this.namespaceCheck(pack.name);
        var containerComp = "div";
        var child = "";
        var restrictCommonMtds = true;
        var Itype = "";
        var tab = "    ";
        var newLine = "\n";
        var element = "sf-" + comp.baseClass.toLowerCase();
        options.parentTagName = element;
        var namespace = "sf." + json.name.replace(/\-/g, "").toLowerCase() + "." + comp.baseClass;
        var className = comp.baseClass;
        var enums = options.enums;
        var childContent = "";
        var modelVal = "";
        var eventString = "";
        var nativeTemp = "";
        var importNameSpace = '';
        var isClassFile = this.isClassFile(comp);
        var indend = isClassFile ? newLine + tab + tab : newLine + tab;
        var tabIndend = isClassFile ? tab + tab : tab;
        if (comp.inhertClass !== undefined) {
            importNameSpace = "using Syncfusion.Blazor." + comp.inhertClass + ";";
        }
        cnt = cnt.replace(/{{ImportNamespace}}/g, importNameSpace);
        isGenericClass = comp.isGenericClass;
        var nativeEle = tabIndend+ "///<exclude/>\n"+ tab + tab +"[Parameter]" + indend + "[JsonIgnore]" + indend +
            "public EventCallback<{{NativeEventArgs}}> {{NativeEvent}} { get; set; }" + newLine;
        var eventsCollection = JSON.parse(fs.readFileSync(__dirname + "/" + "nativeEvents.json"));
        var jsonKeys = Object.keys(eventsCollection.nativeEventargs);
        var returnvalues = this.getAllPropertiesFromClass(propList[comp.baseClass], comp, { enums: enums }, restrict, restrictCommonMtds);
        var returnvalue = returnvalues.prop;
        var htmlAttr = "";
        if (propList[comp.baseClass]["_allProperties"] && propList[comp.baseClass]["_allProperties"].indexOf("htmlAttributes") < 0) {
            htmlAttr = indend + "[Parameter]" +
                indend + "public Dictionary<string, object> HtmlAttributes" +
                indend + "{" +
                indend + tab + "get {" +
                indend + tab + tab + "return htmlAttributes;" +
                indend + tab + " }" +
                indend + tab + "set {" +
                indend + tab + tab + "htmlAttributes = value;" +
                indend + tab + "}" +
                indend + "}";
        }
        if (comp.preferredTag) {
            containerComp = comp.preferredTag;
        }
        if (comp.defaultTag) {
            var reg = new RegExp(/type(.*?)=(.*?)'(.*?)'/g);
            Itype = comp.defaultTag.match(reg);
            if (Itype === null) {
                Itype = "";
            }
        }

        if (comp.type === 'container' || comp.type === 'form') {
            childContent = '@ChildContent';
        }

        if (comp.twoWays || comp.blazorTwoWays) {
            modelVal = indend + "protected string _value;" + newLine +
                indend + "[Parameter]" + indend + "[JsonIgnore]" +
                indend + "public EventCallback<string> ValueChanged { get; set; }" + newLine;
        }

        if ((comp.complexDirective && comp.complexDirective.length > 0) || (comp.tagDirective && comp.tagDirective.length > 0) || (comp.migratedTagDirective && comp.migratedTagDirective.length > 0) ||
            (comp.blazorTemplates || comp.blazorContainerTemplates) || comp.isGenericClass || comp.isChildContent) {
            var childTab = newLine + tab;
            child = childTab + '<CascadingValue Value="@this">' + childTab + tab +
                '@ChildContent' +
                childTab +
                '</CascadingValue>' + newLine;
            if (childContent === "@ChildContent" || comp.blazorTemplates || comp.blazorContainerTemplates) {
                childContent = child;
                child = "";
            }
        }

        if (containerComp === "input" || containerComp === "button") {
            for (var i = 0; i < jsonKeys.length; i++) {
                // var nativeEve = "On" + this.toInitCap(jsonKeys[i].split('on')[1]);
                var nativeEve = "On" + this.toInitCap(this.toInitCap(jsonKeys[i].slice('on')).split('On')[1]);
                eventString += '@' + jsonKeys[i] + '="@' + nativeEve + '" ';
                nativeTemp = nativeTemp + nativeEle.replace(/{{NativeEvent}}/g, nativeEve) + newLine;
                nativeTemp = nativeTemp.replace(/{{NativeEventArgs}}/g, eventsCollection.nativeEventargs[jsonKeys[i]]);
            }
        } else if (comp.nativeEvents) {
            for (var i = 0; i < comp.nativeEvents.length; i++) {
                var index = jsonKeys.indexOf(comp.nativeEvents[i]);
                if (index === -1) {
                    break;
                }
                var nativeEve = "On" + this.toInitCap(comp.nativeEvents[i].split('on')[1]);
                eventString += '@' + comp.nativeEvents[i] + '="@' + nativeEve + '" ';
                nativeTemp = nativeTemp + nativeEle.replace(/{{NativeEvent}}/g, nativeEve) + newLine;
                nativeTemp = nativeTemp.replace(/{{NativeEventArgs}}/g, eventsCollection.nativeEventargs[comp.nativeEvents[i]]);
            }
        }
        eventString = eventString.length ? ' ' + eventString + ' ' : '';
        var ele = '<{{containerComp}} id="@ID"{{class}}' + eventString + '{{type}}{{closingTag}}{{childContent}}{{containerCompEnd}}';
        ele = ele.replace(/{{containerComp}}/g, containerComp);
        ele = ele.replace(/{{type}}/g, Itype);
        ele = ele.replace(/{{closingTag}}/g, containerComp === "input" ? "/>" : ">");
        ele = ele.replace(/{{childContent}}/g, childContent);
        ele = ele.replace(/{{containerCompEnd}}/g, containerComp === "input" ? "" : "</" + containerComp + ">");
        var hiddenElement = ele.replace(/{{class}}/, ' class="e-blazor-hidden"');
        var defaultEle = ele.replace(/{{class}}/, "");
        // this change need to be removed after Hybrid approach
        if (comp.baseClass == 'TextBox' && comp.blazorMultiline) {
            var textareaEle = ele.replace('<input', '<textarea');
            textareaEle = textareaEle.replace('/>', '></textarea>');
            var hiddenTextareaElement = textareaEle.replace(/{{class}}/, ' class="e-blazor-hidden"');
            hiddenTextareaElement = hiddenTextareaElement.replace(/{{containerComp}}/, 'textarea')
            hiddenTextareaElement = hiddenTextareaElement.replace('/>', '></textarea>');
            var defaultTextareaEle = textareaEle.replace(/{{class}}/, "");
            defaultEle = "@if (this.Multiline)" + newLine +
                tab + tab + "{" + newLine + tab + tab + tab + defaultTextareaEle +
                newLine + tab + tab + "}" +
                newLine + tab + tab + "else" +
                newLine + tab + tab + "{" +
                newLine + tab + tab + tab + defaultEle +
                newLine + tab + tab + "}";
            hiddenElement = "@if (this.Multiline)" + newLine +
                tab + "{" + newLine + tab + tab + hiddenTextareaElement +
                newLine + tab + "}" +
                newLine + tab + "else" +
                newLine + tab + "{" +
                newLine + tab + tab + hiddenElement +
                newLine + tab + "}";
        }
        ele = hiddenElement;
        var templates = "";
        if (comp.blazorTemplates || comp.blazorContainerTemplates) {
            templates = indend + `${className}Templates I${className}.${className}Templates { get; set; }`;
        }
        var blazorCustomBaseComp = comp.blazorCustomBaseComponent;
        if(comp.blazorCustomBaseComponent && comp.blazorCustomBaseComponent.indexOf("Ejs") != -1){
            blazorCustomBaseComp = comp.blazorCustomBaseComponent.replace("Ejs","Sf");
        }
        cnt = cnt.replace(/{{elementName}}/g, element);
        cnt = cnt.replace(/{{childs}}/g, child);
        cnt = cnt.replace(/{{className}}/g, className);
        cnt = cnt.replace(/{{JSNameSpace}}/g, namespace);
        cnt = cnt.replace(/{{NameSpace}}/g, packName);
        cnt = cnt.replace(/{{BaseComponent}}/g, blazorCustomBaseComp || "BaseComponent");
        cnt = cnt.replace(/{{Element}}/g, ele);
        cnt = cnt.replace(/{{NativeEvent}}/g, nativeTemp);
        cnt = cnt.replace(/{{HtmlAttributes}}/g, htmlAttr);
        cnt = cnt.replace(/{{Properties}}/g, returnvalue + templates);
        cnt = cnt.replace(/{{modelValue}}/g, modelVal);
        if (isdataAnnotation) {
            var dataVal = this.dataAnnotation(annotationName, annotationType, isClassFile);
            cnt = cnt.replace(/{{DataAnnotationAttributes}}/g, dataVal);
            isdataAnnotation = false;
        } else {
            cnt = cnt.replace(/{{DataAnnotationAttributes}}/g, "");
        }
        cnt = cnt.replace(/{{NameSpace}}/g, this.toInitCap(this.namespaceCheck(pack.name)));
        var templateModel = "";
        var compString = JSON.stringify(comp);
        if (compString.indexOf('blazorTemplates') !== -1) {
            var indend = isClassFile ? newLine + tab + tab : newLine + tab;
            var param = comp.isGenericClass && !comp.isTTypeIgnore ? '' : indend + '[Parameter]';
            var defaultModelType = comp.isGenericClass && !comp.isTTypeIgnore ? ` = typeof(TValue);` : '';
            var expose = comp.isGenericClass && !comp.isTTypeIgnore ? indend + '[EditorBrowsable(EditorBrowsableState.Never)]' : '';
            templateModel = param +
                indend + "[JsonIgnore]" + expose +
                indend + "public override System.Type ModelType { get; set; }" + defaultModelType + newLine;
        }
        var interfaces = (isClassFile ? ", I" : "I") + className;
        if (comp.blazorCustomInterface) {
            interfaces = isClassFile ? ", " + comp.blazorCustomInterface : comp.blazorCustomInterface;
        }
        var circularComponent = comp.tagDirective && comp.tagDirective.filter(tag => tag.isCircularBlazorComponent);
        interfaces = circularComponent && circularComponent.length ? interfaces + ', ICircularComponent' : interfaces;
        cnt = cnt.replace(/{{ModelType}}/, templateModel);
        cnt = cnt.replace(/{{Interface}}/, interfaces);
        var tValues = '';
        if (comp.genericProperties) {
            tValues = comp.genericProperties.map(tValues => tValues.type);
            tValues = '<' + tValues.join(",") + '>';
        }
        var genericType = isGenericClass ? (isClassFile ? (comp.genericProperties ? tValues : "<TValue>") : newLine + "@typeparam TValue;") : "";
        cnt = cnt.replace(/{{GenericType}}/, genericType);
        cnt = cnt.replace(/{{InitializeProperties}}/, returnvalues.initProps);
        cnt = cnt.replace(/{{SetParameterChanges}}/, returnvalues.propChanges);
        cnt = cnt.replace(/{{UpdateChildProperties}}/, this.generateChildProperties(comp));
        return cnt;
    }

    generateChildProperties(comp, parent) {
        var childProps = "";
        var groupChildProps = "";
        var indend = this.isClassFile(comp) ? newLine + tab + tab : newLine + tab;
        var tagDirective = comp.migratedTagDirective || comp.tagDirective;
        var isBaseClass = comp.baseClass === baseParentObj.baseClass;
        if (tagDirective || comp.complexDirective || comp.isCircularBlazorComponent || (isBaseClass && (comp.blazorTemplates || comp.blazorContainerTemplates))) {
            var collection = [];
            var tagLength = tagDirective ? tagDirective.length : 0;
            var complexLength = comp.complexDirective ? comp.complexDirective.length : 0;
            childProps += newLine + indend + "[EditorBrowsable(EditorBrowsableState.Never)]" +
                indend + "public void updateChildProperties(string key, object value)" +
                indend + "{" +
                indend + tab + "switch(key)" +
                indend + tab + "{" +
                indend + tab + "{{ChildProperties}}" +
                indend + tab + "}" +
                indend + tab + "this.updateDictionary(key, value, this.directParameters);" +
                indend + "}";
            for (var i = 0; i < tagLength; i++) {
                groupChildProps += this.getChildProperty(tagDirective[i], comp, collection, indend);
            }

            for (var i = 0; i < complexLength; i++) {
                groupChildProps += this.getChildProperty(comp.complexDirective[i], comp, collection, indend, "complex");
            }

            if (comp.blazorTemplates && isBaseClass) {
                for (var i = 0; i < comp.blazorTemplates.length; i++) {
                    var tempalteName = this.getTemplateProperty(comp, comp.blazorTemplates[i]).actualProperty;
                    groupChildProps += this.getChildProperty(tempalteName, comp, collection, indend, "template");
                }
            }

            if (comp.blazorContainerTemplates && isBaseClass) {
                for (var i = 0; i < comp.blazorContainerTemplates.length; i++) {
                    var tempalteName = this.getTemplateProperty(comp, comp.blazorContainerTemplates[i]).actualProperty;
                    groupChildProps += this.getChildProperty(tempalteName, comp, collection, indend, "template");
                }
            }

            if (comp.isCircularBlazorComponent) {
                groupChildProps += this.getChildProperty(comp, parent, collection, indend, "complex");
            }

            if (groupChildProps === "") {
                return groupChildProps;
            }
            childProps = childProps.replace(/{{ChildProperties}}/, groupChildProps);
            collection = null;
        }
        childProperties = {};
        return childProps;
    }

    getInitComplex(comp, parent, parentType, baseParentType, publicProperty, hasDynamicParent) {
        if ((comp.arrayDirectiveClassName && !comp.complexDirective) || baseParentObj.blazorType !== "hybrid") {
            return "";
        }
        var indend = this.isClassFile(comp) ? newLine + tab + tab : newLine + tab;
        var isSameBase = parentType == baseParentType;
        var privateProperty = this.toInitSmall(publicProperty);
        var pType = parent && parent.isGenericClass && parentType.startsWith("I") ? parentType.substr(1) + "<T>" : parentType;
        var genericType = comp.isGenericClass ? "<TValue>" : "";
        var genericParent = parent.isGenericClass && !isSameBase ? '<T>' : '';
        var parentArgs = !isSameBase ? `, object parent` : "";
        var parentInit = !isSameBase ? (comp.isCommon ? `parent;` : `(${pType})parent;`) : `(${parentType})baseComponent;`;
        parentInit = comp.arrayDirectiveClassName ? `new ${pType}();` : parentInit;
        var dynamicParent = hasDynamicParent ? indend + tab + `${privateProperty}.dynamicParent = ${privateProperty}.parent;` : "";

        return newLine + indend + `internal static async Task<${publicProperty}${genericType}> Initialize${genericParent}(BaseComponent baseComponent${parentArgs})` +
            indend + `{` +
            indend + tab + `var ${privateProperty} = new ${publicProperty}${genericType}();` +
            indend + tab + `${privateProperty}.parent = ${parentInit}` +
            dynamicParent +
            indend + tab + `${privateProperty}.baseParent = (${baseParentType})baseComponent;` +
            indend + tab + `${privateProperty}.IsAutoInitialized = true;` +
            indend + tab + `await ${privateProperty}.OnInitializedAsync();` +
            indend + tab + `return ${privateProperty};` +
            indend + `}`;
    }

    getChildProperty(tagComplex, parent, collection, indend, type) {
        var propName = typeof tagComplex === "object" ? tagComplex.propertyName : tagComplex;
        var complexProp = childProperties[propName];
        var publicProperty = this.toInitCap(propName);
        if (tagComplex.isDeprecated || collection.indexOf(propName) !== -1) {
            return "";
        }
        collection.push(propName);
        var varName = propName;
        if (reservedWords.indexOf(propName) !== -1) {
            varName = propName + '1';
        }
        var propType = (complexProp && complexProp !== "object") ? `(${complexProp})` : "";
        propType = type === "template" ? "(string)" : propType;
        var childProperty = indend + tab + tab + tab + `this.${publicProperty} = this._${propName} = ${propType}value;`;
        if (type === "complex" && propType.length && baseParentObj.blazorType === "hybrid" && complexProp.indexOf("List<") === -1) {
            var complexObj = tagComplex.isGenericClass ? complexProp.substr(1) + "<object>" : complexProp;
            var genericTagComplex = parent && parent.isGenericClass && parent !== baseParentObj ? '<TValue>' : '';
            var intiArgs = parent == baseParentObj ? "this" : `(BaseComponent)this.baseParent, this`;
            var childProp = complexObj.startsWith('ObservableCollection') ? `new ${complexObj}() : ${propType}value;` :
                `${complexObj}.Initialize${genericTagComplex}(${intiArgs}).Result : ${propType}value;`;
            childProperty = indend + tab + tab + tab +
                `var ${varName} = value == null ? ${childProp}` +
                indend + tab + tab + tab + `this.${publicProperty} = this._${propName} = ${varName};`;
        }
        return indend + tab + tab + `case "${propName}":` +
            childProperty +
            indend + tab + tab + tab + "break;";
    }

    createPropertySyntax(isFirstProperty, obj, comp, parent, tagDirective, options, comment, restrict) {
        var cnt = "";
        var tab = "    ";
        var newLine = "\n";
        var pType = "public ";
        var propInterface = "";
        var initProps = "";
        var propChanges = "";
        var isClassFile = this.isClassFile(comp);
        var indend = isClassFile ? newLine + tab + tab : newLine + tab;
        var tabIndend = isClassFile ? tab + tab : tab;
        var isBaseClass = comp.baseClass === parent.baseClass;
        var blazortype = this.getBlazorTagValue(obj, "blazortype");
        if (obj.name === "id" && restrict) {
            pType = "public override ";
        }
        if (obj.kindString !== "Method") {
            var ignoreProperty =
                obj.comment.tags &&
                obj.comment.tags.filter(function (v) {
                    return v.tag === "blazorignore";
                });
            if (!(ignoreProperty && ignoreProperty.length)) {
                if (comment) {
                    var firstIndend = isFirstProperty ? '' : tabIndend;
                    cnt += comment[obj.name] ?
                        firstIndend + comment[obj.name].split("\n").join(indend) + newLine :
                        cnt;
                }
                var ignoreDefaultValue =
                    obj.comment.tags &&
                    obj.comment.tags.filter(function (v) {
                        return v.tag === "blazordefaultvalueignore";
                    });
                var numberEnum =
                    obj.comment &&
                    obj.comment.tags &&
                    obj.comment.tags.filter(function (v) {
                        return v.tag === "blazornumberenum";
                    });
                var Enumerable =
                    obj.comment &&
                    obj.comment.tags &&
                    obj.comment.tags.filter(function (v) {
                        return v.tag === "isenumeration";
                    });
                var GenericType =
                    obj.comment &&
                    obj.comment.tags &&
                    obj.comment.tags.filter(function (v) {
                        return v.tag === "isgenerictype";
                    });
                var isGenericType = comp.isGenericClass && GenericType && GenericType.length > 0;

                var defaultValue = this.getDefaultPropertyValue(obj, comp, options, tagDirective, parent);
                var propName = this.toInitCap(obj.name);
                var initIndend = isFirstProperty ? '' : tabIndend + tab;
                initProps = this.getInitProps(comp, obj.name, initIndend);
                if ((comp.blazorTemplates || comp.blazorContainerTemplates) && this.isTemplateProperty(obj.name, comp, parent)) {
                    if (isBaseClass) {

                        var parentType = this.getClassName(parent, comp);
                        parentType = this.getGenericParentType(parent, parentType);
                        // parentType = isGenericClass ? parentType + "<TValue>" : parentType;
                        this.generateTemplates(comp, parentType, isBaseClass);
                        var templateType = obj.type.name === "string" ? obj.type.name : "object";
                        cnt = cnt + tabIndend + "[Parameter]" +
                            indend + "[DefaultValue(null)]" +
                            indend + "[JsonProperty(\"" + obj.name + "\")]" +
                            indend + `public ${templateType} ${propName} { get; set; }` +
                            indend + `private ${templateType} _${obj.name} { get; set; }` + newLine + newLine;
                        propInterface = tab + tab + `public ${templateType} ${propName} { get; set; }` + newLine;
                        propChanges = indend + tab + `this.${propName} = this._${obj.name} = await this.updateProperty("${obj.name}", ${propName}, _${obj.name});`;
                        return { content: cnt, interface: propInterface, initProps: initProps, propChanges: propChanges };
                    }
                    else {
                        templates = comp.blazorTemplates ? comp.blazorTemplates : [];
                        templates = comp.blazorContainerTemplates ? templates.concat(comp.blazorContainerTemplates) : templates;
                        var template;
                        for (var i = 0; i < templates.length; i++) {
                            if (templates[i].indexOf(obj.name) !== -1) {
                                template = this.getTemplateProperty(comp, templates[i]);
                                break;
                            }
                        }
                        var templateType = template.isContainerTemplate ? "RenderFragment" : "RenderFragment<object>";
                        if (template.actualProperty === template.blazorProperty) {
                            initProps = ""
                            cnt = cnt + tabIndend + "[Parameter]" +
                                indend + "[DefaultValue(null)]" +
                                indend + "[JsonProperty(\"" + obj.name + "\")]" +
                                indend + "[JsonConverter(typeof(TemplateConverter))]" +
                                indend + "public " + templateType + " " + this.toInitCap(template.blazorProperty) + " { get; set; }" + newLine + newLine;
                            propInterface = tab + tab + "public " + templateType + " " + this.toInitCap(template.blazorProperty) + " { get; set; }" + newLine;
                            return { content: cnt, interface: propInterface, initProps: initProps, propChanges: propChanges };
                        }
                    }
                }
                cnt = comp.isCustomBlazor ? cnt : (cnt + tabIndend + "[Parameter]" + newLine);
                if (blazortype === "RenderFragment") {
                    cnt = cnt + tabIndend + "[JsonIgnore]" + newLine;
                }
                if (obj.kindString !== "Event") {
                    if (!(ignoreDefaultValue && ignoreDefaultValue.length) && ((defaultValue || defaultValue === 0) && !isGenericType) && defaultValue.toString().indexOf("DateTime") === -1) {
                        var defaultValueTemplate = defaultValue === "default" ? "default({{defaultType}})" : defaultValue;
                        cnt = cnt + tabIndend + "[DefaultValue(" + defaultValueTemplate + ")]" + newLine;
                    }

                    cnt = cnt + tabIndend + '[JsonProperty("' + obj.name + '")]' + newLine;
                    if (this.isStringLitrals(obj)) {
                        cnt = cnt + tabIndend + "[JsonConverter(typeof(StringEnumConverter))]" + newLine;
                        this.addEnums(this.propertyList.typeAliases[obj.type.name], comp, cnt, options.enums);
                    } else if (this.isEnumType(obj)) {
                        if (!(numberEnum && numberEnum.length)) {
                            cnt = cnt + tabIndend + "[JsonConverter(typeof(StringEnumConverter))]" + newLine;
                        }
                        this.addEnums(this.propertyList.enumAliases[obj.type.name], comp, cnt, options.enums);
                    } else if (Enumerable && Enumerable.length) {
                        cnt = cnt + tabIndend + "[JsonConverter(typeof(StringEnumConverter))]" + newLine;
                    }
                }
                if (obj.kindString === "Event") {
                    initProps = "";
                    cnt = cnt + tabIndend + "[JsonIgnore]" + newLine;
                    var blazorEvent = this.getBlazorTagValue(obj, "blazorproperty");
                    var type = this.getBlazorTagValue(obj, "blazortype") || "object";
                    type = type.replace(/EJ2./g, '');
                    var eventArgsType = this.getBlazorTagValue(obj, "blazortype");
                    if (this.propertyList.interfacesNames && this.propertyList.interfacesNames.length && obj.type.typeArguments && obj.type.typeArguments.length) {
                        var objTypes = obj.type.typeArguments[0].types ? obj.type.typeArguments[0].types : obj.type.typeArguments;
                        if (eventArgsType) {
                            type = eventArgsType.replace(/EJ2./g, '');
                        } else {
                            this.propertyList.interfacesNames.forEach(e1 =>
                                objTypes.forEach(e2 => {
                                    if (e1 === e2.name) {
                                        type = e1;
                                    }
                                })
                            );
                        }
                    }
                    var eventName = `"${obj.name}"`;
                    if (parent.baseClass != comp.baseClass) {
                        isParametersSet = true;
                    }
                    if (comp.isGenericClass && genericEventModels.indexOf(type) !== -1) {
                        type = type + "<TValue>";
                    }
                    cnt = cnt + tabIndend + pType + "EventCallback<" + type + ">" + " " + (blazorEvent ? this.toInitCap(blazorEvent) : this.toInitCap(obj.name)) +
                        " { " +
                        indend + tab +
                        `get { return (EventCallback<${type}>)this.GetEvent(${eventName}); }` +
                        indend + tab +
                        `set { this.SetEvent<${type}>(${eventName}, value); }` +
                        indend +
                        "}" +
                        newLine + newLine;
                    if (!comp.tagDirective && !comp.migratedTagDirective && !comp.complexDirective && !comp.isGenericClass) {
                        cnt = cnt.replace('</summary>', '<exclude/>\n    /// </summary>');
                    }
                } else if (defaultValue !== "null" && defaultValue !== null && !(ignoreDefaultValue && ignoreDefaultValue.length)) {
                    var propType = this.getPropertyType(obj, comp, options, tagDirective, parent, isGenericType);
                    if (propType == "RenderFragment" && renderFragmentType.indexOf(obj.name) == -1) {
                        renderFragmentType.push(this.toInitCap(obj.name));
                    }
                    var genPropType = genericEventModels.indexOf(propType) !== -1 ? propType + "<TValue>" : propType;
                    // var inheritProp = obj.moduleName && this.toInitCap(obj.moduleName) === comp.inhertClass ? "new " : "";
                    var inheritProp = "";
                    var blazoroverridetype = this.getBlazorTagValue(obj, "blazoroverridetype");
                    if (blazoroverridetype != undefined) {
                        var oType = pType + blazoroverridetype + " ";
                        var accessor = tabIndend + oType + inheritProp + genPropType + this.isNullable(obj) + " " + this.toInitCap(obj.name);
                    } else {
                        accessor = tabIndend + pType + inheritProp + genPropType + this.isNullable(obj) + " " + this.toInitCap(obj.name);
                    }
                    cnt = cnt.replace(/{{defaultType}}/, propType);
                    var propBindings = this.isBindingProp(obj, obj.name, comp, genPropType, defaultValue, isGenericType);
                    cnt = cnt + accessor + propBindings.property + newLine + newLine;
                    if (blazoroverridetype != undefined) {
                        accessor = tabIndend + pType + inheritProp + genPropType + this.isNullable(obj) + " " + this.toInitCap(obj.name);
                    }
                    propInterface = (isGenericType || genericEventModels.indexOf(propType) !== -1) ? "" : (isClassFile ? "" : tab) + accessor + " { get; set; }" + newLine;
                    propChanges = propBindings.propChanges;
                } else {
                    var propType = this.getPropertyType(obj, comp, options, tagDirective, parent, isGenericType);
                    if (propType == "RenderFragment" && renderFragmentType.indexOf(obj.name) == -1) {
                        renderFragmentType.push(this.toInitCap(obj.name));
                    }
                    var genPropType = genericEventModels.indexOf(propType) !== -1 ? propType + "<TValue>" : propType;
                    var accessor = tabIndend + pType + genPropType + this.isNullable(obj) + " " + this.toInitCap(obj.name);
                    cnt = cnt.replace(/{{defaultType}}/, propType);
                    var propBindings = this.isBindingProp(obj, obj.name, comp, genPropType, null, isGenericType);
                    cnt = cnt + accessor + propBindings.property + newLine + newLine;
                    propInterface = (isGenericType || genericEventModels.indexOf(propType) !== -1) ? "" : (isClassFile ? "" : tab) + accessor + " { get; set; }" + newLine;
                    propChanges = propBindings.propChanges;
                }
            }
        } else if (obj.kindString === "Method") {
            if (comment) {
                cnt += comment[obj.name] ? tabIndend + comment[obj.name].split("\n").join(indend) + newLine : cnt;
            }
            var params = this.generateMethodArgs(obj);
            var args = obj.signatures[0].parameters === undefined ? "" : params.args;
            var isGenericType = false;
            if (obj.signatures && obj.signatures.length) {
                isGenericType = comp.isGenericClass && this.isGenericType(obj.signatures[0]);
            }
            var interopType = this.getInteropType(obj, isGenericType);
            var isCommonMethodType = commonMethodTypesKeys.indexOf(interopType.actualType) !== -1 && !interopType.isArray;
            var invokeType = interopType.type;
            var methodType = this.getMethodType(obj, isGenericType);
            var paramList = params.list.length > 0 ? params.list : null;
            var moduleName = obj.isModuleMethod ? `"${obj.moduleName}"` : null;
            var inheritClass = comp.inhertClass ? comp.inhertClass : comp.baseClass;
            var baseComp = obj.isModuleMethod ? `this.${inheritClass}Component` : "this";
            paramList = !moduleName && !paramList ? "" : ", " + paramList;
            var invokeMethod = `await ${baseComp}.InvokeMethod("${obj.name}", ${moduleName}${paramList});`
            if (methodType !== 'async Task') {
                invokeMethod = this.getMethodStatement(methodType) + `${baseComp}.InvokeMethod<${invokeType}>("${obj.name}", ${!isCommonMethodType}, ${moduleName}${paramList});`
            }
            cnt = `${cnt}${tabIndend}${pType}${methodType} ${this.toInitCap(obj.name)}(${args}) {` +
                params.enumDefinition +
                indend + tab + invokeMethod + indend + "}" + newLine + newLine;

        }
        return { content: cnt, interface: propInterface, initProps: initProps, propChanges: propChanges };
    }

    getInitProps(comp, propName, tabIndend) {
        if (comp.complexDirective) {
            var complexProps = this.getComplexProperties(comp.complexDirective);
            if (complexProps.indexOf(propName) !== -1) {
                return tabIndend + `this.updateChildProperties("${propName}", this.${this.toInitCap(propName)});` + newLine;
            }
        }
        return tabIndend + `this._${propName} = this.${this.toInitCap(propName)};` + newLine;
    }

    generateTemplates(comp, parentType, isBaseClass) {
        if (isBaseClass) {
            var rootTemplatePath = "./third-party/blazor/Syncfusion.Blazor/" + this.namespaceCheck(pack.name) + "/" + comp.baseClass + "Templates.razor";
            if (fs.existsSync(rootTemplatePath)) {
                return newLine;
            }
            var templateRender = "";
            var templateParameters = "";
            var templateOnInit = "";
            var templateOnAfterRender = "";
            var innerIndend = tab + tab + tab; 
            var templateIndend = newLine + tab  ;
            var templateDispose = "";  
            var isInstanceCreation = ""; 
            var complexInstance = "";
            var complexDispose = "";     
            var blazorTemplates = comp.blazorTemplates ? comp.blazorTemplates : [];
            var indend = this.isClassFile(comp) ? newLine + tab + tab : newLine + tab;
            blazorTemplates = comp.blazorContainerTemplates ? blazorTemplates.concat(comp.blazorContainerTemplates) : blazorTemplates;
            for (var i = 0; i < blazorTemplates.length; i++) {
                var currentTempalte = this.getTemplateProperty(comp, blazorTemplates[i]);
                var actualName = this.toInitCap(currentTempalte.actualProperty)
                var templateName = this.toInitCap(currentTempalte.blazorProperty);
                var orSeparator = templateDispose != '' ? '|| ':'';
                templateDispose +=  orSeparator + templateName + ' != null ';
                var isContainerTemplate = currentTempalte.isContainerTemplate;
                if (blazorTemplates[i].indexOf('.') === -1) {
                    var modelClass = comp.blazorTemplateModels && comp.blazorTemplateModels[blazorTemplates[i]] ? comp.blazorTemplateModels[blazorTemplates[i]] : null;
                    templateRender += this.getTemplateRender(templateName, isBaseClass, isContainerTemplate, modelClass);
                    templateParameters += this.getTemplateParameters(templateName, false, isContainerTemplate, indend.replace(tab, ''));
                    templateOnInit += this.getTemplateOnInit(isBaseClass, actualName, templateName, i);
                    templateOnAfterRender += this.getTemplateOnAfterRender(templateName, isContainerTemplate, comp.blazorContainerTemplates, indend);
                }
            }
            complexInstance = 'internal DotNetObjectReference<object> DotnetInstance { get; set; }' + templateIndend;
            complexDispose = 'this.DotnetInstance?.Dispose();' + templateIndend + 'this.DotnetInstance = null;'+templateIndend;
            templateOnAfterRender = !comp.blazorContainerTemplates ? templateOnAfterRender + indend + 'TemplateClientChanges = false;' : templateOnAfterRender;
            isInstanceCreation = templateIndend + tab + 'if(('+ templateDispose + ') && this.DotnetInstance == null) {'+ templateIndend + tab + tab + 'this.DotnetInstance = DotNetObjectReference.Create<object>(this);' +templateIndend+ tab + '}';
            templateOnInit += this.getTemplateHashTable();
            var templateContent = templateFile;
            // var genericType = isGenericClass && comp.blazorTemplates ? "@typeparam TValue;" : "";
            // templateContent = templateContent.replace(/{{GenericType}}/, genericType);
            templateContent = templateContent.replace(/{{NameSpace}}/, this.namespaceCheck(pack.name));
            templateContent = templateContent.replace(/{{ParentType}}/g, parentType);
            templateContent = templateContent.replace(/{{TemplateRenderer}}/, templateRender);
            templateContent = templateContent.replace(/{{TemplateParameters}}/, complexInstance + templateParameters);
            templateContent = templateContent.replace(/{{OnInitTemplate}}/, isInstanceCreation + templateOnInit);
            templateContent = templateContent.replace(/{{RenderTemplate}}/, isInstanceCreation + templateOnAfterRender);
            templateContent = templateContent.replace(/{{TemplateName}}/, `${comp.baseClass}Templates`);
            templateContent = templateContent.replace(/{{ComplexDispose}}/, complexDispose);
            templateContent = templateContent.replace(/{{ParentInterface}}/, `I${comp.baseClass}`);
            fs.writeFileSync(rootTemplatePath, templateContent);
        }
    }

    getTemplateProperty(comp, propertyName) {
        var result = {
            actualProperty: "",
            blazorProperty: ""
        };
        if (propertyName.indexOf(':') !== -1) {
            var propertyList = propertyName.split(':');
            result.actualProperty = propertyList[0];
            result.blazorProperty = propertyList[1];
        }
        else {
            result.actualProperty = propertyName;
            result.blazorProperty = propertyName;
        }
        result.isContainerTemplate = comp.blazorContainerTemplates && comp.blazorContainerTemplates.indexOf(propertyName) !== -1;
        return result;
    }

    isTemplateProperty(propertyName, comp, parent) {
        var blazorTemplates = [];
        blazorTemplates = comp.blazorTemplates ? comp.blazorTemplates : blazorTemplates;
        blazorTemplates = comp.blazorContainerTemplates ? blazorTemplates.concat(comp.blazorContainerTemplates) : blazorTemplates;
        if (blazorTemplates.length) {
            for (var i = 0; i < blazorTemplates.length; i++) {
                var configProp = blazorTemplates[i];
                var modifyProperty = configProp.split(':');
                var isTemplate = (configProp === propertyName || propertyName === modifyProperty[0]);

                if (isTemplate) {
                    return isTemplate;
                }
            }
        }
        return false;
    }

    getTemplateRender(templateName, isBaseClass, isContainerTemplate, modelClass) {
        var parent = isBaseClass ? 'templateParent' : 'baseParent';
        modelClass = modelClass ? `typeof(${modelClass})` : `${parent}.ModelType`;
        var templateRender = `@if (${templateName} != null && ${templateName}Data != null)` +
            newLine + "{" +
            newLine + tab + `<div id=@${templateName}ID class="blazor-template" style="visibility: hidden;position: absolute;top: -9999px;">` +
            newLine + tab + tab + `@for (var i = 0; i < ${templateName}Data.Count(); i++)` +
            newLine + tab + tab + "{" +
            newLine + tab + tab + tab + `<div class="blazor-inner-template" data-templateid="@${templateName}Items[i]">` +
            newLine + tab + tab + tab + tab + `@${templateName}(GetObject(${templateName}Data.ElementAt(i), ${modelClass}))` +
            newLine + tab + tab + tab + "</div>" +
            newLine + tab + tab + "}" +
            newLine + tab + "</div>" +
            newLine + "}" + newLine + newLine;
        if (isContainerTemplate) {
            templateRender = `@if (${templateName} != null && ${templateName}Items != null)` +
                newLine + "{" +
                newLine + tab + `<div id=@${templateName}ID class="blazor-template" style="visibility: hidden;position: absolute;top: -9999px;">` +
                newLine + tab + tab + `@for (var i = 0; i < ${templateName}Data.Count(); i++)` +
                newLine + tab + tab + "{" +
                newLine + tab + tab + tab + `<div class="blazor-inner-template" data-templateid="@${templateName}Items[i]">` +
                newLine + tab + tab + tab + tab + `@${templateName}` +
                newLine + tab + tab + tab + "</div>" +
                newLine + tab + tab + "}" +
                newLine + tab + "</div>" +
                newLine + "}" + newLine + newLine;
        }
        return templateRender;
    }

    getTemplateParameters(templateName, isActualParamRendered, isContainerTemplate, indend) {
        var actualParam = "";
        var templateType = isContainerTemplate ? 'RenderFragment' : 'RenderFragment<object>';
        if (!isActualParamRendered) {
            actualParam = indend + "[Parameter]" +
                indend + "[JsonIgnore]" +
                indend + `public ${templateType} ${templateName} { get; set; }`;
        }
        return actualParam +
            indend + "[Parameter]" +
            indend + `public List<Dictionary<string, object>> ${templateName}Data { get; set; }` +
            indend + `public List<string> ${templateName}Items { get; set; }` +
            indend + `public string ${templateName}ID { get; set; }` + newLine;
    }

    getTemplateOnInit(isBaseClass, actualName, templateName, index, isComplex, type) {
        var indend = index !== 0 ? tab + tab : "";
        var parent = isComplex ? "" : "templateParent.";
        if (!isBaseClass && actualName === templateName) {
            return (type == 'container' ? newLine + indend + `if (this.${templateName} != null) {` +
                newLine + tab + tab + tab + `this.InitTemplates("${actualName}", this.parent.baseParent, this.DotnetInstance);` +
                newLine + tab + tab + tab + "}" + newLine : "");
        }
        var collectionTemplate = "";
        if (isBaseClass) {
            collectionTemplate = newLine + tab + tab + tab + `this.InitTemplates(nameof(${templateName}), this.templateParent, this.DotnetInstance);`;
        }
        var divTemplate = renderFragmentType.indexOf(this.toInitCap(actualName)) == -1 ? `this.${parent}${actualName} = "<div>Blazor ${templateName}</div>";` : "";
        return newLine + tab + tab + `if (${templateName} != null) {` +
            (isComplex ? newLine + tab + tab + tab + divTemplate :
                newLine + tab + tab + tab + `this.${parent}updateChildProperties("${this.toInitSmall(actualName)}", "<div>Blazor ${templateName}</div>");`) +
            (type == 'container' ? newLine + tab + tab + tab + `this.InitTemplates("${templateName}", baseParent, this.DotnetInstance);` : '') +
            collectionTemplate +
            newLine + tab + tab + "}";
    }

    getTemplateHashTable(isComplex, isClassFile) {
        var parent = isComplex ? "baseParent" : "templateParent";
        var tabIndend = isClassFile ? tab + tab + tab : tab + tab;
        var indend = isComplex ? newLine + tabIndend : tabIndend;
        return indend + `if (this.DataHashTable.Count == 0) {` +
            newLine + tabIndend + tab + `this.DataHashTable = this.${parent}.DataHashTable;` +
            newLine + tabIndend + "}";
    }

    getTemplateOnAfterRender(templateName, isContainerTemplate, type, indend) {
        var templateMethod = isContainerTemplate ? 'SetContainerTemplates' : 'SetTemplates';
        var instanceInitialize = '';
        var argPass = '';
       // if (templateMethod === 'SetTemplates') {
            instanceInitialize = 'if('+ templateName +' != null){';
            argPass = instanceInitialize ? ', this.DotnetInstance' : '';
       // }
        return indend + instanceInitialize + indend + tab + `this.${templateMethod}("${templateName}", ${templateName}ID, ${templateName}, ${templateName}Data, Guid` + (!type ? `, (firstRender || TemplateClientChanges)` : ``) + argPass + ');'+ indend +'}';
    }

    // getTemplateOnAfterRender(templateName, isContainerTemplate, type, indend) {
    //     var templateMethod = isContainerTemplate ? 'SetContainerTemplates' : 'SetTemplates';
    //     var instanceInitialize = '';
    //     var argPass = '';
    //     if (templateMethod === 'SetTemplates') {
    //         instanceInitialize = 'if('+ templateName +' != null && this.'+ templateName + 'DotnetInstance == null){'+ indend + tab +'this.' + templateName + 'DotnetInstance = DotNetObjectReference.Create<object>(this);'
    //         argPass = instanceInitialize ? ', this.' + templateName + 'DotnetInstance' : '';
    //     }
    //     return indend + instanceInitialize + indend + tab + `await this.${templateMethod}("${templateName}", ${templateName}ID, ${templateName}, ${templateName}Data, Guid` + (!type ? `, (firstRender || TemplateClientChanges)` : ``) + argPass + ');'+ indend +'}';
    // }

    getMethodStatement(methodType) {
        if (methodType === 'async void') {
            return 'await ';
        } else {
            return 'return await ';
        }
    }

    getMethodType(obj, isGenericType) {
        var type;
        var customMethodType = this.getBlazorTagValue(obj, "blazortype");
        if (obj.signatures && obj.signatures.length > 0) {
            customMethodType = this.getBlazorTagValue(obj.signatures[0], "blazortype");
        }
        if (customMethodType) {
            type = customMethodType;
        } else {
            var modelType = this.getType(obj, "method");
            type = modelType.name;
        }
        if (type !== "void") {
            var isGenericEventModel = genericEventModels.indexOf(type) !== -1;
            type = isGenericType ? (isGenericEventModel ? type + "<TValue>" : "TValue") : this.toInitCap(type);
            if (modelType && modelType.isArray) {
                type = type.match(/List<(.*)>/) == null ? `List<${type}>` : type;
                return 'async Task<' + type + '>';
            } else {
                return 'async Task<' + type + '>';
            }
        }
        else {
            type = 'async Task';
        }
        return type;
    }

    getType(obj, apiType, ignoreLog) {
        var result;
        switch (apiType) {
            case "method":
                result = {};
                var isArray = false, type = "void";
                var signature = obj.signatures[0].type.name ? obj.signatures[0].type.name :
                    obj.signatures[0].type.elementType ? obj.signatures[0].type.elementType.name : "void";
                if (obj.signatures[0].type && obj.signatures[0].type.type) {
                    var t = obj.signatures[0].type.type;
                    if (t === "union") { signature = "object" }
                    else if (t === "array") { isArray = true; }
                    else if (t === "reflection") { signature = "object"; }
                }
                if (signature !== "void") {
                    type = "object"
                }
                if (commonMethodTypesKeys.indexOf(signature) !== -1) {
                    type = commonMethodTypes[signature];
                } else if (this.interfaces[signature]) {
                    type = signature;
                }
                else if (this.interfaces[signature + "Model"] && this.interfaces[signature + "Model"].children) {
                    type = signature + "Model";
                }
                else if (this.getDomType(signature, isArray)) {
                    type = this.getDomType(signature, isArray);
                }
                result.name = type;
                result.isArray = isArray;
                break;
            case "interface":
                if (obj.type) {
                    var isArrayType = false;
                    var typeName = obj.type.name;
                    var type = handledTypes[typeName];
                    type = type ? type : this.getDomType(typeName);
                    var isGenericTypeArg = this.isGenericType(obj);
                    var isDataSource = this.isDataSource(obj);
                    if (obj.type.type === "reference") {
                        if (this.types[typeName] || this.enums[typeName] || this.interfaces[typeName]) {
                            type = typeName;
                        }
                        else if (this.interfaces[typeName + "Model"] && this.interfaces[typeName + "Model"].children) {
                            type = typeName + "Model";
                        }
                        if (typeName === "EmitType") {
                            type = "EventCallback<object>"
                        }
                        if (isGenericTypeArg) {
                            type = isDataSource ? "IEnumerable" : "T";
                        }
                    }
                    else if (obj.type.type === "array") {
                        isArrayType = true;
                        typeName = obj.type.elementType.name;
                        type = handledTypes[typeName];
                        type = type ? (isGenericTypeArg ? "T[]" : type + '[]') : this.getDomType(typeName, true);
                        if (this.types[typeName] || this.enums[typeName] || this.interfaces[typeName]) {
                            type = typeName;
                        }
                        else if (this.interfaces[typeName + "Model"] && this.interfaces[typeName + "Model"].children) {
                            type = typeName + "Model";
                        }
                        type = type ? ((type.match(/List<(.*)>/) == null && type.indexOf('[]') === -1) ? 'List<' + (isGenericTypeArg ? "T" : type) + '>' : type) : 'object';
                    }
                    if (isGenericTypeArg) {
                        type = isDataSource ? "IEnumerable" : (isArrayType ? "List<T>" : "T");
                    }
                    result = type ? type : "object";
                }
                else {
                    result = "object";
                }
                if (!ignoreLog) {
                    console.log(obj.name + " - " + result);
                }
                break;
            case "property":
                if (obj.type) {
                    var type, typeName;
                    if (obj.type.name) {
                        typeName = obj.type.name;
                        type = handledTypes[typeName];
                        type = type ? type : this.getDomType(typeName);
                        if (this.interfaces[typeName] || this.enums[typeName] || this.types[obj.type.name]) {
                            type = typeName;
                        }
                        else if (this.interfaces[typeName + "Model"] && this.interfaces[typeName + "Model"].children) {
                            type = typeName + "Model";
                        }
                    }
                    else if (obj.type.type === "array") {
                        typeName = obj.type.elementType.name;
                        type = handledTypes[typeName];
                        type = type ? type + '[]' : this.getDomType(typeName, true);
                        if (this.types[typeName] || this.enums[typeName] || this.interfaces[typeName]) {
                            type = typeName;
                        }
                        else if (this.interfaces[typeName + "Model"] && this.interfaces[typeName + "Model"].children) {
                            type = typeName + "Model";
                        }
                        type = type ? ((type.match(/List<(.*)>/) == null && type.indexOf('[]') === -1) ? 'List<' + type + '>' : type) : 'object';
                    }
                    result = type ? type : "object";
                }
                break;
        }
        result = result ? result : 'object';
        return result;
    }

    getDomType(type, isArray) {
        var typeName;
        if (/HTMLCollection|NodeList|HTMLElement\[\]|Element\[\]/g.test(type)) {
            typeName = "List<DOM>";
        }
        else if (/HTMLElement|Element|Node/g.test(type)) {
            typeName = "DOM";
            if (isArray) {
                typeName = "List<DOM>";
            }
        }
        return typeName;
    }

    getInteropType(obj, isGenericType) {
        var modelType = this.getType(obj, "method");
        var type = 'Object';
        if (modelType.name !== 'void') {
            type = this.toInitCap(modelType.name);
            var isGenericEventModel = genericEventModels.indexOf(type) !== -1;
            type = isGenericType ? (isGenericEventModel ? type + "<TValue>" : "TValue") : this.toInitCap(type);
        }
        if (modelType.isArray && type.match(/List<(.*)>/) == null) {
            type = 'List<' + type + '>';
        }
        var customMethodType = this.getBlazorTagValue(obj, "blazortype");
        if (obj.signatures && obj.signatures.length > 0) {
            customMethodType = this.getBlazorTagValue(obj.signatures[0], "blazortype");
        }
        type = customMethodType ? customMethodType : type;
        return {
            isArray: modelType.isArray,
            actualType: modelType.name,
            type: type
        };
    }

    generateMethodArgs(obj) {
        var allArgs = [];
        var argsType;
        var argsName;
        var blazorArgsType = this.getBlazorTagValue(obj, "blazorargstype");
        if (blazorArgsType) {
            var singleSplit = blazorArgsType.split('|');
            if (blazorArgsType.indexOf(',') !== -1) {
                var multipleSplit = blazorArgsType.split(',');
                for (var argsIndex = 0; argsIndex < multipleSplit.length; argsIndex++) {
                    argsName = multipleSplit[argsIndex].split("|")[0].trim();
                    argsType = multipleSplit[argsIndex].split("|")[1].split("\n")[0].trim();
                    if(argsType.indexOf(".EJ2.") != -1){
                        argsType = argsType.replace(".EJ2","");
                    }
                    allArgs.push({
                        name: argsName,
                        type: argsType
                    });
                }
            } else {
                argsName = singleSplit[0].trim();
                argsType = singleSplit[1].split("\n")[0].trim();
                allArgs.push({
                    name: argsName,
                    type: argsType
                });
            }
        }
        var params = "";
        var paramList = [];
        var optionalParam;
        var enumDefinition = "";
        var parameters = obj.signatures[0].parameters;
        var paramLength = parameters && parameters.length;
        if (paramLength) {
            var args = [];
            for (var parameter of parameters) {
                var isCustomArgType = false;
                var name = parameter.type.name || parameter.name;
                var pName = parameter.name === "event" ? "Event" : parameter.name;
                if (allArgs.length > 0) {
                    for (var arg of allArgs) {
                        if (pName === arg.name) {
                            name = arg.type;
                            isCustomArgType = true;
                        }
                    }
                }
                if (handledTypesKeys.indexOf(name) !== -1) {
                    name = handledTypes[name];
                } else if (!this.interfaces[name] && !this.enums[name] && !this.types[name] && !isCustomArgType) {
                    name = "object";
                }
                if (parameter.flags && parameter.flags.isOptional === true && !this.isCustomArgs(allArgs, pName)) {
                    if (name === "bool" || name === "double") {
                        optionalParam = "Nullable<" + name + "> " + pName + " = null";
                    } else if (name === "DateTime" || (name.indexOf("object") === -1 && name.indexOf("string") === -1)) {
                        optionalParam = name + "? " + pName + " = null";
                    } else {
                        optionalParam = name + " " + pName + " = null";
                    }
                } else {
                    optionalParam = '';
                }
                if (allArgs.length > 0) {
                    params = params + name + " ";
                } else {
                    params = params + (parameter.type.types || parameter.type.type === "array" ? "object" : name) + " ";
                }
                params = optionalParam ? optionalParam : params + pName;
                if (this.enums[name] || this.types[name]) {
                    enumDefinition += newLine + tab + tab + `string _${pName} = SfBase.GetEnumValue<${name}>(${pName});`;
                    pName = `_${pName}`;
                }
                paramList.push(pName);
                args.push(params);
                params = "";
            }
            params = args.join(", ");
        }
        return {
            args: params,
            list: paramList.join(", "),
            enumDefinition: enumDefinition
        };
    }

    isCustomArgs(allArgs, pName) {
        var cusArgs = false;
        for (var arg of allArgs) {
            if (pName === arg.name) {
                cusArgs = true;
            }
        }
        return cusArgs;
    }

    addEnums(obj, comp, cnt, array) {
        var res = {};
        var values = [];
        var numValues = [];
        var numberEnum = obj.comment &&
            obj.comment.tags &&
            obj.comment.tags.filter(function (v) {
                return v.tag === "blazornumberenum";
            });
        if (obj.kindString === "Enumeration") {
            for (var i = 0; i < obj.children.length; i++) {
                if (numberEnum && numberEnum.length) {
                    numValues.push(obj.children[i].defaultValue);
                }
                if (obj.children[i].name) {
                    values.push(this.toInitCap(obj.children[i].name));
                }
            }
        } else {
            for (var j = 0; obj.type && obj.type.types && j < obj.type.types.length; j++) {
                if (obj.type.types[j].value) {
                    values.push(this.toInitCap(obj.type.types[j].value));
                }
            }
        }
        if (values.length && !array.filter(function (ob) {
            return !!ob[obj.name];
        }).length
        ) {
            res[obj.name] = values;
            if (numberEnum && numberEnum.length) {
                res[obj.name].numberEnum = numValues;
            }
            array.push(res);
        }
    }
    isStringLitrals(obj, isNestedType) {
        if (isNestedType) {
            obj.type = obj;
        }
        return obj.type && !!(
            this.propertyList.typeAliases[obj.type.name] &&
            this.propertyList.typeAliases[obj.type.name].type &&
            this.propertyList.typeAliases[obj.type.name].type.types
        );
    }

    isEnumType(obj, isNestedType) {
        if (isNestedType) {
            obj.type = obj;
        }
        return obj.type && this.propertyList.enumAliases[obj.type.name];
    }

    getBlazorTagValue(obj, tagName) {
        var retTagValue;
        var tagObject =
            obj.comment &&
            obj.comment.tags &&
            obj.comment.tags.filter(function (v) {
                return v.tag === tagName;
            });

        if (tagObject && tagObject[0] && tagObject[0].tag === "deprecated") {
            return true;
        }

        if (obj.kindString === 'Method') {
            tagObject =
                obj.signatures[0].comment &&
                obj.signatures[0].comment.tags &&
                obj.signatures[0].comment.tags.filter(function (v) {
                    return v.tag === tagName;
                });
        }

        if (tagObject && tagObject[0] && tagObject[0].text) {
            retTagValue = tagObject[0].text.split("\n")[0].trim().replace(/'/g, '').replace(/"/g, '');
        }
        return retTagValue;
    }

    isGenericType(obj) {
        var tagObject =
            obj.comment &&
            obj.comment.tags &&
            obj.comment.tags.filter(function (v) {
                return v.tag === 'isgenerictype';
            });
        return tagObject && tagObject.length > 0;
    }

    getDefaultPropertyValue(obj, comp, options, tagDirective, parent, isEventModel) {
        var cnt = "null";
        var curType = isEventModel ? this.getType(obj, "property") : this.getPropertyType(obj, comp, options, tagDirective, parent);
        var Enumerable = obj.comment &&
            obj.comment.tags &&
            obj.comment.tags.filter(function (v) {
                return v.tag === "isenumeration";
            });
        if (handledTypesKeys.indexOf(curType) !== -1 || this.isStringLitrals(obj) || this.isEnumType(obj) || (Enumerable && Enumerable.length)) {
            var cntVal = obj.comment && obj.comment.tags &&
                obj.comment.tags.filter(function (v) {
                    return v.tag === "blazordefaultvalue" || v.tag === "default";
                });
            if (cntVal !== undefined) {
                for (var c = 0; c < cntVal.length; c++) {
                    if (cntVal[c] !== undefined && cntVal[c].tag === "blazordefaultvalue") {
                        cntVal = cntVal[c];
                    }
                }
            }
            if (cntVal && cntVal[0] && cntVal[0].text && !/undefined|null/g.test(cntVal) || cntVal && cntVal.text && !/undefined|null/g.test(cntVal)) {
                if (cntVal.text !== undefined) {
                    cntVal = cntVal.text.split("\n")[0];
                } else {
                    cntVal = cntVal[0].text.split("\n")[0];
                }
                if (cntVal.indexOf("Syncfusion.") >= 0 && cntVal.indexOf("Syncfusion.Blazor.") === -1) {
                    var splitType = cntVal.split(".");
                    if (cntVal.indexOf("Syncfusion.EJ2.Blazor.") === -1) {
                        splitType.splice(1, 1, "Blazor");
                    } else {
                        splitType.splice(1, 1);
                    }
                    cntVal = splitType.join().replace(/\,/g, ".");
                }
                if(cntVal.indexOf("Ejs")!=-1){
                    cntVal = cntVal.replace("Ejs","Sf");
                }
                if (curType === "bool") {
                    cnt = cntVal.replace(/[^\w\s]|\n|/gi, "");
                    return cnt != "null" ? cnt : "default";
                }
                if (curType === "DateTime") {
                    if (cntVal.indexOf("new DateTime") !== -1) {
                        return '"' + cntVal + '"';
                    }
                    if (cntVal.match(/new Date\((.*)\)/)) {
                        return `"${cntVal.replace(/Date/, "DateTime")}"`;
                    }
                }
                if (curType === "double" && !this.isGenericType(obj)) {
                    if (cntVal.replace(/\W/g, "") === "null") {
                        return "default";
                    }
                    if (cntVal.indexOf('Double.NaN') !== -1) {
                        return cntVal;
                    }
                    cnt = parseFloat(cntVal.replace(/\n|\:|\s|\'|/gi, ""));
                    return cnt;
                }
                if (curType === "int") {
                    if (cntVal.replace(/\W/g, "") === "null") {
                        return "default";
                    }
                    cnt = parseInt(cntVal.replace(/\n|\:|\s|\'|/gi, ""));
                    return cnt;
                }
                if (this.isStringLitrals(obj)) {
                    if (cntVal.replace(/\W/g, "") === "null") {
                        return "null";
                    }
                    cnt = this.toInitCap(curType) + "." + this.toInitCap(cntVal.replace(/[^\w\s]|\n|/gi, ""));
                    return cnt;
                }
                if (this.isEnumType(obj)) {
                    if (cntVal.replace(/\W/g, "") === "null") {
                        return `(${this.toInitCap(curType)})0`;
                    }
                    cnt = this.toInitCap(curType) + "." + this.toInitCap(cntVal.replace(/[^\w\s]|\n|/gi, ""));
                    return cnt;
                }
                if (curType === "string") {
                    if (cntVal.replace(/\W/g, "") === "null") {
                        return "null";
                    }
                    cnt = cntVal.replace(/^'|'$/g, '"');
                    if (cntVal === "undefined" || cntVal === "'undefined'") {
                        cnt = null;
                    }
                } else {
                    if (cntVal.replace(/\W/g, "") === "null") {
                        return "null";
                    }
                    return cntVal;
                }
            }
        }
        return cnt;
    }

    getActualPropertyType(obj) {
        if (this.isStringLitrals(obj) || this.isEnumType(obj)) {
            return this.toInitCap(obj.type.name);
        }
    }

    getUnionType(obj, options) {
        var combination = [];
        obj.type.types.filter(function (value) {
            if (value.name) {
                combination.push(value.name);
            } else if (value.type === "array") {
                combination.push(value.type);
            }
            return value;
        });
        var combinations = combination.join(" ");
        if (options && options === "Enabled") {
            combinations = combinations.replace(/HTMLCollection|NodeList|Node\[\]|HTMLElement\[\]|Element\[\]/g, 3);
            combinations = combinations.replace(/HTMLElement|HTMLInputElement|Element|Node/g, 2);
            if (/3/g.test(combinations)) {
                return "List<DOM>";
            }
            else if (/2/g.test(combinations)) {
                return "DOM";
            }
        } else {
            combinations = combinations.replace(/number|Number|string|String|Date|Element|HTMLElement|HTMLInputElement|Node/g, 1);
        }
        combinations = combinations.replace(/[a-z-A-Z]/g, 0);
        if (/0/g.test(combinations)) {
            return "object";
        }
        return "string";
    }

    getPropertyType(obj, comp, options, tagDirective, parent, isGenericType) {
        var cusTagDirective, cusComplexDirective;
        if (isGenericType) {
            if (comp.genericProperties) {
                var returnType;
                returnType = comp.genericProperties.filter(returnType => returnType.name === obj.name);
                return returnType[0].type;
            } else {
                return this.isDataSource(obj) ? "IEnumerable<TValue>" : "TValue";
            }
        }
        if (comp) {
            cusTagDirective = comp.migratedTagDirective || comp.tagDirective;
            cusComplexDirective = comp.complexDirective;
        }
        var defaultValue = obj.comment &&
            obj.comment.tags &&
            obj.comment.tags.filter(function (v) {
                return v.tag === "blazortype";
            });
        if (defaultValue && defaultValue[0] && defaultValue[0].text) {
            var valType = defaultValue[0].text.split("\n")[0].trim();
            if (valType.indexOf("Syncfusion.") >= 0 && valType.indexOf("Syncfusion.Blazor.") === -1) {
                var splitType = valType.split(".");
                if (valType.indexOf("Syncfusion.EJ2.Blazor.") === -1) {
                    splitType.splice(1, 1, "Blazor");
                } else {
                    splitType.splice(1, 1);
                }
                valType = splitType.join().replace(/\,/g, ".");
                this.updateChildProperties(comp, obj.name, valType);
                return valType;
            } else {
                this.updateChildProperties(comp, obj.name, valType);
                return valType;
            }
        }
        if (obj.kindString === "Event" || obj.name === "query") {
            return "string";
        } else {
            //var res = (obj.type && obj.type.name) ? obj.type.name : "object";
            var res = "object";
            // if (isMultiType) {
            //     obj.type = MultiTypeObj;
            // }
            if (this.isStringLitrals(obj) || this.isEnumType(obj)) {
                if (tagDirective && tagDirective.baseClass && this.propertyList[tagDirective.baseClass]._allProperties.indexOf(obj.type.name.toLowerCase()) !== -1) {
                    return "Syncfusion.Blazor." + this.namespaceCheck(pack.name) + "." + this.toInitCap(obj.type.name);
                } else {
                    if (handledTypesKeys.indexOf(obj.type.name) === -1 && !this.enums[obj.type.name] && !this.types[obj.type.name]) {
                        //return (obj.type && obj.type.name) ? obj.type.name : "object";
                        return "object";
                    } else {
                        return this.toInitCap(obj.type.name);
                    }
                }
            }
            if (tagDirective) {
                cusTagDirective = tagDirective.migratedTagDirective || tagDirective.tagDirective;
                cusComplexDirective = tagDirective.complexDirective;
            }
            else {
                tagDirective = comp;
            }
            if (obj.type && obj.type.type === "union") {
                return this.getUnionType(obj, options);
            }

            if (cusTagDirective) {
                for (var i = 0; i < cusTagDirective.length; i++) {
                    if (cusTagDirective[i].propertyName === obj.name) {
                        if (cusTagDirective[i].isGenericClass) {
                            res = "List<" + this.getGenericParentType(cusTagDirective[i]) + ">";
                            childProperties[obj.name] = res;
                        }
                        else {
                            res = "List<" + this.getClassName(tagDirective, cusTagDirective[i], "complexType", parent) + ">";
                            childProperties[obj.name] = res;
                        }
                    }
                }
            }

            if (cusComplexDirective) {
                for (var j = 0; j < cusComplexDirective.length; j++) {
                    var tagDirectiveObj = cusComplexDirective[j].migratedTagDirective || cusComplexDirective[j].tagDirective;
                    if (tagDirectiveObj) {
                        for (var k = 0; k < tagDirectiveObj.length; k++) {
                            if (tagDirectiveObj[k].propertyName === obj.name) {
                                if (cusComplexDirective[j].isGenericClass) {
                                    res = "List<" + this.getGenericParentType(cusComplexDirective[j]); + ">";
                                    childProperties[obj.name] = res;
                                }
                                else {
                                    res = "List<" + this.getClassName(tagDirectiveObj, tagDirectiveObj[k], "complexType", parent) + ">";
                                    childProperties[obj.name] = res;
                                }
                            }
                        }
                    }
                    if (cusComplexDirective[j].propertyName === obj.name) {
                        if (cusComplexDirective[j].isGenericClass) {
                            res = this.getGenericParentType(cusComplexDirective[j]);
                            childProperties[obj.name] = res;
                        }
                        else {
                            res = this.getClassName(comp, cusComplexDirective[j]);
                            childProperties[obj.name] = res;
                        }
                    }
                }
            }

            if (res === "object") {
                var type = res;
                if (comp && obj.name === comp.propertyName && (comp.aspClassName || comp.directiveClassName)) {
                    var className = comp.aspClassName ? comp.aspClassName : comp.directiveClassName;
                    if (obj.type.type === "array" && comp.baseClass) {
                        type = 'List<' + className + '>';
                    }
                    else {
                        type = className;
                    }
                }
                type = type !== 'object' ? type : this.getType(obj, "property");
                res = type;
            }
            return res;
        }
    }

    updateChildProperties(comp, propName, value) {
        if (comp.complexDirective) {
            var currentComplex = comp.complexDirective.filter(complex => complex.propertyName === propName);
            currentComplex.length ? childProperties[propName] = value : null;
        }
        if (comp.tagDirective) {
            var currentComplex = comp.tagDirective.filter(complex => complex.propertyName === propName);
            currentComplex.length ? childProperties[propName] = value : null;
        }
    }
    isExported(obj) {
        if (obj.flags && obj.flags.isPrivate) {
            return false;
        } else {
            return obj.flags && obj.flags.isExported;
        }
    }

    getTagSelector(comp, data, isComplex) {
        var complexTagName, collectionTagName, parentTagName;

        if (isComplex) {
            complexTagName = data.aspSelectorName ? data.aspSelectorName : "e-" + comp.baseClass.toLowerCase() + "-" + data.propertyName.toLowerCase();
        } else {
            collectionTagName = data.aspArrayDirectiveSelector ? data.aspArrayDirectiveSelector : "e-" + comp.baseClass.toLowerCase() + "-" + data.arrayDirectiveClassName.toLowerCase();
            complexTagName = data.aspDirectiveSelector ? data.aspDirectiveSelector : "e-" + comp.baseClass.toLowerCase() + "-" + data.directiveClassName.toLowerCase();
        }

        return {
            complexTagName: complexTagName,
            collectionTagName: collectionTagName,
            parentTagName: parentTagName
        };
    }

    getAllPropertiesFromClass(propList, comp, options, restrict, restrictCommonMtds) {
        var props = propList;
        var oninitData, curProp, isDeprecate;
        var prop = "";
        var compInterface = "";
        var compEvents = "";
        var initProps = "";
        var propChanges = "";
        for (var i = 0; i < props._allProperties.length; i++) {
            isDeprecate = false;
            var curProperty = props._allProperties[i];
            var curPropObj = props._propObjects[curProperty];
            curPropObj.isModuleProperty = propList.isModule;
            curPropObj.moduleName = curPropObj.isModuleProperty ? propList.moduleName : null;
            if (curPropObj.comment.tags && curPropObj.comment.tags.length > 0) {
                for (var j = 0; j < curPropObj.comment.tags.length; j++) {
                    if (curPropObj.comment.tags[j].tag === "deprecated") {
                        isDeprecate = true;
                    }
                }
            }
            if (!isDeprecate) {
                if (props._propObjects[curProperty] && this.isDataSource(props._propObjects[curProperty])) {
                    oninitData = this.isDataSource(props._propObjects[curProperty]);
                    curProp = curProperty;
                }
                if (curPropObj && curPropObj.flags.isPrivate === undefined) {
                    var firstIndend = prop.length === 0;
                    var currentProperty = this.createPropertySyntax(firstIndend, curPropObj, comp, comp, undefined, options, propList._propShortComments);
                    prop += currentProperty.content;
                    compInterface += currentProperty.interface;
                    initProps += currentProperty.initProps;
                    propChanges += currentProperty.propChanges;
                }
            }
        }
        prop += this.getCustomProperties(comp);
        for (var j = 0; j < props._allEvents.length; j++) {
            isDeprecate = false;
            var curEvent = props._allEvents[j];
            if (props._propObjects[curEvent].comment.tags && props._propObjects[curEvent].comment.tags.length > 0) {
                for (var ij = 0; ij < props._propObjects[curEvent].comment.tags.length; ij++) {
                    if (props._propObjects[curEvent].comment.tags[ij].tag === "deprecated") {
                        isDeprecate = true;
                    }
                }
            }
            if (!isDeprecate) {
                if (props._propObjects[curEvent]) {
                    var tagDirectiveObj = comp.migratedTagDirective || comp.tagDirective;
                    var currentProperty = this.createPropertySyntax(false, props._propObjects[curEvent], comp, comp, tagDirectiveObj, options, propList._eventShortComments, restrict);
                    if ((comp.type === "container" || comp.type === "form") && !comp.complexDirective && !comp.tagDirective && !comp.migratedTagDirective && !comp.isGenericClass) {
                        prop = prop + compEvents + currentProperty.content;
                    } else {
                        compEvents = compEvents + currentProperty.content;
                    }
                }
            }
        }
        for (var k = 0; k < props._allMethods.length; k++) {
            isDeprecate = false;
            var curMethod = props._allMethods[k];
            if (props[curMethod].obj.signatures[0].comment && props[curMethod].obj.signatures[0].comment.tags && props[curMethod].obj.signatures[0].comment.tags.length > 0) {
                for (var j = 0; j < props[curMethod].obj.signatures[0].comment.tags.length; j++) {
                    if (props[curMethod].obj.signatures[0].comment.tags[j].tag === "deprecated") {
                        isDeprecate = true;
                    }
                }
            }
            if (!isDeprecate) {
                if (restrictCommonMethods.indexOf(curMethod) < 0 && restrictCommonMtds) {
                    var curMethodObj = props[curMethod] ? props[curMethod].obj : undefined;
                    if (curMethodObj) {
                        curMethodObj.isModuleMethod = propList.isModule;
                        curMethodObj.moduleName = curMethodObj.isModuleMethod ? propList.moduleName : null;
                        var tagDirectiveObj = comp.migratedTagDirective || comp.tagDirective;
                        var currentProperty = this.createPropertySyntax(false, curMethodObj, comp, comp, tagDirectiveObj, options, propList._methodShortComments);
                        prop = prop + currentProperty.content;
                    }
                }
            }
        }
        if (pack.isServerComponent) {
            for (var k = 0; k < props._allAccessors.length; k++) {
                var curAccessor = props._allAccessors[k];
                var curAccessorObj = props._propObjects[curAccessor];
                curAccessorObj.isModuleProperty = propList.isModule;
                curAccessorObj.moduleName = propList.isModule ? propList.moduleName : null;
                prop = prop + this.createAccessorSyntax(curAccessorObj, comp, undefined, options, propList._accessorShortComments, propList.isModule);
            }
        }
        this.generateInterface(comp, compInterface, null, true);
        if ((!pack.isServerComponent && compEvents.length > 0 && !comp.isRestrictEvents) || (pack.isServerComponent && !propList.isModule)) {
            this.generateEvents(comp, compEvents);
        }
        return {
            prop: prop,
            oninitData: oninitData,
            curProp: curProp,
            interface: compInterface,
            initProps: initProps,
            propChanges: propChanges
        };
    }

    generateEvents(comp, eventProps) {
        var eventTemplate = fs.readFileSync(__dirname + '/events.template', 'utf8');
        var genericType = comp.isGenericClass ? newLine + "@typeparam TValue;" : newLine;
        var eventContent = eventTemplate.replace(/{{GenericType}}/g, genericType);
        eventContent = eventContent.replace(/{{EventProperties}}/, eventProps);
        fs.writeFileSync("./third-party/blazor/Syncfusion.Blazor/" + this.namespaceCheck(pack.name) + "/" + comp.baseClass + "Events.razor", eventContent);
    }

    generateInterface(comp, compInterface, parentType, isBaseClass) {
        var genericBaseClass = isBaseClass ? comp.baseClass : baseClass.replace('Sf', '') + comp.baseClass;
        var interfaceName = parentType ? parentType : "I" + genericBaseClass;
        var packName = this.namespaceCheck(pack.name);
        var baseInterface = isGenericClass ? " : IBaseComponent" : "";
        var commonMethods = comp.tagDirective || comp.migratedTagDirective || comp.complexDirective ? newLine + tab + tab + "public void updateChildProperties(string key, object value);" : "";
        var interfaceTemplate = fs.readFileSync(__dirname + '/interface.template', 'utf8');
        var templates = "";
        if (isBaseClass && (comp.blazorTemplates || comp.blazorContainerTemplates)) {
            var templateName = `${genericBaseClass}Templates`;
            templates = newLine + tab + tab + `${templateName} ${templateName} { get; set; }`;
        }
        interfaceTemplate = interfaceTemplate.replace(/{{NameSpace}}/g, this.namespaceCheck(pack.name));
        interfaceTemplate = interfaceTemplate.replace(/{{Name}}/g, interfaceName);
        interfaceTemplate = interfaceTemplate.replace(/{{BaseInterface}}/g, baseInterface);
        interfaceTemplate = interfaceTemplate.replace(/{{Interfaces}}/g, tab + tab + compInterface.trim() + templates);
        interfaceTemplate = interfaceTemplate.replace(/{{CommonMethods}}/g, commonMethods);
        shelljs.mkdir('-p', "./third-party/blazor/Syncfusion.Blazor/" + packName + "/Interfaces/");
        fs.writeFileSync("./third-party/blazor/Syncfusion.Blazor/" + packName + "/Interfaces/" + interfaceName + ".cs", interfaceTemplate)
    }

    toInitCap(str) {
        return str.charAt(0).toUpperCase() + str.substr(1);
    }

    toInitSmall(str) {
        return str.charAt(0).toLowerCase() + str.substr(1);
    }

    isDataSource(obj) {
        var propName = obj.name;
        var dataSource = obj.comment &&
            obj.comment.tags &&
            obj.comment.tags.filter(function (v) {
                return v.tag == "isdatamanager";
            });
        if (dataSource !== undefined && dataSource.length > 0) {
            if (dataSource[0].text.indexOf("true") >= 0) {
                return {
                    dataSource: dataSource[0].text.split("\n")[0],
                    propName: propName
                }
            } else {
                return undefined;
            }
        }
        else if (propName === "dataSource") {
            return {
                dataSource: "true",
                propName: propName
            };
        }
    }

    dataAnnotation(annotationName, annotationType, isClassFile) {
        var val = "";
        var indend = isClassFile ? newLine + tab + tab : newLine + tab;
        for (var i = 0; i < annotationName.length; i++) {
            val = val + indend + "[Parameter]" + indend + "[JsonIgnore]" + indend +
                "public Expression<Func<" + annotationType[i] + ">> " + this.toInitCap(annotationName[i]) + "Expression { get; set; }" + newLine;
        }
        annotationName.length = 0;
        annotationType.length = 0;
        return val;
    }

    isNullable(obj) {
        var nullableVal;
        var isNullable =
            obj.comment &&
            obj.comment.tags &&
            obj.comment.tags.filter(function (v) {
                return v.tag === "isblazornullabletype";
            });
        if (isNullable && isNullable[0] && isNullable[0].text) {
            nullableVal = isNullable[0].text.split("\n")[0].trim();
        }
        if (nullableVal === "true") {
            return "?";
        } else {
            return "";
        }
    }

    isBindingProp(obj, name, comp, type, defaultValue, isGenericType) {
        var prop = "";
        var propChanges = "";
        var propName = this.toInitCap(name);
        var nullableType = this.isNullable(obj);
        var dataSource = this.isDataSource(obj), dataSrc;
        var dataObj = { type: type, nullableType: nullableType, defaultValue: defaultValue };
        var isClassFile = this.isClassFile(comp);
        var indend = isClassFile ? newLine + tab + tab : newLine + tab;
        if (dataSource !== undefined) {
            dataSrc = dataSource.dataSource;
        }
        var comptwoWays = comp.blazorTwoWays || comp.twoWays;
        if (comptwoWays && comptwoWays.indexOf(name) !== -1) {
            isTwoway = true;
            for (var t = 0; t < comptwoWays.length; t++) {
                if ((dataSource != null && dataSrc != null) && comptwoWays[t] === name) {
                    twoWays.push(comptwoWays[t]);
                    var data = this.generateDataSource(name, dataObj, true, isGenericType, isClassFile);
                    prop += data.property + newLine;
                    propChanges += indend + tab + tab + data.propChanges;
                } else if (comptwoWays[t] === name) {
                    isdataAnnotation = true;
                    twoWays.push(comptwoWays[t]);
                    if (annotationName && !annotationName.includes(comptwoWays[t])) {
                        annotationName.push(comptwoWays[t]);
                        annotationType.push(type + nullableType);
                    }
                    prop = `${this.defaultVal(defaultValue)}` +
                        indend + `private ${type}${nullableType} _${comptwoWays[t]} { get; set; }` + newLine +
                        indend + "[Parameter]" + indend + "[JsonIgnore]" + indend +
                        `public EventCallback<${type}${nullableType}> ${this.toInitCap(comptwoWays[t])}Changed { get; set; }` + newLine;
                    propChanges += indend + tab + `this.${propName} = this._${name} = await this.updateProperty("${name}", ${propName}, _${name}, ${propName}Changed, ${propName}Expression, false);`;
                }
            }
        } else if (dataSource != null && dataSrc != null) {
            var data = this.generateDataSource(name, dataObj, false, isGenericType, isClassFile);
            prop = data.property;
            propChanges = data.propChanges;
        } else {
            var defaultVal = (defaultValue && defaultValue.toString().indexOf("new DateTime") !== -1) ? " = " + defaultValue.replace(/^"|"$/g, '') + ";" : (defaultValue ?
                " = " + defaultValue + ";" : "");
            prop = ` { get; set; }${defaultVal}` +
                indend + `private ${type}${nullableType} _${name} { get; set; }`;
            propChanges = indend + tab + `this.${propName} = this._${name} = await this.updateProperty("${name}", ${propName}, _${name});`;
            var isDataSource = this.getBlazorTagValue(obj, "isdatamanager");
            if (isDataSource === 'false') {
                propChanges = propChanges.split(')')[0] + ', null, null, false, true);';
            }
            if (comp.isCustomBlazor) {
                defaultVal = defaultVal.length ? defaultVal : ";";
                if (comp.complexDirective) {
                    var complexProps = this.getComplexProperties(comp.complexDirective);
                    defaultVal = complexProps.indexOf(name) !== -1 ? ` = new ${type}${nullableType}();` : defaultVal;
                }
                prop = indend + "{" +
                    indend + tab + `get { return this._${name}; }` +
                    indend + tab + "set" +
                    indend + tab + "{" +
                    indend + tab + tab + `this._${name} = value;` +
                    indend + tab + tab + `UpdateProperty("${this.toInitCap(name)}", this._${name});` +
                    indend + tab + "}" +
                    indend + "}" +
                    indend + `private ${type}${nullableType} _${name}${defaultVal}`;
            }
        }
        return { property: prop, propChanges: propChanges };
    }

    generateDataSource(name, dataObj, isTwoWay, isGenericType, isClassFile) {
        var propName = this.toInitCap(name);
        var indend = isClassFile ? newLine + tab + tab : newLine + tab;
        var genericType = isGenericType ? "IEnumerable<TValue>" : dataObj.type;
        var dataSource = " { get; set; }" +
            indend + `private ${genericType}${dataObj.nullableType} _${name}${this.defaultVal(dataObj.defaultValue)}` + newLine;
        dataSource += isTwoWay ? indend + "[Parameter]" +
            indend + "[JsonIgnore]" +
            indend + `public EventCallback<${genericType}> ${propName}Changed { get; set; }` : "";
        var eventCallback = isTwoWay ? `, ${propName}Changed` : ", null";
        var propChanges = indend + tab + `this.${propName} = this._${name} = await this.updateProperty("${name}", ${propName}, _${name}${eventCallback}, null, true);`;
        return {
            property: dataSource,
            propChanges: propChanges
        };
    }

    defaultVal(defaultValue) {
        if (defaultValue !== null && defaultValue !== undefined) {
            return ` { get; set; } = ${defaultValue};`;
        }
        return ' { get; set; }';
    }

    getComments(propList, tagDirective, curBuilderProperty) {
        var comment = "";
        if (curBuilderProperty.comment) {
            var newLine = "\n";
            var tab = "    ";
            comment = propList[tagDirective.baseClass]._propShortComments[curBuilderProperty.name] ||
                propList[tagDirective.baseClass]._eventShortComments[curBuilderProperty.name];
            comment = comment.split("\n").join(newLine + tab + tab) + newLine;
        }
        return comment;
    }

    generateEnum(enums, typeList, enumList) {
        var helper = fs.readFileSync(__dirname + "/" + "enumerations.template").toString();
        if (enums.length) {
            var tab = "    ";
            var enumProp = "";
            var newLine = "\n";
            for (var i = 0; i < enums.length; i++) {
                var curObj = enums[i];
                var typeName = Object.keys(curObj)[0];
                if (this.propertyList[typeName] && this.propertyList[typeName]._propShortComments[typeName]) {
                    var comment = this.propertyList[typeName]._propShortComments[typeName].split("\n").join(newLine + tab);
                    enumProp = enumProp + tab + comment + newLine;
                }

                var isNumberEnum = curObj[typeName].numberEnum && curObj[typeName].numberEnum.length;
                var flag = isNumberEnum ? tab + "[Flags]" + newLine : "";
                enumProp = !isNumberEnum ? enumProp + newLine + tab + "[JsonConverter(typeof(StringEnumConverter))]" + newLine : enumProp;
                var name = this.toInitCap(typeName);
                enumProp = enumProp + flag + tab + "public enum " + name + newLine;
                enumProp = enumProp + tab + "{" + newLine;
                for (var j = 0; j < curObj[typeName].length; j++) {
                    var value = curObj[typeName];
                    var enumCmt = '';
                    if (typeList[this.toInitCap(typeName)] && typeList[this.toInitCap(typeName)].comment && typeList[this.toInitCap(typeName)].comment.shortText) {
                        enumCmt = this.generateEnumComment(typeList[this.toInitCap(typeName)].comment.shortText, value[j]);
                    }
                    if (isNumberEnum) {
                        var quotes = curObj[typeName].numberEnum.length - 1 === j ? "" : ",";
                        if (curObj[typeName].numberEnum[j].replace(/\W/g, "") === "null") {
                            enumProp = enumProp + tab + tab + value[j] + quotes + newLine;
                        } else {
                            enumProp = enumProp + tab + tab + value[j] + "= " + curObj[typeName].numberEnum[j] + quotes + newLine;
                        }
                    } else {
                        enumProp = enumProp + enumCmt + tab + tab +'[EnumMember(Value ="' + value[j] + '")]' + newLine;
                        enumProp = enumProp + tab + tab + this.toInitCap(value[j].replace(/\s/g, "")) + "," + newLine;
                    }
                }
                enumProp = enumProp + tab + "}" + newLine + newLine;
            }
            var packName = this.namespaceCheck(pack.name);
            shelljs.mkdir("-p", "./third-party/blazor/Syncfusion.Blazor/" + packName + "/Enumeration/");
            helper = helper.replace(/{{NameSpace}}/g, packName);
            helper = helper.replace(/{{enumerations}}/g, enumProp);
            fs.writeFileSync("./third-party/blazor/Syncfusion.Blazor/" + packName + "/Enumeration/" + packName.trim() + "Enumerations.cs", helper);
        }
    }

    generateEnumComment(cmt, enumname) {
        var result = '';
        var matchRegex = '`' + enumname + '.+';
        var regex = new RegExp(matchRegex, "g");
        var getcmt = cmt.match(regex);
        if (getcmt && getcmt[0].split('-')[0] && enumname === getcmt[0].split('-')[0].replace(' ', '').replace(/`/g, '')) {
            result = tab + tab + '///<summary>\n' + tab + tab + '///' + getcmt[0].split('-')[1] + '\n' + tab + tab + '///</summary>\n';
        }
        return result;
    }


    generateModules(propList, comp, options, restrict, curCompName) {
        var proxy = this;
        var modules = comp.modules;
        var enums = options.enums;
        var inhertClass = '';
        var importNameSpace = '';
        if (comp.inhertClass !== undefined) {
            inhertClass = ": " + comp.inhertClass + "Base";
            importNameSpace = "using Syncfusion.Blazor." + comp.inhertClass + ";";
        }
        var restrictCommonMtds = true;
        shelljs.mkdir("-p", "./third-party/blazor/Syncfusion.Blazor/" + curCompName + "/" + "Modules");
        for (var i = 0; i < modules.length; i++) {
            var module = modules[i];
            var className = module.className;
            var classObj = propList[className];
            classObj.isModule = true;
            classObj.moduleName = module.propertyName;
            var returnvalues = proxy.getAllPropertiesFromClass(classObj, comp, { enums: enums }, restrict, restrictCommonMtds);
            var cnt = fs.readFileSync(__dirname + "/" + "module.template").toString();
            var options = {
                enums: enums
            };
            cnt = cnt.replace(/{{Properties}}/g, returnvalues.prop);
            cnt = cnt.replace(/{{CompName}}/g, curCompName);
            cnt = cnt.replace(/{{ModuleName}}/g, className);
            cnt = cnt.replace(/{{InhertClass}}/g, inhertClass);
            cnt = cnt.replace(/{{ImportNamespace}}/g, importNameSpace);
            fs.writeFileSync("./third-party/blazor/Syncfusion.Blazor/" + "/" + curCompName + "/" + "Modules" + "/" + className + ".cs", cnt);
        }
    }

    createAccessorSyntax(obj, comp, tagDirective, options, comment, isModule) {
        var cnt = "";
        var tab = "    ";
        var newLine = "\n";
        var pType = "public";
        var type = this.getPropertyType(obj, comp, options, tagDirective);
        var baseComp = comp.inhertClass ? comp.inhertClass : comp.baseClass;
        var baseComponent = isModule ? `this.${baseComp}Component` : "this";
        if (obj.getSignature) {
            if (comment) {
                cnt += comment._getComments[obj.name] ? tab + comment._getComments[obj.name].split("\n").join(newLine + tab) + newLine : cnt;
            }
            if (obj.getSignature.type.type === 'reference') {
                if (type === 'object' && this.propertyList.typeAliases[obj.getSignature.type.name] !== undefined) {
                    this.addEnums(this.propertyList.typeAliases[obj.getSignature.type.name], comp, cnt, options.enums);
                    type = obj.getSignature.type.name;
                    cnt = cnt + tab + `${pType} async Task<${type}> Get${this.toInitCap(obj.name)}()` +
                        newLine + tab + '{' +
                        newLine + tab + tab + `string result = await ${baseComponent}.InvokeGet<string>("${obj.moduleName}", "${obj.name}");` +
                        newLine + tab + tab + `${type} ${obj.name};` +
                        newLine + tab + tab + `Enum.TryParse<${type}>(result, out ${obj.name});` +
                        newLine + tab + tab + `return ${obj.name};` +
                        newLine + tab + '}' + newLine + newLine;
                }
                else {
                    type = type + 'Module';
                    cnt = cnt + tab + `${pType} ${type} Get${this.toInitCap(obj.name)}()` +
                        newLine + tab + '{' +
                        newLine + tab + tab + `if (_${obj.name} == null)` +
                        newLine + tab + tab + '{' +
                        newLine + tab + tab + tab + `_${obj.name} = new ${type}(${baseComponent});` +
                        newLine + tab + tab + '}' + tab +
                        newLine + tab + tab + `return _${obj.name};` +
                        newLine + tab + '}' +
                        newLine + tab + `private ${type} _${obj.name} = null;` + newLine + newLine;
                }
            }
            else {
                cnt = cnt + tab + `${pType} async Task<${type}> Get${this.toInitCap(obj.name)}()` +
                    newLine + tab + '{' +
                    newLine + tab + tab + `return await ${baseComponent}.InvokeGet<${type}>("${obj.moduleName}", "${obj.name}");` +
                    newLine + tab + '}' + newLine + newLine;
            }
        }
        if (obj.setSignature && obj.setSignature.parameters !== undefined && obj.setSignature.parameters.length) {
            if (comment) {
                cnt += comment._setComments[obj.name] ? tab + comment._setComments[obj.name].split("\n").join(newLine + tab) + newLine : cnt;
            }
            var paramName = obj.setSignature.parameters[0].name;
            var valParamName = paramName;
            if (this.propertyList.typeAliases[obj.setSignature.parameters[0].type.name] !== undefined) {
                //Convert to Enum Value
                valParamName = paramName + ".ToString()";
            }
            cnt = cnt + newLine + tab + `${pType} async void Set${this.toInitCap(obj.name)}(${type} ${paramName}) {` +
                newLine + tab + tab + `await ${baseComponent}.InvokeSet<Object>("${obj.moduleName}", "${obj.name}", ${valParamName});` +
                newLine + tab + "}" + newLine + newLine;
        }
        return cnt;
    }
}

module.exports = function (json, propList, done) {
    var pJson = JSON.parse(fs.readFileSync("./package.json"));
    return new BlazorSourceGen(json, propList, pJson, done);
};
/* jshint ignore:end */
