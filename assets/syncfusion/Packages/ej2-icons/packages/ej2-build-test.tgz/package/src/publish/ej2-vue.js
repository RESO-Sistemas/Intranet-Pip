'use strict';

var reg = require('../tasks/registry.js');
var fs = global.fs = global.fs || require('fs');
var glob = global.glob || require('glob');
var common = global.config = global.config || require('../utils/common.js');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var gulp = global.gulp = global.gulp || require('gulp');

var localpath = './ej2-vue-repo/';
var config = common.config();
var currentRepo = common.currentRepo;
var currentPackage = common.currentPackage;

if (currentPackage !== 'ej2-base') {
    currentPackage = currentPackage.replace('ej2-', 'ej2-vue-');
}

var nFiles = [];

/**
 * Components auto update in ej2 repository
 */
gulp.task('publish-ej2-vue', function (done) {
    shelljs.rm('-rf', './ej2-vue-repo');
    if (new RegExp(config.thirdPartyWords.join('|')).test(currentRepo) || !config.components) {
        done();
        return;
    }
    var branchName = common.isMasterBranch ? 'master' : process.env.githubSourceBranch || 'development';
    var simpleGit = require('simple-git');
    if (!fs.existsSync('./ej2-vue-repo')) {
        fs.mkdirSync('./ej2-vue-repo');

        // clone components repository  
        var user = 'SyncfusionAutomation';
        var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
        var ej2Repo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-vue-es5.git';
        simpleGit().clone(ej2Repo, './ej2-vue-repo', function (err) {
            if (err) {
                done(err);
                return;
            }
        }).exec(function () {
            simpleGit('./ej2-vue-repo').checkout(branchName, function (err) {
                if (err) {
                    done(err);
                    return;
                }
                // create components
                createVueComponents();

                // get commit message
                simpleGit().log(function (err, log) {
                    var logs = common.getCommitDetails(log);
                    var commitMessage = logs.lastCommit;

                    // check current component in package.json
                    shelljs.cd(localpath);

                    // update npmrc contents
                    reg.setNpmrc();

                    var packages = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
                    var deps = Object.keys(packages.dependencies);

                    if (deps.indexOf('@syncfusion/' + currentPackage) === -1) {
                        shelljs.exec('npm install @syncfusion/' + currentPackage + ' --save');

                        // Get updated package
                        packages = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
                        deps = Object.keys(packages.dependencies);
                    }

                    if (nFiles.length) {
                        var files = nFiles.toString().split(',').join(' ');
                        shelljs.exec('git add ' + files);
                    }

                    var differences = shelljs.exec('git diff ' + branchName).stdout;
                    if (!differences.length) {
                        shelljs.cd('../');
                        done();
                        return;
                    }
                    // update npm package dependencies
                    for (var i = 0; i < deps.length; i++) {
                        if (deps[i].indexOf('@syncfusion') !== -1) {
                            packages.dependencies[deps[i]] = '*';
                        }
                    }
                    fs.writeFileSync('./package.json', JSON.stringify(packages, null, '\t'));
                    if (!common.isMasterBranch) {
                        shelljs.exec('npm version -f ' + logs.release + ' --no-git-tag-version --no-verify');
                    }
                    shelljs.cd('../');
                    // push updated component src  to components repository
                    simpleGit('./ej2-vue-repo').init()
                        .add('./*')
                        .commit(commitMessage)
                        .pull(branchName)
                        .push(ej2Repo, branchName, function () {
                            console.log(currentPackage + ' - source updated in ej2 vue es5');
                            done();
                        });
                });
            });
        });
    }
});

function createVueComponents() {
    // create component in ej2 vue
    if (fs.existsSync('./src')) {
        exportVueComponents();
    }

    // update index.ts with all components
    var components = '/**\n * ej2 vue source\n */\n';
    var files = glob.sync('./ej2-vue-repo/**.ts', { ignore: ['ej2-vue-repo/index.ts'] });
    var exportContent = 'export { ';
    var lastpack = files[files.length - 1];
    for (let file of files) {
        var isLast = lastpack === file ? ' };\n' : ', ';
        var packName = file.replace('ej2-vue-repo/', '').replace('.ts', '');
        components = components + `import * as ${packName.replace(/-/g, '')} from './${packName}';\n`;
        exportContent = exportContent + packName.replace(/-/g, '') + isLast;
    }
    addNewFiles(localpath + '/index.ts');
    fs.writeFileSync(localpath + '/index.ts', components + exportContent);
}

function exportVueComponents() {
    // typescript export
    var filename = currentPackage.replace(/ej2-vue-|ej2-/, '').trim() + '.ts';
    var content = 'export * from \'@syncfusion/' + currentPackage + '\';\n';
    if (!fs.existsSync('./third-party/config.json') || currentPackage === 'ej2-base') {
        addNewFiles(localpath + filename);
        fs.writeFileSync(localpath + filename, content);
        return;
    }
    var tpConfig = JSON.parse(fs.readFileSync('./third-party/config.json', 'utf-8'));
    var hasDynamicModules = tpConfig.components &&
        tpConfig.components.filter(com => com.dynamicModules &&
            Array.isArray(com.dynamicModules) &&
            com.dynamicModules.length > 0).length > 0 ? true : false;
    if (!hasDynamicModules) {
        addNewFiles(localpath + filename);
        fs.writeFileSync(localpath + filename, content);
        return;
    }
    content = 'import * as index from \'@syncfusion/' + currentPackage + '\';\n';
    for (let thirdPartyComponent of tpConfig.components) {
        var dyModuleCount = thirdPartyComponent.dynamicModules ? thirdPartyComponent.dynamicModules.length : 0;
        if (dyModuleCount <= 0) {
            continue;
        }
        var dynamicContent = 'index.' + thirdPartyComponent.baseClass + '.Inject(';
        for (let dyModule of thirdPartyComponent.dynamicModules) {
            var isLastModule = dyModuleCount > 0 && thirdPartyComponent.dynamicModules[dyModuleCount - 1] === dyModule ? ');\n' : ',';
            dynamicContent = dynamicContent + 'index.' + dyModule + isLastModule;
        }
        content = content + dynamicContent;
    }
    content = content + 'export * from \'@syncfusion/' + currentPackage + '\';\n';
    addNewFiles(localpath + filename);
    fs.writeFileSync(localpath + filename, content);
}

function addNewFiles(filePath) {
    if (!fs.existsSync(filePath)) {
        nFiles.push(filePath.replace(localpath, './'));
    }
}
