'use strict';

var fs = global.fs = global.fs || require('fs');
var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var md2json = require('md-2-json');
var glob = require('glob');
var path = require('path');
var changelogPath = {
    'common': './CHANGELOG.md',
    'javascript': './third-party/changelog/javascript.md',
    'typescript': './third-party/changelog/typescript.md',
    'angular': './third-party/changelog/angular.md',
    'react': './third-party/changelog/react.md',
    'vue': './third-party/changelog/vue.md'
};
var commonPackage = {
    'ej2-base': 'typescript',
    'ej2-angular-base': 'angular',
    'ej2-react-base': 'react',
    'ej2-vue-base': 'vue'
};
var versios = {
    'vue': 16.2
};
var chalogRegex = /changelog/i;
var versionCheckRegex = /^(\d+\.)?(\d+\.)?(\*|\d+).+/;
var changeLogtypes = ['Bug Fixes', 'New Features', 'Breaking Changes', 'Deprecated'];

gulp.task('getChangelog', function (done) {
    var user = 'SyncfusionAutomation';
    var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
    var branch = 'development';
    var platforms;
    var basePackages = Object.keys(commonPackage);
    if (basePackages.indexOf(global.config.currentPackage) > -1) {
        platforms = [commonPackage[global.config.currentPackage]];
    }
    var origin = 'https://' + user + ':' + token + '@gitea.syncfusion.com/syncfusion-content/releasenotes.git';
    // checkout ej2-release-notes in ej2-changelog location
    shelljs.exec('git clone ' + origin + ' -b ' + branch + ' ./releasenotes');
    if (fs.existsSync('./CHANGELOG.md')) {
        if (platforms) {
            var baseChangelog = fs.readFileSync('./CHANGELOG.md', 'utf8');
            var baseReleaseNotes = md2json.parse(baseChangelog).Changelog;
            var baseVersion = Object.keys(baseReleaseNotes);
            var getBaseVersion = getVersion(baseVersion[0]);
            getBaseVersion = getBaseVersion.charAt(0).toUpperCase() + getBaseVersion.slice(1);
            const baseFileName = Object.keys(baseReleaseNotes['[Unreleased]']);
            if (baseFileName.length === 0) {
                return done();
            }
            else {
                var createFolder = `releasenotes/ej2-${platforms}/Release-Notes/${getBaseVersion}` + `/`;
                shelljs.mkdir('-p', createFolder);
                for (var j = 0; j < baseFileName.length; j++) {
                    if (baseFileName[j] === 'raw' || checkSpecialCharacters(baseFileName[j])) {
                        console.log('Invalid file name', baseFileName[j]);
                        process.exit(1);
                    }
                    else {
                        var releaseContent = md2json.toMd({ [baseFileName[j]]: baseReleaseNotes['[Unreleased]'][baseFileName[j]] });
                        releaseContent = releaseContent.replace(/^## (.*)$/gm, '### $1').replace(/^# (.*)$/gm, '## $1');
                        fs.writeFileSync(createFolder + `1.${baseFileName[j].replace(/\s+/, '')}.md`, releaseContent, 'utf8');
                        if (platforms[0] === 'typescript') {
                            createFolder = `releasenotes/ej2-javascript/Release-Notes/${getBaseVersion}` + `/`;
                            shelljs.mkdir('-p', createFolder);
                            fs.writeFileSync(createFolder + `1.${baseFileName[j].replace(/\s+/, '')}.md`, releaseContent, 'utf8');
                        }
                    }
                }
            }
        }
        else {
            var commonChangelog = fs.readFileSync('./CHANGELOG.md', 'utf8');
            var changelogFile = glob.sync('./third-party/changelog/**/*.md');
            for (var i = 0; i < changelogFile.length; i++) {
                var file = changelogFile[i];
                const basename = path.basename(changelogFile[i], '.md');
                // const dirname = require('./package.json').name;
                if (file.indexOf('.md') !== -1 && file.indexOf('README.md') === -1 && chalogRegex.test(file)) {
                    if (basename === 'typescript' || basename === 'javascript' || basename === 'angular' || basename === 'react' || basename === 'vue') {
                        var mdContent = fs.readFileSync(file, 'utf8');
                        var mdObj = md2json.parse(mdContent).Changelog;
                        var versionName = Object.keys(mdObj);
                        var releaseVer = getVersion(versionName[0]);
                        releaseVer = releaseVer.charAt(0).toUpperCase() + releaseVer.slice(1);
                        console.log('releaseVer ---> ' + releaseVer);
                        const fileName = Object.keys(mdObj[versionName[0]]);
                        if (fileName.length === 0) {
                            var releaseNotes = md2json.parse(commonChangelog).Changelog;
                            var commonVersion = Object.keys(releaseNotes);
                            const fileName = Object.keys(releaseNotes[commonVersion[0]]);
                            if (fileName.length === 0) {
                                continue;
                            }
                            else {
                                const createFolder = `releasenotes/ej2-${basename}/Release-Notes/${releaseVer}` + `/`;
                                shelljs.mkdir('-p', createFolder);
                                for (var l = 0; l < fileName.length; l++) {
                                    if (fileName[l] === 'raw' || checkSpecialCharacters(fileName[l])) {
                                        console.log('Invalid file name', fileName[l]);
                                        process.exit(1);
                                    }
                                    else {
                                        var releasContent = md2json.toMd({ [fileName[l]]: releaseNotes[commonVersion[0]][fileName[l]] });
                                        releasContent = releasContent.replace(/^## (.*)$/gm, '### $1').replace(/^# (.*)$/gm, '## $1');
                                        fs.writeFileSync(createFolder + fileName[l].replace(/\s+/, '') + '.md', releasContent);
                                    }
                                }
                            }
                        }
                        else {
                            var thirdPartymdContent = fs.readFileSync(file, 'utf8');
                            var thirdPartymdObj = md2json.parse(thirdPartymdContent).Changelog;
                            var thirdPartyVersionName = Object.keys(thirdPartymdObj);
                            var thitdPartyReleaseVer = getVersion(thirdPartyVersionName[0]);
                            thitdPartyReleaseVer = thitdPartyReleaseVer.charAt(0).toUpperCase() + thitdPartyReleaseVer.slice(1);
                            console.log('releaseVer ---> ' + thitdPartyReleaseVer);
                            const createFolder = `releasenotes/ej2-${basename}/Release-Notes/${thitdPartyReleaseVer}` + `/`;
                            const fileName = Object.keys(thirdPartymdObj[thirdPartyVersionName[0]]);
                            if (fileName.length === 0) {
                                continue;
                            }
                            else {
                                shelljs.mkdir('-p', createFolder);
                                for (var k = 0; k < fileName.length; k++) {
                                    if (fileName[k] === 'raw' || checkSpecialCharacters(fileName[k])) {
                                        console.log('Invalid file name', fileName[k]);
                                        process.exit(1);
                                    }
                                    else {
                                        var releaseCon = md2json.toMd({ [fileName[k]]: thirdPartymdObj[thirdPartyVersionName[0]][fileName[k]] });
                                        releaseCon = releaseCon.replace(/^## (.*)$/gm, '### $1').replace(/^# (.*)$/gm, '## $1');
                                        fs.writeFileSync(createFolder + fileName[k].replace(/\s+/, '') + '.md', releaseCon);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    shelljs.cd('./releasenotes');
    // pull the remote changes
    shelljs.exec('git pull', { silent: false });
    // add all new changes in the git
    shelljs.exec('git add .', { silent: false });
    // commit the new changes
    shelljs.exec('git commit -m "' + common.currentPackage + ' release-notes are merged"', { silent: false });
    // push the commited changes to remote
    shelljs.exec('git push -f --set-upstream origin ' + branch + ' --no-verify', { silent: false });
    shelljs.cd('../');
    // remove releasenotes folder
    shelljs.rm('-rf', './releasenotes');
    done();
});
function getVersion(fileName) {
    if (fileName.indexOf('migration') === -1) {
        return (fileName.indexOf('[Unreleased]') !== -1 || fileName.indexOf('Unreleased') !== -1) ? 'unreleased' : fileName.match(/([0-9]{2}.[0-9]{1}.([0-9]{2}|[0-9]{1}))/)[0];
    }
}
function checkSpecialCharacters(string) {
    var pattern = /[,~`!@#$%^&*()-+=\[\]{}|\\;:'"<>,.?]/;
    return pattern.test(string);
}

gulp.task('changelog-validation', function (done) {
    if (process.env.githubSourceBranch !== undefined) {
        return;
    }
    var differences = shelljs.exec('git diff --name-only HEAD').stdout.split('\n');
    console.log('differences ---> ' + differences);
    for (var i = 0; i < differences.length; i++) {
        var isSyntaxError = false;
        var file = differences[i];
        if (file.indexOf('.md') !== -1 && file.indexOf('README.md') === -1 && chalogRegex.test(file)) {
            var mdContent = fs.readFileSync(file, 'utf8');
            var mdObj = md2json.parse(mdContent).Changelog;
            var versionName = Object.keys(mdObj);
            for (var j = 0; j < versionName.length; j++) {
                var comp = mdObj[versionName[j]];
                var compName = Object.keys(comp);
                if (versionCheckRegex.test(versionName[j]) || versionName[j] === '[Unreleased]') {
                    if (Object.keys(comp).length === 0) {
                        continue;
                    }
                    for (var k = 0; k < compName.length; k++) {
                        isSyntaxError = changeLogtypes.indexOf(compName[k]) !== -1 || compName[k] === `raw`;
                        var compKey = comp[compName[k]];
                        var change = Object.keys(compKey);
                        for (var l = 0; l < change.length; l++) {
                            isSyntaxError = changeLogtypes.indexOf(change[l]) === -1 && change[l] !== 'raw';
                        }
                    }
                } else {
                    isSyntaxError = true;
                }
                if (isSyntaxError) {
                    console.log('syntax error in the changelog --------> ' + file);
                    console.log('Component version --------> ' + versionName[j]);
                    process.exit(1);
                }
            }
        }
    }
    done();
});

gulp.task('publish-changelog', function (done) {
    if (process.env.githubSourceBranch !== 'master' && !process.env.githubSourceBranch.startsWith('release/') &&
        !process.env.githubSourceBranch.startsWith('hotfix/')) {
        return;
    }
    var user = 'SyncfusionAutomation';
    var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
    var branch = process.env.githubSourceBranch;
    var origin = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-release-notes.git';
    // checkout ej2-release-notes in eh2-changelog location
    shelljs.exec('git clone ' + origin + ' -b ' + branch + ' ./ej2-changelog');
    var platforms = Object.keys(changelogPath);
    var basePackages = Object.keys(commonPackage);
    if (basePackages.indexOf(global.config.currentPackage) > -1) {
        platforms = [commonPackage[global.config.currentPackage]];
    }
    for (var i = 0; i < platforms.length; i++) {
        if (!fs.existsSync('./ej2-changelog/src/' + platforms[i])) {
            // create the folder path
            shelljs.mkdir('-p', './ej2-changelog/src/' + platforms[i]);
        }
        mergeChangelog(platforms[i]);
    }
    // navigate into ej2-changelog folder
    shelljs.cd('./ej2-changelog');
    // pull the remote changes
    shelljs.exec('git pull', { silent: false });
    // add all new changes in the git
    shelljs.exec('git add .', { silent: false });
    // commit the new changes
    shelljs.exec('git commit -m "' + common.currentPackage + ' release-notes are merged"', { silent: false });
    // push the commited changes to remote
    shelljs.exec('git push -f --set-upstream origin ' + branch + ' --no-verify', { silent: false });
    // navigate to root folder
    shelljs.cd('../');
    // remove ej2-changelog folder
    shelljs.rm('-rf', './ej2-changelog');
    done();
});

function mergeChangelog(platform) {
    var isAspNet = platform === 'aspnetcore' || platform === 'aspnetmvc';
    if (!fs.existsSync(changelogPath.common)) {
        return;
    }
    if (!isAspNet) {
        getChangelog(platform, changelogPath.common);
        if (platform !== 'common') {
            var isThirdPartyExist = fs.existsSync(changelogPath[platform]);
            if (isThirdPartyExist) {
                getChangelog(platform, changelogPath[platform], isThirdPartyExist);
            }
        }
    }
    if (isAspNet && fs.existsSync(changelogPath[platform])) {
        getChangelog(platform, changelogPath[platform]);
    }
}

function getChangelog(platform, mdPath, isThirdParty) {
    // read the changelog file
    var changelog = fs.readFileSync(mdPath, 'utf8');
    // parse the changelog to JSON format
    var changelogJson = md2json.parse(changelog).Changelog;
    // Check whether the previous result is not empty
    if (!changelogJson) { return; }
    var keys = Object.keys(changelogJson);
    for (var i = 0; i < keys.length; i++) {
        var filePath = './ej2-changelog/src/' + platform + '/';
        var fullPath = filePath + keys[i] + '.md';
        if (versios[platform] && keys[i] !== '[Unreleased]' && parseFloat(keys[i]) < versios[platform]) {
            continue;
        }
        if (fs.existsSync(fullPath)) {
            var merged;
            // convert current changelog json to md format
            var currentChangelog = changelogJson[keys[i]];
            // convert existing changelog to json
            var prevChanglog = md2json.parse(fs.readFileSync(fullPath, 'utf8'));
            if (!isThirdParty) {
                // merge the new changes to existing changelog
                merged = Object.assign(prevChanglog, currentChangelog);
            } else {
                // merge the third-party changelog with existing changelog
                merged = mergeThirdPartyChangelog(currentChangelog, prevChanglog);
            }
            // get distict changelog
            removeDuplicateLines(merged);
            // get sorted changelog
            let sortedChangelog = getSortedChangelog(merged, true);
            // convert merged changelog json to md format
            var mergedChangelog = md2json.toMd(sortedChangelog);
            // write the changelog to ej2-release-notes
            fs.writeFileSync(fullPath, mergedChangelog);
        } else {
            // sort the changelogJson and store the output in sortedChangelog
            let sortedChangelog = getSortedChangelog(changelogJson[keys[i]], true);
            // convert sortedChangelog json to md format
            var releaseNotes = md2json.toMd(sortedChangelog);
            // Check releaseNotes is not empty & write the changelog to ej2-release-notes
            if (releaseNotes) { fs.writeFileSync(fullPath, releaseNotes); }
        }
    }
}

function removeDuplicateLines(jsonObj) {
    //  var ikeys = Object.keys(jsonObj);
    for (var curComponent in jsonObj) {
        var curObj = jsonObj[curComponent];
        for (var curProp in curObj) {
            if (curProp === 'raw' || !curObj[curProp].raw) {
                continue;
            }
            var curInput = curObj[curProp].raw.split('\n');
            curObj[curProp].raw = curInput.filter(function (line, index, lines) {
                if (line) {
                    return lines.indexOf(line) === index;
                } else {
                    return true;
                }
            }).join('\n');
        }
    }
}

function getSortedChangelog(jsonObj, isSort) {
    var keys = Object.keys(jsonObj);
    // releaseNotesCategories array has changelog categories to sort the content in proper order
    const releaseNotesCategories = ['bug fixes', 'features', 'new features', 'breaking changes', 'known issues'];
    // the sorting will be done using the releaseNotesCategories array data order precedence 
    keys.sort((a, b) => {
        if (releaseNotesCategories.includes(a.toLowerCase())) {
            return releaseNotesCategories.indexOf(a.toLowerCase()) - releaseNotesCategories.indexOf(b.toLowerCase());
        }
        else {
            return a.localeCompare(b);
        }
    });
    var commonIndex = keys.indexOf('Common');
    if (commonIndex !== -1) {
        keys.splice(commonIndex, 1);
        keys.splice(0, 0, 'Common');
    }
    var sortedChangelog = {};
    for (var i = 0; i < keys.length; i++) {
        if (isSort) {
            sortedChangelog[keys[i]] = getSortedChangelog(jsonObj[keys[i]]);
        } else {
            sortedChangelog[keys[i]] = jsonObj[keys[i]];
        }
    }
    return sortedChangelog;
}

function mergeThirdPartyChangelog(srcObj, destObj) {
    // get current changelog keys
    var compKeys = Object.keys(srcObj);
    for (var i = 0; i < compKeys.length; i++) {
        // compKey will be Common | Button | etc..
        var compKey = compKeys[i];
        // get third-party changelog
        var srcChangelog = srcObj[compKey];
        // get ej2-release-notes changelog
        var destChangelog = destObj[compKey];
        var typeKeys = Object.keys(srcChangelog);
        if (destChangelog) {
            for (var j = 0; j < typeKeys.length; j++) {
                // keyType will be New Features | Bug Fixes | Breaking Changes | Known Issues
                var keyType = typeKeys[j];
                // check ej2-release-notes already have the keyType
                if (destChangelog && destChangelog[keyType] && destChangelog[keyType].raw &&
                    srcChangelog[keyType] && srcChangelog[keyType].raw) {
                    // add third-party changelog with ej2-release-notes changelog
                    destObj[compKey][keyType].raw = srcChangelog[keyType].raw + destChangelog[keyType].raw;
                } else {
                    // create third-party changelog in ej2-release-notes
                    destObj[compKey] = destChangelog ? destChangelog : {};
                    destObj[compKey][keyType] = srcChangelog[keyType];
                }
            }
        } else {
            destObj[compKey] = srcChangelog;
        }
    }
    return destObj;
}
