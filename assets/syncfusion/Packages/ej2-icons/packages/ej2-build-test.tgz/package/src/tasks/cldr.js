var fs = global.fs = global.fs || require('fs');
var gulp = global.gulp = global.gulp || require('gulp');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var glob = global.glob = global.glob || require('glob');
var path = require("path");
var tableify = require('tableify');
var email = require('emailjs');
var extend = require('../utils/common.js').extend;

var npmignore = `/node_modules/
package-lock.json
newcldr
dist
update.json
.npmrc
config.json
gulpfile.js
Jenkinsfile`;

function cldrAllJson(target) {
    var culFiles = glob.sync(`${target}/main/*`);
    console.log('CLDR Culture Files count', culFiles.length);
    culFiles.forEach(culture => {
        var mainData = {};
        var gregorianData = JSON.parse(fs.readFileSync(`./${culture}/ca-gregorian.json`, 'utf8'));
        var islamicData = JSON.parse(fs.readFileSync(`./${culture}/ca-islamic.json`, 'utf8'));
        var currencyData = JSON.parse(fs.readFileSync(`./${culture}/currencies.json`, 'utf8'));
        var numbersData = JSON.parse(fs.readFileSync(`./${culture}/numbers.json`, 'utf8'));
        var timezoneData = JSON.parse(fs.readFileSync(`./${culture}/timeZoneNames.json`, 'utf8'));
        var cldrData = [numbersData, islamicData, gregorianData, currencyData, timezoneData];
        for (var i = 0; i < cldrData.length; i++) {
            var obj = cldrData[i];
            extend(mainData, obj, {}, true);
        }
        fs.writeFileSync(`./${culture}/all.json`, JSON.stringify(mainData, null, 2));
    });
}

function removeVersion(type) {
    var culturePath;
    var ignoreList = ['node_modules/**/*', 'dist/**', 'package.json', 'package-lock.json', 'config.json', 'update.json', 'GitLeaksReport.json'];
    if (type == 'newCldr') {
        culturePath = './newCldr/**/*.json';
        ignoreList;
    } else {
        culturePath = './**/*.json';
        ignoreList.push('newCldr/**');
    }
    var culFiles = glob.sync(culturePath, {
        ignore: ignoreList
    });
    culFiles.forEach(culturePath => {
        var cultureJson = require(fs.realpathSync(`./${culturePath}`));
        if (cultureJson['main']) {
            var cultureName = culturePath.includes('newCldr') ? culturePath.split(path.sep)[2] : culturePath.split(path.sep)[1];
            delete cultureJson['main'][cultureName]['identity'];
        } else {
            delete cultureJson['supplemental']['version'];
        }
        fs.writeFileSync(culturePath, JSON.stringify(cultureJson, null, 2));
    });
}

gulp.task('package-status-report', function (done) {
    shelljs.exec('npm i -g npm-check-updates@16.14.18');
    shelljs.exec('ncu', { silent: true }, function (code, stdout, stderr) {
        if (code !== 0) {
            console.log(`exec error: ${stderr}`);
        } else {
            console.log('stdout: ', stdout);
            if (stdout.includes('Run ncu -u')) {
                fs.writeFileSync('./update.json', JSON.stringify({
                    "newPackageDetected": true, "status": stdout
                }));
                shelljs.exec('ncu -u');
                shelljs.exec('npm install');
                console.log('Package update completed');
            } else {
                fs.writeFileSync('./update.json', JSON.stringify({
                    "newPackageDetected": false, "status": stdout
                }));
                console.log('All packages are up to date');
            }
            shelljs.mkdir("-p", "./newCldr/supplemental");
            shelljs.mkdir("-p", "./newCldr/main");
            generateCldrData('newCldr');
            shelljs.exec('gulp json-compare');
        }
    });
    done();
});

function reportMail(status) {
    var server = new email.SMTPClient({
        user: 'automation@syncfusion.com',
        password: 'mjkbwpxmyzlkrpjq',
        host: 'smtp-mail.outlook.com',
        timeout: 50000,
        tls: { ciphers: 'SSLv3' }
    });
    var tableData;
    if (!status.includes('latest')) {
        // Split content into lines
        const lines = status.split('\n');
        // Filter out empty lines
        const filteredLines = lines.filter(line => line.trim() !== '' && !line.includes('Run ncu -u to upgrade package.json'));
        // Extract package data from each line
        tableData = filteredLines.slice(1).map(line => {
            const [packageName, oldVersion, arrow, newVersion] = line.trim().split(/\s+/);
            return { Package: packageName, 'Old Version': oldVersion, 'New Version': newVersion };
        });
    }
    else {
        tableData = 'All dependencies match the latest package versions.';
    }
    var array = [
        {
            "Repository": 'ej2-cldr-data',
            "Package Status": tableData,
            "Artifact link": `<a href=${process.env.JOB_URL + process.env.BUILD_NUMBER}/artifact/dist/ >${process.env.JOB_URL + process.env.BUILD_NUMBER}/artifact/dist/</a>`
        }
    ];
    var html = tableify(array);
    var to;
    var cc;
    var tempString;
    to = 'mydeensn@syncfusion.com';
    cc = 'balaji.elumalai@syncfusion.com';
    tempString = `Hi Everyone, </br></br> Automation has been initiated to detect updates in the 
    CLDR package from the corresponding repository. Please find the package details below.</br>`;
    var message = {
        from: 'ej2blazortestautomation@syncfusion.com',
        to: to,
        cc: cc,
        subject: `Reg: EJ2 CLDR Package Report`,
        /* jshint ignore:start */
        attachment: [{
            data: '<html><style> table {border-top: 1px solid #000;border-right: 1px solid #000;' +
                'border-collapse: collapse;font-family: sans-serif;margin: 0 auto;}' +
                'td,th {text-align: center;vertical-align: center;border-left: 1px solid #000;' +
                'border-bottom: 1px solid #000;padding: 10px;}' +
                'th, td {padding: 10px;} td.failed {color:red;} td.success {color:green;}' +
                'th{background-color: #007dd1;color: #ffffff;}</style>' +
                tempString + '</br></br> ' + html + '</br></br> ' + 'Regards,</br>EJ2 Core team</html>',
            alternative: true
        }]
        /* jshint ignore:end */
    };
    //send the message and get a callback with an error or details of the message that was sent
    server.send(message, function (err) {
        if (err) {
            console.log('Error:  ', err);
        } else {
            console.log('Validation report send Successfully');
        }
    });
}

gulp.task('json-compare', function (done) {
    shelljs.mkdir("-p", "./dist/htmlVisualizer/supplemental");
    shelljs.mkdir("-p", "./dist/htmlVisualizer/main");
    fs.writeFileSync('./dist/output.json', JSON.stringify({}, null, 2));
    const jsonCompareTemplate = fs.readFileSync(path.join(__dirname, './json-compare.txt'), 'utf8');
    compareJsonFiles('./supplemental/*.json', './dist/htmlVisualizer/supplemental', jsonCompareTemplate, 'supplemental');
    compareJsonFiles('./main/**/*.json', './dist/htmlVisualizer/main', jsonCompareTemplate, 'main');
    done();
});

function compareJsonFiles(sourcePattern, outputDir, template, type) {
    const sourcePaths = glob.sync('./newCldr/' + sourcePattern);
    const targetPaths = glob.sync(sourcePattern);
    const jsonData = fs.readFileSync('./dist/output.json', 'utf8');
    let output = JSON.parse(jsonData);
    Object.assign(output, {
        [type]: {
            "Existing Files count": targetPaths.length,
            "New Files count": sourcePaths.length
        }
    });
    for (let i = 0; i < sourcePaths.length; i++) {
        try {
            let sourceJson = require(fs.realpathSync(sourcePaths[i]));
            let targetJson = fs.existsSync('./' + sourcePaths[i].split('newCldr')[1]) ? require(fs.realpathSync('./' + sourcePaths[i].split('newCldr')[1])) : {};
            let jsonCompareHtml = template.replace('$left', JSON.stringify(targetJson));
            jsonCompareHtml = jsonCompareHtml.replace('$right', JSON.stringify(sourceJson));
            let outputPath = '';
            if (type === 'main') {
                outputPath = path.join(outputDir, sourcePaths[i].split(path.sep)[2], `${path.basename(sourcePaths[i]).replace('.json', '')}.html`);
                shelljs.mkdir("-p", path.join(outputDir, sourcePaths[i].split(path.sep)[2]));
            } else {
                outputPath = path.join(outputDir, `${path.basename(sourcePaths[i]).replace('.json', '')}.html`);
            }
            fs.writeFileSync(outputPath, jsonCompareHtml);
        } catch (error) {
            console.log(`Error: ${error}`);
            Object.assign(output, { "Error": error });
        }
    }
    fs.writeFileSync('./dist/output.json', JSON.stringify(output, null, 2));
}

gulp.task('cldr-build', function (done) {
    shelljs.exec('gulp package-status-report');
    generateCldrData('.');
    done();
});

function generateCldrData(destination) {
    shelljs.cp('-r', './node_modules/cldr-core/supplemental/numberingSystems.json', `${destination}/supplemental`);
    shelljs.cp('-r', './node_modules/cldr-core/supplemental/weekData.json', `${destination}/supplemental`);
    shelljs.cp('-r', './node_modules/cldr-core/supplemental/currencyData.json', `${destination}/supplemental`);
    var files = [];
    var cldrPack = ['cldr-numbers-modern', 'cldr-dates-modern', 'cldr-cal-islamic-modern'];
    cldrPack.forEach(pack => {
        const filePath = pack == 'cldr-cal-islamic-modern' ? `./node_modules/${pack}/main/**/ca-islamic.json` : `./node_modules/${pack}/main/**/*.json`;
        const matchingFiles = glob.sync(filePath, {
            ignore: [
                `node_modules/${pack}/main/**/ca-generic.json`,
                `node_modules/${pack}/main/**/dateFields.json`
            ]
        });
        files.push(...matchingFiles);
    });
    files.forEach(file => {
        var copyPath = path.join(`${destination}/main/`, file.split('main' + path.sep)[1].split(path.sep)[0]);
        shelljs.mkdir('-p', copyPath);
        shelljs.cp('-r', file, copyPath);
    });
    removeVersion(destination);
    if (destination === 'newCldr') {
        cldrAllJson('./newCldr');
    } else {
        cldrAllJson('.');
    }
}

gulp.task('cldr-publish', function (done) {
    var packageDetail = JSON.parse(fs.readFileSync('./update.json', 'utf8'));
    console.log('New Package detected: ', packageDetail.newPackageDetected);
    if (process.env.branchName === 'development' && packageDetail.newPackageDetected) {
        //github commit
        var user = 'SyncfusionAutomation';
        var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
        shelljs.exec('git add .');
        shelljs.exec(`git commit -m "ej2-000: package Updated"`);
        shelljs.exec(`git push https://${user}:${token}@gitea.syncfusion.com/essential-studio/ej2-cldr-data.git`);
        // nexus publish
        shelljs.exec('gulp nexus-publish-files');
        // npmjs publish
        console.log('npmjs token: ', process.env.NPM_AUTH_TOKEN);
        var isPublic = false;
        if (isPublic) {
            var npmPath = `registry=https://registry.npmjs.org/
            //registry.npmjs.org/:_authToken=` + process.env.NPM_AUTH_TOKEN;
            fs.readFileSync('./.npmrc', npmPath, 'utf8');
            var JsonPackage = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
            var packVersion = shelljs.exec('npm show @syncfusion/ej2 version').stdout;
            JsonPackage.version = packVersion;
            fs.writeFileSync('./package.json', JSON.stringify(JsonPackage));
            fs.writeFileSync('./.npmignore', npmignore, 'utf8');
            var publish = shelljs.exec('npm publish --access=public', { silent: false });
            var status = publish.code === 0 ? 'published' : 'failed';
            console.log('Syncfusion CLDR package was ' + status + ' on npmjs with' + packVersion);
        }
    }
    if (process.env.JOB_URL) {
        reportMail(packageDetail.status);
    }
    done();
});

gulp.task('nexus-publish-files', function (done) {
    var npmrcBranch = `ej2-development`;
    var npmrcFile = `registry=https://registry.npmjs.org/
        @syncfusion:registry=https://nexus.syncfusioninternal.com/repository/${npmrcBranch}
        //nexus.syncfusioninternal.com/repository/${npmrcBranch}/:username=ej2
        //nexus.syncfusioninternal.com/repository/${npmrcBranch}/:_password=ZWoyY29yZW5wbQ==
        //nexus.syncfusioninternal.com/repository/${npmrcBranch}/:email=pipeline@syncfusion.com
        //nexus.syncfusioninternal.com/repository/${npmrcBranch}/:always-auth=true`;
    fs.writeFileSync('./.npmrc', npmrcFile, 'utf8');
    var gitignore = fs.readFileSync('./.gitignore', 'utf8');
    var gitignoreData = `
    .npmrc
    config.json
    gulpfile.js
    Jenkinsfile`;
    gitignore += gitignoreData;
    fs.writeFileSync('./.gitignore', gitignore, 'utf8');
    shelljs.exec('npm publish --access=public')
    done();
});