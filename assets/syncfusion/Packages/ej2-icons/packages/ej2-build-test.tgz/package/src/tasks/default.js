'use strict';

var gulp = global.gulp = global.gulp || require('gulp');

/**
 * Lint and build the TS file
 */
gulp.task('default', function (callback) {
    var runSequence = require('gulp4-run-sequence');
    return runSequence(
        'lint',
        'build',
        callback
    );
});
