'use strict';

var modList, classList = {},
    interfaceList = [],
    classProperties = {},
    interfaceProperties = {},
    typeAliases = {},
    enumAliases = {};

/**
 * Property Reader
 */
class PropertyReader {

    constructor(json) {
        return this.render(json.children);
    }

    readClasses(cntMod) {
        for (var j = 0; j < cntMod.length; j++) {
            var curItem = cntMod[j];
            if (curItem.kindString === 'Class') {
                classList[curItem.name] = curItem;
                classProperties[curItem.name] = { _allProperties: [], _allEvents: [], _propComments: {}, _eventComments: {},
                 _propObjects: {}, _propShortComments: {}, _eventShortComments: {} };
                if (curItem.children && curItem.children.length) {
                    this.readDecoratorProperties(curItem.children, classProperties[curItem.name]);
                }
            }
            if (curItem.kindString === 'Interface') {
                interfaceList.push(curItem);
                interfaceProperties[curItem.name] = curItem;
            }
            if (curItem.kindString === 'Type alias') {
                typeAliases[curItem.name] = curItem;
                classProperties[curItem.name] = { _allProperties: [], _allEvents: [], _propComments: {}, _eventComments: {},
                 _propObjects: {}, _propShortComments: {}, _eventShortComments: {} };
            }
            if(curItem.kindString === 'Enumeration'){
                enumAliases[curItem.name] = curItem;
                classProperties[curItem.name] = { _allProperties: [], _allEvents: [], _propComments: {}, _eventComments: {},
                 _propObjects: {}, _propShortComments: {}, _eventShortComments: {} };
            }
        }
        return classList;
    }

    readDecoratorProperties(properties, desObj) {
        for (var k = 0; k < properties.length; k++) {
            var prop = properties[k];
            var comment = {};
            if ((prop.kindString === 'Property' || prop.kindString === 'Event') &&  prop.decorators) {
                comment = this.getComments(prop.comment);
            }
            if (prop.kindString === 'Property' && prop.decorators) {
                var type = prop.decorators[0].name.toLowerCase();
                desObj[prop.name] = { type: { name: type }, obj: prop, comment: comment.comment, shortComment: comment.shortComment };
            }
            if (prop.kindString === 'Event' && prop.decorators) {
                var eType = prop.decorators[0].name.toLowerCase();
                desObj[prop.name] = { type: { name: eType }, obj: prop, comment: comment.comment, shortComment: comment.shortComment };
            }
        }
    }

    isCollectionDecorator(prop) {
        if (prop.kindString === 'Property' && prop.decorators) {
            return prop.decorators[0].name === 'Collection';
        } else {
            return false;
        }

    }

    createInputArray() {
        var keys = Object.keys(classProperties);
        var comment = {};
        for (var i = 0; i < keys.length; i++) {
            var prop = classProperties[keys[i]];
            var subKeys = Object.keys(prop);
            
            var interFaceProps = interfaceProperties[keys[i] + 'Model'];
            var alais = enumAliases[keys[i]] || typeAliases[keys[i]];
            if (interFaceProps) {
                var modelProps = interFaceProps.children;
                for (var k = 0; modelProps && k < modelProps.length; k++) {
                    var curModel = modelProps[k];
                    comment = this.getComments(curModel.comment);
                    if (curModel.type && curModel.type.name === 'EmitType') {
                        prop._allEvents.push(curModel.name);
                        prop._eventComments[curModel.name] = comment.comment;
                        prop._eventShortComments[curModel.name] = comment.shortComment;
                        prop._propObjects[curModel.name] = curModel;

                    } else {
                        prop._allProperties.push(curModel.name);
                        prop._propComments[curModel.name] = comment.comment;
                        prop._propShortComments[curModel.name] = comment.shortComment;
                        prop._propObjects[curModel.name] = curModel;
                    }
                }
            }
            
            else if(alais && alais.comment && alais.comment.shortText){
                comment = this.getComments(alais.comment);
                prop._propShortComments[alais.name] = comment.shortComment; 
            }
            for (var j = 0; j < subKeys.length; j++) {
                var subKey = subKeys[j];
                var curProp = prop[subKey].obj;
                if (!(/(_)/g).test(subKey)) {
                    prop[subKey].aspProperties = this.aspParseInputArray(curProp, prop[subKey].aspProperties, '', prop[subKey]);
                }
            }

        }
    }

    getComments(comment) {
        if (!comment) { return { comment:'', shortComment: ''}; }
        var shortComment = '';
        var result = '    /** \n     * ';
        comment.shortText = comment.shortText.replace(/```([^]+)```/g, '');
        var commentArray = comment.shortText.split('\n');
        shortComment = commentArray.join('\n/// ').replace(/(\*|<[^]*>)/g, '') + '\n';
        result = result + commentArray.join(' \n     * ') + '\n';
        if (comment.text) {
            var commentTextArray = comment.text.split('\n');
            result = result + '     * \n     * ' + commentTextArray.join('\n     *') + '     \n';
        }
        for (var i = 0; comment.tags && i < comment.tags.length; i++) {
            var curTag = comment.tags[i];
            result = result + '     * @' + curTag.tag + ' ' + curTag.text.replace('\n', '') + '\n';
        }
        result = result + '     */';
        return { comment: result, shortComment: '/// <summary>\n/// ' + shortComment + '/// </summary>' };
    }

    aspParseInputArray(prop, resultAr, prevObj, classObj) {
        var result = resultAr;
        var type = '';
        if (this.isPropArray(prop.type)) {
            type = this.getReferenceType([prop.type]);
        } else if (this.isUnionArray(prop.type.types)) {
            type = this.getReferenceType(prop.type.types);
        }
        if (type !== '') {
            var obj = this.getTypeObject(type);
            if (obj && prevObj !== obj && obj.children) {
                result = this.readProperties(obj.children, [], obj, classObj);
            }
        }
        return result;
    }

    isUnionArray(types) {
        for (var i = 0; types && i < types.length; i++) {
            var type = types[i];
            if (type.isArray || type.type === 'array') {
                return true;
            }
        }
        return false;
    }

    isPropArray(type) {
        if (type.isArray || type.type === 'array') {
            return true;
        }
        return false;
    }

    pushToArray(resultAr, val, ignorePush) {
        if (ignorePush !== true) {
            resultAr.push(val);
        }
    }

    readProperties(properties, desObj, prevObj, classObj) {
        for (var k = 0; k < properties.length; k++) {
            var prop = properties[k];
            var comment = {};
            if (prop.kindString === 'Property') {
                if (this.isPropArray(prop.type) || this.isUnionArray(prop.type.types)) {
                    desObj[prop.name] = this.aspParseInputArray(prop, desObj, prevObj, {});
                }
                comment = this.getComments(prop.comment);
                if (prop.type.type === 'instrinct') {
                    classObj[prop.name] = { type: prop.type.name, comment: comment.comment, shortComment: comment.shortComment };
                } else {
                    classObj[prop.name] = { type: 'any', comment: comment.comment, shortComment: comment.shortComment };
                }
                desObj.push(prop.name);
            }
        }
        return desObj;
    }

    getTypeObject(type) {
        return interfaceProperties[type];
    }

    getReferenceType(types) {
        if (types) {
            for (var i = 0; i < types.length; i++) {
                var type = types[i];

                if (type.type === 'array' && type.elementType.type === 'reference' && (/Model/).test(type.elementType.name)) {
                    return type.elementType.name;
                }
            }
        }

        return '';
    }

    render(mods) {
        modList = mods;
        for (var i = 0; i < mods.length; i++) {
            if (modList[i].children) {
                this.readClasses(modList[i].children);
            }
        }
        this.createInputArray();
        classProperties.__this = this;
        classProperties.interfaces = interfaceProperties;
        classProperties.allClasses = classList;
        classProperties.typeAliases = typeAliases;
        classProperties.enumAliases = enumAliases;
        return classProperties;
    }

}

module.exports = function(json) {
    return new PropertyReader(json);
};