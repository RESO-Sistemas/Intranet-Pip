'use strict';

var fs = global.fs = global.fs || require('fs');
var gulp = global.gulp = global.gulp || require('gulp');
global.config = global.config || require('../utils/common.js');


var regexp = global.config.regexp;

/**
 * Git commit message validator
 */
gulp.task('commit-message', function (done) {
    // Get commit message from git commit edit message file   
    var msg = fs.readFileSync('./.git/COMMIT_EDITMSG', 'utf8');
    msg = msg.split('\n').join(' ');
    if (!RegExp(regexp.COMMIT_TYPES).test(msg)) {
        var error = '\n The template: \n <type>(<jira-id>): <summary> \n\n Example: \n bug(EJ2-01): Typescript implemented \n\n';
        var types = 'The list of supported commit types are: \n 1. bug \n 2. config \n 3. documentation \n 4. feature \n 5. sample \n';
        console.log(error + types);
        done();
        // process.exit(1);
    }
    else {
        // Allow git commit
        process.exit(0);
    }
});
