'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
var shelljs = require('shelljs');
// var request = require('request');
var fs = require('fs');
var javaScriptObfuscator = require('javascript-obfuscator');
/* jshint ignore:start */
const https = require('https');
const fetch = require('node-fetch');
const httpsAgent = new https.Agent({
    rejectUnauthorized: false,
});


/**
* ci report
*/
gulp.task('ci-report', async function () {

    try {
        //Handled the component CI data post process
        console.log('Post data Process started');
        console.log('status', process.argv[4]);
        var packConfig = require('./pack.json');
        var branch = process.env.githubSourceBranch || 'development';
        var testReport;
        if (fs.existsSync('./coverage/testReport.json')) {
            testReport = require(fs.realpathSync('./coverage/testReport.json'));
        }
        const data = {
            Repository: common.currentRepo,
            Branch: branch,
            jobLink: process.env.JOB_URL + process.env.BUILD_NUMBER,
            Status: process.argv[4],
            lastRunTime: new Date().toISOString(),
            ProductOwner: packConfig[common.currentPackage].productOwner,
            coverageReport: testReport ? testReport.coverage.toString() : '',
            result: testReport ? JSON.stringify(testReport.testResults) : ''
        };
        console.log('CI-report', data);

        const response = await fetch('https://sfblazor.azurewebsites.net/status/sources/post', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data),
            agent: httpsAgent
        });
        const responseData = await response.json();
        console.log('Posted Data: ', responseData);
        console.log('Post data Process completed');
    } catch (error) {
        console.error('Error in API post process: ', error);
    }
    // var jenkinUrl = process.env.JOB_URL.replace('jenkins.syncfusion.com',
    //     'SyncfusionAutomation' + ':' + process.env.JENKINS_GITLAB_TOKEN + '@jenkins.syncfusion.com');
    // shelljs.exec('curl GET ' + jenkinUrl + '/' + parseInt(process.env.BUILD_NUMBER) + '/api/json', { silent: true },
    //     function (err, result) {
    //         var res = JSON.parse(result);
    //         if (res.changeSets.length) {
    //             var causesDetails = [];
    //             var lastCommitDetails = [];
    //             for (var k = 0; k < res.changeSets.length; k++) {
    //                 if (res.changeSets[k].items.length) {
    //                     for (var i = 0; i < res.changeSets[k].items.length; i++) {
    //                         var index = getIndex(causesDetails, res.changeSets[k].items[i].author.fullName);
    //                         if (!causesDetails.length || index === -1) {
    //                             causesDetails.push({
    //                                 UserName: res.changeSets[k].items[i].author.fullName,
    //                                 UserID: res.changeSets[k].items[i].authorEmail
    //                             });
    //                             lastCommitDetails.push({
    //                                 author: res.changeSets[k].items[i].author.fullName,
    //                                 userID: res.changeSets[k].items[i].authorEmail,
    //                                 comments: res.changeSets[k].items[i].comment,
    //                                 files: res.changeSets[k].items[i].affectedPaths
    //                             });
    //                         }
    //                     }
    //                 }
    //             }
    //             var data = {
    //                 fullDisplayName: res.fullDisplayName,
    //                 'BuildType': 'Component',
    //                 'Timestamp': res.timestamp,
    //                 'Duration': res.duration,
    //                 Url: process.env.JOB_URL + res.number,
    //                 Number: res.number,
    //                 Reason: 'Build ' + process.argv[4],
    //                 Result: process.argv[4],
    //                 causes: causesDetails,
    //                 LastCommit: lastCommitDetails,
    //             };
    //             console.log('CI Report Data : ......\n\n' + JSON.stringify(data) + '\n\n........\n');
    //             request({
    //                 url: 'https://ej2services.syncfusion.com/cicentral/api/getCIHealthReport',
    //                 method: 'POST',
    //                 json: true,
    //                 body: data,
    //                 headers: {
    //                     'authorization': 'ej2centrailzedstatus',
    //                     'content-type': 'application/json'
    //                 }
    //             }, function () {
    //                 done();
    //             });
    //         }
    //         else {
    //             done();
    //         }
    //     }
    // );
});
/* jshint ignore:end */

// function getIndex(causesDetails, name) {
//     var userNameIndex = causesDetails.findIndex(x => x.UserName === name);
//     return userNameIndex;
// }


/** 
 * pre-push hook gulp tasks
 */
gulp.task('pre-push', function (done) {
    runSequence('scripts',  'coverage', 'spell-check-ci', 'api-diff', done);
});

/** 
 * pre-commit hook gulp tasks
 */
gulp.task('pre-commit', function (done) {
    runSequence('lint', done);
});

/** 
 * commit-msg hook gulp tasks
 */
gulp.task('commit-msg', function (done) {
    runSequence('commit-message', done);
});

/** 
 * ci-compile gulp tasks
 */
gulp.task('ci-compile', function (done) {
    runSequence( 'license-version', 'update-themes', 'copy-themes', 'add-config', 'styles-all', done);
});

// Obfuscate the bin license file.
gulp.task('obfuscate', function (done) {
    if (common.currentRepo === 'ej2-base-library' && fs.existsSync('./bin/syncfusion-license.js')) {
        var data = fs.readFileSync('./bin/syncfusion-license.js', 'UTF8');
        var obfuscateData = javaScriptObfuscator.obfuscate(data);
        fs.writeFileSync('./bin/syncfusion-license.js', obfuscateData.getObfuscatedCode());
    }
    done();
});

// License version update

gulp.task('license-version', function (done) {
    var packName = JSON.parse(fs.readFileSync('./package.json')).name;
    var branchName = process.env.githubSourceBranch || 'development';
    if (packName === '@syncfusion/ej2-base') {
        var licValidate = fs.readFileSync('./src/validate-lic.ts', 'utf8');
        var valLicense = fs.readFileSync('./bin/syncfusion-license.js', 'utf8');
        // here we have added previous version internal testing purpose
        if (process.env.RELEASE_VERSION) {
            licValidate = licValidate.replace('{syncfusionReleaseversion}', process.env.RELEASE_VERSION.substring(0, 2));
            valLicense = valLicense.replace('{syncfusionReleaseversion}', process.env.RELEASE_VERSION.substring(0, 2));
            licValidate = licValidate.replace(/{versionencodedData}/g, Buffer.from(process.env.RELEASE_VERSION.substring(0, 2)).toString('base64'));

        } else if (/hotfix\/|release\//.test(branchName)) {
            licValidate = licValidate.replace('{syncfusionReleaseversion}', branchName.split('/')[1].substring(0, 2));
            valLicense = valLicense.replace('{syncfusionReleaseversion}', branchName.split('/')[1].substring(0, 2));
            licValidate = licValidate.replace(/{versionencodedData}/g, Buffer.from(branchName.split('/')[1].substring(0, 2)).toString('base64'));
        } else if (branchName === 'development') {
            licValidate = licValidate.replace('{syncfusionReleaseversion}', '29');
            valLicense = valLicense.replace('{syncfusionReleaseversion}', '29');
            licValidate = licValidate.replace(/{versionencodedData}/g, Buffer.from('29').toString('base64'));
        }
        fs.writeFileSync('./src/validate-lic.ts', licValidate);
        fs.writeFileSync('./bin/syncfusion-license.js', valLicense);
    }
    done();
});

/** 
 * ci-test gulp tasks
 */
gulp.task('ci-test', function (done) {
    // shelljs.exec('gulp css-validation');
    // build task is added for compiling accessibility samples to generate accessibility report in ci.
    runSequence('code-leaks-analysis', 'css-validation', 'lint', 'memoryLeak-detect', 'pre-push', done);
});

/** 
 * list of release tasks
 */
gulp.task('release', function (done) {
    runSequence('release-scripts', 'umd-deploy', done);
});

/** 
 * ci-publish gulp tasks
 */
gulp.task('ci-publish', function (done) {
    var publish = common.isMasterBranch || common.isReleaseBranch || common.isHotfixBranch ? 'publish-production' : 'publish';
    var registry;
    if (common.isRemoteServer) {
        registry = common.isMasterBranch ? 'production-registry' : 'dev-registry';
        registry = common.isReleaseBranch ? 'release-registry' : registry;
        registry = common.isHotfixBranch ? 'hotfix-registry' : registry;
    } else {
        registry = common.isMasterBranch ? 'local-production-registry' : 'local-dev-registry';
    }
    runSequence('release', 'getChangelog', 'publish-github-source', publish, registry, 'publish-ej2', 'publish-resources', 'publish-typedoc', 'publish-api', done);

});

var user = 'SyncfusionAutomation';
var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;

// trigger EJ2 repo
gulp.task('trigger-ci', function (done) {
    /* jshint ignore:start */
    console.log('started');
    var jenkinsapi = require('jenkins-api');
    var jenkins = jenkinsapi.init(`https://555412e6-467a-46e4-b2e6-65b9a24edcd1:1162cf7d05b5fba7135d3c41e8eb0b321c@ci.syncfusion.com`, { strictSSL: false });
    var branch = process.env.githubSourceBranch || 'development';
    var ciLink = `ES/job/ej2`;
    var date = new Date();
    var CommitId = shelljs.exec(`git ls-remote https://${user}:${token}@gitea.syncfusion.com/essential-studio/ej2.git ${branch}`, { silent: true }).stdout;
    var params = {
        githubSourceRepoHttpUrl: `https://gitea.syncfusion.com/essential-studio/ej2`,
        CommitId: CommitId.split('\t')[0],
        githubSourceBranch: branch,
        githubTargetBranch: branch
    }
    console.log('triggering CI for branch: ' + branch);
    if (date.getMinutes() > 35) {
        // jenkins.last_build_info(ciLink, {}, function (err, data) {
        //     if (err) { return console.log(err); }
        //     if (data.result !== null) {
        console.log('params', params);
        jenkins.build_with_params(ciLink, params, function (err, data) {
            if (err) { return console.log(err); }
            console.log(data);
        });
        //}
        // });
        ciLink = `ES/job/ej2-angular-template`;
        var CommitId = shelljs.exec(`git ls-remote https://${user}:${token}@gitea.syncfusion.com/essential-studio/ej2-angular-template.git ${branch}`, { silent: true }).stdout;
        var params = {
            githubSourceRepoHttpUrl: `https://gitea.syncfusion.com/essential-studio/ej2-angular-template`,
            CommitId: CommitId.split('\t')[0],
            githubSourceBranch: branch,
            githubTargetBranch: branch
        }
        console.log('params', params);
        jenkins.build_with_params(ciLink, params, function (err, data) {
            if (err) { return console.log(err); }
            console.log(data);
        });
        var sbPlatforms = ['ej2-samples', 'ej2-javascript-samples', 'ej2-angular-samples', 'ej2-react-samples', 'ej2-vue-samples'];
        for (var i = 0; i < sbPlatforms.length; i++) {
            ciLink = `ES/job/${sbPlatforms[i]}`;
            var CommitId = shelljs.exec(`git ls-remote https://${user}:${token}@gitea.syncfusion.com/essential-studio/${sbPlatforms[i]}.git ${branch}`, { silent: true }).stdout;
            var params = {
                githubSourceRepoHttpUrl: `https://gitea.syncfusion.com/essential-studio/${sbPlatforms[i]}`,
                CommitId: CommitId.split('\t')[0],
                githubSourceBranch: branch,
                githubTargetBranch: branch
            }
            console.log('params', params);
            jenkins.build_with_params(ciLink, params, function (err, data) {
                if (err) { return console.log(err); }
                console.log(data);
            });
        }

    }
    /* jshint ignore:end */
    done();
});

/** 
 * ci-build-publish gulp tasks
 */
gulp.task('ci-build-publish', function (done) {
    if (common.isMasterBranch || common.isReleaseBranch || common.isHotfixBranch) {
        gulp.series('publish-production')();
    } else {
        gulp.series('publish')();
    }
    done();
});

gulp.task('complete-build', function (done) {
    var rollUp = 'node --max-old-space-size=8192 node_modules/gulp/bin/gulp.js';
    var buildScripts = 'gulp scripts && gulp ci-compile && gulp es-scripts && gulp esm-scripts && ' +
        'gulp umd-scripts && gulp global-scripts && gulp rm-temp && gulp npmignore && gulp license';

    if (!fs.existsSync('./src') && fs.existsSync('./styles')) {
        buildScripts = 'gulp ci-compile && gulp rm-temp && gulp npmignore && gulp license';
    }
    if (common.currentPackage === 'ej2') {
        buildScripts = 'gulp build && gulp ej2-js && gulp ship-ej2-es5 && gulp npmignore';
    }
    if (common.currentPackage === 'ej2-angular-base') {
        buildScripts = 'gulp schematics-build && gulp scripts && gulp ci-compile && gulp es-scripts && ' +
            rollUp + ' esm-scripts umd-scripts global-scripts && gulp rm-temp && gulp npmignore && gulp license';
    }
    var completeBuild = shelljs.exec(buildScripts, { silent: false });
    if (completeBuild.code !== 0) {
        process.exit(1);
    }
    done();
});

gulp.task('angular-complete-build', function (done) {
    var angularScripts = 'gulp angular-root-file && npm run scripts && gulp aot-scripts && gulp styles-all';
    var angularCompleteBuild = shelljs.exec(angularScripts, { silent: false });
    if (angularCompleteBuild.code !== 0) {
        process.exit(1);
    }
    done();
});

gulp.task('react-complete-build', function (done) {
    var reactScripts = 'gulp generate-root-files && gulp build ci-compile && gulp es5-scripts && ' +
        'gulp esm5-scripts && gulp umd-scripts && gulp rm-temp';
    var reactCompleteBuild = shelljs.exec(reactScripts, { silent: false });
    if (reactCompleteBuild.code !== 0) {
        process.exit(1);
    }
    done();
});

gulp.task('vue-complete-build', function (done) {
    var vueScripts = 'gulp build && gulp ci-compile && gulp es5-scripts && gulp esm5-scripts && gulp umd-scripts && gulp rm-temp';
    var vueCompleteBuild = shelljs.exec(vueScripts, { silent: false });
    if (vueCompleteBuild.code !== 0) {
        process.exit(1);
    }
    done();
});

gulp.task('build-output', function (done) {
    var fs = require('fs');
    var config = JSON.parse(fs.readFileSync('./config.json'));
    var samples = { 'typescript': 'TypeScript', 'javascript': 'JavaScript', 'angular': 'Angular', 'react': 'React', 'vue': 'Vue' };
    var configSrc = JSON.parse(fs.readFileSync(__dirname + '/../../config.json'));
    var publishSample = configSrc.publishSamples;
    gulp.src(publishSample)
        .pipe(gulp.dest(samples[config.platform]))
        .on('end', done);
});

gulp.task('failure-mail', function (done) {
    /* jshint ignore:start */
    var tableify = require('tableify');
    var { SMTPClient } = require('emailjs');
    var packJosn = require('./../../../../../package.json');
    var packConfig = require('./pack.json');
    var componentName = packConfig[packJosn.name.replace('@syncfusion/', '')].name;
    var contactMail = packConfig[packJosn.name.replace('@syncfusion/', '')].mail;
    var branchName = process.env.githubSourceBranch || 'development';
    var array = [
        {
            "Component": componentName,
            "Status": "Failure",
            "Jenkins link": "<a href='https://ej2-jenkins.syncfusion.com/job/EJ2/job/" + componentName + "/job/development/'>https://ej2-jenkins.syncfusion.com/job/EJ2/job/" + componentName + "/job/" + branchName.replace('/', '%252F') + "/" + "</a>",
            "failure": "{{reason}}"

        }
    ];
    var html = tableify(array);
    html = html.replace(`class="string">Failure`, `class="string failed">Failure`);
    var errorLog = '';
    if (fs.existsSync('./gulp_error.log')) {
        errorLog = fs.readFileSync('./gulp_error.log', 'utf8')
    } else {
        errorLog = 'Unknown reason';
    }
    html = html.replace('{{reason}}', errorLog);
    console.log('error log---->\n' + errorLog);
    var server = new SMTPClient({
        user: 'ej2blazortestautomation@syncfusion.com',
        password: 'mjkbwpxmyzlkrpjq',
        host: 'smtp-mail.outlook.com',
        timeout: 50000,
        tls: { ciphers: 'SSLv3' }
    });
    var to;
    var cc;
    var tempString;

    to = contactMail;
    cc = 'sivakumarr@syncfusion.com,sumankumarg@syncfusion.com,mydeensn@syncfusion.com,ej2@syncfusion.com,ej2core@syncfusion.com';
    tempString = `Hi <a href="mailto:${to}" style="background-color:#DCDCDC;text-decoration:none;color:#2F4F4F">@${to}</a> </br></br>` +
        `CI failed for ${componentName} from the ${branchName.replace('/', '%252F')} branch, Could please check and resolve ASAP.</br>`;

    var message = {
        from: 'ej2blazortestautomation@syncfusion.com',
        to: to,
        cc: cc,
        subject: `Reg: Components CI failure`,
        attachment: [{
            data: '<html><style> table {border-top: 1px solid #000;border-right: 1px solid #000;' +
                'border-collapse: collapse;font-family: sans-serif;margin: 0 auto;}' +
                'td,th {text-align: center;vertical-align: center;border-left: 1px solid #000;' +
                'border-bottom: 1px solid #000;padding: 10px;}' +
                'th, td {padding: 10px;} td.failed {color:red;} td.success {color:green;}' +
                'th{background-color: #007dd1;color: #ffffff;}</style>' +
                tempString +
                '</br>Please refer the failure details below </br></br>' + html + '</br></br> ' +
                `<a href='https://syncfusion.sharepoint.com/sites/EJ2CoreJavaScript/_layouts/15/Doc.aspx?sourcedoc={35aa13a8-0261-424b-9306-fbd1a8e7021c}&action=edit&wd=target%28Previous%20Releases%2FVolume%202%202022.one%7C0fd65db4-c4ca-4297-8942-164f6dd8d569%2FComponent%20CI%20failures%7C0525fdba-94fc-440a-9295-b9c98fffda71%2F%29&wdorigin=NavigationUrl'>Guidelines to resolve the issue</a>` + '</br></br> ' +
                'Regards,</br>EJ2 Core team</html>',
            alternative: true
        }]
    }
    // send the message and get a callback with an error or details of the message that was sent
    server.send(message, function (err) {
        if (err) {
            console.log('Error:  ', err);
        } else {
            console.log('Test report send Successfully');
        }
    });
    done();
    /* jshint ignore:end */
});
