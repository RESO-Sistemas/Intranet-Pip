'use strict';
 
var through, packJson, toInitCap, toInitLower, propList, toPascalCase, namespaceToVariable;
var fs = global.fs = global.fs || require('fs');
var shelljs = global.shelljs || require('shelljs');
var glob = require('glob');
var selectors = [];
 
/**
 * Angular source generator class
 */
class NGSourceGen {
 
    constructor(json, propCollection, pJson, done, srcPath) {
        this.allIndex = [];
        this.allComponents = [];
        this.allDIModules = [];
        through = global.through || require('through2');
        packJson = pJson;
        propList = propCollection;
        this.srcPath = srcPath || './third-party/angular/src/';
        toInitCap = function(str) {
            return str.replace(/\w\S*/g, function(txt) {
                return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
            });
        };
        toPascalCase = function(str) {
            return str.replace(/\w\S*/g, function(txt) {
                return txt.charAt(0).toUpperCase() + txt.substr(1);
            });
        };
        toInitLower = function(str) {
            return str.replace(/\w\S*/g, function(txt) {
                return txt.charAt(0).toLowerCase() + txt.substr(1);
            });
        };
        namespaceToVariable = function(str) {
            if (/\./g.test(str)) {
                return toInitLower(str.split('.').map(function(val) {
                    return val[0].toUpperCase() + val.substr(1);
                }).join(''));
            } else {
                return toInitLower(str);
            }
        };
        if (json) {
            this.render(json, done);
            // var tagChange = fs.readFileSync('./third-party/angular/postinstall/tagchange.js', 'utf8');
            // tagChange = tagChange.replace(`// selectors`,`var selectors = ['`+ selectors.toString().replace(/\,/g,`','`) +`'];`);
            // fs.writeFileSync('./third-party/angular/postinstall/tagchange.js', tagChange, 'utf8');
        }
        return this;
    }
    filter(value){
        return value.filter((content,index)=>{
            return  value.indexOf(content) === index;
         });
    }
    render(json, done) {
        /* jshint ignore:start */
        this.currentBaseName = json.name;
        /* jshint ignore:end */
        for (var i = 0; i < json.components.length; i++) {
            var comp = json.components[i];
            if (comp.isBlazorOnly) {
                continue;
            }
            if (comp.type) {
                var cnt = fs.readFileSync(__dirname + '/' + comp.type + '-comp.template').toString();
                var dirName = comp.directoryName || '';
                var compColl = {
                    allComponents: [],
                    compIndexList: [],
                    allMods: [],
                    diComponents: [],
                    diService: []
                };
                if(comp.baseClass === 'Chart') {
                    cnt = cnt.replace(/'',\s+([^.]*).\s*changeDetection(.*)/g,`'',`);
                }
                var fileName = comp.baseClass.toLowerCase() + '.component.ts';
                compColl.allComponents.push(comp.baseClass + 'Component');
                cnt = this.generateComponent(cnt, comp, compColl);
                var diServices = '';
                if (compColl.diComponents.length) {
                    diServices = ', ' + compColl.diComponents.join(', ');
                }
                compColl.compIndexList.push('export { ' + comp.baseClass + 'Component' + '} from \'./{{dir}}' +
                    fileName.replace('.ts', '') + '\';');
                compColl.allMods.push('import { ' + comp.baseClass + 'Component' + ' } from \'' +
                    './' + fileName.replace('.ts', '') + '\'');
                this.writeFile(this.srcPath + dirName + '/' + fileName, cnt);
                if (dirName) {
                    this.generateModule(compColl, comp.baseClass, dirName + '/');
                    this.writeFile(this.srcPath + dirName + '/' + 'index.ts', this.filter(compColl.compIndexList).join('\n').replace(/{{dir}}/g, ''));
                    this.allIndex.push(this.filter(compColl.compIndexList).join('\n').replace(/{{dir}}/g, dirName + '/'));
                } else {
                    this.generateModule(compColl, comp.baseClass, '');
                    this.allIndex = this.allIndex.concat(compColl.compIndexList);
                    this.allComponents = this.allComponents.concat(compColl.allComponents);
                }
            } else {
                console.error('Template type is not added for component ==> ' + comp.baseClass);
            }
        }
        this.includeStaticFiles();
        this.allIndex.push('export * from \'' + packJson.name + '\';');
        this.writeFile(this.srcPath + 'index.ts', this.filter(this.allIndex).join('\n').replace(/{{dir}}/g, ''));
        done();
    }
 
    includeStaticFiles() {
        if (!fs.existsSync('./third-party/staticfiles/angular/src/')) {
            return;
        }
        shelljs.cp('-Rf', './third-party/staticfiles/angular/src/', './third-party/angular');
        var path = glob.sync(
            './third-party/staticfiles/angular/src/**/*.ts', {
                ignore: './third-party/staticfiles/angular/src/**/index.ts'
            }
        );
        for (var i = 0; i < path.length; i++) {
            if(!path[i].includes('index.ts')){
                var paths = path[i].replace('./third-party/staticfiles/angular/src', '.').replace('third-party\\staticfiles\\angular\\src', '.').replace(/\\/g, '/').replace('third-party/staticfiles/angular/src', '.');
                this.allIndex.push('export * from \'' + paths.replace('.ts', '') + '\';');
            }
        }
    }
 
    generateModule(compColl, compName, dirName) {
        var cnt = fs.readFileSync(__dirname + '/module.template').toString();
        cnt = cnt.replace(/{{components}}/g, (compColl.allComponents.join(',\n        ')));
        cnt = cnt.replace(/{{moduleImports}}/g, (compColl.allMods.join(';\n') + ';'));
        cnt = cnt.replace(/{{moduleName}}/g, compName);
        cnt = cnt.replace(/{{providers}}/g, compColl.diComponents.join(',\n        '));
        var fileName = compName.toLowerCase() + '.module';
        if(compName && compName === 'Ribbon') {
            cnt = this.filter(cnt.split('\n')).join('\n');
            cnt = cnt.replace(/exports:\s*\[\s*\]/, (cnt.match(/declarations:\s*\[\s*((?:\s*\w+\s*,?\s*)+)\]/)[0]).replace(/declarations:/, 'exports:'));
        }
        this.writeFile(this.srcPath + dirName + fileName + '.ts', cnt);
        compColl.compIndexList.push('export { ' + compName + 'Module } from \'./{{dir}}' + fileName + '\';');
        this.generateAllModule(compColl, compName, dirName, fileName);
    }
 
    generateAllModule(compColl, compName, dirName, pFileName) {
        var cnt = fs.readFileSync(__dirname + '/module-all.template').toString();
        var importMod = 'import { ' + compName + 'Module } from \'./' + pFileName + '\';';
        var exports = '';
        cnt = cnt.replace(/{{dependentModule}}/g, importMod);
        cnt = cnt.replace(/{{moduleImports}}/g, (compColl.allMods.join(';\n') + ';'));
        cnt = cnt.replace(/{{moduleName}}/g, compName);
        var _this = this;
        cnt = cnt.replace(/{{defineProviders}}/g, compColl.diService.map(function(val) {
            return 'export const ' + val +
                'Service: ValueProvider = { provide: \'' + _this.currentBaseName + val + '\', useValue: ' + val + '};';
        }).join('\n'));
        cnt = cnt.replace(/{{providers}}/g, compColl.diComponents.join(',\n        '));
        if (compColl.diService.length) {
            cnt = cnt.replace(/{{diImports}}/g, 'import {' + compColl.diService.join(', ') + '} from \'' + packJson.name + '\'');
            exports = ', ' + compColl.diService.map(function(val) {
                return val + 'Service';
            }).join(', ');
        }
        cnt = cnt.replace(/{{diImports}}/g, '');
 
        var fileName = compName.toLowerCase() + '-all.module';
        if(compName && compName === 'Ribbon') {
            cnt = this.filter(cnt.split('\n')).join('\n');
        }
        this.writeFile(this.srcPath + dirName + fileName + '.ts', cnt);
        compColl.compIndexList.push('export { ' + compName + 'AllModule' + exports + ' } from \'./{{dir}}' + fileName + '\';');
    }
 
    generateComponent(cnt, comp, compColl) {
        var comment = '';
        var twoWaysEvent = '';
        var inputs = propList[comp.baseClass]._allProperties.join('\',\'');
        var outputs = propList[comp.baseClass]._allEvents.join('\',\'');
        var oResult = outputs;
 
        if (comp.comment) {
            comment = comp.comment.join('\n');
        }
        if (comp.twoWays && comp.twoWays.length) {
            twoWaysEvent = '    public ' + comp.twoWays.join('Change: any;\n    public ') + 'Change: any;';
        }
        if (outputs !== '') {
            if (comp.twoWays && comp.twoWays.length) {
                outputs = outputs + '\',\'' + comp.twoWays.join('Change\',\'') + 'Change';
            }
            oResult = '\'' + outputs + '\'';
        } else {
            oResult = '';
            if (comp.twoWays && comp.twoWays.length) {
                oResult = '\'' + comp.twoWays.join('Change\',\'') + 'Change\'';
            }
        }
        cnt = cnt.replace(/{{name}}/g, comp.baseClass);
        cnt = cnt.replace(/{{fromEvents}}/g, comp.skipEventPropagation ? '' : '\'focus\', \'blur\', ');
        cnt = cnt.replace(/{{fromEventsDeclaration}}/g,
            comp.skipEventPropagation ? 'private skipFromEvent:boolean = true;' :
            'public focus: any;\n    public blur: any;');
        cnt = cnt.replace(/{{lname}}/g, comp.baseClass.toLowerCase());
        cnt = cnt.replace(/{{selector}}/g, comp.selector || 'ejs-' + comp.baseClass.toLowerCase());
        selectors.push(comp.selector || 'ejs-' + comp.baseClass.toLowerCase());
        cnt = cnt.replace(/{{componentComments}}/g, comment);
        cnt = cnt.replace(/{{SelectOption}}/g, (comp.contentSelect ? `select='` + comp.contentSelect + `'` : ''));
        cnt = cnt.replace(/{{twoways}}/g, (comp.twoWays ? '\'' + comp.twoWays.join('\', \'') + '\'' : ''));
        cnt = cnt.replace(/{{inputs}}/g, '\'' + inputs + '\'');
        cnt = cnt.replace(/{{packagepath}}/g, packJson.name);
        cnt = cnt.replace(/{{outputs}}/g, oResult);
        cnt = cnt.replace(/{{outputsEvents}}/g, this.getEventList(oResult.split(','), oResult === ''));
        cnt = this.templateReplacer(cnt, comp.templateProperties, propList, comp.baseClass);
        cnt = this.tagEvalExp(cnt, comp, compColl, true);
        cnt = this.diReplacer(cnt, comp.dynamicModules, compColl);
        return cnt;
    }
 
    generateTagDirective(tCnt, tagDir, comp, compColl) {
        tCnt = tCnt.replace(/{{className}}/g, toPascalCase(tagDir.directiveClassName || tagDir.name));
        tCnt = tCnt.replace(
            /{{selector}}/g,
            (tagDir.directiveSelector || this.getTagSelector(
                tagDir.arrayDirectiveClassName,
                tagDir.directiveClassName))
        );
        tCnt = tCnt.replace(
            /{{arraySelector}}/g,
            (tagDir.arrayDirectiveSelector || this.getTagSelector(
                comp.directiveClassName || comp.baseClass,
                tagDir.arrayDirectiveClassName, comp.type))
        );
        var comment = '';
        if (tagDir.comment) {
            comment = tagDir.comment.join('\n');
        }
        tCnt = tCnt.replace(/{{tagComment}}/g, comment);
        tCnt = tCnt.replace(/{{arrClassName}}/g, (toPascalCase(tagDir.arrayDirectiveClassName || tagDir.name + 's')));
        tCnt = tCnt.replace(/{{inputs}}/g, this.getNgInputs(comp.baseClass, tagDir.propertyName));
        tCnt = tCnt.replace(/{{outputs}}/g, this.getNgInputs(comp.baseClass, tagDir.propertyName, true));
        /* jshint ignore:start */
        tCnt = tCnt.replace(/{{outputsEvents}}/g, this.getEventList(this.getNgInputs(comp.baseClass, tagDir.propertyName, true).split(','), this.getNgInputs(comp.baseClass, tagDir.propertyName, true) === ''));
        /* jshint ignore:end */
        tCnt = tCnt.replace(/{{property}}/g, tagDir.propertyName.toLowerCase());
        tCnt = tCnt.replace(/{{packagepath}}/g, packJson.name);
        /* jshint ignore:start */
        tCnt = this.templateReplacer(tCnt, tagDir.templateProperties, propList, comp.baseClass, tagDir.propertyName, tagDir.ignoreDottedTemplates);
        /* jshint ignore:end */
        var props = this.getAllpropertiesFromClass(comp.baseClass, tagDir.propertyName, tagDir.templateProperties);
        tCnt = tCnt.replace(/{{propertyRef}}/g, props);
        tCnt = this.tagEvalExp(tCnt, tagDir, compColl, false);
        return tCnt;
    }
 
    getTagSelector(parent, child, ejPrefix) {
        return (ejPrefix ? 'ejs-' : 'e-') + parent.toLowerCase() + '>e-' + child.toLowerCase();
    }
 
    tagRender(cnt, comp, compColl, isComponent) {
        var rs = {
            props: [],
            queries: [],
            imports: [],
            tagDef: [],
            tagObjRef: []
        };
        var previousProperty;
        for (var j = 0; j < comp.tagDirective.length; j++) {
            var tagDir = comp.tagDirective[j];
            var tCnt = fs.readFileSync(__dirname + '/collection-directive.template').toString();
            var fileName = (tagDir.fileName || tagDir.propertyName.toLowerCase()) + '.directive.ts';
            var pClass = (toPascalCase(tagDir.arrayDirectiveClassName || tagDir.name + 's')) + 'Directive';
            tCnt = this.generateTagDirective(tCnt, tagDir, comp, compColl);
            var curComponents = [];
            curComponents.push((toPascalCase(tagDir.directiveClassName || tagDir.name) + 'Directive'));
            curComponents.push(pClass);
            compColl.compIndexList.push('export {' + curComponents.join(',') + '} from \'./{{dir}}' + fileName.replace('.ts', '') + '\';');
            compColl.allComponents.push((toPascalCase(tagDir.directiveClassName || tagDir.name) + 'Directive'));
            compColl.allComponents.push(pClass);
            compColl.allMods.push('import { ' + curComponents.join(', ') + ' } from \'./' + fileName.replace('.ts', '') + '\'');
            this.writeFile(this.srcPath + (comp.directoryName || '') + '/' + fileName, tCnt);
            rs.props.push(tagDir.propertyName);
            rs.queries.push('child' + toPascalCase(tagDir.propertyName) + ': new ContentChild(' + pClass + ')');
            // angular 9 compatibitibilty
            var iscomp = isComponent;
            if(comp.type === 'form') {
                rs.tagDef.push('    public child' + toPascalCase(tagDir.propertyName) + ': any;');
            } else {
            rs.tagDef.push('    public child' + toPascalCase(tagDir.propertyName) + `${iscomp ? ': QueryList<'+ pClass +'>;' : ': any;'}`);
            }
            if (j === 0) {
                rs.tagObjRef.push(`this.tagObjects[${j}].instance = this.child${toPascalCase(tagDir.propertyName)};`);
            } else {
                var string = ``;
                if (comp.directoryName === 'schedule' || comp.directoryName === 'gantt' || comp.directoryName === 'diagram' || comp.directoryName === 'chart') {
                    string = `\n\t    if (this.child${toPascalCase(tagDir.propertyName)}) {
            this.tagObjects[${j}].instance = this.child${toPascalCase(tagDir.propertyName)};
        }`;
                    rs.tagObjRef.push(string);
                } else {
                    rs.tagObjRef.push(`if (this.child${toPascalCase(tagDir.propertyName)}) {
                    this.tagObjects[${j}].instance = this.child${toPascalCase(tagDir.propertyName)} as any;
                }`);
                }
            }
            //store previous dir property
            previousProperty = toPascalCase(tagDir.propertyName);
            rs.imports.push('import { ' + pClass + ' } from \'./' +
                fileName.replace('.ts', '') + '\';');
        }
        cnt = this.queryReplacer(
            cnt,
            (comp.templateProperties ? '' : ', ContentChild'),
            '        ' + rs.queries.join(', \n        '),
            '    public tags: string[] = [\'' + rs.props.join('\', \'') + '\'];',
            rs.imports.join('\n'),
            rs.tagDef.join('\n'), rs.tagObjRef.join('\n        ')
        );
        return cnt;
    }
 
    tagEvalExp(cnt, comp, compColl, isComponent) {
        if (comp.tagDirective) {
            cnt = this.tagRender(cnt, comp, compColl, isComponent);
        } else {
            cnt = this.queryReplacer(cnt);
        }
        return cnt;
    }
 
    queryReplacer(cnt, queryChild, query, tags, imports, tagDef, tagObjRef) {
        cnt = cnt.replace(/{{query}}/g, query || '');
        cnt = cnt.replace(/{{queryChild}}/g, queryChild || '');
        cnt = cnt.replace(/{{tagStmt}}/g, tags || '');
        cnt = cnt.replace(/{{queryImports}}/g, imports || '');
        cnt = cnt.replace(/{{tagDef}}/g, tagDef || '');
        cnt = cnt.replace(/{{tagObjInstance}}/g, tagObjRef || '');
        return cnt;
    }
 
    diReplacer(cnt, modules, compColl) {
        var modContent = '',
            imports = '',
            opt = '',
            exportDI = '';
        if (modules && modules.length) {
            for (var i = 0; i < modules.length; i++) {
                var moduletemp = `        try {
                let mod = this.injector.get('{{name}}');
                if(this.injectedModules.indexOf(mod) === -1) {
                    this.injectedModules.push(mod)
                }
            } catch { }\n\r`;
                modContent = modContent + moduletemp.replace(/{{name}}/g, this.currentBaseName + modules[i]);
                if (this.allDIModules.indexOf(modules[i]) === -1) {
                    this.allDIModules.push(modules[i]);
                    exportDI = exportDI + 'export const ' + modules[i] + 'Service: ValueProvider = { provide: \'' + this.currentBaseName +
                        modules[i] + '\', useValue: ' + modules[i] + '};\n';
                    compColl.diComponents.push(modules[i] + 'Service');
                    compColl.diService.push(modules[i]);
                }
            }
            imports = ', ' + modules.join(', ');
            opt = ', Optional';
        }
        cnt = cnt.replace(/{{injectedModules}}/g, modContent);
        cnt = cnt.replace(/{{optionalImport}}/g, '');
 
        return cnt;
    }
 
    templateReplacer(cnt, tProps, props, className, propertyName, ignoreTempPros) {
        var prop = props[className];
        if (propertyName) {
            prop = prop[propertyName];
        }
        if (tProps && tProps.length) {
            var tRes = '';
            for (var i = 0; i < tProps.length; i++) {
                var comment = (prop && prop[tProps[i]] ? prop[tProps[i]].comment + '\n' : '');
                comment = comment === '' ? (prop && prop[tProps[i].name] ? prop[tProps[i].name].comment + '\n' : '') : comment;
                var defaultValue = '';
                var curVal = tProps[i];
                if (ignoreTempPros && curVal.indexOf('.') >= 0) {
                    continue;
                }
                if (typeof curVal === 'object') {
                    defaultValue = '\'' + curVal.defaultValue + '\'';
                    curVal = curVal.name;
                }
                tRes = tRes + comment + '    @ContentChild(\'' + namespaceToVariable(curVal) +
                    '\')\n    @Template(' + defaultValue + ')\n    public ' + curVal.replace('.', '_') + ': any;\n';
            }
            cnt = cnt.replace(/{{templateProps}}/g, tRes);
            cnt = cnt.replace(/{{templateImport}}/g, 'import { Template } from \'@syncfusion/ej2-angular-base\';');
            cnt = cnt.replace(/{{templateRefImport}}/g, ', ContentChild');
        } else {
            cnt = cnt.replace(/{{templateProps}}/g, '');
            cnt = cnt.replace(/{{templateImport}}/g, '');
            cnt = cnt.replace(/{{templateRefImport}}/g, '');
        }
        return cnt;
    }
 
    getAllpropertiesFromClass(className, propName, templateProperties) {
        var props = propList[className][propName];
        var keys = Object.keys(props);
        var propDef = [];
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var val = props[key].type;
            var comment = props[key].comment;
            if (typeof val === 'string' && (!templateProperties || this.getTemplateAvailable(templateProperties, key))) {
                propDef.push(comment);
                propDef.push('    public ' + key + ': ' + val + ';');
            }
        }
        return propDef.join('\n');
    }
 
    getTemplateAvailable(obj, key) {
        for (var i = 0; i < obj.length; i++) {
            if ((typeof obj[i] === 'object' ? obj[i].name : obj[i]) === key) {
                return false;
            }
        }
        return true;
    }
 
    getNgInputs(className, propName, event) {
        var eList = propList[className][propName].ngInputs._events;
        if (event) {
            return (eList && eList.length ? ('\'' + eList.join('\', \'') + '\'') : '');
        }
        return ('\'' + propList[className][propName].ngInputs.join('\', \'') + '\'');
    }
 
    writeFile(path, content) {
        var shelljs = global.shelljs = global.shelljs || require('shelljs');
        var arPath = path.split('/');
        arPath.pop();
        shelljs.mkdir('-p', arPath.join('/'));
        fs.writeFileSync(path, content, 'utf8');
    }
 
    getEventList(events, isNull){
        var eventsTemp = '\t';
        for (var i = 0; i < events.length && !isNull; i++) {
            if (i === events.length - 1){
                eventsTemp = events[i] !== '' ? eventsTemp +'public '+ events[i].replace(/'/g,'') + ': any;': eventsTemp;    
            }else {
                eventsTemp = events[i] !== '' ? eventsTemp + events[i].replace(/'/g,'') + ': any;\n\t': eventsTemp;
            }
        }
        return eventsTemp;
    }
}
 
module.exports = function(json, propList, done) {
    var pJson = JSON.parse(fs.readFileSync('./package.json'));
    return new NGSourceGen(json, propList, pJson, done);
};
