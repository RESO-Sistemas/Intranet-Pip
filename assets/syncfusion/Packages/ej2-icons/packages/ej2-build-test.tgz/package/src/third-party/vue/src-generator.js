'use strict';

var through, packJson, toInitCap, toInitLower, propList, toPascalCase;
var fs = global.fs = global.fs || require('fs');
var shelljs = global.shelljs = global.shelljs || require('shelljs');

/**
 * Angular source generator class
 */
class VueSourceGen {

    constructor(jsonContent, propCollection, pJson, done, srcPath) {
        this.allIndexColl = [];
        this.allComponents = [];
        through = global.through || require('through2');
        packJson = pJson;
        propList = propCollection;
        this.srcPath = srcPath || './third-party/vue/src/';
        toInitLower = function (str) {
            return str.replace(/\w\S*/g, function (txt) {
                return txt.charAt(0).toLowerCase() + txt.substr(1);
            });
        };
        toPascalCase = function (str) {
            return str.replace(/\w\S*/g, function (txt) {
                return txt.charAt(0).toUpperCase() + txt.substr(1);
            });
        };
        toInitCap = function (str) {
            return str.replace(/\w\S*/g, function (txt) {
                return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
            });
        };
        if (jsonContent) {
            this.render(jsonContent, done);
        }
        return this;
    }

    render(json, done) {
        for (var i = 0; i < json.components.length; i++) {
            var comp = json.components[i];
            if (comp.isBlazorOnly) {
                continue;
            }
            if (comp.type) {
                var cnt = fs.readFileSync(__dirname + '/' + 'component.template').toString();
                var dirName = comp.directoryName || '';
                var compColl = {
                    allComponents: [],
                    compIndexList: [],
                    allMods: [],
                    diComponents: [],
                    childDirectiveImport: '',
                    childDirectivePlugin: ''
                };
                var fileName = comp.baseClass.toLowerCase() + '.component.ts';
                var curPack = 'export * from \'' + packJson.name + '\';';
                if (this.allIndexColl.indexOf(curPack) === -1) {
                    this.allIndexColl.push(curPack);
                }
                compColl.allComponents.push(comp.baseClass + 'Component');
                cnt = this.generateComponent(cnt, comp, compColl);
                var diServices = '';
                if (compColl.diComponents.length) {
                    diServices = ', ' + compColl.diComponents.join(', ');
                }
                this.pushValueToArray(compColl.compIndexList, 'export { ' + comp.baseClass + 'Component, ' + comp.baseClass +
                    'Plugin } from \'./{{dir}}' + fileName.replace('.ts', '') + '\';');
                this.pushValueToArray(compColl.allMods, 'import { ' + comp.baseClass + 'Component' + diServices + ' } from \'' +
                    './' + fileName.replace('.ts', '') + '\'');
                this.writeFile(this.srcPath + dirName + '/' + fileName, cnt);
                if (comp.interfaces) {
                    var interimport = this.generateimports(comp.interfaces, compColl);
                    this.writeFile(this.srcPath + dirName + '/' + 'interface.ts', interimport);
                }
                if (dirName) {
                    this.writeFile(this.srcPath + dirName + '/' + 'index.ts', compColl.compIndexList.join('\n').replace(/{{dir}}/g, ''));
                    this.allIndexColl.push(compColl.compIndexList.join('\n').replace(/{{dir}}/g, dirName + '/'));
                } else {
                    this.allIndexColl = this.allIndexColl.concat(compColl.compIndexList);
                    this.allComponents = this.allComponents.concat(compColl.allComponents);
                }
            } else {
                console.error('Template type is not added for component ==> ' + comp.baseClass);
            }
        }

        this.writeFile(this.srcPath + 'index.ts', this.allIndexColl.join('\n').replace(/{{dir}}/g, ''));
        done();
    }

    generateComponent(cnt, comp, compColl) {
        var comment = '';
        var events = propList[comp.baseClass]._allEvents;
        var props = propList[comp.baseClass]._allProperties.join('\', \'') +
            (events.length !== 0 ? ('\', \'' +  events.join('\', \'')) : '');
        cnt = cnt.replace(/{{method}}/g, this.generateMethod(propList[comp.baseClass]._methods));
        cnt = cnt.replace(/{{methodTypes}}/g, this.generateMethodTypes(propList[comp.baseClass]._methods));
        if (comp.vueComment) {
            comment = comp.vueComment.join('\n');
        }
        var modelImport = '';
        var models = '';
        var modelEvent = '';
        var triggerChange = '';
        var modelTrigger = '';
        if (comp.twoWays && (comp.twoWays.length !== 0)) {
            modelImport = `\nimport { isUndefined } from '@syncfusion/ej2-base';`;
            models = `'${comp.twoWays.join('\', \'')}'`;
            modelEvent = `
    model: { event: 'modelchanged' },`;
            triggerChange = fs.readFileSync(__dirname + '/triggerChange.template').toString();
            modelTrigger = fs.readFileSync(__dirname + '/modelTrigger.template').toString();
        }
        cnt = cnt.replace(/{{modelImport}}/, modelImport);
        cnt = cnt.replace(/{{models}}/, models);
        cnt = cnt.replace(/{{modelEvent}}/g, modelEvent);
        cnt = cnt.replace(/{{triggerChange}}/, triggerChange);
        cnt = cnt.replace(/{{modelTrigger}}/, modelTrigger);
        cnt = cnt.replace(/{{ComponentClass}}/g, comp.baseClass);
        if (comp.baseClass.includes('DocumentEditor') || comp.baseClass.includes('Diagram') || comp.baseClass.includes('MultiSelect') || comp.baseClass.includes('Gantt')) { cnt = cnt.replace(/ej2Instances:/g, 'ej2Instance:'); }
        cnt = cnt.replace(/{{Component}}/g, comp.baseClass.toLowerCase());
        cnt = cnt.replace(/{{packagepath}}/g, packJson.name);
        cnt = cnt.replace(/{{componentComments}}/g, comment);
        cnt = cnt.replace(/{{properties}}/g, '\'' + props + '\'');
        cnt = cnt.replace(/{{tagName}}/g, comp.preferredTag || 'div');
        var noDynamicModules = !(comp.dynamicModules && comp.dynamicModules.length > 0);
        cnt = cnt.replace(/{{dynamicModules}}/g, !noDynamicModules);
        cnt = this.tagEvalExp(cnt, comp, compColl);
        return cnt;
    }

    generateimports(interfacename, compColl) {
        var imprtContent = [];
        var imprt = fs.readFileSync(__dirname + '/imports.template').toString();
        imprt = imprt.replace(/{{ComponentName}}/g, packJson.name);
        for (var i = 0; i < interfacename.length; i++) {
            imprtContent.push(interfacename[i].InterfaceName);
        }
        imprt = imprt.replace(/{{InterfacesName}}/g, imprtContent.toString());
        imprt = imprt.replace(/{{Interfaces}}/g, this.generateInterface(interfacename, compColl));
        return imprt;
    }

    generateInterface(intervalues, compColl) {
        if (intervalues.length !== 0) {
            var interTemp = fs.readFileSync(__dirname + '/interface.template').toString();
            var interfaceContent = [];
            var interfaces = [];
            for (var intervalue of intervalues) {
                var inter = interTemp;
                var newvales = 'custom' + intervalue.InterfaceName;
                inter = inter.replace(/{{NewInterfaceName}}/g, newvales);
                inter = inter.replace(/{{InterfaceName}}/g, intervalue.InterfaceName);
                inter = inter.replace(/{{properties}}/g, this.generateproperties(intervalue.PropertyName));
                interfaceContent.push(inter);
                interfaces.push(newvales);
            }
            this.pushValueToArray(compColl.compIndexList, 'export { ' + interfaces.toString() + ' } from \'./{{dir}}' + 'interface' + '\';');
            return interfaceContent.join('\n');
        }
        return '';
    }

    generateproperties(props) {
        if (props.length !== 0) {
            var mProps = fs.readFileSync(__dirname + '/property.template').toString();
            var propsContent = [];
            for (var prop of props) {
                var mProp = mProps;
                mProp = mProp.replace(/{{propertyName}}/g, prop);
                propsContent.push(mProp);
            }
            return propsContent.join('\n');
        }
        return '';
    }

    generateMethod(methods) {
        if (methods.length !== 0) {
            var mTemp = fs.readFileSync(__dirname + '/method.template').toString();
            var methodContent = [];
            for (var method of methods) {
                var mCnt = mTemp;
                mCnt = mCnt.replace(/{{methodName}}/g, method.name);
                mCnt = mCnt.replace(/{{methodType}}/g, method.type);
                var parameter = this.generateParameter(method.parameters);
                mCnt = mCnt.replace(/{{parameter}}/g, parameter.param);
                mCnt = mCnt.replace(/{{parameterType}}/g, parameter.paramType);
                methodContent.push(mCnt);
            }
            return methodContent.join('\n');
        }
        return '';
    }

    generateMethodTypes(methods) {
        if (methods.length !== 0) {
            var mType = `{{methodName}}({{parameterType}}): {{methodType}}`;
            var methodTypes = [];
            for (var method of methods) {
                var mTyp = mType;
                mTyp = mTyp.replace(/{{methodName}}/g, method.name);
                mTyp = mTyp.replace(/{{methodType}}/g, method.type);
                var parameter = this.generateParameter(method.parameters);
                mTyp = mTyp.replace(/{{parameterType}}/g, parameter.paramType);
                methodTypes.push(mTyp);
            }
            return methodTypes.join(';\n    ');
        }
        return '';
    }

    generateParameter(params) {
        var parameter = {
            param: '',
            paramType: ''
        };
        if (params.length !== 0) {
            var paramArray = [];
            var paramTypeArray = [];
            for (var param of params) {
                paramArray.push(param.name);
                paramTypeArray.push(param.name + (param.isOptional ? '?' : '') + ': ' + this.fetchParamType(param.type));
            }
            parameter.param = paramArray.join(', ');
            parameter.paramType = paramTypeArray.join(', ');
        }
        return parameter;
    }

    fetchParamType(type) {
        if (type.isUnion) {
            var uTypes = [];
            for (var uType of type.types) {
                uTypes.push(this.fetchParamType(uType));
            }
            return uTypes.join(' | ');
        }
        return type.name + (type.isArray ? '[]' : '');
    }

    tagRender(tagNameMapper, comp, compColl) {
        var mapper = {};
        for (var j = 0; j < comp.tagDirective.length; j++) {
            var tagDir = comp.tagDirective[j];
            var tCnt = fs.readFileSync(__dirname + '/directive.template').toString();
            var fileName = (tagDir.fileName || tagDir.propertyName.toLowerCase()) + '.directive.ts';
            var tagSelector = this.fetchTag(tagDir);
            var arrayDirTag = tagSelector.arrayDirTag;
            var dirTag = tagSelector.dirTag;
            var arrayDirClass = toPascalCase(tagDir.arrayDirectiveClassName);
            var dirClass = toPascalCase(tagDir.directiveClassName);
            tCnt = tCnt.replace(/{{arrayDirectiveClass}}/g, arrayDirClass);
            tCnt = tCnt.replace(/{{arrayDirective}}/g, arrayDirTag);
            tCnt = tCnt.replace(/{{DirectiveClass}}/g, dirClass);
            tCnt = tCnt.replace(/{{Directive}}/g, dirTag);
            tCnt = tCnt.replace(/{{baseClass}}/g, tagDir.baseClass);
            tCnt = tCnt.replace(/{{packagepath}}/g, packJson.name);
            compColl.childDirectivePlugin = this.concatString(compColl.childDirectivePlugin, `        Vue.component(${dirClass}Plugin.name, ${dirClass}Directive);\n` +
                `        Vue.component(${arrayDirClass}Plugin.name, ${arrayDirClass}Directive);\n`);
            var comment = '';
            if (tagDir.vueComment) {
                comment = tagDir.vueComment.join('\n');
            }
            tCnt = tCnt.replace(/{{tagComment}}/g, comment);
            this.writeFile(this.srcPath + (comp.directoryName || '') + '/' + fileName, tCnt);
            mapper['e-' + arrayDirTag] = {};
            if (tagDir.tagDirective) {
                mapper['e-' + arrayDirTag]['e-' + dirTag] = {};
                mapper['e-' + arrayDirTag]['e-' + dirTag] = this.tagRender(tagNameMapper, tagDir, compColl);
            } else {
                mapper['e-' + arrayDirTag] = 'e-' + dirTag;
            }
            if (tagDir.propertyName && (arrayDirTag !== tagDir.propertyName)) {
                tagNameMapper['e-' + arrayDirTag] = 'e-' + tagDir.propertyName;
            }
            var curComponents = [];
            curComponents.push(arrayDirClass + 'Directive', dirClass + 'Directive',
                arrayDirClass + 'Plugin', dirClass + 'Plugin');
            this.pushValueToArray(compColl.compIndexList, 'export { ' + curComponents.join(', ') +
                ' } from \'./{{dir}}' + fileName.replace('.ts', '') + '\';');
            this.pushValueToArray(compColl.allComponents, toPascalCase(dirTag) + 'Directive');
            this.pushValueToArray(compColl.allComponents, toPascalCase(arrayDirTag) + 'Directive');
            var dirImport = 'import { ' + curComponents.join(', ') + ' } from \'./' + fileName.replace('.ts', '') + '\'';
            compColl.childDirectiveImport = this.concatString(compColl.childDirectiveImport, dirImport + '\n');
            this.pushValueToArray(compColl.allMods, dirImport);
        }
        return mapper;
    }

    fetchTag(tagDir) {
        var tagSelector = {
            arrayDirTag: '',
            dirTag: ''
        };
        tagSelector.arrayDirTag = tagDir.arrayDirectiveSelector ?
            this.fetchTagSelector(tagDir.arrayDirectiveSelector) : tagDir.arrayDirectiveClassName.toLowerCase();
        tagSelector.dirTag = tagDir.directiveSelector ? this.fetchTagSelector(tagDir.directiveSelector) :
            tagDir.directiveClassName.toLowerCase();
        return tagSelector;
    }

    fetchTagSelector(tag) {
        var tagSplit = tag.split('>');
        return tagSplit[tagSplit.length - 1].replace('e-', '');
    }

    tagEvalExp(cnt, comp, compColl) {
        var notHasChildDirective = !comp.tagDirective;
        cnt = cnt.replace(/{{hasChildDirective}}/g, !notHasChildDirective);
        var tagMapper = {};
        var tagNameMapper = {};
        if (comp.tagDirective) {
            tagMapper = this.tagRender(tagNameMapper, comp, compColl);
        }
        cnt = cnt.replace(/{{childDirectivePlugin}}/g, compColl.childDirectivePlugin);
        cnt = cnt.replace(/{{childDirectiveImport}}/g, compColl.childDirectiveImport);
        compColl.childDirectiveImport = '';
        compColl.childDirectivePlugin = '';
        cnt = cnt.replace(/{{tagMapper}}/g, JSON.stringify(tagMapper));
        cnt = cnt.replace(/{{tagNameMapper}}/g, JSON.stringify(tagNameMapper));
        return cnt;
    }

    writeFile(path, content) {
        var aPath = path.split('/');
        aPath.pop();
        shelljs.mkdir('-p', aPath.join('/'));
        fs.writeFileSync(path, content, 'utf8');
    }

    pushValueToArray(array, value) {
        if (array.indexOf(value) === -1) {
            array.push(value);
        }
    }

    concatString(target, source) {
        if (target.indexOf(source) === -1) {
            target += source;
        }
        return target;
    }
}

module.exports = function (json, propList, done) {
    var pJson = JSON.parse(fs.readFileSync('./package.json'));
    return new VueSourceGen(json, propList, pJson, done);
};
