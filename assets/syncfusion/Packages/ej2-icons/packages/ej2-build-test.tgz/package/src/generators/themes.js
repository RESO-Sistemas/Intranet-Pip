'use strict';
var fs = global.fs = global.fs || require('fs');
var common = global.config = global.config || require('../utils/common.js');
var config = common.config();

// List of themes to filter ej2-base lines
const themesToFilter = [
    'bootstrap5-dark',
    'bootstrap4',
    'bootstrap',
    'bootstrap-dark',
    'bds',
    'material'
];

// Generate theme files
function generateThemes(themes) {
    var comp = config.styleDependency;
    if (comp === 'none') {
        return;
    }
    for (var i = 0; i < themes.length; i++) {
        var content = '',
            root = '',
            component;
        var baseContent = '';
        if (!config.isThirdParty && common.currentPackage !== 'ej2-base') {
            baseContent = '@use \'ej2-base/styles/definition/' + themes[i] + '\' as *;\n';
        }
        if (!comp.length || common.currentPackage === 'ej2-base') {
            content = baseContent;
            if (common.currentPackage === 'ej2-base') {
                if (themes[i].indexOf('-dark') !== -1 || themes[i].indexOf('-light') !== -1) {
                    content = '@use \'ej2-icons/styles/' + themes[i].split('-')[0] + '\' as *;\n';
                } else if (themes[i] === 'bootstrap5.3') {
                    content = '@use \'ej2-icons/styles/bootstrap5' + '\' as *;\n';
                } else {
                    content = '@use \'ej2-icons/styles/' + themes[i] + '\' as *;\n';
                }
            }
            createThemeFile(themes[i], content);
        } else {
            content = comp.toString() === 'ej2' ? '' : baseContent;
            for (var j = 0; j < comp.length; j++) {
                component = Object.keys(comp[j])[0];
                var addDarkTheme = ['tailwind-dark', 'bootstrap5-dark', 'fluent-dark', 'material3-dark'];
                if (addDarkTheme.indexOf(themes[i]) !== -1) {
                    if (!fs.existsSync('./styles/' + component + '/_' + themes[i] + '-definition.scss') && fs.existsSync('./styles/' + component + '/_' + addDarkTheme[addDarkTheme.indexOf(themes[i])].split('-')[0] + '-definition.scss')) {
                        var addLightTheme = `@use 'ej2-base/styles/definition/` + themes[i] + `' as *;\n@forward 'ej2-base/styles/definition/` + themes[i] + `';\n`;
                        fs.writeFileSync('./styles/' + component + '/_' + themes[i] + '-definition.scss', addLightTheme);
                    }
                    if (!fs.existsSync('./styles/' + component + '/icons/_' + themes[i] + '.scss') && fs.existsSync('./styles/' + component + '/icons/_' + addDarkTheme[addDarkTheme.indexOf(themes[i])].split('-')[0] + '.scss')) {
                        var addLightIcons = `@use './` + addDarkTheme[addDarkTheme.indexOf(themes[i])].split('-')[0] + `' as *;\n`;
                        fs.writeFileSync('./styles/' + component + '/icons/_' + themes[i] + '.scss', addLightIcons);
                    }
                }
                if (config.isThirdParty || fs.existsSync('./styles/' + component + '/_' + themes[i] + '-definition.scss') || component === 'sortable') {
                    if (typeof comp[j] === 'string') {
                        if (fs.existsSync('./styles/' + component + '_definition.scss')) {
                            content = content + getImportStatement(comp[j], themes[i]);
                            if (j === comp.length - 1) {
                                createThemeFile(themes[i], content);
                            }
                        }
                    } else {
                        content = baseContent;
                        component = Object.keys(comp[j])[0];
                        root = root + '@use \'' + component + '/' + themes[i] + '\' as *;\n';
                        content = content + getComponentStyles(comp[j][component], themes[i]);
                        createThemeFile(themes[i], content, component);
                    }
                }
            }
            createThemeFile(themes[i], root, component, true);
        }
    }
    // Additional generation for non-ej2-base repos targeting node_modules/@syncfusion/ej2-base/styles
    if (common.currentPackage !== 'ej2-base') {
        for (var i = 0; i < themes.length; i++) {
            var basePath = 'node_modules/@syncfusion/ej2-base/styles/';
            var baseContent = '';
            if (themes[i].indexOf('-dark') !== -1 || themes[i].indexOf('-light') !== -1) {
                baseContent = '@use \'ej2-icons/styles/' + themes[i].split('-')[0] + '\' as *;\n';
            } else if (themes[i] === 'bootstrap5.3') {
                baseContent = '@use \'ej2-icons/styles/bootstrap5' + '\' as *;\n';
            } else {
                baseContent = '@use \'ej2-icons/styles/' + themes[i] + '\' as *;\n';
            }
            createThemeFile(themes[i], baseContent, undefined, undefined, basePath);
        }
    }
}
exports.generateThemes = generateThemes;

// Create theme files based on folder structure
function createThemeFile(themeName, content, component, isRoot, basePath = './styles/') {
    var control = (component && !isRoot) ? component + '/' : '';
    var liteContent = content;
    if (common.currentRepo !== 'ej2-samples' && !(new RegExp(config.thirdPartyWords.join('|')).test(common.currentRepo))) {
        content = content + getThemeStyles(themeName, control, basePath);
        if (!isRoot) {
            content = content + `@use 'all.${themeName}' as *;\n`;
            if (fs.existsSync(`${basePath}${control}_bigger.scss`)) {
                content += `@use 'bigger.${themeName}' as *;`;
            }
        } else {
            const rootContents = [];
            const liteContents = [];
            for (let k = 0; k < config.styleDependency.length; k++) {
                const subComp = Object.keys(config.styleDependency[k]);
                if (fs.existsSync(`${basePath}${subComp}/${themeName}.scss`)) {
                    content = fs.readFileSync(`${basePath}${subComp}/${themeName}.scss`, 'utf8')
                        .replace(/@use '(?!(ej2|\.\/|\.\.\/))/g, `@use '${subComp}/`)
                        .replace(/\.\.?\//g, '')
                        .split('\n');
                    content.forEach(line => {
                        if (!rootContents.includes(line)) {
                            rootContents.push(line);
                            if (!line.includes("@use 'bigger")) {
                                liteContents.push(line);
                            }
                        }
                    });
                }
            }
            content = rootContents.join('\n');
            liteContent = liteContents.join('\n');
        }
    }
    // Filter out lines containing 'ej2-base' for specified themes in ./styles/
    if (!control && basePath === './styles/' && themesToFilter.includes(themeName)) {
        content = content.split('\n').filter(line => !line.includes('ej2-base')).join('\n');
        liteContent = liteContent.split('\n').filter(line => !line.includes('ej2-base')).join('\n');
    }
    writeFile(basePath + control + themeName + '.scss', content);
    if (common.currentPackage === 'ej2-base' || basePath.includes('node_modules/@syncfusion/ej2-base/')) {
        // For ej2-base or node_modules/@syncfusion/ej2-base/, write lite.scss without modifications
        writeFile(basePath + control + themeName + '-lite.scss', content);
    } else if (isRoot && !config.isThirdParty) {
        // For non-ej2-base repos, remove any @use statement containing 'bigger' from liteContent only for ./styles/[themeName]-lite.scss
        if (!control) { // Ensure only root-level files (./styles/[themeName]-lite.scss)
            liteContent = liteContent.split('\n').filter(line => !line.startsWith('@use ') || !line.includes('bigger')).join('\n');
        }
        writeFile(basePath + control + themeName + '-lite.scss', liteContent);
    }
    if (config.isThirdParty) {
        var compName = JSON.parse(fs.readFileSync('./package.json', 'utf8')).name.replace(/-(angular|react|vue)/, '');
        var cssFile = basePath + control + themeName + '.css';
        var urlName = cssFile.replace(basePath.replace(/\/$/, ''), '');
        var importContent = `@import '${compName}/styles${urlName}';`;
        writeFile(cssFile, importContent);
        if (isRoot) {
            var sassContent = `@use '${compName.replace('@syncfusion/', '')}${urlName}';`;
            writeFile(basePath + control + themeName + '-lite.scss', sassContent.replace('.css\';', '-lite\' as *;'));
            writeFile(basePath + control + themeName + '-lite.css', importContent.replace('.css', '-lite.css'));
        }
    }
}
exports.createThemeFile = createThemeFile;

// Get inner level folder styles
function getComponentStyles(dependent, theme) {
    var content = '';
    for (var i = 0; i < dependent.length; i++) {
        content = content + getImportStatement(dependent[i], theme);
    }
    return content;
}
exports.getComponentStyles = getComponentStyles;

// Get import statement from component and theme name
function getImportStatement(comp, theme) {
    var statement = '';
    var styles = 'styles/';
    var splitted = comp.split('/');
    if (comp === 'ej2') {
        statement = '@import \'' + comp + '/' + theme + '.scss\';\n';
    }
    if (config.isThirdParty) {
        statement = '@use \'' + splitted[0] + '/' + styles + splitted[1] + '/' + theme + '\' as *;\n';
    } else if (comp.indexOf('../') !== -1 && fs.existsSync(comp.replace('../', 'styles/') + '/_' + theme + '-definition.scss')) {
        statement = '@use \'' + comp + '/' + theme + '-definition\' as *;\n';
    } else if (comp.indexOf('/') !== -1) {
        if (fs.existsSync('./node_modules/@syncfusion/' + splitted[0] + '/' + styles + splitted[1] + '/_' + theme + '-definition.scss')) {
            statement = '@use \'' + splitted[0] + '/' + styles + splitted[1] + '/' + theme + '-definition\' as *;\n';
        }
    } else if (fs.existsSync(comp + '/' + styles + '_' + theme + '-definition.scss')) {
        statement = '@use \'' + comp + '/' + styles + theme + '-definition\' as *;\n';
    }
    return statement;
}
exports.getImportStatement = getImportStatement;

// Get additional styles for component's theme
function getThemeStyles(themeName, control, basePath = './styles/') {
    var themeStyles = '';
    var themeFile = themeName + '-definition.scss';
    if (fs.existsSync(basePath + control + '_definition.scss')) {
        var themeDefinition = '';
        if (fs.existsSync(basePath + control + '_' + themeFile)) {
            themeDefinition = fs.readFileSync(basePath + control + '_' + themeFile, 'utf8');
        }
    }
    if (fs.existsSync(basePath + control + '_' + themeFile)) {
        themeStyles = common.currentPackage == 'ej2-base' ? themeStyles + '@forward \'' + themeFile.replace('.scss', '') + '\';\n' :
         themeStyles + '@use \'' + themeFile.replace('.scss', '') + '\' as *;\n';
    }
    if (fs.existsSync(basePath + control + 'icons/_' + themeName + '.scss')) {
        themeStyles = themeStyles + '@use \'icons/' + themeName + '\' as *;\n';
    }
    return themeStyles;
}
exports.getThemeStyles = getThemeStyles;

function writeFile(path, content) {
    var shelljs = global.shelljs = global.shelljs || require('shelljs');
    var arPath = path.split('/');
    arPath.pop();
    shelljs.mkdir('-p', arPath.join('/'));
    fs.writeFileSync(path, content, 'utf8');
}
exports.writeFile = writeFile;