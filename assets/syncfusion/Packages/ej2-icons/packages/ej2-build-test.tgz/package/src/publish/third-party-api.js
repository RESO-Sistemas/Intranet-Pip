'use strict';

var fs = global.fs = global.fs || require('fs');
var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var angularApiGenerator = require('../generators/angular-api-generator.js');
var reactApiGenerator = require('../generators/react-api-generator.js');
var vueApiGenerator = require('../generators/vue-api-generator.js');
var apiCodeBlock = require('../generators/api-code-block.js');
var simpleGit = global.simpleGit = global.simpleGit || require('simple-git');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');

var localpath = './ej2-docs/src/';
var currentPackage = common.currentPackage;

/**
 * Generates Angular Api
 */
gulp.task('angular-api-gen', function (done) {
    publishApi('angular', done);
});

/**
 * Generates React Api
 */
gulp.task('react-api-gen', function (done) {
    publishApi('react', done);
});

/**
 * Generates Vue Api
 */
gulp.task('vue-api-gen', function (done) {
    publishApi('vue', done);
});

gulp.task('angular-api', function (done) {
    runSequence('typedoc', 'angular-api-gen', done);
});

gulp.task('react-api', function (done) {
    runSequence('typedoc', 'react-api-gen', done);
});

gulp.task('vue-api', function (done) {
    runSequence('typedoc', 'vue-api-gen', done);
});

gulp.task('local-angular-api', function () {
    angularApiGenerator.clearComponentFolder(localpath);
    angularApiGenerator.generateAngularApi(localpath);
    apiCodeBlock.addCodeBlock('angular');
});

gulp.task('local-react-api', function () {
    angularApiGenerator.clearComponentFolder(localpath);
    reactApiGenerator.generateReactApi(localpath);
    apiCodeBlock.addCodeBlock('react');
});

gulp.task('local-vue-api', function () {
    angularApiGenerator.clearComponentFolder(localpath);
    vueApiGenerator.generateVueApi(localpath);
    apiCodeBlock.addCodeBlock('vue');
});

function publishApi(repo, done) {
    try {
        if (!fs.existsSync('./ej2-docs')) {
            fs.mkdirSync('./ej2-docs');
            var user = 'SyncfusionAutomation';
            var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
            var stageBranch = process.env.githubSourceBranch || 'development';
            var ej2docRepo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-' + repo + '-api-library.git';
            simpleGit().clone(ej2docRepo, './ej2-docs', function (err) {
                if (err) {
                    done(err);
                    return;
                }
            }).then(function () {
                simpleGit('./ej2-docs').checkout(stageBranch, function (err) {
                    if (err) {
                        done(err);
                        return;
                    }
                    angularApiGenerator.clearComponentFolder(localpath);
                    var isApiGenerated = false;
                    if (repo === 'angular') {
                        isApiGenerated = angularApiGenerator.generateAngularApi(localpath);
                    } else if (repo === 'react') {
                        isApiGenerated = reactApiGenerator.generateReactApi(localpath);
                    } else if (repo === 'vue') {
                        isApiGenerated = vueApiGenerator.generateVueApi(localpath);
                    }
                    apiCodeBlock.addCodeBlock(repo);
                    // create api md files from typedoc
                    if (isApiGenerated) {
                        // push updated ej2-docs content to gitlab
                        simpleGit('./ej2-docs').init()
                            .add('./*')
                            .commit('documentation(EJ2-000): ' + currentPackage + ' -' + repo + ' api content published')
                            .pull(stageBranch)
                            .push(ej2docRepo, stageBranch, function () {
                                console.log(currentPackage + ' - ej2 ' + repo + ' docs api content published');
                                done();
                            });
                    } else {
                        done();
                    }
                });
            });
        } else {
            done();
            return;
        }
    } catch (error) {
        throw error;
    }
}
