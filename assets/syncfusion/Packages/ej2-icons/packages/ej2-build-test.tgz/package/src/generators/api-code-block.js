'use strict';

//Global variables
var fs = global.fs = global.fs || require('fs');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var common = global.config || require('../utils/common.js');
var config = common.config();
var glob = require('glob');

function copyCodeBlock(cblockpaths, mdfile, platform) {
    let mdContent = fs.existsSync(mdfile) ? fs.readFileSync(mdfile, 'utf-8') : '';
    if (!mdContent) {
        return;
    }
    for (let cBPath of cblockpaths) {
        if (!cBPath) {
            mdContent = mdContent.replace(cBPath, '');
            continue;
        }
        let path = cBPath.replace(/\s/g, '').replace(/\{\%codeBlocksrc\=\'(.*?)\'\%\}\{\%endcodeBlock\%\}/, '$1');
        let codeBlockPath = path ? `./api-code-blocks/${platform}/${path}` : '';
        let codeBlock = fs.existsSync(codeBlockPath) ? '\n' + fs.readFileSync(codeBlockPath, 'utf-8') : '';
        mdContent = mdContent.replace(cBPath, codeBlock);
    }
    fs.writeFileSync(mdfile, mdContent, 'utf-8');
}

function addCodeBlock(platform) {
    if (platform === 'ts') {
        shelljs.mkdir('-p', './ej2-docs-api/src');
        shelljs.cp('-r', `./ej2-docs/src`, `./ej2-docs-api/src`);
    }
    config = platform === 'ts' ? config : fs.existsSync('../../config.json') ? JSON.parse(fs.readFileSync('../../config.json')) : {};
    var components = config ? config.components : [];
    if (!components.length) {
        components = [common.currentPackage.split('ej2-')[1]];
    }
    for (var comp of components) {
        var curFolders = './ej2-docs/src/' + comp;
        var files = glob.sync(curFolders + '/*.md', { silent: true });
        for (let file of files) {
            let mdContent = fs.existsSync(file) ? fs.readFileSync(file, 'utf-8') : '';
            let cBlockPaths = mdContent !== '' ? mdContent.match(/\{\% codeBlock(.*?)\%\}\{\% endcodeBlock \%\}/gm) : null;
            if (cBlockPaths) { copyCodeBlock(cBlockPaths, file, platform); }
        }
    }
}

exports.addCodeBlock = addCodeBlock;