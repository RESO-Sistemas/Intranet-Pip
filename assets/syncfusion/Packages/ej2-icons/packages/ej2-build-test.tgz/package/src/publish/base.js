'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var fs = global.fs = global.fs || require('fs');
var path = global.path = global.path || require('path');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var glob = require('glob');
// var cdn = require('./cdn.js');
var user = 'SyncfusionAutomation';
var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
var regexp = common.regexp;
var currentRepo = common.currentRepo;
var runSequence = require('gulp4-run-sequence');
var branch = process.env.githubSourceBranch;
var themes = [];
/* jshint ignore:start */
var themes = ['material', 'fabric', 'bootstrap', 'highcontrast', 'bootstrap4', 'bootstrap5', 'fluent', 'tailwind', 'material3', 'fluent2', 'material-dark', 'fabric-dark', 'bootstrap-dark', 'bootstrap5-dark', 'tailwind-dark', 'fluent-dark', 'material3-dark', 'bootstrap5.3', 'tailwind3', 'bds', 'fluent2-dark', 'bootstrap5.3-dark', 'tailwind3-dark', 'fluent2-highcontrast'];
/* jshint ignore:end */
var gzip = require('gulp-gzip');

var productionIgnore =
    `.npmrc
**/*.ts
**/*.tsx
**/*.log
!**/*.d.ts
api.**/
spec/
demo/
demos/
aot/
blazor/
ej2-docs/
api-code-blocks/
ej2-resources/
ej2-js-es5/
public/
gitleaks-ci/
gitleaks-ci.tar.gz
GitLeaksReport.json
.git/
archive/
.vscode/
coverage/
cireports/
accessibility/
accessibility-reports/
tempFile
shelljs_*
.npmignore
.gitignore
config.json
api.json
*.docx
help.md
CHANGELOG.md
pipeline.cmd
system.config.js
gulpfile.js
test-report/
github-repo/
test-main.js
tsconfig.json
rollup.config.js
tsconfig-aot.json
node-modules/
karma.conf.js
Jenkinsfile
coverage.txt
yarn.lock
.spelling
umd-deploy/
third-party/
dist/ts/
targetBranch.txt
coverage-cdn/
cireports/
compare-api.json
current-api.json
api-changes.html
branchPackage.tgz
dist/global/blazor/
.gitlab/
blazor-source/
**/index-all.js
schematics-samples/
themestudio/
tree-shaking/
memory-leak-samples/
memory-leak-reports/
releasenotes/
.github/
readme/
hotfix/
release/
src/pdfviewer/ej2-pdfviewer-lib/
src/pdf-data-extract/core/ej2-pdf-lib/
!schematics/generators/template/**/*.ts
!schematics/generators/*/samples/**/*.ts` +
    '\n!dist/global/' + common.currentPackage + '.min.js' +
    '\ndist/' + common.currentPackage + '.umd.js';

var npmIgnore = productionIgnore +
    `
!dist/ts/**/*.ts`;

// Ship src at root 
function shipSrc(source, destination, ignore) {
    var glob = require('glob');
    var files = glob.sync(source, {
        silent: true,
        ignore: ignore
    });
    for (var i = 0; i < files.length; i++) {
        var file = files[i].split('src/')[1];
        var target = destination + file;
        if (!fs.existsSync(path.dirname(target))) {
            shelljs.mkdir('-p', path.dirname(target));
        }
        fs.writeFileSync(target, fs.readFileSync(files[i]));
    }
}
exports.shipSrc = shipSrc;

/**
 * Create npmignore at root
 */
gulp.task('npmignore', async function () {
    return createNpmIgnore(currentRepo);
});

// npmignore override
function createNpmIgnore(currentRepo, isProduction) {
    if (currentRepo !== 'ej2-build-tasks') {
        var currentIgnore, ignorePath = './.npmignore';
        try {
            if (fs.statSync(ignorePath).isFile()) {
                currentIgnore = fs.readFileSync(ignorePath);
                fs.writeFileSync(ignorePath, '');
            }
        } catch (e) { }
        if (isProduction) {
            npmIgnore = productionIgnore;
        }
        npmIgnore = currentIgnore ? npmIgnore + '\n' + currentIgnore : npmIgnore;
        if (currentRepo !== 'ej2-base-library') {
            npmIgnore = npmIgnore +
                `
            e2e/`;
        }
        fs.writeFileSync(ignorePath, npmIgnore);
    }
}
exports.createNpmIgnore = createNpmIgnore;

/**
 * Mapping typings file to package.json file
 */
gulp.task('typings-mapping', function (done) {
    var Addtyping = JSON.parse(fs.readFileSync('./package.json'));
    Addtyping.typings = 'index.d.ts';
    fs.writeFileSync('./package.json', JSON.stringify(Addtyping, null, '\t'), 'utf8');
    done();
});

/**
 * Mapping es5 module to package.json file
 */
gulp.task('es5-mapping', function (done) {
    var packJson = JSON.parse(fs.readFileSync('./package.json'));
    if (packJson.es2015) {
        packJson.es2015 = packJson.es2015.replace(/es2015/, 'es5');
        fs.writeFileSync('./package.json', JSON.stringify(packJson, null, '\t'), 'utf8');
    }
    done();
});

/**
 * Publish npm packages
 */
gulp.task('publish', gulp.series('typings-mapping', 'npmignore', 'dev-registry', 'es5-mapping', function (done) {
    var simpleGit = require('simple-git')();
    if (currentRepo === 'ej2-build-tasks') {
        shipSrc('./src/services/**/*', './');
    }
    if (currentRepo === 'ej2-pdfviewer-library' && fs.existsSync('./src/pdfviewer/ej2-pdfviewer-lib/')) {
        if (!fs.existsSync('./dist/ej2-pdfviewer-lib/')) {
            shelljs.mkdir('-p', './dist/ej2-pdfviewer-lib/');
        }
        shelljs.mv('./src/pdfviewer/ej2-pdfviewer-lib/*', './dist/ej2-pdfviewer-lib/');
    }
    if (currentRepo === 'ej2-pdf-data-extract' && fs.existsSync('./src/pdf-data-extract/core/ej2-pdf-lib/')) {
        if (!fs.existsSync('./dist/ej2-pdf-lib/')) {
            shelljs.mkdir('-p', './dist/ej2-pdf-lib/');
        }
        shelljs.mv('./src/pdf-data-extract/core/ej2-pdf-lib/*', './dist/ej2-pdf-lib/');
    }
    simpleGit.log(function (err, log) {
        var logs = common.getCommitDetails(log);
        if (process.env.githubSourceBranch === common.stagingBranch) {
            if (currentRepo === 'ej2-angular-base') {
                shelljs.rm('-rf', './schematics');
                shelljs.cp('-rf', './node_modules/@syncfusion/ej2-build-test/templates/schematics', './');
            }
            let pkg = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
            pkg.version = '32.1.1';
            fs.writeFileSync('./package.json', JSON.stringify(pkg, null, 2));
            console.log('Package version updated', logs.release);
            shelljs.exec('npm version -f ' + '32.1.1' + ' --no-git-tag-version --no-verify');
            var npmrc = fs.readFileSync('./.npmrc', 'utf8');
            npmrc = npmrc.replace(/\/ej2-development/g, '/ej2-angular-development');
            fs.writeFileSync('./.npmrc', npmrc);
            console.log('npmrc file updated: \n', npmrc);
            /* jshint ignore:start */
            var publish = shelljs.exec('npm publish --registry https://nexus.syncfusioninternal.com/repository/ej2-angular-development/');
            /* jshint ignore:end */
            npmrc = npmrc.replace(/\/ej2-angular-development/g, '/ej2-development');
            console.log('npmrc file updated: \n', npmrc);
            fs.writeFileSync('./.npmrc', npmrc);
            shelljs.exec('npm publish --registry https:' + process.env.PRIVATE_DEV_REGISTRY, function (exitCode) {
                done();
                shellDone(exitCode);
            });
        } else {
            done();
        }
    });
}));

function shellDone(exitCode) {
    if (exitCode !== 0) {
        process.exit(1);
    }
}
exports.shellDone = shellDone;

/**
 * Deploy umd files in ftp location
 */
gulp.task('umd-deploy', function (done) {
    runSequence('ship-dist');
    var currentPackage = (common.currentPackage === 'ej2' ||
        common.currentPackage === 'ej2-vue-es5') ? '' : common.currentPackage;
    var location = common.isMasterBranch ? 'packages/production/' + currentPackage : 'packages/development/' + currentPackage;
    location = common.isReleaseBranch ? 'packages/release/' + currentPackage : location;
    location = common.isHotfixBranch ? 'packages/hotfix/' + currentPackage : location;
    done();
    // cdn.publish('./umd-deploy', false, location, done);
});

/**
 * for angular - ship dist files
 */
gulp.task('angular-ship-dist', function (done) {
    var shipSrc = ['styles/**/*.css', '!styles/resources/*.css'];
    return gulp.src(shipSrc, {
        base: '.'
    })
        .pipe(gzip({
            append: false
        }))
        .pipe(gulp.dest('./umd-deploy'))
        .on('end', done);
});

/**
 * Deploy umd files in ftp location only for angular
 */
gulp.task('angular-umd-deploy', gulp.series('angular-ship-dist', function (done) {
    var currentPackage = common.currentPackage;
    var location = common.isMasterBranch ? 'packages/production/' + currentPackage : 'packages/development/' + currentPackage;
    location = common.isReleaseBranch ? 'packages/release/' + currentPackage : location;
    location = common.isHotfixBranch ? 'packages/hotfix/' + currentPackage : location;
    // Moving umd file to deploy folder
    shelljs.mkdir('./umd-deploy/dist/');
    shelljs.cp('-rf', './dist/bundles/**.umd.min.js', './umd-deploy/dist/');
    // commented this since we have not used these scripts

    done();
    //  cdn.publish('./umd-deploy', false, location, done);
}));

/**
 * publish js files in ftp location
 */
gulp.task('ej2-js-publish', function (done) {
    shelljs.exec('gulp ej2-js');
    common.EJJavascriptPublish();
    done();
});

/**
 * publish vue es5 files in ftp location
 */
gulp.task('ej2-vue-es5-publish', function (done) {
    shelljs.exec('gulp ej2-vue');
    common.EJVuePublish();
    done();
});

/**
 * ship dist files
 */
gulp.task('ship-dist', function (done) {
    var shipSrc = ['dist{,/**}', '!./dist/ts{,/**}', 'styles/**/*.css', '!styles/resources/*.css', 'styles/**/*.scss'];
    if (common.currentPackage === 'ej2') {
        shipSrc.concat(['./*.css', './*.scss']);
    }
    return gulp.src(shipSrc, {
        base: '.'
    })
        .pipe(gzip({
            append: false
        }))
        .pipe(gulp.dest('./umd-deploy'))
        .on('end', done);
});

gulp.task('ci-skip', function (done) {
    var simpleGit = require('simple-git')();
    simpleGit.log(function (err, log) {
        var logs = common.getCommitDetails(log),
            coverage = '',
            stagingBranch = common.stagingBranch;
        if (currentRepo !== 'ej2-vue-base' && (RegExp(regexp.COMMIT_TYPES).test(logs.lastCommit) || currentRepo === 'ej2') &&
            !RegExp(regexp.CI_SKIP).test(logs.lastCommit) && process.env.githubSourceBranch === stagingBranch) {
            var user = 'SyncfusionAutomation';
            var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
            var origin = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/' + common.currentRepo + '.git';
            shelljs.exec('git remote set-url origin ' + origin + ' && git pull origin ' + stagingBranch);
            if (fs.existsSync('./coverage')) {
                coverage = 'coverage.txt';
                fs.writeFileSync('./' + coverage, fs.readFileSync('./coverage/report.txt'));
            }
            if (fs.existsSync(path.resolve('./current-api.json'))) {
                let apipath = path.resolve('./api.json');
                let json = JSON.stringify(require(path.resolve('./current-api.json')), null, '\t');
                fs.writeFileSync(apipath, json, 'utf-8');
            }
            shelljs.exec('git add -f package.json api.json ' + coverage);
            shelljs.exec('git commit -m \"ci-skip(EJ2-000): Branch merged and package is published [ci skip]\" --no-verify');
            shelljs.exec('git branch -f ' + stagingBranch + ' HEAD && git checkout ' + stagingBranch, shellDone);
            shelljs.exec('git push -f --set-upstream origin ' + stagingBranch + ' --no-verify', {
                silent: true
            }, function (exitCode) {
                done();
                shellDone(exitCode);
            });
        } else {
            done();
        }
    });
});

gulp.task('ej2-js-pack', function (done) {
    var shipSrc = ['dist{,/**}', '!./dist/*.ts', 'styles/**/*.css', 'styles/**/*.scss', '!styles/resources/*.css',
        'package.json', '.npmrc', 'license', 'ReadMe.md', 'README-ES5-Nuget.md'];
    return gulp.src(shipSrc, {
        base: '.'
    })
        .pipe(gulp.dest('./ej2-js-es5'))
        .on('end', done);
});

gulp.task('ej2-vue-pack', function (done) {
    var shipSrc = ['dist{,/**}', '!./dist/*.ts', 'styles/**/*.css', '!styles/resources/*.css', 'package.json', '.npmrc'];
    return gulp.src(shipSrc, {
        base: '.'
    })
        .pipe(gulp.dest('./ej2-vue-es5'))
        .on('end', done);
});

gulp.task('package-json', function (done) {
    var packageJson = JSON.parse(fs.readFileSync('./ej2-js-es5/package.json'));
    packageJson.dependencies = {};
    packageJson.name = '@syncfusion/ej2-js-es5';
    shelljs.cp('-R', ['./*.css', './combined-scss/*.scss'], './ej2-js-es5/styles');
    if (fs.existsSync('./ej2-js-es5/dist')) {
        shelljs.mv('./ej2-js-es5/dist', './ej2-js-es5/scripts');
    }
    fs.writeFileSync('./ej2-js-es5/package.json', JSON.stringify(packageJson, null, '\t'));
    done();
});

gulp.task('package-json-vue', function (done) {
    var packageJson = JSON.parse(fs.readFileSync('./ej2-vue-es5/package.json'));
    packageJson.dependencies = {};
    packageJson.name = '@syncfusion/ej2-vue-es5';
    if (fs.existsSync('./ej2-vue-es5/dist')) {
        shelljs.mv('./ej2-vue-es5/dist', './ej2-vue-es5/scripts');
    }
    fs.writeFileSync('./ej2-vue-es5/package.json', JSON.stringify(packageJson, null, '\t'));
    done();
});

gulp.task('publish-mvcscripts', function (done) {
    publishScripts('ej2-aspmvc-samples', './ej2-mvcsource', 'Content/styles', 'Scripts', false, done);
});

gulp.task('publish-docprocess-mvcscripts', function (done) {
    publishScripts('ej2-document-processing-aspmvc-samples', './ej2-docprocess-mvcsource', 'Content/styles', 'Scripts', false, done);
});

gulp.task('publish-wordeditor-mvcscripts', function (done) {
    publishScripts('ej2-word-editor-aspmvc-samples', './ej2-wordeditor-mvcsource', 'Content/styles', 'Scripts', false, done);
});

gulp.task('publish-spreadsheet-mvcscripts', function (done) {
    publishScripts('ej2-spreadsheet-aspmvc-samples', './ej2-spreadsheet-mvcsource', 'Content/styles', 'Scripts', false, done);
});

gulp.task('publish-pdfviewer-mvcscripts', function (done) {
    publishScripts('ej2-pdfviewer-aspmvc-samples', './ej2-pdfviewer-mvcsource', 'Content/styles', 'Scripts', false, done);
});

gulp.task('publish-aspscripts', function (done) {
    publishScripts('ej2-aspcore-samples', './ej2-aspsource', 'wwwroot/styles', 'wwwroot/scripts', false, done);
});

gulp.task('publish-docprocess-scripts', function (done) {
    publishScripts('ej2-document-processing-aspcore-samples', './ej2-docuprocess-coresource', 'wwwroot/styles', 'wwwroot/scripts', false, done);
});

gulp.task('publish-wordeditor-scripts', function (done) {
    publishScripts('ej2-word-editor-aspcore-samples', './ej2-wordeditor-coresource', 'wwwroot/styles', 'wwwroot/scripts', false, done);
});

gulp.task('publish-spreadsheet-scripts', function (done) {
    publishScripts('ej2-spreadsheet-aspcore-samples', './ej2-spreadsheet-coresource', 'wwwroot/styles', 'wwwroot/scripts', false, done);
});

gulp.task('publish-pdfviewer-scripts', function (done) {
    publishScripts('ej2-pdfviewer-aspcore-samples', './ej2-pdfviewer-coresource', 'wwwroot/styles', 'wwwroot/scripts', false, done);
});

gulp.task('publish-aspcoresource-scripts', function (done) {
    publishScripts('ej2-asp-core', './ej2-aspcoresource', 'src/wwwroot/styles', 'src/wwwroot/scripts', false, done);
});

gulp.task('publish-blazor-source', function (done) {
    publishScripts('ej2-blazor-source', './blazor-source', 'Syncfusion.Blazor/wwwroot/styles', 'Scripts', true, done);
});

gulp.task('publish-blazor-sb-scripts', function (done) {
    publishScripts('ej2-blazor-samples', './ej2-blazorsource', 'ServerSide-Blazor/blazor-samples/wwwroot/styles',
        'ServerSide-Blazor/blazor-samples/wwwroot/scripts', true, done);
});


function publishScripts(sampleName, localPath, stylesPath, sourcePath, isBlazorSource, done) {
    var gitPath = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/' + sampleName;
    var gitLocalPath = localPath;
    var clone = shelljs.exec('git clone ' + gitPath + ' -b ' + branch + ' ' + gitLocalPath, { silent: true });
    if (clone.code !== 0) {
        done();
        return;
    }
    else {
        if (isBlazorSource) {
            var copyPath = localPath + '/' + sourcePath;
            //Copy ej2.min.js and theme files to blazor source
            var ej2MinJsPath = './dist/ej2.min.js';
            var themeFilesPath = glob.sync('./*.css');
            var themeCssRegex = /[^\.]+.css/;
            if (fs.existsSync(ej2MinJsPath) && fs.existsSync(copyPath)) {
                shelljs.cp('-r', ej2MinJsPath, copyPath);
                var placeholderCssPath = copyPath + '/placeholder.css';
                var hcplaceholderCssPath = copyPath + '/highcontrast-placeholder.css';
                var placeholderCss = fs.existsSync(placeholderCssPath) ? fs.readFileSync(placeholderCssPath, 'utf8') : '';
                var hcPlaceholderCss = fs.existsSync(hcplaceholderCssPath) ? fs.readFileSync(hcplaceholderCssPath, 'utf8') : '';
                for (var themeFilePath of themeFilesPath) {
                    shelljs.cp('-r', themeFilePath, copyPath);
                    var themeCss = themeFilePath.match(themeCssRegex)[0];
                    var themeBlazorPath = (themeFilePath.indexOf('bootstrap5.3') === -1) ? copyPath + '/' + themeCss : copyPath + '/' + themeFilePath;
                    fs.writeFileSync(themeBlazorPath, (fs.readFileSync(themeBlazorPath, 'utf8') + '\n' +
                        ((themeFilePath.indexOf('highcontrast.css') !== -1) ? hcPlaceholderCss : placeholderCss)), 'utf8');
                }
                // if (fs.existsSync('./blazor-styles')) {
                //     shelljs.cp('-R', './blazor-styles/*.css', localPath + '/' + stylesPath);
                //     shelljs.cp('-R', './blazor-styles/customized/*.css', localPath + '/' + stylesPath + '/customized');
                // }
                if (fs.existsSync('./ej2-js-es5')) {
                    shelljs.cp('-R', './ej2-js-es5/styles/*.css', localPath + '/' + stylesPath);
                    shelljs.cp('-R', './ej2-js-es5/styles/customized/*.css', localPath + '/' + stylesPath + '/customized');
                }
            }
        } else {
            if (fs.existsSync('./ej2-js-es5')) {
                if (sampleName === 'ej2-aspcore-samples' || sampleName === 'ej2-document-processing-aspcore-samples' || sampleName === 'ej2-spreadsheet-aspcore-samples' || sampleName === 'ej2-word-editor-aspcore-samples' || sampleName === 'ej2-pdfviewer-aspcore-samples' 
                || sampleName === 'ej2-aspmvc-samples' || sampleName === 'ej2-document-processing-aspmvc-samples' || sampleName === 'ej2-word-editor-aspmvc-samples' || sampleName === 'ej2-spreadsheet-aspmvc-samples' || sampleName === 'ej2-pdfviewer-aspmvc-samples') {
                    var jsPath = `./ej2-js-es5/scripts/ej2.min.js`;
                    if (!fs.readFileSync(jsPath, 'utf-8').includes('window.syncfusion={isLicValidated:true};')) {
                        fs.writeFileSync(jsPath, fs.readFileSync(jsPath, 'utf-8') + 'window.syncfusion={isLicValidated:true};', 'utf-8');
                    }
                }
                shelljs.cp('-R', './ej2-js-es5/styles/*.css', localPath + '/' + stylesPath);
                shelljs.cp('-R', './ej2-js-es5/scripts/*', localPath + '/' + sourcePath);
            }
        }
        shelljs.cd(localPath);
        var addFiles, addCustomCss, message;
        var excludedFiles = [
                'bds-dark.css',
                'bds-dark-lite.css',
                'bds-lite.css',
                'bds.css'
            ];
        var unstageExcludes = excludedFiles.map(f => `git reset ${stylesPath}/${f}`).join(' && ');
        if (isBlazorSource) {
            addFiles = 'git add ' + stylesPath + '/*.css';
            addCustomCss = 'git add ' + stylesPath + '/customized/*.css';
            shelljs.exec(addCustomCss);
            message = 'latest styles has been shipped';
        } else {
            addFiles = sampleName.includes('asp')
                ? `git add ${sourcePath}/ej2.min.js && git add ${stylesPath}/*.css`
                : `git add ${sourcePath}/ej2.min.js ${sourcePath}/ej2-pdfviewer-lib/* ${sourcePath}/ej2-pdf-lib/* ${stylesPath}/*.css`;
            message = 'latest scripts and styles has been shipped';
        }
        shelljs.exec(addFiles);
        shelljs.exec(unstageExcludes);
        if (sampleName !== 'ej2-blazor-source') {
            shelljs.exec('git reset ' + stylesPath + '/*-lite.css');
        }
        shelljs.exec('git commit -m \"' + message + '\" --no-verify');
        shelljs.exec('git push -f --set-upstream origin --no-verify', { silent: true });
        shelljs.cd('../');
        shelljs.rm('-rf', localPath);
        done();
    }
}

gulp.task('ej2-js', function (done) {
    var runSequence = require('gulp4-run-sequence');
    runSequence('ej2-js-pack', 'package-json', 'ej2-write-dts', 'publish-blazor-source',
        'publish-mvcscripts', 'publish-docprocess-mvcscripts', 'publish-wordeditor-mvcscripts', 
        'publish-spreadsheet-mvcscripts', 'publish-pdfviewer-mvcscripts', 'publish-aspscripts', 
        'publish-docprocess-scripts', 'publish-wordeditor-scripts', 'publish-spreadsheet-scripts', 
        'publish-pdfviewer-scripts', 'publish-aspcoresource-scripts', done);
});

gulp.task('ej2-vue', function (done) {
    runSequence('ej2-vue-pack', 'package-json-vue', done);
});

// generate the style packages
function generateStylesPackages(themeName, done, isLast) {
    var path = './ej2-' + themeName;
    if (!fs.existsSync(path)) {
        shelljs.mkdir('-p', path);
        if (fs.existsSync('./ej2-js-es5')) {
            var files = glob.sync('./ej2-js-es5/styles/**/' + themeName + '{-lite,}.css');
            var scssFiles = glob.sync('./ej2-js-es5/styles/**/' + themeName + '{-lite,}.scss');
            files = files.concat(scssFiles);
            for (var j = 0; j < files.length; j++) {
                var file = files[j].split('/');
                console.log('file', file);
                file = file.splice(2, file.length - 2).join('/');
                var folder = file.split('/')[0];
                shelljs.mkdir('-p', './ej2-' + themeName + '/styles');
                if (!folder.includes('.css')) {
                    shelljs.mkdir('-p', './ej2-' + themeName + '/styles/' + folder);
                }
                shelljs.cp('-R', files[j], './ej2-' + themeName + '/styles/' + file);
            }
            shelljs.cp('-R', './ej2-js-es5/license', './ej2-' + themeName + '/');
            var packageJson = JSON.parse(fs.readFileSync('./package.json'));
            delete packageJson.dependencies;
            delete packageJson.devDependencies;
            delete packageJson.scripts;
            packageJson.name = '@syncfusion/ej2-' + themeName + '-theme';
            shelljs.cp('-R', './ej2-js-es5/.npmrc', './ej2-' + themeName + '/');
            fs.writeFileSync('./ej2-' + themeName + '/package.json', JSON.stringify(packageJson, null, '\t'));
            var ReadME = `# ej2-${themeName}-theme

## Setup
To install ${themeName} theme, use the following command\n\n` +

                '```sh \nnpm install @syncfusion/ej2-' + themeName + '-theme\n```\n' +

                '## License\n' +
                '> This is a commercial product and requires a paid license for possession or use.' +
                ' Syncfusion’s licensed software, including this component, is subject to the terms and ' +
                'conditions of Syncfusion' + 's [EULA](https://www.syncfusion.com/eula/es/). ' +
                'To acquire a license, you can [purchase](https://www.syncfusion.com/sales/products) or ' +
                '[start a free 30-day trial](https://www.syncfusion.com/account/manage-trials/start-trials).\n\n' +

                '> A [free community license](https://www.syncfusion.com/products/communitylicense) is also available for companies and ' +
                'individuals whose organizations have less than $1 million USD in annual gross revenue and five or fewer developers.\n\n' +

                `   © Copyright ${new Date().getFullYear().toString()} Syncfusion, Inc. All Rights Reserved. 
    The Syncfusion Essential Studio license and copyright applies to this distribution.`;
            fs.writeFileSync('./ej2-' + themeName + '/README.md', ReadME);
            common.EJThemesPublish(path, done, isLast);
        }
    }
}
exports.generateStylesPackages = generateStylesPackages;

// publish the styles themewise
gulp.task('ej2-publish-styles', function (done) {
    for (var i = 0; i < themes.length; i++) {
        var isLast = i === themes.length - 1;
        generateStylesPackages(themes[i], done, isLast);
    }
});

// Shipping source to blazor-soure repo
gulp.task('blazor-library-scripts', function (done) {
    var wrapperScripts = common.config().blazorWrapperScripts;
    
    // Define excluded packages
    var excludedPackages = ['ej2-base', 'ej2-pdf', 'ej2-excel-export', 'ej2-pdf-export', 'ej2-ribbon', 'ej2-markdown-converter'];
    
    // Check if current package is NOT in excluded list
    if (excludedPackages.indexOf(common.currentPackage) === -1) {
        if (fs.existsSync('./dist/global/')) {
            var gitClonePath = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-blazor-source';
            var blazorClone = shelljs.exec('git clone ' + gitClonePath + ' -b ' + branch + ' ./blazor-source', { silent: true });
            if (blazorClone.code !== 0) {
                done();
                return;
            }
            else {
                var blazorPath = `./blazor-source/Scripts/modules`;
                shelljs.mkdir('-p', blazorPath);
                var currentPackage = common.currentPackage.replace('ej2', '').replace(/-/g, '');
                if(wrapperScripts.indexOf(currentPackage) !== -1){
                    // copy global file to blazor source
                    var scriptContent = fs.readFileSync(`./dist/global/blazor/${currentPackage}.js`, 'utf8');
                    fs.writeFileSync(`${blazorPath}/${currentPackage}.js`, scriptContent);
                    shelljs.cd(`./blazor-source`);
                    shelljs.exec('git add .');
                    shelljs.exec('git pull');
                    shelljs.exec('git commit -m \"ci-skip(EJ2-000): Source shipping from ' + common.currentPackage + '\" --no-verify');
                    shelljs.exec('git push');
                    shelljs.cd('../');
                }
                else{
                    var scriptFilePath = `./dist/global/blazor/${currentPackage}.js`;
                    if (fs.existsSync(scriptFilePath)) {
                        throw new Error(`Invalid scripts found: ${currentPackage}. Scripts must be either in wrapperScripts or contain 'sf-' prefix.`);
                    } 
                }
            }
        }
    }
    done();
});