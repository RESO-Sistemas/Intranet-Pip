'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var common = global.config = global.config || require('../utils/common.js');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
var fs = global.fs = global.fs || require('fs');
var config = common.config();
var changelogObj = require('../../src/third-party/changelog.js');

gulp.task('angular-checkout', function (done) {
    common.checkout('angular', 'angular', done);
});


gulp.task('aot-scripts', function (done) {
    var build = require('../tasks/build');
    var tsConfigs = {
        module: 'amd'
    };
    var gulpObj = {
        src: config.ts,
        dest: './aot/amd',
        base: '.'
    };
    return build.compileTSFiles(tsConfigs, gulpObj, done);
});


gulp.task('angular-generate', function (done) {
    var srcGen = require('../third-party/angular/src-generator.js');
    var propGen = require('../third-party/shared/property-reader');
    var propCollection = propGen(JSON.parse(fs.readFileSync('./public/api/file.json')));
    shelljs.cp('./third-party/readme/angular.md', './third-party/angular/README.md');
    if (fs.existsSync('./CHANGELOG.md')) {
        var mdContent = changelogObj.changelog('./CHANGELOG.md', './third-party/changelog/angular.md');
        fs.writeFileSync('./third-party/angular/CHANGELOG.md', mdContent);
    }
    var themesList = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
    themesList = themesList.themes;
    var thirdpartyConfig = JSON.parse(fs.readFileSync('./third-party/angular/config.json', 'utf8'));
    thirdpartyConfig.themes = themesList;
    fs.writeFileSync('./third-party/angular/config.json', JSON.stringify(thirdpartyConfig), 'utf8');
    srcGen(JSON.parse(fs.readFileSync('./third-party/config.json')), propCollection, done);
});

gulp.task('angular-configure', function (done) {
    common.thridPartyConfigure('angular', 'angular');
    done();
});

gulp.task('schematics-build', function (done) {
    shelljs.rm('-rf', './node_modules/@syncfusion/ej2-build-test/node_modules/');
    var build = require('./build');
    var gulpObj = {
        src: ['schematics/**/*.ts', '!schematics/generators/*/samples/**/*.ts', '!schematics/generators/template/**/*.ts'],
        dest: 'schematics',
        base: 'schematics',
        needDts: true
    };
    return build.compileTSFiles({}, gulpObj, 'schematics/tsconfig.json', done);
});

gulp.task('schematics-generator', function (done) {
    var path = require('path');
    var currentPkg = require(path.resolve(__dirname, '../../../../../schematics/utils/lib-details'));
    var generator = require(path.resolve(__dirname, '../../../ej2-angular-base/schematics/generators/index'));

    if (generator && generator.emitSampleFiles && currentPkg) {
        generator.emitSampleFiles(currentPkg.pkgName);
    } else {
        console.log('\x1b[33m%s\x1b[0m', `ERROR: Schematics samples generation is stopped, either dependency ` +
            `ej2-angular-base doesn't have generator module or schematics files aren't generated for current angular ` +
            `component package.`);
    }
    // schematicsRemoveSamples();
    done();
});

gulp.task('schematics-copy-samples', function (done) {
    var fsExtra = require('fs-extra');
    var path = require('path');

    var sampleSource = path.resolve(__dirname, '../../../../../schematics-samples');
    var sampleDestRoot = path.resolve(__dirname, '../../../../../third-party/angular');
    var sampleEmitPath = path.resolve(`${sampleDestRoot}/ej2-angular-samples`);

    if (fsExtra.existsSync(sampleSource) && fsExtra.existsSync(sampleDestRoot)) {
        fsExtra.copySync(sampleSource, sampleEmitPath);
    }
    done();
});

gulp.task('schematics-remove-samples', function (done) {
    schematicsRemoveSamples();
    done();
});

function schematicsRemoveSamples() {
    var fsExtra = require('fs-extra');
    var path = require('path');

    var sampleDest = path.resolve(__dirname, '../../../../../ej2-angular-samples');
    if (fsExtra.existsSync(sampleDest)) {
        fsExtra.removeSync(sampleDest);
    }
}

gulp.task('schematics-versioning', function (done) {
    if (fs.existsSync('./third-party/angular/package.json')) {
        fs.readFile('./third-party/angular/package.json', 'utf8', function (err, contents) {
            if (err) {
                console.log(err);
            } else {
                var pkgJSON = JSON.parse(contents);
                var pkgName = pkgJSON.name;
                var pkgVersion = pkgJSON.version;
                var configJSON = fs.existsSync('./third-party/config.json') ?
                    JSON.parse(fs.readFileSync('./third-party/config.json')) : {};
                var moduleName = '';

                for (var i = 0; i < configJSON.components.length; i++) {
                    if (configJSON.components && configJSON.components[i].baseClass) {
                        moduleName = moduleName + configJSON.components[i].baseClass + 'Module, ';
                    }
                }
                moduleName = moduleName.replace(/,\s*$/, '');

                if (fs.existsSync('./third-party/angular/schematics/utils/lib-details.ts')) {
                    // Reading lib-details.ts
                    var libDetails = fs.readFileSync('./third-party/angular/schematics/utils/lib-details.ts').toString();
                    libDetails = libDetails.replace('{{packageName}}', pkgName);
                    libDetails = libDetails.replace('{{packageVersion}}', pkgVersion);
                    libDetails = libDetails.replace('{{moduleName}}', moduleName);
                    libDetails = libDetails.replace('{{themeVersion}}', pkgVersion);

                    // Writing package details in lib-details.ts
                    var writeStream = fs.createWriteStream('./third-party/angular/schematics/utils/lib-details.ts');
                    writeStream.write(libDetails);
                    writeStream.end();
                }
                done();
            }
        });
    }
});

// Ex: gulp schematics-versioning-release --version 16.2.46 --theme 16.3.21
gulp.task('schematics-versioning-release', function (done) {
    if (fs.existsSync('./schematics/utils/lib-details.js')) {
        var libDetails = fs.readFileSync('./schematics/utils/lib-details.js').toString();
        libDetails = libDetails.replace(/pkgVer = '.*?'\;/i, `pkgVer = \'${process.argv[4]}\'\;`);
        libDetails = libDetails.replace(/themeVer = '.*?'\;/i,
            `themeVer = \'${process.argv[6] ? `~${process.argv[6]}` : 'latest'}\'\;`);
        // Writing package details in lib-details.js
        var writeStream = fs.createWriteStream('./schematics/utils/lib-details.js');
        writeStream.write(libDetails);
        writeStream.end();
        done();
    } else {
        done();
    }
});

gulp.task('copy-ng-code-block', function (done) {
    if (fs.existsSync('./api-code-blocks/angular/')) {
        shelljs.mkdir('-p', `./third-party/angular/api-code-blocks`);
        shelljs.cp('-r', `./api-code-blocks/angular`, `./third-party/angular/api-code-blocks`);
        done();
    }
    else {
        done();
    }
});

gulp.task('angular-build', function (done) {
    runSequence('angular-checkout', 'angular-configure', 'angular-generate', 'schematics-versioning',
        'schematics-copy-samples', 'copy-ng-code-block', done);
});
