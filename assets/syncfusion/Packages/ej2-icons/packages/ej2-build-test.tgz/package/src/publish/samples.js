'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var config = common.config();
var gzip = require('gulp-gzip');
var shelljs = require('shelljs');
var cdn = require('./cdn.js');
var fs = require('fs');

/**
 * publish sample browser 
 */

gulp.task('publish-samples', function (done) {
    var mapping = {
        'ng': 'angular', 'react': 'react', 'javascript': 'javascript', 'ts': 'typescript',
        'angular': 'angular', 'vue': 'vue'
    };
    var hotfixVersion;
    var isMaster = common.isMasterBranch;
    var isHotFix = common.isReleaseBranch ? common.isReleaseBranch : common.isHotfixBranch;
    if (isHotFix) {
        hotfixVersion = process.env.githubSourceBranch.split('/')[1].replace(/_.*/g, '');
    }
    var demoPath = isMaster ? './production/demos' : './development/demos';
    demoPath = isHotFix ? './hotfix/' + hotfixVersion + '/demos' : demoPath;
    var platforms = Object.keys(mapping);
    var platformName;
    if (config.isShowCase) {
        var currentPlatformName = common.currentPackage.split('-')[1];
        var showcasePath = common.currentPackage.replace(/-/g, '').replace('ej2' + currentPlatformName, '');
        platformName = mapping[currentPlatformName] + '/' + showcasePath;
        demoPath = isMaster ? `./production/showcase/${platformName}` : `./development/showcase/${platformName}`;
        demoPath = isHotFix ? `./hotfix/${hotfixVersion}/${platformName}` : demoPath;
    }
    else {
        for (var i = 0; i < platforms.length; i++) {
            if (common.currentPackage === `ej2-${platforms[i]}-samples`) {
                platformName = mapping[platforms[i]];
                demoPath = isMaster ? `./production/${platformName}/demos` : `./development/${platformName}/demos`;
                demoPath = isHotFix ? `./hotfix/${hotfixVersion}/${platformName}/demos` : demoPath;
            }
        }
    }
    shelljs.mkdir('-p', demoPath);
    config.publishSamples.push('!' + demoPath + '/**', '!' + demoPath);
    var prefixName = demoPath.split('./')[1];
    var content = '<h1> 404 - Not Found </h1>';
    fs.writeFileSync('./error.html', content);
    if (fs.existsSync('./index.html') && !isHotFix) {
        var filecontent = fs.readFileSync('./index.html', 'utf8');
        var embedLink = 'https://syncfusion.atlassian.net/s/d41d8cd98f00b204e9800998ecf8427e-T' +
            '/tu9duo/b/c/7ebd7d8b8f8cafb14c7b0966803e5701/_/download/batch/' +
            'com.atlassian.jira.collector.plugin.jira-issue-collector-plugin:issuecollector/' +
            'com.atlassian.jira.collector.plugin.jira-issue-collector-plugin:issuecollector.js?locale=en-US&collectorId=b1db4791';
        var embedScript = '<script type="text/javascript" src="' + embedLink + '"></script>\n';
        filecontent = filecontent.replace('</head>', embedScript + '</head>');
        fs.writeFileSync('./index.html', filecontent);
    }
    gulp.src(config.publishSamples)
        .pipe(gzip({ append: false }))
        .pipe(gulp.dest(demoPath))
        .on('end', function () {
            cdn.publish(demoPath, false, prefixName, done);
        })
        .on('error', function (e) {
            done(e);
        });
});
