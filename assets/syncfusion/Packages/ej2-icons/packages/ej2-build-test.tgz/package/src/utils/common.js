'use strict';

var fs = global.fs = global.fs || require('fs');
var shelljs = global.shelljs = global.shelljs || require('shelljs');

function shellDone(exitCode) {
    if (exitCode !== 0) {
        process.exit(1);
    }
}
exports.shellDone = shellDone;

/* jshint ignore:start */

// Function to get the IST Date and Time from any location.
function getDateAndTime(time) {
    var dateOptions = {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    };
    var date = time ? new Date(time) : new Date();
    return date.toLocaleString('en-US', dateOptions).toString();
}
exports.getDateAndTime = getDateAndTime;

async function postTestData(data) {
    const fetch = require('node-fetch');
    const authenticationAPIURL = 'https://testresults.syncfusion.com:449/api/Authentication/Authentication';
    const updateTestResultsAPIURL = 'https://testresults.syncfusion.com:449/api/UpdateTestResult/UpdateCentralizedTestResults/';
    let secretKey = '';
    const licenseToken = {
        clientId: process.env.BUILD_CLIENT_ID,
        clientSecret: process.env.BUILD_SECRET_KEY
    };
    try {
        if (process.env.BUILD_CLIENT_ID !== undefined && process.env.BUILD_SECRET_KEY !== undefined) {
            const authenticationResponse = await fetch(authenticationAPIURL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(licenseToken)
            });
            secretKey = JSON.parse(await authenticationResponse.text());
            if (authenticationResponse.status === 200) {
                var platform_Name = data.repositoryName.indexOf('blazor') !== -1 ? "Blazor" : "JavaScript - EJ2";
                const testResult = `{\"platformName\": \"${platform_Name}\", \"controlName\": \"${data.component}\", \"project\": \"${data.repositoryName}\",
                 \"tags\": \"${data.category}\", \"testingToolName\": \"Selenium\", \"testcaseStartTime\": \"${data.startTime}\", \"testcaseEndTime\": \"${data.endTime}\",
                  \"testcaseStatus\": \"${data.Status}\", \"totalTestcaseCount\": ${data.TotalSpec}, \"successCount\": ${data.PassedSpec},
                   \"failureCount\": ${data.FailedSpec}, \"notRunCount\": ${data.IgnoredSpec}, \"testRunName\": \"E2E Testing Automation\",
                    \"testRunLink\": \"${data.jobLink}\", \"branch\": \"${data.branch}\", \"updateBy\": \"buildautomation@syncfusion.com\", \"version\": \"${data.version}\",
                     \"secretKey\": \"\\\"${secretKey}\\\"\"}`;
                console.log('testResult', testResult);
                const updateTestResultsResponse = await fetch(updateTestResultsAPIURL, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: testResult
                });
                const returnStatusMessage = await updateTestResultsResponse.text();
                if (updateTestResultsResponse.status === 200) {
                    console.log(returnStatusMessage);
                } else {
                    console.log('Failure in updating test results: ' + returnStatusMessage);
                }
            } else {
                console.log('Authentication Failure');
            }
        }
    } catch (error) {
        console.log(error);
    }
}
exports.postTestData = postTestData;

/* jshint ignore:end */


/**
 * override config.json  
 */
exports.config = function () {
    var localConfig = require('../../config.json');
    var rootConfig = require(fs.realpathSync('./config.json'));
    var result = Object.assign(localConfig, rootConfig);
    result.themes = ['material', 'fabric', 'bootstrap',
        'highcontrast', 'material-dark', 'fabric-dark', 'bootstrap-dark',
        'highcontrast-light', 'bootstrap4', 'bootstrap5-dark', 'tailwind', 'tailwind-dark',
        'fluent', 'fluent-dark', 'material3', 'material3-dark', 'fluent2', 'bootstrap5.3', 'tailwind3', 'bds'];
    return result;
};

/**
 * get current repository name 
 */
var currentRepo = shelljs.exec('git config --get remote.origin.url', {
    silent: true
})
    .stdout.split('essential-studio/')[1].replace('.git', '').replace('/', '').trim();
exports.currentRepo = currentRepo;

/**
 * get current package name 
 */
var pack = fs.readFileSync('./package.json', 'utf8');
var json = JSON.parse(pack);
var currentPackage = function () {
    return json.name.replace('@syncfusion/', '');
};
exports.currentPackage = currentPackage();

var hostName = shelljs.exec('hostname', {
    silent: true
}).stdout;
exports.hostName = hostName;
var isRemoteServer = hostName.indexOf('syncdesk') === -1;
exports.isRemoteServer = isRemoteServer;

/**
 * get current package version 
 */
var currentVersion = function () {
    return json.version;
};
exports.currentVersion = currentVersion();

/**
 * get regex templates  
 */
var regexp = {
    BUG: /^bug(\(([A-Za-z0-9]+[-][0-9]*)\))?\: /,
    CI_SKIP: /^ci-skip(\(([A-Za-z0-9]+[-][0-9]*)\))?\: /,
    COMMIT_TYPES: /^(bug|config|documentation|feature|sample|ci-skip)(\(([A-Za-z0-9]+[-][0-9]*)\))?\: (.*)$/,
};
exports.regexp = regexp;

/**
 * get last valid commit message and release version  
 */
exports.getCommitDetails = function (log) {
    var version = 'minor';
    var validCommit = log.latest.message,
        prevCommit = null,
        i = 0,
        Id = log.latest.hash;
    while (checkCommitMessage(prevCommit, validCommit) && log.all.length !== i && currentRepo !== 'ej2') {
        prevCommit = log.all[i - 1] ? log.all[i - 1].message : prevCommit;
        validCommit = log.all[i].message;
        i++;
    }
    console.log('Commit Message: ' + validCommit);
    if (RegExp(regexp.BUG).test(validCommit)) {
        version = 'patch';
    }
    var logs = {
        release: version,
        lastCommit: validCommit,
        commitId: Id
    };
    return logs;
};

function checkCommitMessage(prevMessage, currentMessage) {
    return (!RegExp(regexp.COMMIT_TYPES).test(currentMessage) ||
        (RegExp('^Merge ').test(prevMessage) && RegExp(regexp.CI_SKIP).test(currentMessage)));
}

exports.stagingBranch = process.env.STAGING_BRANCH;

var isMasterBranch = process.env.githubSourceBranch === 'master';
exports.isMasterBranch = isMasterBranch;

var isReleaseBranch = /^((release\/))/g.test(process.env.githubSourceBranch);
exports.isReleaseBranch = isReleaseBranch;

var isHotfixBranch = /^((hotfix\/))/g.test(process.env.githubSourceBranch);
exports.isHotfixBranch = isHotfixBranch;

var isDevBranch = process.env.githubSourceBranch === 'development';
exports.isDevBranch = isDevBranch;

var isProtectedBranch = isMasterBranch || isReleaseBranch || isHotfixBranch || isDevBranch;
exports.isProtectedBranch = isProtectedBranch;

exports.checkout = function (prefix, product, done) {
    var user = 'SyncfusionAutomation';
    var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
    if (user && token) {
        if (prefix === 'asp-core') {
            clone(user, token, done, 'ej2-' + prefix, product);
        } else if (prefix === 'blazor') {
            clone(user, token, done, 'ej2-' + prefix + '-source', product);
        } else {
            clone(user, token, done, 'ej2-' + prefix + '-template', product);
        }
    } else {
        const readline = require('readline');
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        rl.question('Git Lab UserName:', (userName) => {
            rl.question('Git Lab Password:', (pwd) => {
                rl.close();
                if (prefix === 'asp-core') {
                    clone(userName, pwd, done, 'ej2-' + prefix, product);
                } else if (prefix === 'blazor') {
                    clone(userName, pwd, done, 'ej2-' + prefix + '-source', product);
                } else {
                    clone(userName, pwd, done, 'ej2-' + prefix + '-template', product);
                }
            });
        });
    }
};

function clone(user, token, done, name, product) {
    var shelljs = global.shelljs = global.shelljs || require('shelljs');
    token = token.replace('@', '%40');
    var tempRepo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/' + name;
    if (product === 'angular') {
        shelljs.exec(
            'git clone ' + tempRepo + ' -b ' + '866077-Ivy-dev' + ' ./third-party/' + product, {
            silent: false
        },
            function () {
                console.log('Clone has been completed!');
                done();
            }
        );
    }
    else if (product === 'react' || product === 'vue') {
        shelljs.exec(
            'git clone ' + tempRepo + ' -b ' + '867921-update-dev' + ' ./third-party/' + product, {
            silent: false
        },
            function () {
                console.log('Clone has been completed!');
                done();
            }
        );
    } else {
        shelljs.exec(
            'git clone --filter=blob:none ' + tempRepo + '.git' + ' ./third-party/' + product, {
            silent: false
        },
            function () {
                console.log('Clone has been completed!');
                done();
            }
        );
    }
}
exports.clone = clone;
exports.thridPartyConfigure = function (product, prefix) {
    var libInfo = JSON.parse(fs.readFileSync('./third-party/config.json').toString());
    var localConfig = JSON.parse(fs.readFileSync('./config.json').toString());
    var packInfo = JSON.parse(fs.readFileSync('./package.json').toString());
    var descriptionMapper = {
        angular: 'Angular',
        react: 'React',
        vue: 'Vue'
    };
    var packPath = './third-party/' + product + '/package.json';
    var confPath = './third-party/' + product + '/config.json';
    var splitup, keywords;

    if (typeof libInfo.keywords === 'string') {
        keywords = libInfo.keywords;
        splitup = keywords.split(',').join('","');
    } else {
        keywords = [].concat(libInfo.keywords.common);
        if (product === 'react') {
            keywords = [].concat(libInfo.keywords.react);
        }
        if (product === 'angular') {
            keywords = [].concat(libInfo.keywords.angular);
        }
        if (product === 'vue') {
            keywords = [].concat(libInfo.keywords.vue);
        }
        splitup = keywords.join('","');
    }

    var packContent = fs.readFileSync(packPath).toString();
    var confContent = fs.readFileSync(confPath).toString();
    packContent = packContent.replace(/0.0.0/g, packInfo.version);
    packContent = packContent.replace(/{{description}}/g, packInfo.description + ' for ' + descriptionMapper[product]);
    packContent = packContent.replace(/{{reponame}}/g, 'ej2-' + prefix + '-' + libInfo.name.toLowerCase());
    packContent = packContent.replace(/{{dependentrepo}}/g, packInfo.name);
    packContent = packContent.replace(/{{keywords}}/g, '["' + splitup + '"]');
    packContent = packContent.replace(/{{repo}}/g, JSON.stringify(libInfo.repository));
    fs.writeFileSync(packPath, packContent);
    var curRepoName = packInfo.name.split('/')[1];
    if (typeof localConfig.styleDependency[0] === 'object') {
        var result = [];
        for (var i = 0; i < localConfig.styleDependency.length; i++) {
            var key = Object.keys(localConfig.styleDependency[i])[0];
            result.push('{"' + key + '": ["' + curRepoName + '/' + key + '"]}');
        }
        confContent = confContent.replace(/{{styleDependency}}/g, result.join(', '));
    } else if (localConfig.styleDependency === 'none') {
        confContent = confContent.replace(/\[{{styleDependency}}\]/g, '"none"');
    } else {
        confContent = confContent.replace(/{{styleDependency}}/g, '"' + curRepoName + '"');
    }
    fs.writeFileSync(confPath, confContent);
};
exports.extend = extend;

function extend(copied, first, second, deep) {
    var result = copied || {};
    var length = arguments.length;
    if (deep) {
        length = length - 1;
    }
    var _loop_1 = function (i) {
        if (!arguments_1[i]) {
            return 'continue';
        }
        var obj1 = arguments_1[i];
        Object.keys(obj1).forEach(function (key) {
            var src = result[key];
            var copy = obj1[key];
            var clone;
            if (deep && isObject(copy)) {
                clone = isObject(src) ? src : {};
                result[key] = extend({}, clone, copy, true);
            } else {
                result[key] = copy;
            }
        });
    };
    var arguments_1 = arguments;
    for (var i = 1; i < length; i++) {
        _loop_1(i);
    }
    return result;
}

function isObject(obj) {
    var objCon = {};
    return (!isNullOrUndefined(obj) && obj.constructor === objCon.constructor);
}

function isNullOrUndefined(value) {
    return value === undefined || value === null;
}

function EJJavascriptPublish() {
    if (fs.existsSync('./ej2-js-es5')) {
        shelljs.cd('./ej2-js-es5');
        var jsPublish = process.env.githubSourceBranch === 'master' ? 'production-registry' : 'dev-registry';
        jsPublish = isReleaseBranch ? 'release-registry' : jsPublish;
        jsPublish = isHotfixBranch ? 'hotfix-registry' : jsPublish;
        var runSequence = require('gulp4-run-sequence');
        runSequence(jsPublish);
        shelljs.exec('npm publish', function () {
            shelljs.cd('../');
        });
    }
}
exports.EJJavascriptPublish = EJJavascriptPublish;

function EJVuePublish() {
    if (fs.existsSync('./ej2-vue-es5')) {
        shelljs.cd('./ej2-vue-es5');
        var vuePublish = process.env.githubSourceBranch === 'master' ? 'production-registry' : 'dev-registry';
        vuePublish = isReleaseBranch ? 'release-registry' : vuePublish;
        vuePublish = isHotfixBranch ? 'hotfix-registry' : vuePublish;
        var runSequence = require('gulp4-run-sequence');
        runSequence(vuePublish);
        shelljs.exec('npm publish', function () {
            shelljs.cd('../');
        });
    }
}
exports.EJVuePublish = EJVuePublish;

function getReleaseVersion(version) {
    version = version.split('.');
    version.splice(2, 1);
    return version.join('.');
}

exports.getReleaseVersion = getReleaseVersion;

function EJThemesPublish(path, done, isLast) {
    if (fs.existsSync(path)) {
        shelljs.cd(path);
        var stylesPublish = '/ej2-development';
        stylesPublish = isReleaseBranch ? '/ej2-release' : stylesPublish;
        stylesPublish = isHotfixBranch ? '/ej2-hotfix-new' : stylesPublish;
        var npmrcContent = `registry=https://registry.npmjs.org/
        @syncfusion:registry=https://nexus.syncfusioninternal.com/repository/ej2-development/
        //nexus.syncfusioninternal.com/repository/ej2-development/:username=ej2
        //nexus.syncfusioninternal.com/repository/ej2-development/:_password=ZWoyY29yZW5wbQ==
        //nexus.syncfusioninternal.com/repository/ej2-development/:email=pipeline@syncfusion.com
        //nexus.syncfusioninternal.com/repository/ej2-development/:always-auth=true`;
        fs.writeFileSync('./.npmrc', npmrcContent.replace(/\/ej2-development/g, stylesPublish));
        shelljs.exec('npm publish');
        shelljs.cd('../');
        if (isLast) {
            done();
        }
    } else {
        shelljs.cd('../');
        if (isLast) {
            done();
        }
    }
}
exports.EJThemesPublish = EJThemesPublish;
