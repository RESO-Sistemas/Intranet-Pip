'use strict';

var apiGenerator = require('./api-generator');

var fs = global.fs || require('fs');
var config = fs.existsSync('../../config.json') ? JSON.parse(fs.readFileSync('../../config.json')) : {};
var components = config.components;
var glob = require('glob');
var dirRegex = /Directive|Component/i;
var compRegex = /Component/i;
var typeMatcher = ['Enumeration', 'Interface', 'Variable'];
var curPath = '';
var currModuleName = '';
var apiCollArray = {};
var indexCollectionObj = {};
var prChild = [];
var h1 = '# ';
var finalMapper = {
    'Component': 'Components',
    'Directive': 'Directives'
};
var apiThead = '\n| Name | Description |\n|------|-------------|';
var isUpdated = false;
var mdFiles = [];
var vueCompContent = {};

if (fs.existsSync('../vueComp.json')) {
    vueCompContent = JSON.parse(fs.readFileSync('../vueComp.json'));
}

function generateVueApi(path) {
    apiGenerator.generateApi(path, 'vue');
    if (components) {
        curPath = path;
        var apiFileJson = JSON.parse(fs.readFileSync('./public/api/file.json'));
        var children = apiFileJson.children;
       
        for (var child of children) {
            currModuleName = getCurrModName(child);
            if (currModuleName.length && !apiCollArray[currModuleName]) {
                apiCollArray[currModuleName] = {
                    Component: '',
                    Directive: ''
                };
            }
            if (!currModuleName) {
                continue;
            }
            if (child.children) {
                for (var childs of child.children) {
                    if (childs.defaultValue && childs.defaultValue.includes('vueDefineComponent') && dirRegex.test(child.name)) {
                        prChild = [childs];
                        processChild(prChild);
                    }
                }
            }
        }
        for (var x = 0; x < components.length; x++) {
            if (!indexCollectionObj[components[x]]) {
                indexCollectionObj[components[x]] = '';
            }
            var loc = '../../ej2-docs/src/' + components[x] + '/';
            if (fs.existsSync(loc) && fs.existsSync('./ej2-docs/src/' + components[x])) {
                var componentFile = apiGenerator.replaceSubLimeText(components[x]);
                mdFiles = glob.sync(loc + '*.md', {
                    silent: true,
                    ignore: [loc + 'api.md',loc + 'summary.md',loc+componentFile+'.md',loc+'index.md']
                });
                for (var i = 0; i < mdFiles.length; i++) {
                    var lname = mdFiles[i].slice(mdFiles[i].lastIndexOf('/') + 1, mdFiles[i].lastIndexOf('.'));
                    if (lname !== 'overview') {
                        var name = lname[0].toUpperCase() + lname.substring(1);
                        indexCollectionObj[components[x]] += '\n* [' + name + '](' + components[x] + '/' + lname + ')';
                    }
                }
            }
        }
        for (var api in apiCollArray) {
            var content = '';
            var collection = apiCollArray[api];
            for (var type in collection) {
                if (collection[type].length) {
                    content += '\n## ' + finalMapper[type] + '\n' + apiThead + collection[type] + '\n';
                }
            }
            if (content.length) {
                content = '# API\n' + content;
                createFile(api, 'overview', content, true);
                createFile(api, 'summary', apiGenerator.overviewTemplate.replace(/{{:compFolder}}/, api) +
                    indexCollectionObj[api].slice(1), true);
            }
        }
        return isUpdated;
    }
}
exports.generateVueApi = generateVueApi;


function getCurrModName(children) {
    var bName = children.name.replace(/"/g, '').split('/')[0];
    return components.indexOf(bName) !== -1 ? bName : '';
}

function createFile(modName, fName, fileContent, previousChange) {
    var modPath = curPath + modName;
    if (!fs.existsSync(modPath)) {
        return;
    }
    isUpdated = true;
    if(apiGenerator.isCurrentModuleFile(modName + 'component',fName )){
        fName = 'index';
    }
    fs.writeFileSync(modPath + '/' + apiGenerator.convertToLower(fName, previousChange) + '.md', fileContent, 'utf8');
}

function processChild(children) {
    for (var curProp of children) {
        var name = curProp.name;
        var kindString = curProp.kindString;
        var decorator = compRegex.test(curProp.sources[0].fileName.match(dirRegex)[0]) ? 'Component' : 'Directive';
        if (decorator === 'Component' && typeMatcher.indexOf(kindString) !== -1 && curProp.flags.isExported &&
            vueCompContent[currModuleName] && vueCompContent[currModuleName][name]) {
            var topMessage = apiGenerator.getMessageText(curProp);
            // var description = topMessage.split('.');
            // if(description.length){
            //     description = description[0] +'.';
            // } else {
            //     description = '';
            // }
            var topComment = h1 + name + '\n' + (topMessage.length ? '\n' + topMessage + '\n' : '');
            createFile(currModuleName, name, topComment + vueCompContent[currModuleName][name], false);
            var lname = apiGenerator.convertToLower(name);
            var shortText = apiGenerator.getMessageText(curProp, true);
            var curText = apiGenerator.getTableText(shortText);
            if (curText.length) {
                var moName = (apiGenerator.isCurrentModuleFile(currModuleName + 'component', name) ?
                    '' : ( lname+'/'));
                apiCollArray[currModuleName][decorator] += '\n| [' + name + '](./' + moName + ')| ' + curText + '|';
            }
            if(! indexCollectionObj[currModuleName]) {
                indexCollectionObj[currModuleName] = '';
            }
            if(!apiGenerator.isCurrentModuleFile(currModuleName + 'component', name )){
                indexCollectionObj[currModuleName] += '\n* [' + name + '](' + currModuleName + '/' + lname + ')';
            }
        }
    }
}
