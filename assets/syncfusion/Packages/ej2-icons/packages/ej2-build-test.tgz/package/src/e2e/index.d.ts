import { ProtractorBrowser, promise } from 'protractor';

/**
  * Extended Protractor Browser
  */
export interface ProtractorTypes extends ProtractorBrowser {
    basePath: string;
    test: (path: string, callback: Function) => void;
}

export interface HTMLCSRunner {
    run: Function;
}

export declare let browser: ProtractorTypes;


export * from "protractor";
