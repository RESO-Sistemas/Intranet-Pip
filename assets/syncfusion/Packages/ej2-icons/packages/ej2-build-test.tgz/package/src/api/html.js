'use strict';
let fs = global.fs = global.fs || require('fs');
//generating html for changes in public APIs
class generateHTML {

    constructor(changes) {
        this.changes = changes;
        this.common = global.config = global.config || require('../utils/common.js');
    }

    //generating html table for JSON object
    generateHTMLTable(jsonObj) {
        if(!jsonObj){
            return;
        }
        let tableify = require('tableify');
        return tableify(jsonObj);
    }

    //initializing the html generation
    InitializeHtmlGeneration() {
        if (!this.changes) {
            return '';
        }
        let html = `<h1>${this.common.currentPackage}</h1>\r\n`;
        html = html.concat(this.changes.added.length > 0 ? this.generateModuleAnchorTags(this.changes.added, 'Added') : '');
        html = html.concat(this.changes.removed.length > 0 ? this.generateModuleAnchorTags(this.changes.removed, 'Removed') : '');
        html = html.concat(this.changes.updated.length > 0 ? `${this.generateModuleAnchorTags(this.changes.updated, 'Updated')}
        <hr width="100%" color="#5f97ef" size="4" >` : '');
        html = html.concat(this.changes.added.length > 0 ? this.generateObjAnchor(this.changes.added, 'Added') : '');
        html = html.concat(this.changes.removed.length > 0 ? this.generateObjAnchor(this.changes.removed, 'Removed') : '');
        html = html.concat(this.changes.updated.length > 0 ? this.generateObjAnchor(this.changes.updated, 'Updated') : '');
        let style = fs.readFileSync(__dirname + '/style.html', 'utf8');
        html = html.concat(style);
        return html;
    }

    generateModuleAnchorTags(modules, type) {
        if (!modules || !type) {
            return;
        }
        let heading = `<h2>${type}</h2>\r\n`;
        let modulhtml = '';
        let anchor = `<ul>\r\n`;
        for (let modul of modules) {
            if (modul && modul.ModuleName && !/-model.d/.test(modul.ModuleName)) {
                anchor = anchor.concat(`<li><a href = "#${modul.ModuleName}">${modul.ModuleName}</a></li>\r\n`);
            }
        }
        return heading + anchor.concat(`</ul>\r\n`) + modulhtml;
    }

    //generating html for changed mpdules
    generateObjAnchor(modules, type) {
        if (!modules || !type) {
            return;
        }
        let modulehtml = '';
        for (let modul of modules) {
            if (/-model.d/.test(modul.ModuleName)) {
                continue;
            }
            modulehtml = modulehtml.concat(`<h3 id = "${modul.ModuleName}">${modul.ModuleName}</h3>\r\n`);
            if (type !== 'Updated') {
                //generating html with anchor added/removed module
                modulehtml = modulehtml.concat(
                    `${modul.Classes && modul.Classes.length > 0 ? 
                        `<h4>Classes</h4>\r\n${this.generateAnchors(modul.Classes, 'Class', modul.ModuleName)}` : ''}
                    ${modul.Interfaces && modul.Interfaces.length > 0 ? 
                        `<h4>Interfaces</h4>\r\n${this.generateAnchors(modul.Interfaces, 'Interface', modul.ModuleName)}` : ''}
                    ${modul.Methods && modul.Methods.length > 0 ? 
                        `<h4>Methods</h4>\r\n${this.generateAnchors(modul.Methods, 'Method', modul.ModuleName)}` : ''}
                    ${modul.Classes && modul.Classes.length > 0 ? 
                        `${this.generateCIObjHTML(modul.Classes, 'Class', !modul.Classes.added, modul.ModuleName)}
                        <hr width="100%" color="#4e7abf" size="2" >` : ''}
                    ${modul.Interfaces && modul.Interfaces.length > 0 ? 
                        `${this.generateCIObjHTML(modul.Interfaces, 'Interface', !modul.Interfaces.added, modul.ModuleName)}
                        <hr width="100%" color="#4e7abf" size="2" >` : ''}`);
            }
            else {
                //generating anchor tag for updated module
                modulehtml = modulehtml.concat(
                    `${modul.Classes ? this.generateClassAnchors(modul.Classes, modul.ModuleName) : ''}
                     ${modul.Interfaces ? this.generateInterfaceAnchors(modul.Interfaces, modul.ModuleName) : ''}
                     ${modul.Properties ? this.generateMPropAnchors(modul.Properties, modul.ModuleName) : ''}
                     ${modul.Methods ? this.generateMMethoAnchors(modul.Methods, modul.ModuleName) : ''}`);
                //generating html for updated module
                modulehtml = modulehtml.concat(
                    `${modul.Classes ? this.generateClassObjHTML(modul.Classes, modul.ModuleName) : ''}
                     ${modul.Interfaces ? this.generateInterfaceObjHTML(modul.Interfaces, modul.ModuleName) : ''}
                     ${modul.Properties ? this.generatePropObjHTML(modul.Properties, modul.ModuleName) : ''}
                    ${modul.Methods ? this.generateMethodObjHTML(modul.Methods, modul.ModuleName) : ''}`);
            }
        }
        return `${modulehtml}<hr width="100%" color="#4e7abf" size="3" >`;
    }

    //generating anchor tags
    generateAnchors(objects, type, parentname) {
        if (!objects || !type) {
            return;
        }
        let anchor = `<ul>\r\n`;
        for (let obj of objects) {
            anchor = anchor.concat(`<li><a href = "#${obj[`${type}Name`]}-${type}-${parentname}">${obj[`${type}Name`]}</a></li>\r\n`);
        }
        return anchor + `</ul>\r\n`;
    }

    //generating anchor tags for classes
    generateClassAnchors(classes, modulename) {
        if (!classes) {
            return '';
        }
        let anchorhtml = `${(classes.added && classes.added.length && classes.added.length > 0) || 
            (classes.removed && classes.removed.length && classes.removed.length > 0) || 
            (classes.updated && classes.updated.length && classes.updated.length > 0) ? `<h4>Classes</h4>\r\n` : ''}
             ${classes.added && classes.added.length && classes.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateAnchors(classes.added, 'Class', modulename)}` : ''}
             ${classes.removed && classes.removed.length && classes.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateAnchors(classes.removed, 'Class', modulename)}` : ''}
             ${classes.updated && classes.updated.length && classes.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateAnchors(classes.updated, 'Class', modulename)}` : ''}`;
        return anchorhtml;
    }

    //generating anchor tags for interfaces
    generateInterfaceAnchors(interfaces, modulname) {
        if (!interfaces) {
            return '';
        }
        let anchorhtml = `${(interfaces.added && interfaces.added.length && interfaces.added.length > 0)  || 
            (interfaces.removed && interfaces.removed.length && interfaces.removed.length > 0)  || 
            (interfaces.updated && interfaces.updated.length && interfaces.updated.length > 0) ? `<h4>Interfaces</h4>\r\n` : ''}
             ${interfaces.added && interfaces.added.length && interfaces.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateAnchors(interfaces.added, 'Interface', modulname)}` : ''}
             ${interfaces.removed && interfaces.removed.length && interfaces.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateAnchors(interfaces.removed, 'Interface', modulname)}` : ''}
             ${interfaces.updated && interfaces.updated.length && interfaces.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateAnchors(interfaces.updated, 'Interface', modulname)}` : ''}`;
        return anchorhtml;
    }

    //generating anchor tags for properties
    generateMPropAnchors(properties, modulname) {
        if (!properties) {
            return '';
        }
        let anchorhtml = `${(properties.added && properties.added.length && properties.added.length > 0) || 
            (properties.removed && properties.removed.length && properties.removed.length > 0) || 
            (properties.updated && properties.updated.length && properties.updated.length > 0) ? `<h4>Properties</h4>\r\n` : ''}
             ${properties.added && properties.added.length && properties.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateAnchors(properties.added, 'Property', modulname)}` : ''}
             ${properties.removed && properties.removed.length && properties.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateAnchors(properties.removed, 'Property', modulname)}` : ''}
             ${properties.updated && properties.updated.length && properties.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateAnchors(properties.updated, 'Property', modulname)}` : ''}`;
        return anchorhtml;
    }

    //generating anchor tags for methods
    generateMMethoAnchors(methods, modulname) {
        if (!methods) {
            return '';
        }
        let anchorhtml = `${(methods.added && methods.added.length && methods.added.length > 0) || 
            (methods.removed && methods.removed.length && methods.removed.length > 0) || 
            (methods.updated && methods.updated.length && methods.updated.length > 0) ? `<h4>Methods</h4>\r\n` : ''}
             ${methods.added && methods.added.length && methods.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateAnchors(methods.added, 'Method', modulname)}` : ''}
             ${methods.removed && methods.removed.length && methods.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateAnchors(methods.removed, 'Method', modulname)}` : ''}
             ${methods.updated && methods.updated.length && methods.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateAnchors(methods.updated, 'Method', modulname)}` : ''}`;
        return anchorhtml;
    }

    //generating html for classes
    generateClassObjHTML(classes, modulname) {
        if (!classes) {
            return '';
        }
        let cobjhtml = `${classes.added && classes.added.length && classes.added.length > 0  ? 
            this.generateCIObjHTML(classes.added, 'Class', !classes.added, modulname) : ''}
             ${classes.removed && classes.removed.length && classes.removed.length > 0 ? 
                this.generateCIObjHTML(classes.removed, 'Class', !classes.removed, modulname) : ''}
             ${classes.updated && classes.updated.length && classes.updated.length > 0 ? 
                this.generateCIObjHTML(classes.updated, 'Class', !classes.updated, modulname) : ''}`;
        return cobjhtml;
    }

    //generating html for interfaces
    generateInterfaceObjHTML(interfaces, modulname) {
        if (!interfaces) {
            return '';
        }
        let iobjhtml = `${interfaces.added && interfaces.added.length && interfaces.added.length > 0 ? 
            this.generateCIObjHTML(interfaces.added, 'Interface', !interfaces.added, modulname) : ''}
             ${interfaces.removed && interfaces.removed.length && interfaces.removed.length > 0 ? 
                this.generateCIObjHTML(interfaces.removed, 'Interface', !interfaces.removed, modulname) : ''}
             ${interfaces.updated && interfaces.updated.length && interfaces.updated.length > 0 ? 
                this.generateCIObjHTML(interfaces.updated, 'Interface', !interfaces.updated, modulname) : ''}`;
        return iobjhtml;
    }

    //generating html for properties
    generatePropObjHTML(mproperties, modulname) {
        if (!mproperties) {
            return '';
        }
        let pobjhtml = `${(mproperties.added && mproperties.added.length && mproperties.added.length > 0) || 
            (mproperties.removed && mproperties.removed.length && mproperties.removed.length > 0) || 
            (mproperties.updated && mproperties.updated.length && mproperties.updated.length > 0) ? `<h4>Properties</h4>\r\n` : ''}
             ${mproperties.added && mproperties.added.length && mproperties.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateObjHTML(mproperties.added, 'Property', modulname)}` : ''}
             ${mproperties.removed && mproperties.removed.length && mproperties.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateObjHTML(mproperties.removed, 'Property', modulname)}` : ''}
             ${mproperties.updated && mproperties.updated.length && mproperties.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateObjHTML(mproperties.updated, 'Property', modulname)}` : ''}`;
        return pobjhtml;
    }

    //generating html for methods
    generateMethodObjHTML(mmethods, modulname) {
        if (!mmethods) {
            return '';
        }
        let mobjhtml = `${(mmethods.added && mmethods.added.length && mmethods.added.length > 0) || 
            (mmethods.removed && mmethods.removed.length && mmethods.removed.length > 0) || 
            (mmethods.updated && mmethods.updated.length && mmethods.updated.length > 0) ? `<h4>Methods</h4>\r\n` : ''}
             ${mmethods.added && mmethods.added.length && mmethods.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateObjHTML(mmethods.added, 'Method', modulname)}` : ''}
             ${mmethods.removed && mmethods.removed.length && mmethods.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateObjHTML(mmethods.removed, 'Method', modulname)}` : ''}
             ${mmethods.updated && mmethods.updated.length && mmethods.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateObjHTML(mmethods.updated, 'Method', modulname)}` : ''}`;
        return mobjhtml;
    }

    generateCIObjHTML(objects, type, isaddremove, modulname) {
        if (!objects || !type || isaddremove === null || isaddremove === undefined) {
            return;
        }
        let objhtml = '';
        for (let obj of objects) {
            objhtml = objhtml.concat(`<h4 id = "${obj[`${type}Name`]}-${type}-${modulname}" >${obj[`${type}Name`]}</h4>\r\n`);
            if (isaddremove) {
                objhtml = objhtml.concat(
                    `${obj ? this.generateCIAddRemovAnchor(obj, `${obj[`${type}Name`]}-${modulname}`) : ''}
                    ${obj ? this.generateCIAddRemovObjHTML(obj, `${obj[`${type}Name`]}-${modulname}`) : ''}`);
            }
            else {
                if (obj.Properties.length >= 0 || obj.Methods.length >= 0 || obj.Events.length >= 0) {
                    objhtml = objhtml.concat(`${obj ? this.generateCIAddRemovAnchor(obj, `${obj[`${type}Name`]}-${modulname}`) : ''}`);
                }
                else {
                    objhtml = objhtml.concat(
                        `${obj.Properties ? this.generateCIPropAnchor(obj.Properties, `${obj[`${type}Name`]}-${modulname}`) : ''}
                         ${obj.Methods ? this.generateCIMethodAnchor(obj.Methods, `${obj[`${type}Name`]}-${modulname}`) : ''}
                         ${obj.Events ? this.generateCIEventAnchor(obj.Events, `${obj[`${type}Name`]}-${modulname}`) : ''}`);
                }
                if (obj.Properties.length >= 0 || obj.Methods.length >= 0 || obj.Events.length >= 0) {
                    objhtml = objhtml.concat(`${obj ? this.generateCIAddRemovObjHTML(obj, `${obj[`${type}Name`]}-${modulname}`) : ''}`);
                }
                else {
                    objhtml = objhtml.concat(
                        `${obj.Properties ? this.generateCIPropObjHTML(obj.Properties, `${obj[`${type}Name`]}-${modulname}`) : ''}
                         ${obj.Methods ? this.generateCIMethodObjHTML(obj.Methods, `${obj[`${type}Name`]}-${modulname}`) : ''}
                         ${obj.Events ? this.generateCIEventObjHTML(obj.Events, `${obj[`${type}Name`]}-${modulname}`) : ''}`);
                }
            }
        }
        return objhtml;
    }

    //generate anchor tags for add/remove items of class
    generateCIAddRemovAnchor(obj, parent) {
        if (!obj) {
            return '';
        }
        let ciaddanchor = `${obj.Properties && obj.Properties.length && obj.Properties.length > 0 ? 
            `<h4>Properties</h4>\n\r${this.generateAnchors(obj.Properties, 'Property', parent)}` : ''}
         ${obj.Methods && obj.Methods.length && obj.Methods.length > 0 ? 
            `<h4>Methods</h4>\n\r${this.generateAnchors(obj.Methods, 'Method', parent)}` : ''}
         ${obj.Events && obj.Events.length && obj.Events.length > 0 ? 
            `<h4>Events</h4>\n\r${this.generateAnchors(obj.Events, 'Event', parent)}` : ''}`;
        return ciaddanchor;
    }

    //generated anchor tags for updated class properties
    generateCIPropAnchor(properties, parent) {
        if (!properties) {
            return '';
        }
        let cipropanchor = `${properties.added && properties.added.length > 0 || 
            properties.removed && properties.removed.length > 0 || 
            properties.updated && properties.updated.length > 0 ? `<h4>Properties</h4>\r\n` : ''}
             ${properties.added && properties.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateAnchors(properties.added, 'Property', parent)}` : ''}
             ${properties.removed && properties.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateAnchors(properties.removed, 'Property', parent)}` : ''}
             ${properties.updated && properties.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateAnchors(properties.updated, 'Property', parent)}` : ''}`;
        return cipropanchor;
    }

    //generated anchor tags for updated class methods
    generateCIMethodAnchor(methods, parent) {
        if (!methods) {
            return '';
        }
        let cimethodanchor = `${methods.added && methods.added.length > 0 || 
            methods.removed && methods.removed.length > 0 || 
            methods.updated && methods.updated.length > 0 ? `<h4>Methods</h4>\r\n` : ''}
             ${methods.added && methods.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateAnchors(methods.added, 'Method', parent)}` : ''}
             ${methods.removed && methods.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateAnchors(methods.removed, 'Method', parent)}` : ''}
             ${methods.updated && methods.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateAnchors(methods.updated, 'Method', parent)}` : ''}`;
        return cimethodanchor;
    }

    //generated anchor tags for updated class events
    generateCIEventAnchor(events, parent) {
        if (!events) {
            return '';
        }
        let cieventanchor = `${events.added && events.added.length > 0 || 
            events.removed && events.removed.length > 0 || 
            events.updated && events.updated.length > 0 ? `<h4>Events</h4>\r\n` : ''}
             ${events.added && events.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateAnchors(events.added, 'Event', parent)}` : ''}
             ${events.removed && events.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateAnchors(events.removed, 'Event', parent)}` : ''}
             ${events.updated && events.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateAnchors(events.updated, 'Event', parent)}` : ''}`;
        return cieventanchor;
    }

    //generate html for add/remove property, method and event of updated class
    generateCIAddRemovObjHTML(obj, parent) {
        if (!obj) {
            return '';
        }
        let ciaddhtml = `${obj.Properties && obj.Properties.length && obj.Properties.length > 0 ? 
            `<h4>Properties</h4>\n\r${this.generateObjHTML(obj.Properties, 'Property', parent)}` : ''}
             ${obj.Methods && obj.Methods.length && obj.Methods.length > 0 ? 
                `<h4>Methods</h4>\n\r${this.generateObjHTML(obj.Methods, 'Method', parent)}` : ''}
             ${obj.Events && obj.Events.length && obj.Events.length > 0 ? 
                `<h4>Events</h4>\n\r${this.generateObjHTML(obj.Events, 'Event', parent)}` : ''}`;
        return ciaddhtml;
    }

    generateCIPropObjHTML(properties, parent){
        if(!properties){
            return '';
        }
        let ciprophtml = `${properties.added && properties.added.length > 0 || 
            properties.removed && properties.removed.length > 0 || 
            properties.updated && properties.updated.length > 0 ? 
            `<h4>Properties</h4>\r\n` : ''}
            ${properties.added && properties.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateObjHTML(properties.added, 'Property', parent)}` : ''}
            ${properties.removed && properties.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateObjHTML(properties.removed, 'Property', parent)}` : ''}
            ${properties.updated && properties.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateObjHTML(properties.updated, 'Property', parent)}` : ''}`;
        return ciprophtml;
    }

    generateCIMethodObjHTML(methods, parent){
        if(!methods){
            return '';
        }
        let cimethodhtml = `${methods.added && methods.added.length > 0 || 
            methods.removed && methods.removed.length > 0 || 
            methods.updated && methods.updated.length > 0 ? 
            `<h4>Methods</h4>\r\n` : ''}
            ${methods.added && methods.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateObjHTML(methods.added, 'Method', parent)}` : ''}
            ${methods.removed && methods.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateObjHTML(methods.removed, 'Method', parent)}` : ''}
            ${methods.updated && methods.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateObjHTML(methods.updated, 'Method', parent)}` : ''}`;
        return cimethodhtml;
    }

    generateCIEventObjHTML(events, parent){
        if(!events){
            return '';
        }
        let cieventhtml = `${events.added.length > 0 || events.removed.length > 0 || events.updated.length > 0 ? 
            `<h4>Events</h4>\r\n` : ''}
            ${events.added.length > 0 ? 
                `<h5>Added</h5>\r\n${this.generateObjHTML(events.added, 'Event', parent)}` : ''}
            ${events.removed.length > 0 ? 
                `<h5>Removed</h5>\r\n${this.generateObjHTML(events.removed, 'Event', parent)}` : ''}
            ${events.updated.length > 0 ? 
                `<h5>Updated</h5>\r\n${this.generateObjHTML(events.updated, 'Event', parent)}` : ''}`;
        return cieventhtml;
    }

    generateObjHTML(objects, type, parentname) {
        if (!objects || !type) {
            return;
        }
        let objecthtml = ``;
        for (let obj of objects) {
            objecthtml = objecthtml.concat(this.generatActionTable([obj], type, parentname));
        }
        return objecthtml;
    }

    //generating html table for changes in module
    generatActionTable(items, action, parent) {
        if (!items || items.length === 0) {
            return ``;
        }
        return `<h5 id = "${items[0][`${action}Name`]}-${action}-${parent}" >${items[0][`${action}Name`]} :</h5>\r\n
        ${this.generateHTMLTable(items)}\r\n`;
    }
}

module.exports = generateHTML;