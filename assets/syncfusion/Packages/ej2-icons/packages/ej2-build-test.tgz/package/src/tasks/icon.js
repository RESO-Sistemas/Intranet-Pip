'use strict';

var fs = require('fs');
var gulp = require('gulp');
var glob = require('glob');
var shelljs = require('shelljs');
var liTemplate, htmlTemplate, icons = {};

gulp.task('svg-min', function() {
    var svgmin = require('gulp-svgmin');
    return gulp.src('./styles/**/icons/**/*.svg')

    .pipe(svgmin({
            plugins: [{
                cleanupAttrs: true,
            }, {
                removeDoctype: true,
            }, {
                removeXMLProcInst: true,
            }, {
                removeComments: true,
            }, {
                removeMetadata: true,
            }, {
                removeTitle: true,
            }, {
                removeDesc: true,
            }, {
                removeUselessDefs: true,
            }, {
                removeEditorsNSData: true,
            }, {
                removeEmptyAttrs: true,
            }, {
                removeHiddenElems: true,
            }, {
                removeEmptyText: true,
            }, {
                removeEmptyContainers: true,
            }, {
                removeViewBox: false,
            }, {
                cleanUpEnableBackground: true,
            }, {
                convertStyleToAttrs: true,
            }, {
                convertColors: true,
            }, {
                convertPathData: true,
            }, {
                convertTransform: true,
            }, {
                removeUnknownsAndDefaults: false,
            }, {
                removeNonInheritableGroupAttrs: true,
            }, {
                removeUselessStrokeAndFill: true,
            }, {
                removeUnusedNS: true,
            }, {
                cleanupIDs: true,
            }, {
                cleanupNumericValues: true,
            }, {
                moveElemsAttrsToGroup: true,
            }, {
                moveGroupAttrsToElems: true,
            }, {
                collapseGroups: true,
            }, {
                removeRasterImages: false,
            }, {
                mergePaths: true,
            }, {
                convertShapeToPath: false,
            }, {
                sortAttrs: true,
            }, {
                transformsWithOnePath: false,
            }, {
                removeDimensions: true,
            }, {
                removeAttrs: { attrs: '()' },
            }]
        }))
        .pipe(gulp.dest('./styles/icons/svg/'));
});

gulp.task('create-icons', gulp.series('svg-min', function(done) {
    var path = require('path');
    var shelljs = require('shelljs');
    // get existing icon scss files
    var iconFiles = glob.sync('{./styles/**/icons/_*.scss,./styles/resources/**/index.scss}');
    // remove all scss files
    shelljs.rm('-rf', iconFiles);
    var files = glob.sync('./styles/icons/svg/**/*.svg');
    liTemplate = fs.readFileSync('./styles/resources/li-template', 'utf8');
    htmlTemplate = fs.readFileSync('./styles/resources/html-template', 'utf8');

    for (var i = 0; i < files.length; i++) {
        var filePath = path.dirname(files[i]);
        var themePath = filePath.replace('/svg/icons/', '/');
        var fileName = path.basename(files[i], '.svg');
        var splitted = themePath.split('/');
        var themeName = '_' + splitted[splitted.length - 1] + '.scss';
        var svgContent = fs.readFileSync(files[i], 'utf8');
        svgContent = svgContent.replace(/(fill=")(.+?)(?=")/, 'fill="#{icon-color}');
        svgContent = svgContent.replace(/(viewBox=")(.+?)(?=")/, 'viewBox="#{view-box}');
        svgContent = svgContent.replace(/"/g, '\'').replace(/</g, '%3C').replace(/>/g, '%3E');

        var encoded = '$' + fileName + ': "' + svgContent + '";\n';
        fs.appendFileSync('./styles/icons/' + themeName, encoded);

        getIcons(fileName, splitted[splitted.length - 1]);
    }
    shelljs.rm('-rf', './styles/icons/svg/');
    createResources();
    done();
}));

function getIcons(iconName, themeName) {
    var scss = `.${iconName} {
  @include icon($${iconName}, #000, '.${iconName}');
}

`;
    themeName = themeName.replace('_', '');
    shelljs.mkdir('-p', './styles/resources/' + themeName);
    fs.appendFileSync('./styles/resources/' + themeName + '/index.scss', scss);
    var li = liTemplate.replace(/{{:name}}/g, iconName);
    if (!icons[themeName]) {
        icons[themeName] = {};
    }
    icons[themeName][iconName] = li;
}

var headers = `@import '../../common/mixin.scss';
@import '../../icons/{{:themename}}.scss';

`;

function createResources() {
    var themes = Object.keys(icons);
    var sassDiasabled = '// sass-lint:disable quotes\n';
    for (var i = 0; i < themes.length; i++) {
        var iconNames = Object.keys(icons[themes[i]]);
        var liContent = '';
        for (var j = 0; j < iconNames.length; j++) {
            liContent += icons[themes[i]][iconNames[j]];
        }

        var themeFile = './styles/icons/_' + themes[i] + '.scss';
        var themeContent = fs.readFileSync(themeFile, 'utf8');
        fs.writeFileSync(themeFile, sassDiasabled + themeContent);

        var html = htmlTemplate.replace(/{{:li}}/g, liContent).replace(/{{:themename}}/g, themes[i]);
        fs.writeFileSync('./styles/resources/' + themes[i] + '/index.html', html);

        var importHeaders = headers.replace('{{:themename}}', themes[i]);
        var resource = fs.readFileSync('./styles/resources/' + themes[i] + '/index.scss', 'utf8');
        fs.writeFileSync('./styles/resources/' + themes[i] + '/index.scss', importHeaders + resource);
    }
}