'use strict';

var common = global.config = global.config || require('../utils/common.js');
var shelljs = require('shelljs');
var fs = require('fs');
var gulp = require('gulp');
var user = 'SyncfusionAutomation';
var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
var glob = require('glob');
var configJson = '';

gulp.task('sample-browser-test', function (done) {
    var currentBranch = process.env.githubSourceBranch ? process.env.githubSourceBranch :
        shelljs.exec('git rev-parse --abbrev-ref HEAD').replace('\n', '');
    if (currentBranch === 'development' || currentBranch === 'master' || common.isReleaseBranch || common.isHotfixBranch) {
        return;
    }

    // check target branch in remote server
    var branchName;
    if (fs.existsSync('./targetBranch.txt')) {
        branchName = fs.readFileSync('./targetBranch.txt', 'utf8');
        console.log('Target Branch: ' + branchName);
        sampleTest(branchName.trim());
        shelljs.rm('-rf', './targetBranch.txt');
    } else {
        var devBranchList = shelljs.exec('git branch --contains development');
        var list = devBranchList.replace(new RegExp('\r?\n', 'g'), '').replace(/\*/g, '').split(' ');
        branchName = list.indexOf(currentBranch) !== -1 ? 'development' : 'master';
        sampleTest(branchName);
    }
    done();
});

function sampleTest(branch) {
    var registry = require('./registry.js');
    var localPath = './ej2-sample-test/';
    shelljs.mkdir('-p', localPath);
    shelljs.exec('gulp npmignore && npm pack');
    var gitPath = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-samples';

    // clone current repository
    shelljs.exec('git clone ' + gitPath + ' ' + localPath, { silent: false });

    // generate tar file
    var tarFile = glob.sync('./*.tgz');
    var currentPackageName = common.currentPackage;
    if (fs.existsSync('./config.json')) {
        configJson = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
    }
    shelljs.cd(localPath);

    // checkout the current branch
    shelljs.exec('git checkout ' + branch);
    var packageJson = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
    packageJson.dependencies['@syncfusion/' + currentPackageName] = '../' + tarFile;

    // modified the package json file
    fs.writeFileSync('./package.json', JSON.stringify(packageJson));
    if (configJson.sampleList && configJson.sampleList.length) {
        fs.writeFileSync('./controlWiseSample.json', JSON.stringify(configJson.sampleList));
    }

    // test the sample Browser
    registry.setNpmrc(branch);
    var sampleTest = shelljs.exec('npm install && gulp sample-test', { silent: false });
    if (sampleTest.code === 1) {
        process.exit(1);
    }
    if (fs.existsSync('./controlWiseSample.json')) {
        shelljs.rm('-rf', './controlWiseSample.json');
    }
    // navigate to root location
    shelljs.cd('../');
    //removed the cloned sample browser
    shelljs.rm('-rf', localPath);
    //removed the tar file
    shelljs.rm('./*.tgz');
}
