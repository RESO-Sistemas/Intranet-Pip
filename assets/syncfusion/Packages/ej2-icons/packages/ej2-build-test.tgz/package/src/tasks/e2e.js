'use strict';
/* jshint ignore: start */
var fs = global.fs = global.fs || require('fs');
var gulp = global.gulp = global.gulp || require('gulp');
var path = global.path = global.path || require('path');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var build = require('./build');
const zip = require('gulp-zip');
var common = global.config = global.config || require('../utils/common.js');
var unzip = require('gulp-unzip');
var user = 'SyncfusionAutomation';
var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
var path = global.path = global.path || require('path');
var ipv4 = 'localhost';
var config = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
if (config.seleniumAddress && config.seleniumAddress.indexOf('localhost') === -1) {
    const publicIp = require('public-ip');
    publicIp.v4().then(ip => {
        ipv4 = ip;
    });
}

let s3config = {
    accessKeyId: process.env.AWS_ACCESS_KEY,
    secretAccessKey: process.env.AWS_SECRET_KEY,
};

gulp.task('unzip-testreport', function (done) {
    gulp.src(__dirname + '/../test-report/SyncfusionUpdateTestResults.zap')
        .pipe(unzip())
        .pipe(gulp.dest('./testreport'))
        .on('end', done);
});

gulp.task('e2e-zip', function (done) {
    return gulp.src(['e2e/**/*.*', '!e2e/tests/*.*'])
        .pipe(zip('e2e.zip'))
        .pipe(gulp.dest('./'))
        .on('end', done);
});

gulp.task('e2e-commit', function (done) {
    var origin = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/' + common.currentRepo + '.git';
    shelljs.exec('git remote set-url origin ' + origin);
    var currentBranch = shelljs.exec('git rev-parse --abbrev-ref HEAD').stdout.split('\n').filter(Boolean);
    shelljs.exec('git checkout ' + currentBranch[0]);
    shelljs.exec('git add e2e/Expected');
    shelljs.exec('git commit -m \"ci-skip(EJ2-000): Committing for expected images [ci skip]\" --no-verify');
    shelljs.exec('git push -f --set-upstream origin ' + currentBranch[0] + ' --no-verify', { silent: true }, function () {
        done();
    });
});
// toggle w3c mode in chrome browser
function enablew3c(toggle) {


    var protractorFile = fs.readFileSync(__dirname + '/../../../ej2-base/e2e/protractor.config.js', 'utf8');
    if (toggle) {
        protractorFile = protractorFile.replace(/{W3cdisabled}/g, '{W3cenabled}');
    } else {
        protractorFile = protractorFile.replace(/{W3cenabled}/g, '{W3cdisabled}');
    }
    fs.writeFileSync(__dirname + '/../../../ej2-base/e2e/protractor.config.js', protractorFile);
}
// enable w3c in chrome browser
gulp.task('enable-legacy-chrome-api', function (done) {
    enablew3c(true);
    done();
});

// disable w3c in chrome browser
gulp.task('disable-legacy-chrome-api', function (done) {
    enablew3c(false);
    done();
});

gulp.task('e2e-serve', require('gulp-protractor').webdriver_standalone);

gulp.task('e2e-webdriver-update', require('gulp-protractor').webdriver_update_specific({
    webdriverManagerArgs: ['--versions.chrome 2.37', '--ie', '--edge']
}));

gulp.task('e2e-scripts', function (done) {
    var tsConfigs = {
        module: 'commonjs',
        types: ['jasmine', 'node']
    };
    var gulpObj = {
        src: ['./e2e/**/*.ts'],
        dest: './',
        base: './'
    };
    build.compileTSFiles(tsConfigs, gulpObj, done);
});

gulp.task('accessibility-scripts', function (done) {
    var tsConfigs = {
        module: 'commonjs',
        types: ['jasmine', 'node']
    };
    var gulpObj = {
        src: ['./accessibility/**/*.ts'],
        dest: './',
        base: './'
    };
    build.compileTSFiles(tsConfigs, gulpObj, done);
});

gulp.task('e2e-tests', function (done) {
    process.env['startTime'] = new Date().toLocaleString("en-Us", { timeZone: 'Asia/Kolkata' }).replace(/T/, ' ').replace(/\..+/, '');
    e2eTest('node_modules/@syncfusion/ej2-base/e2e/protractor.config.js', done);
});

function e2eTest(configFileLocation, done) {
    var browserSync = require('browser-sync');
    var bs = browserSync.create('Essential JavaScript 2 Sample');
    var options = {
        port: 6565,
        server: {
            baseDir: './',
            directory: false
        },
        ui: false,
        open: false,
        notify: false
    };
    bs.init(options, function () {
        var pNo = bs.instance.server._connectionKey.split(':');
        var currentPort = pNo[pNo.length - 1];
        var dt = { basePath: 'http://' + ipv4 + ':' + currentPort };
        fs.writeFileSync('./protractor.browser.json', JSON.stringify(dt));
        process.on('uncaughtException', function (err) {
            console.log('Caught exception: ' + err);
        });
        gulp.src(['./e2e/**/*.spec.js'])
            .pipe(require('gulp-protractor').protractor({
                configFile: configFileLocation
            }))
            .on('error', function (e) {
                console.error('Error: ' + e.message);
                //shelljs.rm('./protractor.browser.json');
                if (common.currentRepo.indexOf('samples') !== -1) {
                    shelljs.rm('-rf', './e2e');
                }
                process.env['endTime'] = new Date().toLocaleString("en-Us", { timeZone: 'Asia/Kolkata' }).replace(/T/, ' ').replace(/\..+/, '');
                if (s3config.accessKeyId && s3config.secretAccessKey)
                    shelljs.exec('gulp e2e-mailreport');
                done();
                process.exit(1);
            })
            .on('end', function () {
                //shelljs.rm('./protractor.browser.json');
                if (common.currentRepo.indexOf('samples') !== -1) {
                    shelljs.rm('-rf', './e2e');
                }
                process.env['endTime'] = new Date().toLocaleString("en-Us", { timeZone: 'Asia/Kolkata' }).replace(/T/, ' ').replace(/\..+/, '');
                if (s3config.accessKeyId && s3config.secretAccessKey)
                    shelljs.exec('gulp e2e-mailreport');
                done();
                process.exit(0);
            });
    });
}

gulp.task('e2e-ci-test', function (done) {
    fs.access('./e2e/tests', fs.constants.F_OK, function (error) {
        if (error) {
            console.log('E2E test not configured!');
            done();
        } else {
            var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
            runSequence('unzip-testreport', 'hide-license', 'e2e-scripts', 'e2e-tests', done);
        }
    });
});

function e2eSampleTest(islocal, done) {
    shelljs.mkdir('-p', './e2e');
    fs.writeFileSync('e2e/spec.js', fs.readFileSync(__dirname + '/prospec.txt'));
    fs.writeFileSync('e2e/conf.js', fs.readFileSync(__dirname + '/protractor.conf.js'));
    if (islocal) {
        fs.readFile('e2e/conf.js', function (err, data) {
            if (err) {
                throw err;
            }
            var file = data.toString().split('\n');
            file.splice(-4, 1);
            fs.writeFile('./e2e/conf.js', file.join('\n'), function (err) {
                if (err) {
                    return console.log(err);
                }
            });
        });
    }
    e2eTest('e2e/conf.js', done);
}

function e2ePlunkerSampleTest(done) {
    shelljs.mkdir('-p', './e2e');
    fs.writeFileSync('e2e/spec.js', fs.readFileSync(__dirname + '/plnkrspec.txt'));
    fs.writeFileSync('e2e/conf.js', fs.readFileSync(__dirname + '/protractor.conf.js'));
    e2eTest('e2e/conf.js', done);
}

gulp.task('e2e-sampletest', gulp.series('e2e-webdriver-update', function (done) {
    e2eSampleTest(true, done);
}));

gulp.task('e2e-ci-sampletest', gulp.series('e2e-webdriver-update', function (done) {
    e2eSampleTest(false, done);
}));

gulp.task('e2e-plunkrtest', gulp.series('e2e-webdriver-update', function (done) {
    e2ePlunkerSampleTest(done);
}));



gulp.task('e2e-accessibility', gulp.series('e2e-webdriver-update', function (done) {
    e2eTest(path.resolve(__dirname, '../e2e/protractor.config.js'), done);
}));

gulp.task('e2e-m-tests', function (done) {
    var browserSync = require('browser-sync');
    var bs = browserSync.create('Essential JavaScript 2 Sample');
    var options = {
        port: 6565,
        server: {
            baseDir: './',
            directory: true
        },
        ui: false,
        open: false,
        notify: false
    };
    bs.init(options, function () {
        var pNo = bs.instance.server._connectionKey.split(':');
        var currentPort = pNo[pNo.length - 1];
        var dt = {
            basePath: 'http://' + ipv4 + ':' + currentPort
        };
        console.log(dt.basePath);
        fs.writeFileSync('./protractor.browser.json', JSON.stringify(dt));
        gulp.src(['./e2e/mobile-test/**/*.spec.js'])
            .pipe(require('gulp-protractor').protractor({
                //path change
                configFile: 'node_modules/@syncfusion/ej2-base/e2e/m.protractor.config.js'
            }))
            .on('error', function (e) {
                console.error('Error: ' + e.message);
                shelljs.rm('./protractor.browser.json');
                done();
                process.exit(1);
            })
            .on('end', function () {
                shelljs.rm('./protractor.browser.json');
                done();
                process.exit(0);
            });
    });
});

gulp.task('e2e-mci-test', function (done) {
    fs.access('./e2e/tests', fs.constants.F_OK, function (error) {
        if (error) {
            console.log('E2E test not configured!');
            done();
        } else {
            var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
            runSequence('unzip-testreport', 'e2e-scripts', 'e2e-m-tests', done);
        }
    });
});

gulp.task('e2e-accessibility-test', function (done) {
    fs.access('./accessibility', fs.constants.F_OK, function (error) {
        if (error) {
            console.log('Accessibility test not configured!');
            done();
        } else {
            var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
            runSequence('accessibility-scripts', 'e2e-accessibility', done);
        }
    });
});
/* jshint ignore: end */
