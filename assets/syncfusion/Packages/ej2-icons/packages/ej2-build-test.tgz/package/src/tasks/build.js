'use strict';

// Node JS global scope
var fs = global.fs = global.fs || require('fs');
var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
const { glob } = require('glob');
var shelljs = require('shelljs');
var gutil = require('gulp-util');
var sass = require('gulp-sass')(require('sass'));
var autoPrefixer = require('gulp-autoprefixer');
const replace = require('gulp-replace');

var config = common.config();

function compileTSFiles(tsConfigs, gulpObj, tsConfigPath, done) {
    var ts = require('gulp-typescript');
    // Default typescript config
    var defaultConfig = {
        typescript: require('typescript')
    };

    var args = new Array(arguments.length);
    for (var i = 0; i < args.length; ++i) {
        args[i] = arguments[i];
    }

    tsConfigs = args.shift();
    gulpObj = args.shift();
    done = args.pop();

    tsConfigPath = args.length ? args.shift() : 'tsconfig.json';

    var tsProject, tsResult;

    function refreshValue(flag) {
        // Create the typescript project
        tsProject = ts.createProject(tsConfigPath, Object.assign((flag ? { removeComments: false } : {}), defaultConfig, tsConfigs));
        // Get typescript result
        tsResult = gulp.src(gulpObj.src, { base: gulpObj.base })
            .pipe(tsProject())
            .on('error', function (e) {
                fs.appendFileSync('./gulp_error.log', 'Failed scripts-gen task \ndetails/n' + e);
                done(e);
                process.exit(1);
            });
    }

    // Compile d.ts and minified files
    if (gulpObj.needDts) {
        refreshValue(true);
        tsResult.dts.pipe(gulp.dest(gulpObj.dest));
    }
    refreshValue();
    // Combine and uglify js files using webpack

    if (gulpObj.hasOwnProperty('combine')) {
        var webpackStream = require('webpack-stream');
        var webpack = require('webpack');
        tsResult.js.pipe(webpackStream({
            output: {
                filename: `${common.currentPackage}${gulpObj.combine ? '.umd.min.js' : '.umd.js'}`,
                libraryTarget: 'umd'
            },
            externals: (gulpObj.externals || []),
            plugins: gulpObj.combine ? [
                new webpack.optimize.UglifyJsPlugin()
            ] : [],
            devtool: gulpObj.combine ? '' : 'inline-source-map',
        })).pipe(gulp.dest(gulpObj.dest))
            .on('end', function () {
                done();
            });
    }
    // Compile normal js files without uglification
    else {
        tsResult.js.pipe(gulp.dest(gulpObj.dest))
            .on('end', function () {
                done();
            });

    }
}
exports.compileTSFiles = compileTSFiles;

// Generate root files manually.
gulp.task('generate-root-files', function (done) {
    generateRootFiles('./src');
    done();
});
/** 
 * Compile TypeScript to JS
 */
var isValidRepo = (common.currentRepo !== 'ej2' && common.currentRepo !== 'ej2-samples' && common.currentRepo !== 'ej2-react-samples');
var preScript = !isValidRepo ? [] : ['execute-generator'];
gulp.task('scripts-gen', function (done) {
    if (common.currentRepo === 'ej2-angular-base' && fs.existsSync('./node_modules/@syncfusion/ej2-build-test/node_modules/typescript')) {
        shelljs.rm('-rf', './node_modules/@syncfusion/ej2-build-test/node_modules/typescript');
    }
    var isRemote = process.env.GiteaBuildAutomation_Autocommit_PrivateToken || global.isLocal;
    var gulpObj = {
        src: config.ts,
        dest: './',
        base: '.',
        needDts: isRemote ? true : false
    };
    if (isRemote && isValidRepo) {
        generateRootFiles('./src');
    }
    return compileTSFiles({}, gulpObj, function (err) {
        if (err) {
            console.error('Error during scripts-gen task:', err);
        } else {
            console.log(`Finished 'ci-compile'`);
        }
        done(err);
    });
});

// TS Script Generation with Execute Generator
gulp.task('scripts', function (done) {
    console.log(`Starting 'ci-compile'`);
    var tasks = common.currentRepo === 'ej2-es-build' ? 'scripts-gen' : gulp.series('hide-license', 'scripts-gen');
    return gulp.series(preScript, tasks)(done);
});

//builders  execution
gulp.task('execute-generator', function (done) {
    runSequence('create-model', 'typedoc', done);
});

// Create common root files 
function generateRootFiles(source) {
    var path = require('path');
    var files = fs.readdirSync(source);
    for (var i = 0; i < files.length; i++) {
        var pathObj = path.parse(files[i]);
        var file = path.join(source, files[i]);
        var stat = fs.lstatSync(file);
        if ((stat.isDirectory()) || (pathObj.name === 'index' && pathObj.ext === '.ts')) {
            var name = pathObj.name === 'index' ? pathObj.name : pathObj.name + '/index';
            var content = getCommentLine(pathObj.name) + 'export * from \'' + source + '/' + name + '\';';
            fs.writeFileSync('./' + pathObj.name + '.ts', content);
        }
    }
    return;
}
exports.generateRootFiles = generateRootFiles;

// Generate comment line
function getCommentLine(description) {
    return '/**\n' + ' * ' + description + '\n */\n';
}
exports.getCommentLine = getCommentLine;

gulp.task('tree-shaking', async function () {
    var subControls = ['Accordion',
        'AccumulationChart',
        'Appbar',
        'AutoComplete',
        'Avatar',
        'Badge',
        'BarcodeGenerator',
        'BreadCrumb',
        'BulletChart',
        'Button',
        'Calendar',
        'Card',
        'Carousel',
        'Chart',
        'Checkbox',
        'Chips',
        'CircularGauge',
        'ColorPicker',
        'ComboBox',
        'ContextMenu',
        'DashboardLayout',
        'DataManager',
        'DatePicker',
        'DateRangePicker',
        'DateTimePicker',
        'Diagram',
        'Dialog',
        'DocumentEditor',
        'DropDownButton',
        'DropDownList',
        'DropDownTree',
        'Fab',
        'FileExplorer',
        'FileManager',
        'Gantt',
        'Grid',
        'HeatMap',
        'ImageEditor',
        'InPlaceEditor',
        'Kanban',
        'LinearGauge',
        'ListBox',
        'ListView',
        'Maps',
        'MaskedTextBox',
        'Mention',
        'Menu',
        'Message',
        'MultiSelect',
        'NumericTextBox',
        'DialogUtility',
        'PDFViewer',
        'PivotView',
        'ProgressBar',
        'QueryBuilder',
        'RangeNavigator',
        'Ribbon',
        'RichTextEditor',
        'Rating',
        'Slider',
        'Schedule',
        'SiderBar',
        'Signature',
        'Skeleton',
        'SmithChart',
        'Sparkline',
        'SpeedDial',
        'Spinner',
        'SplitButton',
        'Splitter',
        'Spreadsheet',
        'StockChart',
        'Switch',
        'SymbolPalette',
        'Tab',
        'TextBox',
        'TimePicker',
        'Toast',
        'Toolbar',
        'Tooltip',
        'TreeGrid',
        'TreeMap',
        'TreeView',
        'Uploader'];
    var moduleCount = {};
    var controlsCount = {};
    shelljs.mkdir('-p', './tree-shaking');
    if (fs.existsSync('./third-party/config.json')) {
        var modules = require('../../../../../third-party/config.json');
        var components = modules.components;
        for (var i = 0; i < components.length; i++) {
            var dynamicModules = components[i].dynamicModules;
            if (dynamicModules) {
                for (var k = 0; k < dynamicModules.length; k++) {
                    var getSrc = glob.sync('./src/**/*.ts');
                    for (var j = 0; j < getSrc.length; j++) {
                        var src = fs.readFileSync(getSrc[j], 'utf8');
                        if (src.indexOf(`new ${dynamicModules[k]}(`) !== -1) {
                            console.log(dynamicModules[k], getSrc[j]);
                            if (!moduleCount[dynamicModules[k]]) {
                                moduleCount[dynamicModules[k]] = [];
                            }
                            moduleCount[dynamicModules[k]].push(getSrc[j]);
                        }
                    }
                }
                fs.writeFileSync('./tree-shaking/modules.json', JSON.stringify(moduleCount, null, 2));
            }
        }
    }
    for (var l = 0; l < subControls.length; l++) {
        var control = subControls[l];
        var getSrccode = glob.sync('./src/**/*.ts');
        for (var m = 0; m < getSrccode.length; m++) {
            var srcCode = fs.readFileSync(getSrccode[m], 'utf8');
            if (srcCode.indexOf(`new ${control}(`) !== -1) {
                console.log(control, getSrccode[m]);
                if (!controlsCount[control]) {
                    controlsCount[control] = [];
                }
                controlsCount[control].push(getSrccode[m]);
            }
        }
    }
    fs.writeFileSync('./tree-shaking/controls.json', JSON.stringify(controlsCount, null, 2));
    var fileCount = calculateFileCount();
    return fileCount;
});

function calculateFileCount() {
    var getJson = glob.sync('./tree-shaking/*.json');
    var modules = ['controls', 'modules'];
    for (var i = 0; i < getJson.length; i++) {
        var report = JSON.parse(fs.readFileSync(getJson[i], 'utf8'));
        const lines = Object.keys(report);
        if (lines.length === 0 || lines.length === undefined || lines.length === null) {
            return 'No tree shaking issue found';
        }
        console.log('Total ' + modules[i] + ' count: ' + lines.length);
    }
}

/**
 * Bundle all module using webpack
 */
gulp.task('bundle', function (done) {
    // require files    
    var webpackUtil = require('../utils/webpack');
    var webpackConfig = require(fs.realpathSync('./webpack.config.js'));
    return webpackUtil.bundleWebpack(webpackConfig, done);
});

/** 
 * Generate Model definition file.
 */
gulp.task('create-model', function () {
    var modelGen = require('../generators/model.js');
    return gulp.src(config.createmodel)
        .pipe(modelGen());
});

/**
 * Compile default theme
 */
gulp.task('styles', function (done) {
    runSequence('default-theme', 'compile-styles', done);
});

/**
 * Compile all themes
 */
gulp.task('styles-all', function (done) {
    runSequence('all-themes', 'compile-styles', 'offline-theme', 'removeCss', done);
});

/** 
 * Compile scss to css
 */
var isCompiled = true;
const THEMES=[
  { name: 'bds', def: './_bds-definition' },
  { name: 'bds-lite', def: './_bds-definition' },
  { name: 'material', def: './_material-definition' },
  { name: 'material-lite', def: './_material-definition' },
  { name: 'material-dark', def: './_material-dark-definition' },
  { name: 'material-dark-lite', def: './_material-dark-definition' },
  { name: 'bootstrap', def: './_bootstrap-definition' },
  { name: 'bootstrap-lite', def: './_bootstrap-definition' },
  { name: 'bootstrap-dark', def: './_bootstrap-dark-definition' },
  { name: 'bootstrap-dark-lite', def: './_bootstrap-dark-definition' },
  { name: 'bootstrap4', def: './_bootstrap4-definition' },
  { name: 'bootstrap4-lite', def: './_bootstrap4-definition' },
  { name: 'bootstrap5-dark', def: './_bootstrap5-dark-definition' },
  { name: 'bootstrap5-dark-lite', def: './_bootstrap5-dark-definition' },
  { name: 'bootstrap5', def: './_bootstrap5-definition' },
  { name: 'bootstrap5-lite', def: './_bootstrap5-definition' },
  { name: 'bootstrap5.3', def: './_bootstrap5.3-definition' },
  { name: 'bootstrap5.3-lite', def: './_bootstrap5.3-definition' },
  { name: 'fabric', def: './_fabric-definition' },
  { name: 'fabric-lite', def: './_fabric-definition' },
  { name: 'fabric-dark', def: './_fabric-dark-definition' },
  { name: 'fabric-dark-lite', def: './_fabric-dark-definition' },
  { name: 'highcontrast', def: './_highcontrast-definition' },
  { name: 'highcontrast-lite', def: './_highcontrast-definition' },
  { name: 'highcontrast-light', def: './_highcontrast-light-definition' },
  { name: 'highcontrast-light-lite', def: './_highcontrast-light-definition' },
  { name: 'tailwind', def: './_tailwind-definition' },
  { name: 'tailwind-lite', def: './_tailwind-definition' },
  { name: 'tailwind-dark', def: './_tailwind-dark-definition' },
  { name: 'tailwind-dark-lite', def: './_tailwind-dark-definition' },
  { name: 'fluent', def: './_fluent-definition' },
  { name: 'fluent-lite', def: './_fluent-definition' },
  { name: 'fluent-dark', def: './_fluent-dark-definition' },
  { name: 'fluent-dark-lite', def: './_fluent-dark-definition' },
  { name: 'material3-lite', def: './_material3-definition' },
  { name: 'material3', def: './_material3-definition' },
  { name: 'material3-dark', def: './_material3-dark-definition' },
  { name: 'material3-dark-lite', def: './_material3-dark-definition' },
  { name: 'fluent2', def: './_fluent2-definition' },
  { name: 'fluent2-lite', def: './_fluent2-definition' },
  { name: 'tailwind3', def: './_tailwind3-definition' },
  { name: 'tailwind3-lite', def: './_tailwind3-definition' }
];

const NAMESPACE_TO_RELATIVE = {
    from: /(@use\s+['"])styles\/([^'"]+)(['"]\s+as\s+)([a-zA-Z_-][\w-]*)( *;)/gi,
    to: '$1../$2$3$4$5'
};

const RELATIVE_TO_NAMESPACE = {
    from: /(@use\s+['"])\.\.\/([^'"]+)(['"]\s+as\s+)([a-zA-Z_-][\w-]*)( *;)/gi,
    to: '$1styles/$2$3$4$5'
};

// Apply patch to all relevant files
const applyPatch = (pattern, replacement) => {
    return gulp.src('node_modules/@syncfusion/**/*.scss', { base: '.' })
        .pipe(replace(pattern, replacement))
        .pipe(gulp.dest('.'));
};

gulp.task('compile-styles', async function (done) {
    if (config.isThirdParty) return done();

    const isBasePackage = common.currentPackage === 'ej2-base';
    const stylesPath = isBasePackage
        ? './styles'
        : './node_modules/@syncfusion/ej2-base/styles';
            const hasStylesFolder = fs.existsSync('./styles') && fs.lstatSync('./styles').isDirectory();
            if (!hasStylesFolder) return done();
    let isCompiled = true;
    if (!isBasePackage) {
        await new Promise((resolve, reject) => {
            applyPatch(NAMESPACE_TO_RELATIVE.from, NAMESPACE_TO_RELATIVE.to)
                .on('end', resolve)
                .on('error', (err) => {
                    fs.appendFileSync('./gulp_error.log', 'Failed applyPatch (namespace→relative)\ndetails\n' + err + '\n');
                    gutil.log(new gutil.PluginError('applyPatch', err.message || err.toString()).toString());
                    reject(err);
                });
        });
    }

    for (const theme of THEMES) {
        await new Promise((resolve) => {
            gulp.src([
                `${stylesPath}/${theme.name}.scss`,
                `./styles/*/${theme.name}.scss`,
                `./styles/${theme.name}.scss`,
                `./demos/**/${theme.name}.scss`
            ], { base: './', allowEmpty: true })
                .pipe(sass({
                    outputStyle: common.currentRepo === 'ej2' ? 'compressed' : 'expanded',
                    includePaths: config.node_modules
                }).on('error', function (error) {
                    isCompiled = false;
                    fs.appendFileSync('./gulp_error.log', 'Failed compile-all-styles task \ndetails\n' + error + '\n');
                    gutil.log(new gutil.PluginError('sass', error.messageFormatted).toString());
                    this.emit('end');
                }))
                .pipe(autoPrefixer({ overrideBrowserslist: ['last 2 versions', 'ie >= 11'] }))
                .pipe(gulp.dest('.'))
                .on('end', resolve);
        });
    }
    // === 4. RESTORE original 'styles/...' paths after compilation ===
    if (!isBasePackage) {
        await new Promise((resolve, reject) => {
            applyPatch(RELATIVE_TO_NAMESPACE.from, RELATIVE_TO_NAMESPACE.to)
                .on('end', resolve)
                .on('error', (err) => {
                    fs.appendFileSync('./gulp_error.log', 'Failed applyPatch (relative→namespace)\ndetails\n' + err + '\n');
                    gutil.log(new gutil.PluginError('applyPatch', err.message || err.toString()).toString());
                    reject(err);
                });
        });
    }

    if (!isCompiled) {
        process.exit(1);
    }
    done();
});

gulp.task('removeCss', function (done) {
    if (common.currentRepo !== 'ej2-base-library') {
        var getCss = glob.sync('./styles/**/*.css');
        for (var i = 0; i < getCss.length; i++) {
            var cssContent = fs.readFileSync(getCss[i], 'utf8');
            cssContent = cssContent.replace(
                /(:root\s*,)|(:root\s*{[^}]*})|(\.e-dark-mode\s*{[^}]*})|(\.e-high-contrast\s*{[^}]*})/g,
                ''
            );
            fs.writeFileSync(getCss[i], cssContent, 'utf8');
        }
    }
    done();
});

/**
 * Generate tailwind theme files
 */
gulp.task('tailwind-theme', function (done) {
    runSequence('tailwind-generate', 'compile-styles', done);
});

gulp.task('tailwind-generate', function () {
    var tailwindTheme = ['tailwind', 'tailwind-dark'];
    var themes = require('../generators/themes.js');
    return themes.generateThemes(tailwindTheme);
});

/**
 * Generate Bootstrap5 theme files
 */
gulp.task('bootstrap5-theme', function (done) {
    runSequence('bootstrap5-generate', 'compile-styles', done);
});

gulp.task('bootstrap5-generate', function () {
    var bootstrap5Theme = ['bootstrap5'];
    var themes = require('../generators/themes.js');
    var b5Variables = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
    b5Variables.themes.push('bootstrap5');
    var b5Theme = JSON.stringify(b5Variables);
    for (var i = 0; i < b5Variables.components.length; i++) {
        if (fs.existsSync('./styles/' + b5Variables.components[i] + '/_bootstrap5-definition.scss')) {
            if (b5Variables.themes.indexOf('bootstrap5') !== -1) {
                fs.writeFileSync('./config.json', b5Theme);
            }
        }
    }
    return themes.generateThemes(bootstrap5Theme);
});


/**
 * Generate default theme files
 */
gulp.task('default-theme', function () {
    var themes = require('../generators/themes.js');
    return themes.generateThemes([config.defaultTheme]);
});

/**
 * Generate all theme files
 */
gulp.task('all-themes', async function () {
    config.themes = [
        'material',
        'fabric',
        'bootstrap',
        'highcontrast',
        'material-dark',
        'fabric-dark',
        'bootstrap-dark',
        'highcontrast-light',
        'bootstrap4',
        'bootstrap5',
        'bootstrap5-dark',
        'tailwind',
        'tailwind-dark',
        'fluent',
        'fluent-dark',
        'material3',
        'material3-dark',
        'fluent2',
        'bootstrap5.3',
        'bds',
        'tailwind3'
    ];
    var themes = require('../generators/themes.js');
    return themes.generateThemes(config.themes);
});

/**
 * detect duplicate codes
 */
gulp.task('dedupe', function (done) {
    // var jscpd = require('gulp-jscpd');
    // var source = config.dedupe;
    // if (common.currentRepo === 'ej2-build-tasks') {
    //     source = ['./src/**/*.js', './spec/**/*.js', '!./src/**/blazor.js',
    //         '!./src/third-party/blazor/src-generator.js', '!./src/third-party/asp-core/src-generator.js',
    //         '!./src/third-party/shared/property-reader.js', '!./src/third-party/vue/property-reader.js',
    //         '!./src/third-party/blazor/property-reader.js'
    //     ];
    // }
    // return gulp.src(source)
    //     .pipe(jscpd({
    //         verbose: true
    //     }));
    done();
});

gulp.task('add-config', function (done) {
    var addThemes = ['fluent', 'fluent-dark', 'material3', 'material3-dark', 'fluent2', 'bootstrap5.3', 'bds', 'tailwind3'];
    var themeVariables = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
    if ((themeVariables.components) && (fs.existsSync('./styles/'))) {
        for (var i = 0; i < themeVariables.components.length; i++) {
            for (var j = 0; j < addThemes.length; j++) {
                if (fs.existsSync('./styles/' + themeVariables.components[i] + '/_' + addThemes[j] + '-definition.scss') || addThemes[j].indexOf('-dark') !== -1) {
                    if (themeVariables.themes.indexOf(addThemes[j]) === -1) {
                        themeVariables.themes.push(addThemes[j]);
                        var addTheme = JSON.stringify(themeVariables);
                        fs.writeFileSync('./config.json', addTheme);
                    }
                }
            }
        }
    }
    done();
});

/**
 * Run build task.
 */
gulp.task('build', function (done) {
    shelljs.exec('gulp update-themes');
    shelljs.exec('gulp copy-themes');
    var b5Variables = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
    if (b5Variables.components) {
        for (var i = 0; i < b5Variables.components.length; i++) {
            if (fs.existsSync('./styles/' + b5Variables.components[i] + '/_bootstrap5-definition.scss')) {
                if (b5Variables.themes.indexOf('bootstrap5-dark') === -1) {
                    b5Variables.themes.push('bootstrap5-dark');
                    var b5Theme = JSON.stringify(b5Variables);
                    fs.writeFileSync('./config.json', b5Theme);
                }
            }
        }
    }
    runSequence('add-config', 'styles-all', 'scripts', done);
});
//Remove robotic Link
gulp.task('customize', function (done) {

    if (common.currentRepo === 'ej2-base-library') {
        if (fs.existsSync('./styles/customize')) {

            customizeTask();
        }
        else {
            fs.mkdirSync('./styles/customize');
            customizeTask();
        }

    }

    done();

});

//Remove robotic Link
gulp.task('offline-theme', function (done) {

    var customPath = ['tailwind.css', 'tailwind-dark.css', 'material.css', 'material-dark.css','tailwind3.css','material3.css','material3-dark.css'];

    if (common.currentRepo === 'ej2-base-library') {

        try {
            if (!fs.existsSync('./styles/offline-theme')) {
                fs.mkdirSync('./styles/offline-theme');
            }

            for (const file of customPath) {
                const inputPath  = `./styles/${file}`;
                const outputPath = `./styles/offline-theme/${file}`;

                let content = fs.readFileSync(inputPath, 'utf-8');

                content = content.replace(/^.*fonts\.googleapis\.com.*$/gm, '');

                content = content
                    .replace(/^\s*[\r\n]+/, '')     // remove leading blank lines
                    .replace(/[\r\n]{3,}/g, '\n\n') // collapse multiple blank lines
                    .trim();

                fs.writeFileSync(outputPath, content, 'utf-8');
            }
        }
        catch (e) {
            fs.appendFileSync('./gulp_error.log', 'Failed offline-theme task \ndetails/n' + e);
            console.log(e);
        }
    }

    done();
});

// React build task.
gulp.task('es-build', function (done) {
    runSequence('styles-all', 'create-model', 'scripts-gen', done);
});

// Install log task.
gulp.task('ls-log', function (done) {
    shelljs.mkdir('-p', './cireports/logs');
    shelljs.exec('npm ls >./cireports/logs/install.log');
    done();
});

gulp.task('update-themes', function (done) {
    try {
        var compName = JSON.parse(fs.readFileSync('./package.json', 'utf8')).name.replace('@syncfusion/ej2-', '');
        var themejson = require(__dirname + '/theme.json');

        if (__dirname.indexOf('/third-party/') === -1 && !fs.existsSync('./themestudio')) {
            if (themejson[compName]) {
                themecheckout(function (error) {
                    if (error) {
                        console.error('Error during themecheckout:', error);
                    } else {
                        console.log('Theme checkout completed successfully.');
                    }
                    done();
                });
            } else {
                console.log('No theme information found for component:', compName);
                done();
            }
        } else {
            console.log('Themes not cloned for third party.');
            done();
        }
    } catch (error) {
        console.error('Error in update-themes:', error);
        done(error);
    }
});

gulp.task('copy-themes', function (done) {
    var shelljs = global.shelljs = global.shelljs || require('shelljs');
    if (__dirname.indexOf('/third-party/') === -1 && config && !config.iscomponentTemplate) {
        if (fs.existsSync('./styles')) {
            shelljs.rm('-rf', './styles');
        }
        var compName = JSON.parse(fs.readFileSync('./package.json', 'utf8')).name.replace('@syncfusion/ej2-', '');
        var themejson = require(__dirname + '/theme.json');
        if (themejson[compName]) {
            shelljs.mkdir('-p', './styles');
            shelljs.cp('-r', `./themestudio/styles/` + themejson[compName] + '/*', `./styles`);
            done();
        }
    }
    done();
});

function themecheckout(done) {
    var user = 'SyncfusionAutomation';
    var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
    var branchName = 'release/33.1.1';
    themeclone(user, token, done, 'ej2-theme-studio', branchName);
}

function themeclone(user, token, done, name, branchName) {
    var shelljs = global.shelljs = global.shelljs || require('shelljs');
    //   token = token.replace('@', '%40');
    var tempRepo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/' + name + ' -b ' + branchName;
    if (!token || token === '') {
        tempRepo = 'https://gitea.syncfusion.com/essential-studio/' + name + ' -b ' + branchName;
    }
    shelljs.exec(
        'git clone ' + tempRepo + ' ./themestudio', {
        silent: false
    },
        function () {
            console.log('Clone has been completed from ' + branchName + ' branch!');
            done();
        }
    );
}
function customizeTask() {
    var customPath = ['tailwind.css', 'tailwind-dark.css', 'material.css', 'material-dark.css'];
    for (var i = 0; i < customPath.length; i++) {

        var content = fs.readFileSync('./styles/' + customPath[i], 'utf-8');
        if (customPath[i] === 'tailwind.css' || customPath[i] === 'tailwind-dark.css') {
            content = content.replace('@import url("https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap");', '');
        }
        else {
            content = content.replace('@import url("https://fonts.googleapis.com/css?family=Roboto:400,500");', '');
        }

        fs.writeFileSync('./styles/customize/' + customPath[i], content);

    }
}

