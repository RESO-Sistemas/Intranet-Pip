'use strict';

var apiGenerator = require('./api-generator');

//Global variables
var fs = global.fs = global.fs || require('fs');
var config = fs.existsSync('../../config.json') ? JSON.parse(fs.readFileSync('../../config.json')) : {};
var components = config.components;
var glob = require('glob');
var curPath = '';
var decRegex = /Directive|Component/;
var apiColl = {};
var indexCollection = {};
var globalReference = {};
var typeAliasColl = [];
var curModuleName;
var typeMatcher = ['Enumeration', 'Interface', 'Class'];
var groupMatch = ['Classes', 'Enumerations', 'Interfaces'];
var pChild = [];
var h1 = '# ';
var h3 = '\n### ';
var finalMapper = {
    'Component': 'Components',
    'Directive': 'Directives'
};
var apiThead = '\n| Name | Description |\n|------|-------------|';
var isUpdated = false;

function generateAngularApi(path) {
    apiGenerator.generateApi(path, 'angular');
    if (components) {
        curPath = path;
        var apiJson = JSON.parse(fs.readFileSync('./public/api/file.json'));
        var children = apiJson.children;
        preProcess(children);
        for (var childs of children) {
            curModuleName = getCurrentModule(childs);
            if (curModuleName.length && !apiColl[curModuleName]) {
                apiColl[curModuleName] = { Component: '', Directive: '' };
                indexCollection[curModuleName] = '';
            }
            if (!curModuleName) {
                continue;
            }
            if (childs.children) {
                for (var child of childs.children) {
                    if (child.children && child.decorators && decRegex.test(child.decorators[0].name)) {
                        pChild = [child];
                        processChild(pChild);
                    }
                }
            }
        }
        for (var api in apiColl) {
            var loc = '../../ej2-docs/src/' + api + '/';
            if (fs.existsSync(loc) && fs.existsSync('./ej2-docs/src/' + api)) {
                var componentFile = apiGenerator.replaceSubLimeText(api);
                var files = glob.sync(loc + '*.md', { silent: true, 
                    ignore: [loc + 'summary.md',loc + 'api.md',loc+componentFile+'.md',loc+'index.md'] });
                for (var i = 0; i < files.length; i++) {
                    if (fs.existsSync(loc + 'index.md')) {
                        var indexEvents = fs.readFileSync(loc + 'index.md', 'utf8').match(/## Events((.|\n)*)/);
                        var isEvents = false;
                        if (indexEvents) {
                            indexEvents = indexEvents[0];
                            isEvents = true;
                        }
                        var indexNg = fs.existsSync('./ej2-docs/src/' + api + '/index.md') ? fs.readFileSync('./ej2-docs/src/' + api + '/index.md', 'utf8') : '';
                        if (isEvents && indexNg.indexOf('## Events') === -1) {
                            fs.writeFileSync('./ej2-docs/src/' + api + '/index.md', indexNg.trim() + '\n\n'+ indexEvents, 'utf8');
                        }
                    }
                    var lname = files[i].slice(files[i].lastIndexOf('/') + 1, files[i].lastIndexOf('.'));
                    if (lname !== 'overview') {
                        var name = lname[0].toUpperCase() + lname.substring(1);
                        indexCollection[api] += '\n* [' + name + '](' + api + '/' + lname + ')';
                    }
                }
            }
            var content = '';
            var coll = apiColl[api];
            for (var type in coll) {
                if (coll[type].length) {
                    content += '\n## ' + finalMapper[type] + '\n' + apiThead + coll[type] + '\n';
                }
            }
            if (content.length) {
                content = '# Overview\n' + content;
                generateFile(api, 'overview', content, true, curPath);
                generateFile(api, 'summary', apiGenerator.overviewTemplate.replace(/{{:compFolder}}/, api) +
                    indexCollection[api].slice(1), true, curPath);
            }
        }
        return isUpdated;
    }
}
exports.generateAngularApi = generateAngularApi;

function preProcess(children) {
    for (var childs of children) {
        var curName = getCurrentModule(childs);
        var cGroups = childs.groups;
        var glen;
        if (!globalReference[curName]) {
            globalReference[curName] = [];
        }
        if (cGroups && (glen = cGroups.length)) {
            for (var i = 0; i < glen; i++) {
                var groups = cGroups[i];
                var title = groups.title;
                if (title === 'Type aliases') {
                    typeAliasColl = typeAliasColl.concat(groups.children);
                } else if (!curName.length) {
                    continue;
                } else if (groupMatch.indexOf(title) !== -1) {
                    globalReference[curName] = globalReference[curName].concat(groups.children);
                }
            }
        }
    }

}

function getCurrentModule(child) {
    var baseName = child.name.replace(/"/g, '').split('/')[0];
    return components.indexOf(baseName) !== -1 ? baseName : '';
}

function generateFile(moduleName, fileName, content, prevChange, curPath) {
    var frontMatter = '';
    var ComponentName = apiGenerator.toInitCap(apiGenerator.replaceSubLimeText(moduleName));
    if(fileName.indexOf('summary') === -1){
        frontMatter = apiGenerator.createFrontMatter({component: ComponentName||'',title:fileName||''});
    }
    var modulePath = curPath + moduleName;
    if (!fs.existsSync(modulePath)) {
        return;
    }
    isUpdated = true;
    if(apiGenerator.isCurrentModuleFile(moduleName + 'component',fileName )){
        fileName = 'index';
    }
    fs.writeFileSync(modulePath + '/' + apiGenerator.convertToLower(fileName, prevChange) + '.md',frontMatter+ content, 'utf8');
}

function processChild(child) {
    for (var curProp of child) {
        var name = curProp.name;
        var kindString = curProp.kindString;
        var decorator = curProp.decorators[0].name;
        if (typeMatcher.indexOf(kindString) !== -1 && curProp.flags.isExported &&
            createTypeReference(curProp, name, kindString, curModuleName, curPath, false)) {
            var lname = apiGenerator.convertToLower(name);
            var shortText = apiGenerator.getMessageText(curProp, true);
            var curText = apiGenerator.getTableText(shortText);
            if (curText.length) {
                var moName = (apiGenerator.isCurrentModuleFile(curModuleName + 'component', lname) ?
                    '' : ( lname + '/'));
                apiColl[curModuleName][decorator] += '\n| [' + name + '](./' + moName + ')| ' + curText + '|';
            }
            if(!apiGenerator.isCurrentModuleFile(curModuleName + 'component',name )){
                indexCollection[curModuleName] += '\n* [' + name + '](' + curModuleName + '/' + lname + ')';
            }
        }
    }
}

function createTypeReference(obj, propName, kind, curModuleName, curPath, isReact, vueCompContent) {
    var canIncluded = false;
    var topMessage = apiGenerator.getMessageText(obj);
    var topComment = h1 + propName + '\n' + (topMessage.length ? '\n' + topMessage + '\n' : '');
    var contents = '';
    var method = '';
    var property = '';
    var vueProperty = '';
    var events = '';
    var vueEvents = '';
    var prop = obj.children || [];
    for (var curObj of prop) {
        var curComment;
        var isClass = kind === 'Class';
        var isExported = curObj.flags.isExported && !(curObj.flags.isPrivate || curObj.flags.isProtected);
        if (curObj.flags.isPublic || isExported) {
            var kString = curObj.kindString;
            if (kString === 'Method') {
                if (checkReference(curObj.inheritedFrom)) {
                    continue;
                }
                curComment = apiGenerator.getMessageText(curObj.signatures[0]);
                if (curComment.length) {
                    var mOptions = apiGenerator.getMethodType(curObj, false, curModuleName);
                    if (mOptions.flag) {
                        var returns = '*Returns void*';
                        if (curObj.signatures[0].type) {
                            var actRet = apiGenerator.getType(curObj.signatures[0].type, false, curModuleName);
                            actRet = actRet.replace(/`/g, '*');
                            if (actRet) {
                            returns = 'Returns' + actRet;
                          }
                        }
                        method += h3 + '' + curObj.name + '\n\n' + curComment + '\n' + (mOptions.content || '') + '\n' + returns + '\n';
                    }
                }
            } else if (kString === 'Enumeration member') {
                contents += '\n* `' + curObj.name + '`';
            } else if (kString === 'Event' || kString === 'Property') {
                curComment = apiGenerator.getMessageText(curObj);
                var propType = apiGenerator.getPropertyWithType(curObj, false, curModuleName, isReact ? 'react' : 'angular');
                if (curComment.length && propType.length) {
                    var propHead = apiGenerator.generateHeaderTemplate(curObj.name, propType);
                    var temp = propHead + curComment;
                    if (isClass) {
                        if (kString === 'Property') {
                            property +=  temp + apiGenerator.getTagValue(curObj.comment, 'default') + '\n';
                        } else {
                            events +=  temp + '\n';
                        }
                    } else {
                        property +=  temp + '\n';
                    }
                }
                if (isReact) {
                    var vuePropType = apiGenerator.getPropertyWithType(curObj, false, curModuleName, 'vue');
                    if (curComment.length && vuePropType.length) {
                        var vuePropHead = apiGenerator.generateHeaderTemplate(curObj.name, vuePropType);
                        var curVueContent = vuePropHead + curComment;
                        if (isClass) {
                            if (kString === 'Property') {
                                vueProperty +=  curVueContent + apiGenerator.getTagValue(curObj.comment, 'default') + '\n';
                            } else {
                                vueEvents +=  curVueContent + '\n';
                            }
                        } else {
                            vueProperty +=  curVueContent + '\n';
                        }
                    }
                }
            }
        }
    }
    contents += apiGenerator.getClassContent([property, method, events]);
    if (contents.length) {
        canIncluded = true;
        generateFile(curModuleName, propName, topComment + contents, false, curPath);
        if (isReact) {
            if (!vueCompContent[curModuleName]) {
                vueCompContent[curModuleName] = {};
            }
            vueCompContent[curModuleName][propName] = apiGenerator.getClassContent([vueProperty, method, vueEvents]);
        }
    }

    return canIncluded;
}
exports.createTypeReference = createTypeReference;

function clearComponentFolder(path) {
    var component = config.components;
    if (!component.length) {
        return;
    }
    for (var comp of components) {
        var curFolder = path + comp;
        if (fs.existsSync(curFolder)) {
            var files = glob.sync(curFolder + '/*.md', { silent: true });
            for (var i = 0; i < files.length; i++)  {
                fs.unlinkSync(files[i]);
            }
        } else {
            if(!fs.existsSync(path)) {
                fs.mkdirSync(path);
            }
            console.log(path);
            fs.mkdirSync(path+comp);
        }
    }
}

exports.clearComponentFolder = clearComponentFolder;

function checkReference(reference) {
    if (reference) {
        var module = reference.name.split('.')[0];
        return module === 'Base' || module === 'Component';
    }
}
exports.checkReference = checkReference;
