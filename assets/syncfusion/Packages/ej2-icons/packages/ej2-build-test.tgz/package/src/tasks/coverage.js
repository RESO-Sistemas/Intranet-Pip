'use strict';

// Node JS global scope
var gulp = global.gulp = global.gulp || require('gulp');
global.config = global.config || require('../utils/common.js');
var path = global.path = global.path || require('path');
var fs = require('fs');
process.on('uncaughtException', (err) => {
  const msg = String((err && err.message) || err || '');
  if (msg.includes('Server is not running.')) {
    console.warn('[IGNORED] ' + msg);
  } else {
    throw err;
  }
});

var service, proxyPort;
var config = global.config.config();
var coverageConfig = require('./coverage-config.json');
const coverageIgnorePath = path.join(__dirname, './coverage-ignore.json');
const coverageIgnoreData = fs.readFileSync(coverageIgnorePath, 'utf8');
const coverageIgnore = JSON.parse(coverageIgnoreData);
/**
 * Generates code coverage report in folder coverage/
 */
gulp.task('service', function (done) {
    var spawn = require('child_process').spawn;
    service = spawn('node', [path.join(__dirname, '../../services/V4service.js')]);

    service.stdout.on('data', (data) => {
        proxyPort = data.toString().trim();
        console.log('Proxy port: ' + proxyPort);
        done();
    });
    done();
});

gulp.task('coverage', gulp.series('service', function (done) {
    var karma = require('karma');
    var totalSpecs = 0;
    var totalPassed = 0;
    var totalFailed = 0;
    var totalSkipped = 0;
    var testRunTime = 0;
  const packData = fs.readFileSync('./package.json', 'utf8');
  const packageJson = JSON.parse(packData);
  const fullName = packageJson.name;
  const packageName = fullName.split('/')[1];
  var checkOverrides = coverageIgnore[packageName] === global.config.currentRepo
    ? config.coverageConfig
    : coverageConfig[global.config.currentRepo];
    var server = new karma.Server({
        configFile: __dirname + config.karma,
        action: 'run',
        singleRun: true,
        preprocessors: config.karmaPreprocess,
        genericPreprocessor: {
            rules: [{
                process: function (content, file, done) {
                    //ignore the typescript generator processors
                    var ignoreNext = ['var __decorate =', 'var __metadata =', 'var __extends ='];
                    for (var j = 0; j < ignoreNext.length; j++) {
                        var regX = new RegExp(ignoreNext[j], 'g');
                        if (regX.test(content)) {
                            content = content.replace(regX, '/* istanbul ignore next */ \n' + ignoreNext[j]);
                        }
                    }
                    done(content);
                }
            }]
        },
        reporters: ['progress', 'coverage'],
        coverageReporter: {
            dir: './coverage',
            subdir: function (browser) {
                return browser.toLowerCase().split(/[ /-]/)[0];
            },
            reporters: [
                { type: 'lcov' },
                { type: 'text-summary', subdir: '.', file: 'report.txt' },
                { type: 'json-summary', subdir: '.', file: 'report.json'}
            ],
            check: {
                each: {
                    statements: 85,
                    branches: 85,
                    functions: 85,
                    lines: 85,
                    overrides: checkOverrides,
                }
            }
        },
        proxies: {
            '/api': {
                'target': 'http://127.0.0.1:' + proxyPort
            }
        },
        // browsers: ['ChromeHeadless'],
        browsers: ['ChromeNoSandbox'],
        customLaunchers: {
            ChromeNoSandbox: {
                base: 'ChromeHeadless',
                flags: ['--no-sandbox']
            }
        },
        browserNoActivityTimeout: 30000
    }, function (e) {
        try {
            if (service && !service.killed) service.kill();
        } catch (err) {
            const msg = String((err && err.message) || err || '');
            if (msg.includes('Server is not running.')) {
                console.warn('[IGNORED] ' + msg);
            } else {
                console.error(err);
            }
        }
        var testObj = {
            testResults: {
              totalSpecs: totalSpecs,
              totalPassed: totalPassed,
              totalFailed: totalFailed,
              totalSkipped: totalSkipped,
              testRunTime: testRunTime,
            }
          };
        if (e === 1) {
            console.log('Karma has exited with ' + e);
            testReport(testObj);
            process.exit(e);
        } else {
            testReport(testObj);
            done();
        }
    });
    server.on('browser_complete', function (browser) {
        var result = browser.lastResult;
        totalSpecs += result.total;
        totalPassed += result.success;
        totalFailed += result.failed;
        totalSkipped += result.skipped;
        testRunTime += result.totalTime;
    });
    server.start();
}));

function testReport(testData) {
    var testResult = testData.testResults;
    var timeDiff = testResult.testRunTime / 1000;
    var hours = Math.floor(timeDiff / 3600);
    var minutes = Math.floor((timeDiff - hours * 3600) / 60);
    var seconds = Math.floor((timeDiff - hours * 3600) - minutes * 60);
    var timeTaken = (hours > 0 ? hours + 'hrs ' : '') + (minutes > 0 ? minutes + ' mins ' : '') + (seconds > -1 ? seconds + ' secs' : '');
    // Log the summary
    console.log('=================== Test Case Summary ====================');
    console.log('Total Run Time: ' + timeTaken);
    console.log('Total Specs: ' + testResult.totalSpecs + ' test cases');
    console.log('Total Passed: ' + testResult.totalPassed + ' test cases');
    console.log('Total Failed: ' + testResult.totalFailed + ' test cases');
    console.log('Total Skipped: ' + testResult.totalSkipped + ' test cases');
    console.log('======================================================');
    testResult.testRunTime = timeTaken;
    if(fs.existsSync('./coverage/report.json')) {
        var overallPercentage = 0;
        const reportContent = JSON.parse(fs.readFileSync('./coverage/report.json', 'utf8'));
        const coverage = reportContent.total;
        overallPercentage = (coverage.lines.pct + coverage.statements.pct + coverage.functions.pct + coverage.branches.pct) / 4;
        testData.coverage = Math.floor(overallPercentage);
        fs.writeFileSync('./coverage/testReport.json', JSON.stringify(testData));
    }
}