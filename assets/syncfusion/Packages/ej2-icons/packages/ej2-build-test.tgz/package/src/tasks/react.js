'use strict';

var common = global.config = global.config || require('../utils/common.js');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var gulp = global.gulp = global.gulp || require('gulp');
var fs = global.fs = global.fs || require('fs');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
var changelogObj = require('../../src/third-party/changelog.js');


gulp.task('react-checkout', function (done) {
    common.checkout('react', 'react', done);
});


gulp.task('react-configure', function (done) {
    common.thridPartyConfigure('react', 'react');
    done();
});


gulp.task('react-generate', function (done) {
    var reactSrcGen = require('../third-party/react/src-generator.js');
    var pJson = JSON.parse(fs.readFileSync('./package.json'));
    
    shelljs.cp('./third-party/readme/react.md', './third-party/react/README.md');
    if (fs.existsSync('./CHANGELOG.md')) {
        var mdContent = changelogObj.changelog('./CHANGELOG.md', './third-party/changelog/react.md');
        fs.writeFileSync('./third-party/react/CHANGELOG.md', mdContent);
    }
    var themesList = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
    themesList = themesList.themes;
    var thirdpartyConfig = JSON.parse(fs.readFileSync('./third-party/react/config.json', 'utf8'));
    thirdpartyConfig.themes = themesList;
    fs.writeFileSync('./third-party/react/config.json', JSON.stringify(thirdpartyConfig), 'utf8');
    reactSrcGen(JSON.parse(fs.readFileSync('./third-party/config.json')), pJson, done);
});

gulp.task('copy-react-code-block', function (done) {
    if (fs.existsSync('./api-code-blocks/react/')) {
        shelljs.mkdir('-p',`./third-party/react/api-code-blocks`);
        shelljs.cp('-r', `./api-code-blocks/react`, `./third-party/react/api-code-blocks`);
        done();
    }
    else {
        done();
    }
});

gulp.task('react-build', function (done) {
    runSequence('react-checkout', 'react-configure', 'react-generate', 'copy-react-code-block', done);
});