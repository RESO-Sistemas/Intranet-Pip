'use strict';

var fs = global.fs = global.fs || require('fs');
var gulp = global.gulp = global.gulp || require('gulp');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var common = global.config = global.config || require('../utils/common.js');

/**
 * remote development registry
 */
gulp.task('dev-registry', function (done) {
    switchRegistry('https://nexus.syncfusioninternal.com/repository/ej2-development/');
    npmrcConfig('//nexus.syncfusioninternal.com/repository/ej2-development/');
    done();
});

gulp.task('angular-registry', function (done) {
    switchRegistry('https://nexus.syncfusioninternal.com/repository/ej2-angular-development/');
    npmrcConfig('//nexus.syncfusioninternal.com/repository/ej2-angular-development/');
    done();
});

/**
 * local development registry
 */
gulp.task('local-dev-registry', function (done) {
    switchRegistry('https:' + process.env.LOCAL_DEV_REGISTRY);
    done();
});

/**
 * remote production registry
 */
gulp.task('production-registry', function (done) {
    switchRegistry('https:' + process.env.PRIVATE_PRODUCTION_REGISTRY);
    npmrcConfig(process.env.PRIVATE_PRODUCTION_REGISTRY);
    done();
});

/**
 * local production registry
 */
gulp.task('local-production-registry', function (done) {
    switchRegistry('https:' + process.env.LOCAL_PRODUCTION_REGISTRY);
    done();
});

/**
 * remote release registry
 */
gulp.task('release-registry', function (done) {
    switchRegistry('https://nexus.syncfusioninternal.com/repository/ej2-release/');
    npmrcConfig('//nexus.syncfusioninternal.com/repository/ej2-release/');
    done();
});

/**
 * remote hotfix registry
 */
gulp.task('hotfix-registry', function (done) {
    switchRegistry('https://nexus.syncfusioninternal.com/repository/ej2-hotfix-new/');
    npmrcConfig('//nexus.syncfusioninternal.com/repository/ej2-hotfix-new/');
    done();
});

// Change registry in npmrc file
function switchRegistry(registry) {
    var content = 'registry=https://registry.npmjs.org/\n@syncfusion:registry=' + registry + '\n';
    fs.writeFileSync('./.npmrc', content);
}
exports.switchRegistry = switchRegistry;

/**
 * Rewrite npmrc config
 */
function npmrcConfig(registry) {
    shelljs.exec('echo ' + registry + ':username=' + process.env.PRIVATE_NPM_USER + ' >> .npmrc', { silent: true });
    shelljs.exec('echo ' + registry + ':_password=' + process.env.PRIVATE_NPM_PASSWORD + ' >> .npmrc', { silent: true });
    shelljs.exec('echo ' + registry + ':email=' + process.env.PRIVATE_NPM_EMAIL + ' >> .npmrc', { silent: true });
    shelljs.exec('echo ' + registry + ':always-auth=true >> .npmrc', { silent: true });
}
exports.npmrcConfig = npmrcConfig;

// update npmrc content
var setNpmrc = function (branchName) {
    var registry;
    var isMaster = common.isMasterBranch || (branchName && branchName === 'master');
    var isReleaseBranch = common.isReleaseBranch || /^((release\/))/g.test(branchName);
    var isHotfixBranch = common.isHotfixBranch || /^((hotfix\/))/g.test(branchName);
    if (common.isRemoteServer) {
        registry = isMaster ? process.env.PRIVATE_PRODUCTION_REGISTRY : process.env.PRIVATE_DEV_REGISTRY;
        registry = isReleaseBranch ? '//nexus.syncfusioninternal.com/repository/ej2-release/' : registry;
        registry = isHotfixBranch ? '//nexus.syncfusioninternal.com/repository/ej2-hotfix-new/' : registry;
    } else {
        registry = isMaster ? process.env.LOCAL_PRODUCTION_REGISTRY : process.env.LOCAL_DEV_REGISTRY;
    }
    var npmrc = 'registry=https://registry.npmjs.org/\n' +
        '@syncfusion:registry=https:' + registry;
    fs.writeFileSync('./.npmrc', npmrc);
};
exports.setNpmrc = setNpmrc;
