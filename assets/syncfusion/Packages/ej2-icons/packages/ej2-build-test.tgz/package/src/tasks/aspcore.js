'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
var fs = global.fs = global.fs || require('fs');
var shelljs = require('shelljs');

gulp.task('aspcore-checkout', function (done) {
    common.checkout('asp-core', 'asp-core', function () {
        var branchname = common.isMasterBranch ? 'master' : 'development';
        branchname = common.isReleaseBranch ? process.env.githubSourceBranch : branchname;
        branchname = common.isHotfixBranch ? process.env.githubSourceBranch : branchname;
        shelljs.cd('./third-party/asp-core/');
        shelljs.exec('git checkout ' + branchname);
        shelljs.cd('../../');
        done();
    }); 
});

gulp.task('aspcore-compile', function(done) {
    shelljs.cd('./third-party/asp-core/');
    shelljs.exec('npm install');
    //net9Install();
    shelljs.exec('dotnet --info');
    //Commented Because of TragetFramework net451 not used in asp-core
    // var csProjFile = fs.readFileSync('./src/Syncfusion.EJ2.csproj','UTF8');
    // var  itemGroupStr = csProjFile.match(/<ItemGroup Condition=([^]*)<\/ItemGroup>/)[0];
    // itemGroupStr = itemGroupStr.slice(0, itemGroupStr.indexOf('</ItemGroup>') + '<ItemGroup>'.length + 1);
    // csProjFile = csProjFile.replace(itemGroupStr,'').replace('net451;','');
    // fs.writeFileSync('./src/Syncfusion.EJ2.csproj', csProjFile);
    
    //ASP Core Nuget
    shelljs.exec('dotnet restore "src/Syncfusion.EJ2.csproj"  --configfile "./src/NuGet.config"');
    shelljs.exec('gulp change-nuspec --nuspec "./src/Syncfusion.EJ2.AspNet.Core.nuspec"');
    var buildCode = shelljs.exec('dotnet build "src/Syncfusion.EJ2.csproj" --verbosity "m" --configuration  "Debug"');
    console.log("\nBuildCode = "+buildCode.code);
    if(buildCode.code != 0){
        done(buildCode.stdout);
        process.exit(1);
    }
    shelljs.exec('git checkout -- src/Syncfusion.EJ2.csproj src/Syncfusion.EJ2.AspNet.Core.nuspec');
    shelljs.cd('../../');
    done();
});

gulp.task('change-nuspec', function (done) {
    console.log(process.argv);
    var file = fs.readFileSync(process.argv[4], 'UTF8');
    file = file.replace(/Release-XML/g, 'Debug');
    fs.writeFileSync(process.argv[4], file);
    done();
});

gulp.task('clean', function(done) {
    shelljs.rm('-rf', './src/bin/');
    shelljs.rm('-rf', './src/obj/');
    shelljs.rm('-rf', './bin/');
    done();
});

gulp.task('aspcore-generate', function (done) {
    var aspSrcGen = require('../third-party/asp-core/src-generator.js');
    var propGen = require('../third-party/asp-core/property-reader');
    var propCollection = propGen(JSON.parse(fs.readFileSync('./public/api/file.json')));
    aspSrcGen(JSON.parse(fs.readFileSync('./third-party/config.json')), propCollection, done);
});

gulp.task('aspcore-build', function (done) {
   // runSequence('aspcore-checkout', 'aspcore-generate', done);
    runSequence('aspcore-checkout', 'aspcore-generate', 'aspcore-compile', done);
});

function dotnetInstall(){
     shelljs.exec('wget https://packages.microsoft.com/config/ubuntu/22.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb');
     shelljs.exec('sudo dpkg -i packages-microsoft-prod.deb');
     shelljs.exec('rm packages-microsoft-prod.deb');
     shelljs.exec('sudo apt-get update');
     shelljs.exec('sudo apt-get install -y apt-transport-https');
     shelljs.exec('sudo apt-get update');
     shelljs.exec('sudo apt-get install -y dotnet-sdk-9.0');
     shelljs.exec('dotnet --version');
}

function net9Install(){
    //shelljs.exec('wget https://packages.microsoft.com/config/ubuntu/22.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb');
     //shelljs.exec('sudo dpkg -i packages-microsoft-prod.deb');
     //shelljs.exec('rm packages-microsoft-prod.deb');
     //shelljs.exec('sudo apt-get update');
     //shelljs.exec('sudo apt-get install -y apt-transport-https');
     //shelljs.exec('sudo apt-get update');
     //shelljs.exec('sudo apt-get install -y dotnet-sdk-9.0');
    shelljs.exec('sudo add-apt-repository ppa:dotnet/backports -y');
    shelljs.exec('sudo apt install dotnet9 -y');
    shelljs.exec('dotnet --version');
}
