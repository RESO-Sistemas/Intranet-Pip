'use strict';

var fs = global.fs = global.fs || require('fs');
var gulp = global.gulp = global.gulp || require('gulp');

var headerErrors = [];
var commonHeaders = ['Bug fixes', 'New Features', 'Features', 'Breaking changes'];
var errors = {
    'h1': 'H1 tag should be - Changelog',
    'h2': 'H2 tag should be - [Unreleased] | released version',
    'h3': 'H3 tag should be - component name',
    'h4': 'H4 tag should be - Bug fixes | Features | Breaking changes'
};

gulp.task('md-header', function(done) {
    if (!fs.existsSync('./CHANGELOG.md')) {
        console.log('There is no changelog file');
        done();
        return;
    }
    var changelog = fs.readFileSync('./CHANGELOG.md', 'utf8');
    var matches = changelog.match(/^(?:#)\s*(.+?)[ \t]*$/gm);
    for (var i = 0; i < matches.length; i++) {
        checkHeaders(matches[i]);
    }
    if (headerErrors.length) {
        for (var j = 0; j < headerErrors.length; j++) {
            console.log(headerErrors[j]);
        }
        process.exit(1);
    }
    done();
});


function checkHeaders(realHeader) {
    var headerSize = realHeader.match(/#/g).length;
    var header = realHeader.substring(headerSize + 1);
    switch (headerSize) {
        case 1:
            if (header !== 'Changelog') {
                headerErrors.push('Header Error: ' + realHeader + ' ==> ' + errors.h1);
            }
            break;
        case 2:
            if (header !== '[Unreleased]' && !RegExp(/^[0-9].+$/).test(header)) {
                headerErrors.push('Header Error: ' + realHeader + ' ==> ' + errors.h2);
            }
            break;
        case 3:
            if (commonHeaders.indexOf(header) !== -1 || checkCommonHeaders(header)) {
                headerErrors.push('Header Error: ' + realHeader + ' ==> ' + errors.h3);
            }
            break;
        case 4:
            const index = commonHeaders.findIndex(element => {
                return element.toLocaleLowerCase === header.toLowerCase();
            });
            if (index !== -1) {
                headerErrors.push('Header Error: ' + realHeader + ' ==> ' + errors.h4);
            }
            break;
    }
}

function checkCommonHeaders(header) {
    for (var i = 0; i < commonHeaders.length; i++) {
        var commonHeader = commonHeaders[i].split(' ').join('').toLowerCase();
        var realHeader = header.split(' ').join('').toLowerCase();
        if (commonHeader.includes(realHeader)) {
            return true;
        }
        return false;
    }
}
