'use strict';

var apiGenerator = require('./api-generator');
var angApiGenerator = require('./angular-api-generator');

//Global variables
var fs = global.fs || require('fs');
var config = fs.existsSync('../../config.json') ? JSON.parse(fs.readFileSync('../../config.json')) : {};
var components = config.components;
var glob = require('glob');
var globalReference = [];
var typeAliasCol = [];
var dirRegex = /Directive|Component/i;
var compRegex = /Component/i;
var typeMatcher = ['Enumeration', 'Interface', 'Class'];
var groupMatch = ['Classes', 'Enumerations', 'Interfaces'];
var curPath = '';
var currModuleName = '';
var apiCollection = {};
var indexCollection = {};
var prChild = [];
var h1 = '# ';
var finalMapper = {
    'Component': 'Components',
    'Directive': 'Directives'
};
var apiThead = '\n| Name | Description |\n|------|-------------|';
var isUpdated = false;
var files = [];
var apiNames = [];
var vueCompContent = {};

function generateReactApi(path) {
    apiGenerator.generateApi(path, 'react');
    if(components) {
        curPath = path;
        var apiJson =   JSON.parse(fs.readFileSync('./public/api/file.json'));
        var children = apiJson.children;
        
        if(files.length) {
            for(var y = 0; y < files.length; y++) {
                apiNames = apiNames.concat(0, files[y].indexOf('.md'));
            }
        }
        preProcess(children);
        for(var child of children) {
            currModuleName = getCurrentModuleName(child);
            if(currModuleName.length && !apiCollection[currModuleName]) {
                apiCollection[currModuleName] = { Component: '', Directive: ''};
            }
            if(!currModuleName) {
                continue;
            }
            if(child.children) {
                for(var childs of child.children) {
                    if(childs.children && dirRegex.test(child.name)) {
                        prChild = [childs];
                        processChildren(prChild);
                    }
                }
            }
        }
        for(var x = 0; x < components.length; x++) {
            if(!indexCollection[components[x]]) {
                indexCollection[components[x]] = '';
            }
            var loc = '../../ej2-docs/src/' + components[x] + '/';
            if (fs.existsSync(loc) && fs.existsSync('./ej2-docs/src/' + components[x])) {
                var componentFile = apiGenerator.replaceSubLimeText(components[x]);
                files = glob.sync(loc + '*.md', { silent: true, 
                    ignore: [loc + 'summary.md',loc + 'api.md',loc+componentFile+'.md',loc+'index.md'] });
                for (var i = 0; i < files.length; i++) {
                    var lname = files[i].slice(files[i].lastIndexOf('/') + 1, files[i].lastIndexOf('.'));
                    if (lname !== 'overview') {
                        var name = lname[0].toUpperCase() + lname.substring(1);
                        indexCollection[components[x]] += '\n* [' + name + '](' + components[x] + '/' + lname + '.md)';
                    }
                }
            }
        }
        if (vueCompContent) {
            fs.writeFileSync('../vueComp.json', JSON.stringify(vueCompContent), 'utf8');
        }
        for(var api in apiCollection) {
            var content = '';
            var collection = apiCollection[api];
            for (var type in collection) {
                if (collection[type].length) {
                    content += '\n## ' + finalMapper[type] + '\n' + apiThead + collection[type] + '\n';
                }
            }
            if (content.length) {
                content = '# API\n' + content;
                generateFile(api, 'overview', content, true);
                generateFile(api, 'summary', apiGenerator.overviewTemplate.replace(/{{:compFolder}}/, api) +
                 indexCollection[api].slice(1), true);
            }

        }
        return isUpdated;
    }
}
exports.generateReactApi = generateReactApi;

function preProcess(children) {
    for (var child of children) {
        var curName = getCurrentModuleName(child);
        var childGroups = child.groups;
        var groupLen;
        if(!globalReference[curName] && curName !== '') {
            globalReference[curName] = [];
        }
        if(childGroups && (groupLen = childGroups.length)) {
            for(var i = 0; i < groupLen; i++) {
                var groups = childGroups[i];
                var gTitle = groups.title;
                if (gTitle === 'Type aliases') {
                    typeAliasCol[curName] = typeAliasCol.concat(groups.children);
                } else if (!curName.length) {
                    continue;
                } else if (groupMatch.indexOf(gTitle) !== -1) {
                    globalReference[curName] = globalReference[curName].concat(groups.children);
                }
            }
        }
    }
}

function getCurrentModuleName(children) {
    var bName = children.name.replace(/"/g, '').split('/')[0];
    return components.indexOf(bName) !== -1 ? bName : '';
}

function generateFile(moduleName, fileName, content, prevChange) {
    var modulePath = curPath + moduleName;
    if (!fs.existsSync(modulePath)) {
        return;
    }
    isUpdated = true;
    if(apiGenerator.isCurrentModuleFile(moduleName + 'component',fileName )){
        fileName = 'index';
    }
    fs.writeFileSync(modulePath + '/' + apiGenerator.convertToLower(fileName, prevChange) + '.md', content, 'utf8');
}

function processChildren(children) {
    for(var curProp of children) {
        var name = curProp.name;
        var kindString = curProp.kindString;
        var decorator = compRegex.test(curProp.sources[0].fileName.match(dirRegex)[0]) ? 'Component' : 'Directive' ;
        if(decorator === 'Directive') {
            if(curProp.extendedTypes && curProp.extendedTypes[0].typeArguments && curProp.extendedTypes[0].typeArguments[0].name) {
                var typeArgs = curProp.extendedTypes[0].typeArguments[0].name;
                var lTypeArgs = apiGenerator.convertToLower(typeArgs, true);
                    if(apiNames.indexOf(lTypeArgs) !== -1) {
                        var apName = apiGenerator.convertToLower(typeArgs);
                        var currText = apiGenerator.getMessageText(curProp, true);
                        currText = apiGenerator.getTableText(currText);
                        if(currText.length){
                            apiCollection[currModuleName][decorator] += '\n| [' + 
                                curProp.name + '](./' + apName + ')| ' + currText + '|';
                            var apiFile = fs.readFileSync('ej2-docs/src/' + currModuleName + '/' + apName + '.md', 'utf8');
                            apiFile = h1 + curProp.name + '\n\n' + apiGenerator.getMessageText(curProp) + 
                                '\n\n' + apiFile.slice(apiFile.indexOf('##'));
                            fs.writeFileSync('./ej2-docs/src/' + currModuleName + '/' + 
                                apiGenerator.convertToLower(curProp.name) + '.md', apiFile, 'utf8');
                        }
                        if(! indexCollection[currModuleName]) {
                            indexCollection[currModuleName] = '';
                        }
                        if(!apiGenerator.isCurrentModuleFile(currModuleName + 'component',curProp.name )){
                         indexCollection[currModuleName] += '\n* [' + curProp.name + '](' + currModuleName + '/' + apName + '.md)';
                        }
                    }
            }
        } else if (decorator === 'Component' && typeMatcher.indexOf(kindString) !== -1 && curProp.flags.isExported &&
            angApiGenerator.createTypeReference(curProp, name, kindString, currModuleName, curPath, true, vueCompContent)) {
            var lname = apiGenerator.convertToLower(name);
            var shortText = apiGenerator.getMessageText(curProp, true);
            var curText = apiGenerator.getTableText(shortText);
            if (curText.length) {
                var moName = (apiGenerator.isCurrentModuleFile(currModuleName + 'component', lname) ?
                    '' : ( lname + '/'));
                apiCollection[currModuleName][decorator] += '\n| [' + name + '](./' + moName + ')| ' + curText + '|';
            }
            if (!indexCollection[currModuleName]) {
                indexCollection[currModuleName] = '';
            }
            if (!apiGenerator.isCurrentModuleFile(currModuleName + 'component', name)) {
                indexCollection[currModuleName] += '\n* [' + name + '](' + currModuleName + '/' + lname + ')';
            }
        }
    }
}
