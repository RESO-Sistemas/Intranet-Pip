'use strict';

var fs = global.fs = global.fs || require('fs');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var gulp = global.gulp = global.gulp || require('gulp');
var common = global.config = global.config || require('../utils/common.js');
var apiGenerator = require('../generators/api-generator.js');
var apiCodeBlock = require('../generators/api-code-block.js');
var simpleGit = global.simpleGit = global.simpleGit || require('simple-git');
var user = 'SyncfusionAutomation';
var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
var stageBranch = process.env.githubSourceBranch || 'development';
var localpath = './ej2-docs/src/';
var currentPackage = common.currentPackage;

gulp.task('local-api', function () {
    apiGenerator.clearComponentFolder(localpath);
    apiGenerator.generateApi('./ej2-docs/src/');
    apiCodeBlock.addCodeBlock('ts');
});

/**
 * publish typedoc contents
 */
gulp.task('publish-api', function (done) {
    try {
        if (!fs.existsSync('./ej2-docs')) {
            fs.mkdirSync('./ej2-docs');
            var ej2docRepo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-api-library.git';
            simpleGit().clone(ej2docRepo, './ej2-docs', function (err) {
                if (err) {
                    done(err);
                    return;
                }
            }).then(function () {
                simpleGit('./ej2-docs').checkout(stageBranch, function (err) {
                    if (err) {
                        done(err);
                        return;
                    }
                    apiGenerator.clearComponentFolder(localpath);
                    // create api md files from typedoc
                    if (apiGenerator.generateApi(localpath)) {
                        apiCodeBlock.addCodeBlock('ts');
                        // push updated ej2-docs content to gitlab
                        simpleGit('./ej2-docs').init()
                            .add('./*')
                            .commit('documentation(EJ2-000): ' + currentPackage + ' - api content published')
                            .pull(stageBranch)
                            .push(ej2docRepo, stageBranch, function (error) {
                                if (error) {
                                    done(error);
                                    return;
                                }
                                console.log(currentPackage + ' - ej2 docs api content published');
                                if (fs.existsSync(`./ej2-docs-api/src`) && fs.existsSync(`./ej2-docs/src`)) {
                                    shelljs.cp('-r', `./ej2-docs-api/src`, `./ej2-docs/src`);
                                }
                                done();
                            });
                    } else {
                        done();
                    }
                });
            });
        } else {
            done();
            return;
        }
    } catch (error) {
        throw error;
    }
});