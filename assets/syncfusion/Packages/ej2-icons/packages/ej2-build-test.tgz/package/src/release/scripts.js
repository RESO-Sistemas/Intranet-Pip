'use strict';

var common = require('../utils/common');
var build = require('../tasks/build.js');
var publish = require('../publish/base.js');
var gulp = global.gulp = global.gulp || require('gulp');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
var fs = global.fs = global.fs || require('fs');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var os = require('os');
var src = ['./src/**/*.ts', './src/**/*.tsx', '!./**/*model.d.ts'];

var rollup = require('rollup'); // jshint ignore:line
var rollupUglify = require('rollup-plugin-uglify');
var rollupCommonjs = require('rollup-plugin-commonjs');
// var rollupResolve = require('rollup-plugin-node-resolve');
var rollupSourcemaps = require('rollup-plugin-sourcemaps');
var rollupUglifyEs = require('rollup-plugin-uglify-es');
var webpack = require('webpack');
var webpackStream = require('webpack-stream');
var path = global.path = global.path || require('path');
const TerserPlugin = require('terser-webpack-plugin');

/* jshint ignore:start */
gulp.task('esm5-scripts', async function () {
    var bObj = distScripts('esm5');
    var bundle = await rollup.rollup(bObj[0]);
    await bundle.write(bObj[1]);
});

gulp.task('esm2015-scripts', async function () {
    var bObj = distScripts('esm2015');
    var bundle = await rollup.rollup(bObj[0]);
    await bundle.write(bObj[1]);
});

gulp.task('blazor-es6-scripts', async function () {
    var isThirdPartyPackage = common.currentPackage.indexOf('angular') !== -1 || common.currentPackage.indexOf('react') !== -1 ||
        common.currentPackage.indexOf('vue') !== -1;
    if (isThirdPartyPackage || process.env.RELEASE_VERSION) {
        return;
    }
    if (fs.existsSync(`./third-party/`)) {
        var modules = fs.readdirSync('./src/').filter(file => fs.statSync(`./src/${file}`).isDirectory());
        for (var i = 0; i < modules.length; i++) {
            var bundleObj = {
                input: `./src/${modules[i]}/index.js`,
                plugins: [
                    rollupCommonjs()
                ]
            };
            var fileName = modules[i].replace(/-/g, '');
            fileName = (fileName === 'common' || fileName === 'base') ? `${common.currentPackage.replace(/ej2/, '').replace(/-/g, '')}base` : fileName;
            var filePath = `dist/blazor/${fileName}.js`;
            var writeObj = {
                file: filePath,
                format: 'es'
            };
            var bundle = await rollup.rollup(bundleObj);
            await bundle.write(writeObj);
            var moduleContent = fs.readFileSync(filePath, 'utf8');
            moduleContent = moduleContent.replace(/@class/g, '@__PURE__ @class');
            fs.writeFileSync(filePath, moduleContent);
        }
    }
    else {
        var user = 'SyncfusionAutomation';
        var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
        var branch = process.env.githubSourceBranch;
        var gitClonePath = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-blazor-source';
        var blazorClone = shelljs.exec('git clone --filter=blob:none ' + gitClonePath + ' -b ' + branch + ' ./blazor-source', { silent: true });
        if (blazorClone.code !== 0) {
            done();
            return;
        }
        else {
            var blazorPath = `./blazor-source/Scripts/modules/`;
            shelljs.mkdir('-p', blazorPath);
            var scriptContent = fs.readFileSync(`./dist/es6/${common.currentPackage}.es5.js`, 'utf8');
            var destFile = common.currentPackage.replace(/-/g, '').replace(/ej2/, '');
            fs.writeFileSync(`${blazorPath}${destFile}.js`, scriptContent);
            shelljs.cd(`./blazor-source`);
            shelljs.exec('git add .');
            shelljs.exec('git pull');
            shelljs.exec('git commit -m \"ci-skip(EJ2-000): source shipping from ' + common.currentPackage + '\" --no-verify');
            shelljs.exec('git push');
            shelljs.cd('../');
        }
    }
});
/* jshint ignore:end */

gulp.task('esm-scripts', function (done) {
    freeUpMem();
    runSequence('esm5-scripts', 'esm2015-scripts', done);
});

function freeUpMem() {
    if (os.hostname().toLowerCase().indexOf('jenkins') !== -1) {
        shelljs.exec('free -m');
    }
    shelljs.exec('increase-memory-limit');
}

gulp.task('blazor-ts-compile', (done) => {
    var tsConfigs = {
        target: 'es5',
        module: 'es2015',
        removeComments: false
    };

    var gulpObj = {
        src: ['./blazor/**/*.ts'],
        dest: './blazor',
        base: 'blazor'
    };

    build.compileTSFiles(tsConfigs, gulpObj, done);
});

/* jshint ignore:start */
gulp.task('global-scripts', gulp.series('blazor-ts-compile', async function (done) {
    shelljs.rm('-rf', './src/global.ts');
    var bObj = distScripts('global');
    var bundle = await rollup.rollup(bObj[0]);
    await bundle.write(bObj[1]);
    indexGenerator();

    console.log('blazor scripts', bObj[2], bObj);
    if (fs.existsSync(bObj[2])) {
        var globalFile = fs.readFileSync(bObj[2], 'utf8');
        var mapper = JSON.parse(fs.readFileSync(__dirname + '/globalPackMapper.json', 'utf8'));
        for (var map of Object.keys(mapper)) {
            globalFile = globalFile.replace(map, mapper[map]);
        }
        fs.writeFileSync(bObj[2], globalFile, 'utf8');
    }

    // blazor global script
    var config = common.config();
    // blazor native rendering scripts
    var glob = global.glob = global.glob || require('glob');
    var nativeFiles = (config.controlName == "PdfViewer" || config.controlName == "DataGrid" || config.controlName == "SpreadSheet") ? glob.sync('./blazor/**/sf-*.js') : glob.sync('./blazor/sf-*.js');
    for (var i = 0; i < nativeFiles.length; i++) {
        var fileName = path.basename(nativeFiles[i]);
        var fileContent = fs.readFileSync(nativeFiles[i], 'utf8');
        var relativeRegex = fileContent.match(/import (.*) \'..\/(.*)\';/g);
        if (relativeRegex) {
            var currentPackage = `@syncfusion/${common.currentPackage}`;
            for (var j = 0; j < relativeRegex.length; j++) {
                fileContent = fileContent.replace(relativeRegex[j], relativeRegex[j].replace(/\'(.*)\'/, `'${currentPackage}'`));
            }
            fs.writeFileSync(nativeFiles[i], fileContent);
        }
        var namespaces = config.blazorNamespace ? Object.keys(config.blazorNamespace) : [];
        var namespace = namespaces.filter(name => config.blazorNamespace[name] === fileName)[0];
        if (namespace) {
            var blazorModule = await rollup.rollup({
                input: nativeFiles[i],
                plugins: [
                    rollupCommonjs()
                ]
            });
            var blazorNativeFile = 'dist/global/blazor/' + fileName
            await blazorModule.write({
                file: blazorNativeFile,
                format: 'iife',
                name: `sfBlazor.${namespace}`
            });

            var blazorNativeContent = fs.readFileSync(blazorNativeFile, 'utf8');
            var matchReg = blazorNativeContent.match(/\(function \((.*)\) \{/);
            if (matchReg && matchReg[1]) {
                blazorNativeContent = blazorNativeContent.replace(new RegExp(`\\(${matchReg[1]}\\)`, 'g'), '()');
            }
            blazorNativeContent = blazorNativeContent.replace(/this.sfBlazor/g, "window.sfBlazor");
            var blazorMapper = JSON.parse(fs.readFileSync(__dirname + '/globalPackMapper.json', 'utf8').replace(/ej\./g, 'sf.'));
            for (var map of Object.keys(blazorMapper)) {
                blazorNativeContent = blazorNativeContent.replace(new RegExp(map, 'g'), blazorMapper[map]);
            }
            fs.writeFileSync(blazorNativeFile, blazorNativeContent);
        }
        done();
    }

    // prevent ej2 wrapper scripts to the repository
    if ((!config.blazorDependencies && fs.existsSync('./third-party/config.json')) ||
        (config.blazorDependencies && config.blazorDependencies.ignoreScripts)) {
        return;
    }
    var glob = global.glob || require('glob');

    var srcPath = './blazorGlobalSrc';
    var impPathRegex = /'[^']+'/;
    var curPackage = common.currentPackage;
    var packName = common.currentPackage.replace(/ej2/, '').replace(/-/g, '');
    var currentPackage = common.currentPackage.replace(/ej2/g, '').replace(/-/g, '');

    if (fs.existsSync('./third-party/config.json') && config.blazorDependencies && !config.blazorDependencies.isSingleBundle) {
        var blazorDeps = JSON.parse(fs.readFileSync('config.json', 'utf8')).blazorDependencies || {};
        var commonDeps = blazorDeps.common || [];

        shelljs.mkdir('-p', srcPath);
        shelljs.cp('-r', './src/*', srcPath);

        var compFiles = glob.sync(srcPath + '/**/*.js', { ignore: [srcPath + '/common/*', srcPath + '/**/index.js', srcPath + '/**/global.js'] });
        console.log('compFiles:\n' + compFiles.join('\n') + '\n');

        for (var compFile of compFiles) {
            // console.log('compfiles', compFiles);
            var curCompName = compFile.match(/blazorGlobalSrc\/([^\/]+)/)[1];
            var blazorCompDeps = blazorDeps[curCompName] || {};
            var internalCompDeps = (blazorCompDeps.internal && blazorCompDeps.internal.length > 0) ? blazorCompDeps.internal : [];
            var ignoreArray = commonDeps.concat(internalCompDeps);
            if (ignoreArray.length > 0) {
                var importRegex = new RegExp('import[^\']+\'[\.\/]+(' + ignoreArray.join('|') + ')\'', 'g');
                var fileContent = fs.readFileSync(compFile, 'utf8');
                var matchedImports = fileContent.match(importRegex);
                if (matchedImports && matchedImports.length > 0) {
                    console.log('\nFile: ' + compFile);
                    console.log('\nMatched Imports:\n------------------\n' + matchedImports.join('\n'));
                    var replaceImports = matchedImports.map((val) => {
                        var allMatch = val.match(/import \* as (.*) from/);
                        if (allMatch) {
                            var moduleName = curPackage.split(/-/g).map(str => {
                                var value = str;
                                if (value !== 'ej2') {
                                    value = value[0].toUpperCase() + value.slice(1);
                                }
                                return value;
                            }).join('');
                            val = val.replace(allMatch[1], moduleName);
                            fileContent = fileContent.replace(new RegExp(allMatch[1], 'g'), moduleName);
                        }
                        return val.replace(impPathRegex, `'@syncfusion/${curPackage}'`);
                    });
                    console.log('\nReplace Imports:\n-------------------\n' + replaceImports.join('\n'));
                    for (var i = 0; i < matchedImports.length; i++) {
                        fileContent = fileContent.replace(matchedImports[i], replaceImports[i]);
                    }
                    fs.writeFileSync(compFile, fileContent, 'utf8');
                }
            }
        }
        if (commonDeps.length > 0) {
            var exportTemplateInit = `export * from './`;
            var exportTemplateClose = `';\n`;
            var globalBaseContent = exportTemplateInit + commonDeps.join(exportTemplateClose + exportTemplateInit) + exportTemplateClose;
            var baseGlobalFile = `dist/global/blazor/${packName}base.js`;
            fs.writeFileSync(srcPath + '/global-base.js', globalBaseContent, 'utf8');

            var bundle = await rollup.rollup({
                input: `${srcPath}/global-base.js`,
                plugins: [
                    rollupSourcemaps(),
                    rollupCommonjs()
                ]
            });
            await bundle.write({
                file: baseGlobalFile,
                format: 'iife',
                name: 'sf.curInst',
                footer: `window.sf.${packName} = window.sf.base.extend({}, window.sf.${packName}, ${packName}base({}));`
            });
            var baseFileContent = fs.readFileSync(baseGlobalFile, 'utf8');
            baseFileContent = baseFileContent.replace('this.sf.curInst', 'var ' + packName + 'base').replace(/this.sf/g, 'window.sf').replace(/\}\(\{\}\,(.*)\)\;/, '});');
            var iifeMethodRegex = baseFileContent.match(/\(function \(exports\,(.*)\) \{/);
            if (iifeMethodRegex) {
                baseFileContent = baseFileContent.replace(',' + iifeMethodRegex[1], '');
            }
            var blazorMapper = JSON.parse(fs.readFileSync(__dirname + '/globalPackMapper.json', 'utf8').replace(/ej\./g, 'sf.'));
            for (var map of Object.keys(blazorMapper)) {
                baseFileContent = baseFileContent.replace(new RegExp(map, 'g'), blazorMapper[map]);
            }
            fs.writeFileSync(baseGlobalFile, baseFileContent);
        }


        var configJson = JSON.parse(fs.readFileSync('./third-party/config.json'), 'utf8');
        if (configJson && configJson.components && configJson.components.length > 0) {
            var compConfig = blazorGlobalScriptsGenerator(configJson, srcPath);
            var wrapperScripts = common.config().blazorWrapperScripts;
            var comps = compConfig.comps;

            for (var comp of comps) {
                if (wrapperScripts.indexOf(comp) === -1) {
                    continue;
                }
                var compName = comp.replace(/-/g, '');
                var moduleName = compConfig.moduleNames[compName] ? compConfig.moduleNames[compName] : compName;
                var compGlobalFile = `dist/global/blazor/${moduleName}.js`;
                var bundle = await rollup.rollup({
                    input: `${srcPath}/${comp}/global.js`,
                    plugins: [
                        rollupSourcemaps(),
                        rollupCommonjs()
                    ]
                });
                await bundle.write({
                    file: compGlobalFile,
                    format: 'iife',
                    name: 'sf.curInst'
                });

                var compFileContent = fs.readFileSync(compGlobalFile, 'utf8');
                compFileContent = compFileContent.replace('this.sf.curInst', 'var sf' + compName).replace(/this.sf/g, 'window.sf');
                var matchReg = compFileContent.match(/\}\(\{\}\,(.*)\)/);
                if (matchReg && matchReg[1]) {
                    var blazorAdaptor = currentPackage == 'data' ? `
sfBlazor.initBlazorAdaptor();` : '';
                    var replaceContent = `
    sf.${fs.existsSync('./third-party/') ? packName : currentPackage} = sf.${fs.existsSync('./third-party/') ?
                            ('base.extend({}, sf.' + packName + ', sf' + compName) : currentPackage}({}));${blazorAdaptor}`;
                    compFileContent = compFileContent.replace(/\}\(\{\}\,(.*)\)\;/, '});') + replaceContent;

                    var iifeMethodRegex = compFileContent.match(/\(function \(exports\,(.*)\) \{/);
                    compFileContent = compFileContent.replace(',' + iifeMethodRegex[1], '');
                    var blazorMapper = JSON.parse(fs.readFileSync(__dirname + '/globalPackMapper.json', 'utf8').replace(/ej\./g, 'sf.'));
                    for (var map of Object.keys(blazorMapper)) {
                        compFileContent = compFileContent.replace(new RegExp(map, 'g'), blazorMapper[map]);
                    }
                }
                if (compConfig.commonModules[comp]) {
                    var regex = new RegExp(`${compConfig.compClassNames[comp]}.Inject(.*);`, 'g');
                    var injectContent = compFileContent.match(regex);
                    if (injectContent) {
                        var injectable = injectContent[injectContent.length - 1];
                        var commonModule = `${compConfig.compClassNames[comp]}.Inject(${compConfig.commonModules[comp].join(',')});`
                        var replacement = injectable + '\n' + commonModule;
                        compFileContent = compFileContent.replace(injectable, replacement);
                    }
                    else {
                        var exportRegex = new RegExp(`exports.${compConfig.compClassNames[comp]} = ${compConfig.compClassNames[comp]};`);
                        var exportsContent = compFileContent.match(exportRegex);
                        if (exportsContent) {
                            var commonModule = `${compConfig.compClassNames[comp]}.Inject(${compConfig.commonModules[comp].join(',')});`;
                            compFileContent = compFileContent.replace(exportsContent[0], commonModule + '\n\n' + exportsContent[0]);
                        }
                    }
                }
                fs.writeFileSync(compGlobalFile, compFileContent);
            }
        }

        shelljs.rm('-rf', srcPath);
        console.log('\n------------------------------\nGlobal componenet wise scripts generated\n');
    }
    // blazor library or single bundle scripts
    else {
        if (currentPackage != 'diagrams') {
            var blazorModule = await rollup.rollup({
                input: './src/global.js',
                plugins: [
                    rollupCommonjs()
                ]
            });
            var blazorGlobalFile = 'dist/global/blazor/' + currentPackage + '.js'
            await blazorModule.write({
                file: blazorGlobalFile,
                format: 'iife',
                name: 'sf.' + currentPackage
            });
            var blazorContent = fs.readFileSync(blazorGlobalFile, 'utf8');
            blazorContent = blazorContent.replace(/this.sf/g, 'window.sf');
            var matchReg = blazorContent.match(/\}\(\{\}\,(.*)\)/);
            if (matchReg && matchReg[1]) {
                var dependencies = matchReg[1].replace(/ej2/g, 'sf.').toLowerCase();
                var blazorAdaptor = currentPackage == 'data' ? `
            sfBlazor.initBlazorAdaptor();` : '';
                var libScript = config.blazorDependencies && config.blazorDependencies.isSingleBundle ? getSingleBundleModules(packName) :
                    '';
                var replaceContent = `});
    ${libScript}
        sf.${currentPackage} = sf.${currentPackage}({});${blazorAdaptor}`;
                blazorContent = blazorContent.replace(/\}\(\{\}\,(.*)\)\;/, replaceContent);

                var iifeMethodRegex = blazorContent.match(/\(function \(exports\,(.*)\) \{/);
                blazorContent = blazorContent.replace(',' + iifeMethodRegex[1], '');
                var blazorMapper = JSON.parse(fs.readFileSync(__dirname + '/globalPackMapper.json', 'utf8').replace(/ej\./g, 'sf.'));
                for (var map of Object.keys(blazorMapper)) {
                    blazorContent = blazorContent.replace(new RegExp(map, 'g'), blazorMapper[map]);
                }
            }
            else {
                blazorContent += currentPackage !== 'base' && currentPackage !== 'fileutils' ? `\nsfBlazor.libs.push("${currentPackage}");` : '';
            }
            fs.writeFileSync(blazorGlobalFile, blazorContent);
        }
    }
    done();
}));

function getSingleBundleModules(packName) {
    var configJson = JSON.parse(fs.readFileSync('./third-party/config.json'), 'utf8');
    var components = configJson.components;
    var modules = '';
    for (var i = 0; i < components.length; i++) {
        modules += `sfBlazor.modules["${components[i].baseClass.toLowerCase()}"] = "${packName}.${components[i].baseClass}";\n`;
    }
    return modules;
}

gulp.task('umd-scripts', async function () {
    var bObj = distScripts('umd');
    freeUpMem();
    var bundle = await rollup.rollup(bObj[0]);
    await bundle.write(bObj[1]);
});

/* jshint ignore:end */

gulp.task('rm-temp', function (done) {
    shelljs.rm('-rf', './dist/src');
    done();
});

gulp.task('es5-scripts', function (done) {
    fs.writeFileSync('./src/global.ts', 'export * from \'./index\';\n');
    if (fs.existsSync('./third-party/config.json')) {
        globalTsGenerator(JSON.parse(fs.readFileSync('./third-party/config.json'), 'utf8'));
    }
    esScripts('es5', done);
});

gulp.task('es6-scripts', function (done) {
    esScripts('es6', done);
});

gulp.task('es-scripts', function (done) {
    runSequence('es5-scripts', 'es6-scripts', done);
});

gulp.task('di-scripts', function (done) {
    runSequence('components-script', 'react-components-script', done);
});

gulp.task('ship-to-app', function (done) {
    shelljs.exec('gulp es5scripts-local');
    if (!process.argv[4]) {
        done();
    }
    var repoName = process.argv[4].replace(/\\/g, '/');
    if (fs.existsSync('./package.json')) {
        var ed = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
        var packageName = ed.name;
        shelljs.cp('-r', 'dist/es5-local/*', repoName + '/node_modules/' + packageName + '/src');
    }
    done();
});

gulp.task('es5scripts-local', function (done) {
    esScripts('es5-local', done);
});

/* jshint ignore:start */
gulp.task('components-script', async function () {
    freeUpMem();
    if ((/-ng|-react|-vue|-base/g).test(common.currentRepo)) {
        return;
    }
    if (fs.existsSync('./src/components.js')) {
        var glob = global.glob = global.glob || require('glob');
        var removeSrcMap = true;
        var bObj = distScripts('esm5', {
            dist: './src/components.js',
            input: './dist/src/es5/components.js'
        });
        var bunComp = await rollup.rollup(bObj[0]);
        await bunComp.write(bObj[1]);
        fs.writeFileSync('./components.d.ts', 'export * from \'./src/components\'');

        var thridPartyConfig = require('../../../../../third-party/config.json');
        console.log(__dirname);
        for (var i = 0; i < thridPartyConfig.components.length; i++) {
            var curComponent = thridPartyConfig.components[i];
            if (curComponent.diModuleFiles) {
                curComponent.diModuleFiles.forEach(async function (mod) {
                    console.log("log dir " + curComponent.directoryName + ' ' + mod.fileName.toLowerCase());
                    if (!fs.existsSync('./' + curComponent.directoryName)) {
                        shelljs.mkdir('./' + curComponent.directoryName);
                    }
                    var bObj = distScripts('esm5', {
                        dist: './' + curComponent.directoryName + '/' + mod.fileName.toLowerCase() + '.js',
                        input: glob.sync('./dist/src/es5/' + curComponent.directoryName + '/**/' + mod.fileName.toLowerCase() + '.js')[0]
                    }, removeSrcMap);

                    var reference = glob.sync('./src/' + curComponent.directoryName + '/**/' + mod.fileName.toLowerCase() + '.js')[0];
                    if (reference) {
                        reference = reference.replace(/.js/g, '')
                    }
                    freeUpMem();
                    fs.writeFileSync('./' + curComponent.directoryName + '/' + mod.fileName.toLowerCase() +
                        '.d.ts', 'export * from \'.' + reference + '\'');
                    var bundle = await rollup.rollup(bObj[0]);
                    await bundle.write(bObj[1]);
                });
            }
        }
    }
});


gulp.task('react-components-script', async function () {
    freeUpMem();
    var readPackname = JSON.parse(fs.readFileSync('./package.json'));
    if (!(/-react/g).test(readPackname.name)) {
        return;
    }
    if (fs.existsSync('./components.js')) {
        var bObj = distScripts('esm5', {
            dist: './components.js',
            input: './dist/src/es5/components.js'
        });
        var bundle = await rollup.rollup(bObj[0]);
        await bundle.write(bObj[1]);
        var readF = fs.readFileSync('./components.ts', 'utf8');
        fs.writeFileSync('./components.d.ts', readF);

        var reactThridPartyConfig = require('../../../../../diConfig.json');
        var packageName = require('../../../../../package.json');
        for (var i = 0; i < reactThridPartyConfig.components.length; i++) {
            var curReactComponent = reactThridPartyConfig.components[i];
            var packName = (packageName.name).replace("-react", '');
            if (curReactComponent.diModuleFiles) {
                curReactComponent.diModuleFiles.forEach(async function (mod) {
                    console.log("log dir " + curReactComponent.directoryName + ' ' + mod.fileName.toLowerCase());
                    if (!fs.existsSync('./' + curReactComponent.directoryName)) {
                        shelljs.mkdir('./' + curReactComponent.directoryName);
                    }
                    freeUpMem();
                    fs.writeFileSync('./' + curReactComponent.directoryName + '/' + mod.fileName.toLowerCase() +
                        '.d.ts', 'export * from \'' + packName + '/' + curReactComponent.directoryName + '/' + mod.fileName.toLowerCase() + '\'');

                    fs.writeFileSync('./' + curReactComponent.directoryName + '/' + mod.fileName.toLowerCase() +
                        '.js', 'export * from \'' + packName + '/' + curReactComponent.directoryName + '/' + mod.fileName.toLowerCase() + '\'');
                });
            }
        }
    }
});
/* jshint ignore:end */

/**
 * Ship typescript source files for dedupe detection
 */
gulp.task('ship-ts', (done) => {
    publish.shipSrc('./src/**/*.{ts,tsx}', './dist/ts/', ['./src/**/*.d.ts', './**/index.ts']);
    done();
});

/**
 * Set license details in the dist files
 */
gulp.task('license', function (done) {
    var fs = global.fs = global.fs || require('fs');
    var path = global.path = global.path || require('path');
    var glob = global.glob = global.glob || require('glob');
    var platformName = JSON.parse(fs.readFileSync('./package.json')).name.split('/')[1];
    var files;
    if (platformName.indexOf('angular')) {
        files = glob.sync('./dist/{@syncfusion,dist}/*');
    } else {
        files = glob.sync('./dist/**/*', {
            ignore: '{./dist/ts/**/*,./dist/es6/**/*,./dist/**/*.map}'
        });
    }
    var license = fs.readFileSync(__dirname + '/../utils/license', 'utf8');
    var version = common.currentVersion;
    license = license.replace('{{version}}', version);
    for (var i = 0; i < files.length; i++) {
        if (path.extname(files[i]).length) {
            var licenseContent = license.replace('{{filename}}', path.basename(files[i]));
            licenseContent += fs.readFileSync(files[i]);
            fs.writeFileSync(files[i], licenseContent);
        }
    }
    done();
});

//adding @__PURE__ comment for webpack bundling
gulp.task('add-pure-webpack', function (done) {
    var path = require('path');
    var filePath = `./dist/es6/${common.currentPackage}.es5.js`;
    if (!fs.existsSync(path.resolve(filePath))) {
        return;
    }
    var es5Content = fs.readFileSync(filePath, 'utf-8');
    es5Content = es5Content.replace(/@class/g, '@__PURE__ @class');
    fs.writeFileSync(filePath, es5Content, 'utf-8');
    done();
});

/**
 * Generate CDN scripts.
 */
gulp.task('cdn-scripts', function (done) {
    var packJson = JSON.parse(fs.readFileSync('./package.json', 'UTF8'));
    var packName = packJson.name.split('/')[1];
    var isReactPack = packName.indexOf('react') > 1;
    var scriptName = packName + '.min.js';
    var externalNames = JSON.parse(fs.readFileSync(path.resolve('./node_modules/@syncfusion/ej2-build-test/libraries.json'), 'UTF8'));
    var libName = externalNames[packJson.name];
    if (isReactPack && !libName) {
        var libReact = [];
        var reactPacks = packName.split('-');
        reactPacks.forEach((reactPack) => {
            var name = reactPack === 'ej2' ? 'Syncfusion' : reactPack;
            libReact.push(name[0].toUpperCase() + name.slice(1));
        });
        libName = libReact.join('');
    }
    if (libName) {
        gulp.src(path.resolve('./src/index.js'))
            .pipe(webpackStream({
                mode: 'production',
                output: {
                    filename: scriptName,
                    library: libName,
                    libraryTarget: 'umd'
                },
                target: 'web',
                externals: externalNames,
                optimization: {
                    minimize: true, // Enable minification
                    minimizer: [new TerserPlugin()], // Use TerserPlugin for minification
                }
            },
                webpack
            ))
            .pipe(gulp.dest('./dist'))
            .on('end', done).on('error', done);
    } else { done(); }
});

gulp.task('dist-scripts', function (done) {
    runSequence('ship-ts', 'es-scripts', 'esm-scripts', 'global-scripts', 'umd-scripts', 'rm-temp', 'add-pure-webpack', 'cdn-scripts', done);
});

gulp.task('release-scripts', function (done) {
    runSequence('dist-scripts', done);
});

function esScripts(sModule, done) {
    var isLocalScript = false;
    if (sModule === 'es5-local') {
        sModule = 'es5';
        isLocalScript = true;
    }
    var tsConfigs = {
        target: sModule,
        module: 'es6',
        lib: ['es5', 'es6', 'es2015.collection', 'es2015.core', 'es2015', 'dom'],
        types: ['jasmine', 'jasmine-ajax', 'requirejs', 'chai'],
        removeComments: false
    };
    var gulpObj = {
        src: src,
        dest: (sModule === 'es5' ? './src' : './dist/src/' + sModule),
        base: 'src'
    };
    if (sModule === 'es5') {
        var gObj = {
            dest: './',
            base: './',
            src: ['./*.ts', './*.tsx', '!./**/*model.d.ts']
        };
        if (isLocalScript) {
            gObj.dest = gulpObj.dest = './dist/es5-local';
        }
        build.compileTSFiles(tsConfigs, gObj, function () {
            build.compileTSFiles(tsConfigs, gulpObj, done);

        });
    } else {
        build.compileTSFiles(tsConfigs, gulpObj, done);
    }
}

function distScripts(scripts, removeSrcMap) { // jshint ignore:line
    var packJson = JSON.parse(fs.readFileSync('./package.json', 'UTF8'));
    packJson.module = './index.js';
    fs.writeFileSync('./package.json', JSON.stringify(packJson), 'UTF8');
    var fileExt = {
        esm5: '.es5',
        esm2015: '.es2015',
        umd: '.umd.min',
        global: '.min'
    };
    var format = {
        umd: 'umd',
        global: 'iife',
        esm5: 'es',
        esm2015: 'es'
    };
    var input = scripts === 'esm2015' ? 'es6' : 'es5';
    var umd = scripts === 'umd';
    var global = scripts === 'global';
    var dir = global ? 'global' : 'es6';
    var file = (umd ? 'dist/' : 'dist/' + dir + '/') + common.currentPackage + fileExt[scripts] + '.js';
    var writeObj;
    if (removeSrcMap === true) {
        writeObj = {
            file: file,
            format: format[scripts]
        };
    } else {
        writeObj = {
            file: file,
            format: format[scripts],
            sourcemap: true
        };
    }
    var entryPoint = (input === 'es6') ? './dist/src/es6/index.js' : ('./src/' + (global ? 'global' : 'index') + '.js');
    var bundleObj = {
        input: entryPoint,
        plugins: [
            rollupSourcemaps(),
            rollupCommonjs()
        ]
    };
    if (umd || global) {
        writeObj.name = 'ej';
        if (global) {
            writeObj.name = 'ej.' + common.currentPackage.slice(4).replace(/-/g, '');
            writeObj.footer = 'this.ejs = ej;';
            // bundleObj.plugins = bundleObj.plugins.concat(rollupResolve());
            bundleObj.plugins = bundleObj.plugins.concat(rollupUglifyEs());
        } else {
            bundleObj.plugins = bundleObj.plugins.concat(rollupUglify.uglify());
        }
    }
    return [bundleObj, writeObj, file];
}

function indexGenerator() { // jshint ignore:line
    var name = common.currentPackage.replace('ej2-', '');
    var nameSpace = name.replace(/-/g, '');
    var importStats = 'import * as _' + nameSpace + ' from \'@syncfusion\/ej2-' + name + '\';';
    var exportStats = '\n\nexport declare namespace ej {\n    const ' + nameSpace + ': typeof _' + nameSpace + ';';
    // var deps = JSON.parse(fs.readFileSync('package.json', 'utf8')).dependencies;
    // var dNameSpace;
    // if (deps) {
    //     var dNames = Object.keys(deps);
    //     for (var dName of dNames) {
    //         if (dName.indexOf('@syncfusion/') !== -1) {
    //             dNameSpace = dName.replace('@syncfusion/ej2-', '').replace(/-/g, '');
    //             importStats += '\nimport * as _' + dNameSpace + ' from \'' + dName + '\';';
    //             exportStats += '\n    const ' + dNameSpace + ': typeof _' + dNameSpace + ';';
    //         }
    //     }
    // }
    exportStats += '\n}\n';
    fs.writeFileSync('./dist/global/index.d.ts', importStats + exportStats, 'utf8');
}

function globalTsGenerator(config) {
    if (!config) {
        return;
    }
    var imports = '';
    var content = '';
    for (var comp of config.components) {
        if (comp.dynamicModules && comp.dynamicModules.length > 0) {
            if (!imports) {
                imports = 'import * as index from \'.\/index\';\n';
            }
            var baseClass = comp.baseClass;
            content += 'index.' + baseClass + '.Inject(index.' + comp.dynamicModules.join(',index.') + ');\n';
        }
    }
    var exportContent = 'export * from \'./index\';\n';
    fs.writeFileSync('./src/global.ts', imports + content + exportContent);
}

/* jshint ignore:start */
function blazorGlobalScriptsGenerator(config, srcPath) {
    var commonConfig = common.config();
    var compConfig = { compClassNames: {}, moduleNames: {}, ignoreScripts: [], commonModules: {} };
    var comps = [];
    var components = config.components;
    if (commonConfig.blazorLibraries) {
        var libraries = Object.keys(commonConfig.blazorLibraries);
        libraries.forEach(lib => {
            var libConfig = {
                directoryName: lib,
                baseClass: commonConfig.blazorLibraries[lib]
            };
            components.push(libConfig);
        });

    }
    for (var comp of components) {
        var imports = '';
        var content = '';
        var exportContent = 'export * from \'./index\';\n';
        var dynamicModules = comp.blazorDynamicModules ? comp.blazorDynamicModules : comp.dynamicModules;
        if (dynamicModules && dynamicModules.length) {
            imports = 'import * as index from \'.\/index\';\n';
            var baseClass = comp.baseClass;
            content += 'index.' + baseClass + '.Inject(index.' + dynamicModules.join(', index.') + ');\n';
        }
        fs.writeFileSync(`${srcPath}/${comp.directoryName}/global.js`, imports + content + exportContent);
        comps.push(comp.directoryName);
        compConfig.compClassNames[comp.directoryName] = comp.baseClass;
        var blazorConfig = commonConfig.blazorDependencies[comp.directoryName];
        if (blazorConfig && blazorConfig.moduleName) {
            compConfig.moduleNames[comp.directoryName] = blazorConfig.moduleName;
        }
        if (blazorConfig && blazorConfig.ignoreScripts) {
            compConfig.ignoreScripts.push(comp.directoryName);
        }
        if (comp.blazorCommonModules) {
            compConfig.commonModules[comp.directoryName] = comp.blazorCommonModules;
        }
    }
    compConfig.comps = comps;
    return compConfig;
}
/* jshint ignore:end */
