'use strict';
let fs = require('fs-extra');
let gulp = require('gulp');

const path = require('path');
var headlessPath = path.join(__dirname, './headless.txt');
var headmodePath = path.join(__dirname, './headmode.txt');

gulp.task('turn-on-headless', (done) => {
    var headless = fs.readFileSync(headlessPath, 'utf8');
    fs.writeFileSync('./node_modules/@syncfusion/ej2-base/e2e/protractor.config.js', headless, 'utf8');
    done();
});

gulp.task('turn-off-headless', (done) => {
    var headmode = fs.readFileSync(headmodePath, 'utf8');
    fs.writeFileSync('./node_modules/@syncfusion/ej2-base/e2e/protractor.config.js', headmode, 'utf8');
    done();
});

/**
 * Gulp task to download and unzip the appropriate ChromeDriver based on the Chrome version.
 * @task {chromedriver}
 * @description The `chromedriver` task is used to download and unzip the appropriate ChromeDriver based on the Chrome version.
 */

// Task for download the build deploy sample

gulp.task('test-build-sample', (done) => {
    var shelljs = global.shelljs = global.shelljs || require('shelljs');
    var platform = process.argv[4] || 'ts';
    var user = 'SyncfusionAutomation';
    var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;;
    var tempRepo = 'https://' + user + ':' + token + `@gitea.syncfusion.com/essential-studio/ej2-build-${platform}-sample.git`;
    if (!token) {
        tempRepo = `https://gitea.syncfusion.com/essential-studio/ej2-build-${platform}-sample.git`;
    }
    if (platform === 'aspnetmvc' || platform === 'aspnetcore') {
        tempRepo = `https://gitea.syncfusion.com/essential-studio/ej2-build-${platform}-samples.git`;
    }
    shelljs.exec(
        'git clone ' + tempRepo, {
        silent: false
    },
        function () {
            console.log('Clone has been completed');
            done();
        });
});

gulp.task('chromedriver', (done) => {
    try {

        if (fs.existsSync('./chromedriver.exe')) {
            console.log('Chrome driver already exists'); done(); return;
        }
        let chromeDriverBaseUrl = 'https://chromedriver.storage.googleapis.com';
        let chromeDriverFileUrl = `chromedriver_win32.zip`;
        let outputFilePath = './chromedriver.zip';
        let chromeVersion = getChromeVersionSync(), chromeDriverVersion = '', chromeVersionFlag = false;
        console.log('Chrome version:', chromeVersion);
        chromeVersion = chromeVersion.split('.')[0];
        // check whether chrome version is 115 and above to fetch the chromedriver version from different URL
        chromeVersionFlag = chromeVersion > 114 ? true : false;

        if (!chromeVersion || chromeVersion.length === 0) {
            throw new Error('Chrome version not found');
        }

        // Fetch the chromedriver version based on the Chrome version with different URL for Chrome version 115 and above
        if (chromeVersionFlag) {
            chromeDriverBaseUrl = `https://edgedl.me.gvt1.com/edgedl/chrome/chrome-for-testing`; chromeDriverFileUrl = `win64/chromedriver-win64.zip`;
            let fetchData = JSON.parse(fetchDataFromURL(`https://googlechromelabs.github.io/chrome-for-testing/latest-versions-per-milestone.json`));

            if (fetchData && fetchData.milestones && fetchData.milestones[chromeVersion]) {
                chromeDriverVersion = fetchData.milestones[chromeVersion].version;
            }
        } else {
            chromeDriverVersion = fetchDataFromURL(`${chromeDriverBaseUrl}/LATEST_RELEASE_${chromeVersion}`);
        }
        console.log('Chrome driver version:', chromeDriverVersion);

        if (!chromeDriverVersion || chromeDriverVersion.length === 0) {
            throw new Error('Chrome driver version not found');
        }
        // Download the chromedriver ZIP file
        fetchDataFromURL(`${chromeDriverBaseUrl}/${chromeDriverVersion}/${chromeDriverFileUrl} --output ${outputFilePath}`);

        if (!fs.existsSync(outputFilePath)) {
            throw new Error('Chrome driver zip not found');
        }
        // Extract the chromedriver.exe file only from the downloaded ZIP file
        // Chrome driver version 115 and above has chromedriver.exe inside chromedriver-win64 folder
        if (chromeVersionFlag) {
            unzipFile(outputFilePath, '', { filter: (entry) => entry.path === 'chromedriver-win64/chromedriver.exe' }, () => {
                fs.move('./chromedriver-win64/chromedriver.exe', './chromedriver.exe', (err) => {
                    if (!err) { fs.remove('./chromedriver-win64'); }
                });
            });
        } else {
            unzipFile(outputFilePath, '', { filter: (entry) => entry.path === 'chromedriver.exe' });
        }
        console.log('chromedriver has successfully downloaded and extracted.');
        done();
    } catch (error) {
        console.error('Error chromedriver Gulp task:', error);
    }
});

/**
 * Fetches data from a URL using the 'curl' command executed by shelljs.
 * @param {string} url - The URL to fetch the data from.
 * @returns {string|null} The fetched data as a string if successful, or null if an error occurs.
 */
function fetchDataFromURL(url) {
    let shell = require('shelljs');
    try {
        let command = `curl -L ${url}`;
        let { code, stdout } = shell.exec(command, { silent: true });
        return code === 0 && stdout && stdout.trim() ? stdout.trim() : null;
    } catch (error) {
        console.error('Error fetchDataFromURL function:', error);
    }
}

/**
 * Unzips a ZIP file using gulp-unzip, moves the specified files to the destination path,
 * and performs an optional callback function after extraction.
 * @param {string} zipFilePath - The path of the ZIP file to unzip.
 * @param {string} destinationPath - The destination path to move the extracted files.
 * @param {function} callback - Optional callback function for filtering specific files to extract.
 * @returns {object} The gulp stream for further chaining.
 */
function unzipFile(zipFilePath, destinationPath, callback, afterunzip) {
    let unzip = require('gulp-unzip');
    try {
        return gulp
            .src(zipFilePath)
            .pipe(unzip(callback))
            .pipe(gulp.dest(destinationPath))
            .on('end', () => {
                try {
                    fs.unlinkSync(zipFilePath);
                    if (typeof afterunzip === 'function') { afterunzip(); }
                } catch (error) {
                    console.error('Error unzipFile function:', error);
                }
            });
    } catch (error) {
        console.error('Error unzipFile function:', error);
    }
}

/**
 * Retrieves the Chrome version using PowerShell command.
 * @returns {string|null} The Chrome version if found, or null if an error occurs.
 */
function getChromeVersionSync() {
    let spawnSync = require('child_process').spawnSync;
    try {
        let powershellScript = fs.existsSync('C:/Program Files/Google/Chrome/Application/chrome.exe') ?
            `&{(Get-Item 'C:/Program Files/Google/Chrome/Application/chrome.exe').VersionInfo.ProductVersion}` :
            `$key = 'HKCU:\\Software\\Google\\Chrome\\BLBeacon'\n$value = (Get-ItemProperty -Path $key -Name version).version \nWrite-Output $value`;

        let powershellCommand = ['powershell', '-command', powershellScript];
        let { error, stdout } = spawnSync(powershellCommand[0], powershellCommand.slice(1));

        if (error) { return null; }

        return stdout && stdout.toString().trim() ? stdout.toString().trim() : null;
    } catch (error) {
        console.error('Error getChromeVersionSync function:', error);
    }
}
