'use strict';

// Node JS global scope
var gulp = global.gulp = global.gulp || require('gulp');
global.config = global.config || require('../utils/common.js');
var config = global.config.config();

/**
 * Watch for sample and source and reload browser on changes
 */
gulp.task('watch', gulp.series('serve', function (done) {
    var browserSync = require('browser-sync');
    var bs = browserSync.get('Essential TypeScript');

    gulp.watch(config.watchSample, ['build', bs.reload]);
    gulp.watch(config.watchTs, ['scripts', bs.reload]);
    gulp.watch(config.styles, ['styles', bs.reload]);
    done();
}));

/**
 * Watch ts files of source
 */
gulp.task('watch-ts', gulp.series('scripts', function (done) {
    gulp.watch(config.watchTs, ['scripts']);
    done();
}));

/**
 * Watch scss files of source
 */
gulp.task('watch-sass', gulp.series('styles', function (done) {
    gulp.watch(config.styles, ['styles']);
    done();
}));
