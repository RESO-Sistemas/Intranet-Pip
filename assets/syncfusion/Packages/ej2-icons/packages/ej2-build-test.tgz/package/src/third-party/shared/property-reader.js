'use strict';

var modList, classList = [],
    interfaceList = [],
    classProperties = {},
    interfaceProperties = {};

/**
 * Property Reader
 */
class PropertyReader {

    constructor(json) {
        return this.render(json.children);
    }

    readClasses(cntMod) {
        for (var j = 0; j < cntMod.length; j++) {
            var curItem = cntMod[j];
            var curItemName = curItem.name;
            if (curItem.kindString === 'Class') {
                classList.push(curItem);
                classProperties[curItemName] = { _allProperties: [], _allEvents: [], _propComments: {}, _eventComments: {} };
                this.readDecoratorProperties(curItem.children, classProperties[curItemName]);
            }

            if (curItem.kindString === 'Interface' && !interfaceProperties[curItemName]) {
                interfaceList.push(curItem);
                interfaceProperties[curItemName] = curItem;
            }

        }
        return classList;
    }

    readDecoratorProperties(properties, desObj) {
        for (var k = 0; k < properties.length; k++) {
            var prop = properties[k];
            if (prop.kindString === 'Property' && prop.decorators) {
                var type = prop.decorators[0].name.toLowerCase();
                desObj[prop.name] = { type: { name: type }, obj: prop, comment: this.getComments(prop.comment) };
            }
            if (prop.kindString === 'Event' && prop.decorators) {
                var eType = prop.decorators[0].name.toLowerCase();
                desObj[prop.name] = { type: { name: eType }, obj: prop, comment: this.getComments(prop.comment) };
            }
        }
    }

    isCollectionDecorator(prop) {
        if (prop.kindString === 'Property' && prop.decorators) {
            return prop.decorators[0].name === 'Collection';
        } else {
            return false;
        }

    }

    createInputArray() {
        var keys = Object.keys(classProperties);
        for (var i = 0; i < keys.length; i++) {
            var prop = classProperties[keys[i]];
            var subKeys = Object.keys(prop);
            var interFaceProps = interfaceProperties[keys[i] + 'Model'];
            if (interFaceProps) {
                var modelProps = interFaceProps.children;
                for (var k = 0; modelProps && k < modelProps.length; k++) {
                    var curModel = modelProps[k];
                    if (curModel.type && curModel.type.name === 'EmitType') {
                        prop._allEvents.push(curModel.name);
                        prop._eventComments[curModel.name] = this.getComments(curModel.comment);

                    } else {
                        prop._allProperties.push(curModel.name);
                        prop._propComments[curModel.name] = this.getComments(curModel.comment);
                    }
                }
            }
            for (var j = 0; j < subKeys.length; j++) {
                var subKey = subKeys[j];
                var curProp = prop[subKey].obj;
                if (!(/(_)/g).test(subKey)) {
                    prop[subKey].ngInputs = this.ngParseInputArray(curProp, prop[subKey].ngInputs, '', prop[subKey]);
                }
            }

        }
    }

    getComments(comment) {
        if (!comment) { return ''; }
        var result = '    /** \n     * ';
        comment.shortText = comment.shortText.replace(/```([^]+)```/g, '');
        var commentArray = comment.shortText.split('\n');
        result = result + commentArray.join(' \n     * ') + '\n';
        if (comment.text) {
            var commentTextArray = comment.text.split('\n');
            result = result + '     * \n     * ' + commentTextArray.join('\n     *') + '     \n';
        }
        for (var i = 0; comment.tags && i < comment.tags.length; i++) {
            var curTag = comment.tags[i];
            result = result + '     * @' + curTag.tag + ' ' + curTag.text.replace('\n', '') + '\n';
        }
        result = result + '     */';
        return result;
    }

    ngParseInputArray(prop, resultAr, prevObj, classObj) {
        var result = resultAr;
        var type = '';
        if (this.isPropArray(prop.type)) {
            type = this.getReferenceType([prop.type]);
        } else if (this.isUnionArray(prop.type.types)) {
            type = this.getReferenceType(prop.type.types);
        }
        if (type !== '') {
            var obj = this.getTypeObject(type);
            if (obj && prevObj !== obj && obj.children) {
                result = this.readProperties(obj.children, [], obj, classObj);
            }
        }
        return result;
    }

    isUnionArray(types) {
        for (var i = 0; types && i < types.length; i++) {
            var type = types[i];
            if (type.isArray || type.type === 'array') {
                return true;
            }
        }
        return false;
    }

    isPropArray(type) {
        if (type.isArray || type.type === 'array') {
            return true;
        }
        return false;
    }

    pushToArray(resultAr, val, ignorePush) {
        if (ignorePush !== true) {
            resultAr.push(val);
        }
    }

    readProperties(properties, desObj, prevObj, classObj) {
        for (var k = 0; k < properties.length; k++) {
            var prop = properties[k];
            if (prop.kindString === 'Property') {
                if (this.isPropArray(prop.type) || this.isUnionArray(prop.type.types)) {
                    desObj[prop.name] = this.ngParseInputArray(prop, desObj, prevObj, {});
                }
                if (prop.type.type === 'instrinct') {
                    classObj[prop.name] = { type: prop.type.name, comment: this.getComments(prop.comment) };
                } else {
                    classObj[prop.name] = { type: 'any', comment: this.getComments(prop.comment) };
                }
                desObj.push(prop.name);
            }
            if (prop.kindString === 'Event') {
                desObj._events = desObj._events || [];
                desObj._events.push(prop.name);
            }
        }
        return desObj;
    }

    getTypeObject(type) {
        return interfaceProperties[type];
    }

    getReferenceType(types) {
        if (types) {
            for (var i = 0; i < types.length; i++) {
                var type = types[i];

                if (type.type === 'array' && type.elementType.type === 'reference' && (/Model/).test(type.elementType.name)) {
                    return type.elementType.name;
                }
            }
        }

        return '';
    }

    render(mods) {
        modList = mods;
        for (var i = 0; i < mods.length; i++) {
            if (modList[i].children) {
                this.readClasses(modList[i].children);
            }
        }
        this.createInputArray();
        classProperties.__this = this;
        classProperties.interfaces = interfaceProperties;
        return classProperties;
    }

}

module.exports = function (json) {
    return new PropertyReader(json);
};