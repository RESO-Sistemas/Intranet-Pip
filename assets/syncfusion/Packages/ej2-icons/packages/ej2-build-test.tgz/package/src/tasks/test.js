'use strict';

// Node JS global scope
var gulp = global.gulp = global.gulp || require('gulp');
global.config = global.config || require('../utils/common.js');
var path = global.path = global.path || require('path');
var glob = require('glob');
var config = global.config.config();
var runSequence = require('gulp4-run-sequence');

var fs = require('fs');
var validateCss = require('css-validator');
var shelljs = require('shelljs');

/**
 * To ship package source to react sample
 */
gulp.task('react-sample-source', function (done) {
    shelljs.exec('gulp build && gulp dist-scripts');
    shelljs.cp('-R', './dist/*', path + 'dist');
    var packName = JSON.parse(fs.readFileSync('./package.json')).name;
    var path = './demos/React-demo/node_modules/' + packName + '/';
    var compiledFiles = glob.sync('./src/*/');
    for (var i = 0; i < compiledFiles.length; i++) {
        shelljs.cp('-R', compiledFiles[i] + '*.{js,d.ts}', path + 'src/' + compiledFiles[i].split('/')[2]);
    }
    shelljs.exec('gulp dist-scripts');
    shelljs.cp('-R', './dist/*', path + 'dist');
    done();
});

/**
 * Run test once and exit
 */
gulp.task('test', gulp.series('scripts', function (done) {
    var karma = require('karma');
    var spawn = require('child_process').spawn;
    var service = spawn('node', [path.join(__dirname, '../../services/V4service.js')]);

    new karma.Server({
        configFile: __dirname + config.karma,
        singleRun: true
    }, function (e) {
        done(e === 0 ? null : 'karma exited with status ' + e);
        fs.appendFileSync('./gulp_error.log', 'Failed test task \ndetails\n** Karma test case issue ***');
        service.kill();
    }).start();
}));

/**
 * Watch for file changes and re-run tests on each change
 */
gulp.task('tdd', function (done) {
    runSequence('watch-ts');
    var karma = require('karma');
    var spawn = require('child_process').spawn;
    var service = spawn('node', [path.join(__dirname, '../../services/V4service.js')]);

    new karma.Server({
        configFile: __dirname + config.karma
    }, function () {
        done();
        service.kill();
    }).start();
});


/**
 * Test build task common functions
 */
gulp.task('build-test', function (done) {
    console.log(`Starting 'ci-compile'`);
    runSequence('js-hint', function () {
        var jasmineNode = require('gulp-jasmine-node');
        return gulp.src(['spec/**/*spec.js'])
            .pipe(jasmineNode({
                timeout: 10000
            }))
            .on('end', function () {
                done(); // Signal async completion when the task is finished
            });
    });
    console.log(`Finished 'ci-compile'`);
    done();
});


/**
 * Test CSS errors and warngins
 */
gulp.task('css-validation', function (done) {
    var files = glob.sync('styles/*.css');
    console.log('Files included for css validation' + files);
    for (var i = 0; i < files.length; i++) {
        var filesource = fs.readFileSync(files[i], 'utf8');
        CssValidateFn(filesource, files[i]);
    }
    done();
});

function CssValidateFn(filesource, filepath) {
    validateCss({ text: filesource, profile: 'css3svg' }, function (err, data) {
        if (data && data.errors) {
            if (data.errors.length === 0) {
                console.log('Success: ' + filepath);
                console.log('No errors or warnings\n');
            } else {
                data.errors.forEach(function (error) {
                    console.log('Error: ' + filepath + ': line ' + error.line);
                    console.log(error.message + '\n');
                });
                fs.appendFileSync('./gulp_error.log', error.message);
                process.exit(1);
            }
        }
    });
}
