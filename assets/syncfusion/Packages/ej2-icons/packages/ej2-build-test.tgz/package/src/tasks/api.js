'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var fs = global.fs = global.fs || require('fs');
var path = global.path = global.path || require('path');

gulp.task('api-diff', function (done) {
    let propGen = require('../api/base');
    let json;
    if (fs.existsSync(path.resolve('./public/api/file.json'))) {
        json = require(path.resolve('./public/api/file.json'));
    }
    let modulearray = json && json.children ? json.children : [];
    let propCollection = modulearray.length > 0 ? new propGen().initializeAPIReader(modulearray) : {};
    fs.writeFileSync(path.resolve('./current-api.json'), JSON.stringify(propCollection, null, '\t'), 'utf-8');
    if (fs.existsSync('./api.json')) {
        let comparejson = require('../api/compare');
        let compare = new comparejson(require(path.resolve('./api.json')), propCollection).initializeComparison();
        fs.writeFileSync(path.resolve('./compare-api.json'), JSON.stringify(compare, null, '\t'), 'utf-8');
        if (compare && (compare.added && compare.added.length && compare.added.length > 0) ||
            (compare.removed && compare.removed.length && compare.removed.length > 0) ||
            (compare.updated && compare.updated.length && compare.updated.length > 0)) {
            let generatehtml = require('../api/html');
            let html = new generatehtml(compare).InitializeHtmlGeneration();
            if (html && html !== '') {
                fs.writeFileSync(path.resolve('./api-changes.html'), html, 'utf-8');
            }
        }
    }
    done();
});