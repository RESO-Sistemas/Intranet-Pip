/* jshint ignore: start */
let gulp = global.gulp = global.gulp || require('gulp');
let email = import('emailjs');
let tableify = require('tableify');
let gzip = require('gulp-gzip');
const JSZip = require('jszip');
let shell = require('shelljs');
let glob = require('glob');
let fs = require("fs");
let path = require('path');
const https = require('https');
const fetch = require('node-fetch');
var common = global.config = global.config || require('../utils/common.js');

const httpsAgent = new https.Agent({
    rejectUnauthorized: false,
});

let config = {
    accessKeyId: process.env.AWS_ACCESS_KEY,
    secretAccessKey: process.env.AWS_SECRET_KEY,
};
let s3 = require('gulp-s3-upload')(config);

// General Info & Software Info for e2e report mail content
let currentRepo = shell.exec('git config --get remote.origin.url', { silent: true}).split('/')[4].replace('.git','').trim() || "Data Not Available";
let currentbranch = shell.exec('git branch --show-current', { silent: true}).stdout;
let SampleName = path.basename(process.env.INIT_CWD) || "Data Not Available";
let currentRepolink = shell.exec('git config --get remote.origin.url', { silent: true})
.replace('.git', (currentbranch ? '/tree/'+ currentbranch : 'Data Not Available')+(path.basename(process.env.INIT_CWD) ? '/'+ SampleName : ''));
let nodeVersion =  shell.exec('node --version', { silent: true}).trim() || "Data Not Available";
let javaVersion = fs.existsSync('C:/Program Files/Java/') ? 'v'+((shell.exec('java --version', { silent: true}).split('\n')[0].split(' ')[1]) || ' ').trim() : "Data Not Available";
let chromeVersion = fs.existsSync('C:/Program Files/Google/Chrome/Application/chrome.exe') ?
    'v'+shell.exec(`powershell -command "&{(Get-Item 'C:/Program Files/Google/Chrome/Application/chrome.exe').VersionInfo.ProductVersion}"`, { silent: true}).trim() : "Data Not Available";
let dotnetVersion = fs.existsSync('C:/Program Files/dotnet/dotnet.exe') ?'v'+shell.exec('dotnet --version', { silent: true}).trim() : "Data Not Available";
let chromeDriverVersion = fs.existsSync('./chromedriver.exe') ?'v'+shell.exec('chromeDriver -v', { silent: true}).split(' ')[1] : "Data Not Available";

let crReport=[], currentReportlink= '', crStatusCount = { total: 0, passed: 0, ignored: 0, failed: 0 };
let startTime = process.env['startTime'], endTime = process.env['endTime'], timeTaken = '';
const maxAttachmentSizeBytes = 25 * 1024 * 1024;

/**
 * Email the CI e2e testing reports 
 */
gulp.task('e2e-mailreport', async function (done) {

    runSequence('zip-file');
    let basePath = process.env.INIT_CWD, cr_spreadHtml = '', configJSON = '';

    try {

        if (!fs.existsSync(path.join(basePath,'jasmine-test-results.json')) || !config.accessKeyId || !config.secretAccessKey)
            throw('Jasmine report or Config not found.');
      
        if (fs.existsSync(path.join(basePath,'config.json'))) configJSON= require(path.join(basePath,'config.json'));

        let jasmineReport = require(path.join(basePath,'jasmine-test-results.json'));

        // Fetch the data from component e2e repository config.json file
        let toMail = (configJSON && configJSON.toMailAddress && configJSON.toMailAddress.length > 0) ? 
            configJSON.toMailAddress : ['ej2@syncfusion.com'];
        let ccMail = (configJSON && Array.isArray(configJSON.ccMailAddress) && configJSON.ccMailAddress.length > 0) ?
            configJSON.ccMailAddress : ['sivakumarr@syncfusion.com', 'rajendranr@syncfusion.com', 'sumankumarg@syncfusion.com'];
        let sampleName = (configJSON && configJSON.sampleName && configJSON.sampleName.length > 0) ? configJSON.sampleName : null;

        // Calculating the time taken of the e2e testing
        if (startTime && endTime) {
            var timeDiff = (new Date(endTime).getTime() - new Date(startTime).getTime()) / 1000;
            var hours = Math.floor(timeDiff / 3600);
            var minutes = Math.floor((timeDiff - hours * 3600) / 60);
            var seconds = Math.floor((timeDiff - hours * 3600) - minutes * 60);
            timeTaken = (hours > 0 ? hours + 'hr ' : '') + (minutes > -1 ? minutes + 'min ' : '') + (seconds > -1 ? seconds + "sec" : '');
        }
        else {
          startTime = 'Data Not Available', endTime = 'Data Not Available', timeTaken = 'Data Not Available';
        }

        // Read the jasmine-test-results.json & calculate the summary for mail content
        for (let i in jasmineReport) {

            if (!jasmineReport[i]['fullName'] || (!jasmineReport[i]['specs'] || jasmineReport[i]['specs'].length === 0)) continue;

            let compName = jasmineReport[i]['fullName'], specs = jasmineReport[i]['specs'];
            let specCount = jasmineReport[i]['specs'].length, passCount = 0, ignoredCount = 0, failCount = 0;

            for (let j in specs) {
                if (specs[j]['status'] === "passed" || ( specs[j]['status'] === "failed" && specs[j]['failedExpectations'][0]['message'] === "Expected 7 to equal 5."))
                    passCount++;
                else if (specs[j]['status'] === "disabled" || specs[j]['status'] === "pending")
                    ignoredCount++;
                else if (specs[j]['status'] === "failed")
                    failCount++;
            }
            writeReport(compName, specCount, passCount, ignoredCount, failCount);
        }

        if (!crReport || crReport.length === 0) throw('Jasmine report has no results.');

        if (crReport.length > 1) writeReport('OverAll', crStatusCount.total, crStatusCount.passed, crStatusCount.ignored, crStatusCount.failed);

        cr_spreadHtml = tableify(crReport)
        cr_spreadHtml = cr_spreadHtml.replace(/class="string">SUCCESS/g, 'class="string" style="color:green;">SUCCESS');
        cr_spreadHtml = cr_spreadHtml.replace(/class="string">FAILED/g, 'class="string" style="color:red;">FAILED');
        cr_spreadHtml = cr_spreadHtml.replace(/<table>/g, '<table class="error-notification" style="margin: auto;">');

        var product_owner = '';
        if (configJSON) {
            product_owner = configJSON.productOwner;
        }
        const data = {
            // JSON data to send in the API request
            RepositoryName: currentRepo,
            Component: configJSON.components.join(', '),
            Branch: configJSON.branchName,
            Category: configJSON.sampleName ? configJSON.sampleName : '',
            Platform: configJSON.platform ? configJSON.platform : '',
            Type: "E2E",
            TestRunTime: new Date().toString(),
            TotalRunTime: timeTaken,
            Result: JSON.stringify(crReport),
            ProductOwner: product_owner,
            JobLink: `https://dev.azure.com/essential-studio/EJ2%20and%20Blazor/_build/results?buildId=${process.env['BUILD_BUILDID']}&view=results`
        };

        //Post data to the API
        await postAPI(data);

        try{
            //Test Data for centralized automation dashboard
            var testData = {
                'component': configJSON.components.join(', '),
                'repositoryName': currentRepo,
                'category': configJSON.sampleName ? configJSON.sampleName : '',
                'branch': configJSON.branchName,
                'startTime': common.getDateAndTime(startTime),
                'endTime': common.getDateAndTime(endTime),
                'Status': crStatusCount.failed > 0 ? 'Failure' : 'Success',
                'TotalSpec':  crStatusCount.total,
                'PassedSpec': crStatusCount.passed,
                'FailedSpec': crStatusCount.failed,
                'IgnoredSpec': crStatusCount.ignored,
                'version': '',
                'jobLink': `https://dev.azure.com/essential-studio/EJ2%20and%20Blazor/_build/results?buildId=${process.env['BUILD_BUILDID']}&view=results`
            }
            common.postTestData(testData);
        } catch (err) {
            console.log('Error in centralized API post process: ', err);
        }

        // Create connection to the email server with credentials
        let server = email.server.connect({
            user: 'automation@syncfusion.com',
            password: 'mjkbwpxmyzlkrpjq',
            host: 'smtp-mail.outlook.com',
            timeout: 50000,
            tls: {
                ciphers: 'SSLv3'
            }
        });

        // CI mail report contents
        let message = {
            from: 'automation@syncfusion.com',
            to: toMail,
            cc: ccMail,
            bcc:'mydeensn@syncfusion.com,suriyakumar.arumugam@syncfusion.com,sathishkumar.rajendran@syncfusion.com,balaji.elumalai@syncfusion.com',
            subject: 'E2E Test Automation Report',
            attachment: [{
                    data: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head><meta charset="utf-8"><meta name="viewport" 
                    content="width=device-width,initial-scale=1,user-scalable=no"><meta name="description" content="Testing Automation Results">
                    <meta name="author" content="Syncfusion"><title>E2E Testing Report</title><link rel="shortcut icon" href="https://ej2.syncfusion.com/home/favicon.ico">
                    <style type="text/css">body{font-size:13px !important;font-family:Segoe UI !important;padding:0 15%}.main-panel{width:100%;text-align:center}
                    .main-panel tr td{padding-left:30px;padding-right:30px}.error-notification,.error-notifications{border:1px solid #bbb;border-collapse:collapse;
                    width:75%}.error-notification th,.error-notifications th{border:1px solid #264c6b;background-color:#007dd1;color:#fff;font-style:italic;
                    padding:10px}.error-notification td,.error-notifications td{border:1px solid #416187;padding:10px !important;text-align:center}</style>
                    </head><body><table class="main-panel" cellspacing="0" cellpadding="0"><tr class="notification header" height="40"><td><b style="font-size:20px">
                    General Info</b></td></tr><tr><td style="height:20px">&nbsp;</td></tr><tr><td><table class="error-notification" style="margin:auto"><tr>
                    <th>Repo Name</th><td>`+currentRepo+`</td></tr>`+ `<tr><th>Branch Name</th><td>`+configJSON.branchName+`</td></tr>`+ `<tr><th>Platform</th><td>`+configJSON.platform+`</td></tr>` +`<tr><th>Sample Name</th><td>`+
                    (sampleName ? sampleName : SampleName)+`</td></tr><tr><th>Start Time</th><td>`+startTime+`</td></tr><tr><th>End Time</th><td>`+endTime+`</td></tr><tr><th>Time Taken</th><td>`
                    +timeTaken+`</td></tr><tr><th>Repo Link</th><td><a target="_blank" rel="noopener noreferrer" href="`+currentRepolink+`" class="blue-color">View in GitHub</a></td></tr><tr><th>Report Link</th>
                    <td><a target="_blank" rel="noopener noreferrer" href="`+currentReportlink+`" class="blue-color">Download</a> ( Contains Actual & Diff images )
                    </td></tr></table></td></tr><tr><td style="height:20px">&nbsp;</td></tr><tr class="notification header" height="40"><td><b style="font-size:20px">
                    Software Info</b></td></tr><tr><td style="height:20px">&nbsp;</td></tr><tr><td><table class="error-notification" style="margin:auto"><tr><th>
                    Node</th><td>`+nodeVersion+`</td></tr><tr><th>Java</th><td>`+javaVersion+`</td></tr><tr><th>.NET</th><td>`+dotnetVersion+`</td></tr><tr><th>
                    Chrome</th><td>`+chromeVersion+`<tr><th>Chrome Driver</th><td>`+chromeDriverVersion+`</td></tr></td></tr></table></td></tr><tr><td style="height:20px">
                    &nbsp;</td></tr><tr class="notification header" height="40"><td><b style="font-size:20px;padding:4px">Summary Report</b></td></tr><tr><td style="height:20px">
                    &nbsp;</td></tr><tr><td>`+cr_spreadHtml+`</td></tr><tr><td style="height:20px">&nbsp;</td></tr><tr class="notification footer" height="40"><td>
                    Copyright &copy; 2001 - `+new Date().getFullYear().toString()+` Syncfusion Inc. All Rights Reserved.</td></tr></table></body></html>`,
                    alternative: true
                }
            ]
        };

        if (fs.existsSync(path.join(basePath,'e2e_report/chrome/chrome.html'))) {
            fs.stat(path.join(basePath,'e2e_report/chrome/chrome.html'), (err, stats) => {
                if (err) {
                    console.error(err);
                } else {
                    if (stats.size <= maxAttachmentSizeBytes) {
                        message.attachment.push({
                            path: path.join(basePath,'e2e_report/chrome/chrome.html'),
                            type: 'application/html',
                            name: 'report.html',
                        });
                    }
                    console.log('stats.size', stats.size)
                    // Send the message and get a callback with an error or details of the message that was sent
                    server.send(message, function (err) {
                        if (!err) {
                            console.log('Test report send Successfully');
                            done();
                        }
                        else throw (err);
                    });
                }
            });
        }
    } catch (err) {
        if (err) console.log('Error in mailreport:  ', err);
        done();
    }
});

//Post data to the API for centrailized automation dashboard.
async function postAPI(data) {
    const maxDurationInMilliseconds = 60 * 60 * 1000; // One hour
    const retryIntervalInMilliseconds = 5000; // 5 seconds retry interval
    let attempt = 1;
    let startTime = Date.now();
    let success = false;

    while (!success && (Date.now() - startTime) < maxDurationInMilliseconds) {
        try {
            const response = await fetch('https://sfblazor.azurewebsites.net/status/testcases/post', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data),
                agent: httpsAgent
            });

            const responseData = await response.json();

            if (response.status === 200) {
                console.log('Success on attempt ' + attempt + ': ' + responseData);
                success = true;
            } else {
                console.log('Failure in updating test results: ' + responseData);
            }

            console.log(responseData);
        } catch (error) {
            console.error('Error in API post process: ', error);
        }

        attempt++;

        // Wait for the retry interval
        await new Promise(resolve => setTimeout(resolve, retryIntervalInMilliseconds));
    }

    if (!success) {
        console.log('Exceeded time limit without success.');
    }
}
// Add testing report in the following variables
function writeReport(compName, totalCount, passCount, ignoreCount, failedCount) {
    let result = {
        SpecTitle: compName,
        TotalSpec: totalCount,
        PassedSpec: passCount,
        IgnoredSpec: ignoreCount,
        FailedSpec: failedCount,
        Status: failedCount ? 'FAILED' : 'SUCCESS'
    };

    crReport.push(result);
    
    if (compName !== 'OverAll') {
        crStatusCount.total += totalCount;
        crStatusCount.passed += passCount;
        crStatusCount.ignored += ignoreCount;
        crStatusCount.failed += failedCount;
    }
}

/// zip e2e report to a folder
gulp.task('zip-file', function(done){

    try {
        if (fs.existsSync('./e2e_report/chrome') && config.accessKeyId && config.secretAccessKey) {
            let files = glob.sync('./e2e_report/chrome/chrome.html');
            console.log(currentRepo); console.log(currentbranch);

            fs.existsSync('./e2e/diff/Chrome') ? files = files.concat(glob.sync('./e2e/diff/Chrome/**/*')) : '';
            fs.existsSync('./e2e/Actual/Chrome') ? files = files.concat(glob.sync('./e2e/Actual/Chrome/**/*')) : '';
            fs.existsSync('output.log') ? files = files.concat(glob.sync('output.log')) : '';

            if (files.length) {
                console.log(files);
                const zip = new JSZip();
                const testReport = zip.folder("TestReport");

                for (const file of  files) {
                    if (fs.existsSync(file) && fs.statSync(file).isFile()) {
                        const fData = fs.readFileSync(file), 
                            fSplit = file.split('/'), 
                            fPath = file.includes('Actual') ? 'Actual/' : file.includes('diff') ? 'diff/' : '';
                        testReport.file(fPath + fSplit[fSplit.length - 1], fData);
                    }
                }

                let curDate = new Date();
                let dString = '' + curDate.getDate() +'-' + (curDate.getMonth() + 1) + '-' + curDate.getFullYear();
                let curTime = new Date().getTime();
                let zippath = './ej2-e2e-report-local/'+dString +'/'+ currentRepo +'/'+  curTime;
                let replPath = zippath.replace('-local','');
                shelljs.mkdir('-p',zippath); console.log(zippath);

                zip.generateNodeStream({ type: 'nodebuffer', streamFiles: true })
                    .pipe(fs.createWriteStream(zippath + '/e2eReport.zip'))
                    .on('finish', function () {
                        currentReportlink = replPath.replace('./','https://s3.ap-south-1.amazonaws.com/npmci.syncfusion.com/') + '/e2eReport.zip';
                        gulp.src(zippath + '/*')
                        .pipe(gzip({
                            append: false
                        }))
                        .pipe(gulp.dest(replPath))
                        .on('end', function () {
                            s3publish(replPath,replPath.replace('./','') , done);
                        })
                        .on('error', function (e) {
                            done(e);
                        });
                        console.log("sample.zip written.");
                    });
            }
        } else {
            done();
        }

    } catch (err) {
        if (err) console.log('Error in zipfile:  ', err);
        done();
    }
});

// Publish the generated e2e zipped report in S3 
let s3publish = function (dirName,  prefixName, done) {
    prefixName = prefixName.endsWith('/') ? prefixName : prefixName + '/';
    dirName = dirName.endsWith('/') ? dirName : dirName + '/';

    gulp.src(dirName + '**', { buffer: false })
        .pipe(s3({
            Bucket: 'npmci.syncfusion.com',
            ACL: 'public-read',
            uploadNewFilesOnly: false,
            ContentEncoding: 'gzip',
            keyTransform: function (relative_filename) {
                let new_name = prefixName + relative_filename;
                return new_name;
            }
        }, {
                maxRetries: 5,
                maxRedirects: 100,
                retryDelayOptions: {
                    base: 1000
                }
            }))
        .on('end', function () {
            console.log('Published in CDN');
            done();
        })
        .on('error', function (e) {
            console.error('unable to sync: ', e.stack);
            done(e);
        });
};

exports.s3publish = s3publish;
/* jshint ignore:start */
