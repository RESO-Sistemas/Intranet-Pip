'use strict';

// Node JS global scope
var gulp = global.gulp = global.gulp || require('gulp');


/**
 * Init the browser-sync for loading samples
 */
gulp.task('serve', gulp.series('build', function (done) {
    var browserSync = require('browser-sync');
    var bs = browserSync.create('Essential TypeScript');
    var options = {
        server: {
            baseDir: './'
        },
        ui: false
    };
    bs.init(options, done);
}));
