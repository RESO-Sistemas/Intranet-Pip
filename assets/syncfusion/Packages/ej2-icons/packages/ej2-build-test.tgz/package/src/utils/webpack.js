'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var fs = global.fs = global.fs || require('fs');

// Get webpack entry points from components or index.js files
function getEntryPoints(components) {
    var config = {},
        moduleName;
    if (components) {
        for (var i = 0; i < components.length; i++) {
            moduleName = getModuleName(components[i]);
            config[moduleName] = './src/' + components[i] + '/';
        }
    } else {
        var glob = require('glob');
        var files = glob.sync('./**/index.js', { silent: true, ignore: ['./node_modules/**', './index.js'] });
        for (var j = 0; j < files.length; j++) {
            var dirName = files[j].split('/')[1];
            moduleName = getModuleName(dirName);
            if (fs.existsSync('./' + dirName + '/index-all.js')) {
                config[moduleName] = './' + dirName + '/index-all.js';
            } else {
                config[moduleName] = './' + dirName + '/';
            }
        }
    }
    return config;
}
exports.getEntryPoints = getEntryPoints;

// Get module name - camel cases
function getModuleName(name) {
    var splitted = name.split('-');
    name = splitted[0];
    for (var k = 1; k < splitted.length; k++) {
        name = name + splitted[k].charAt(0).toUpperCase() + splitted[k].slice(1);
    }
    return name;
}
exports.getModuleName = getModuleName;

// Bundle the webpack based on webpack configurations
function bundleWebpack(webpackConfig, done) {
    var webpack = require('webpack');
    var webpackStream = require('webpack-stream');

    return gulp.src('')
        .pipe(webpackStream(webpackConfig, webpack))
        .pipe(gulp.dest('.'))
        .on('end', function() {
            done();
        });
}
exports.bundleWebpack = bundleWebpack;