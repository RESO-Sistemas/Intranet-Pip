'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var common = global.config = global.config || require('../utils/common.js');
var publish = require('./base.js');
var fs = global.fs = global.fs || require('fs');
var path = global.path = global.path || require('path');
var runSequence = require('gulp4-run-sequence');

var registry = common.isMasterBranch ? 'production-registry' : 'dev-registry';
registry = common.isReleaseBranch ? 'release-registry' : registry;
registry = common.isHotfixBranch ? 'hotfix-registry' : registry;

/**
 * Publish npm production packages
 */
gulp.task('publish-production', function (done) {
    runSequence('typings-mapping', 'production-ignore', registry, 'es5-mapping',
        function () {
            if (common.currentRepo === 'ej2-build-tasks') {
                publish.shipSrc('./src/services/**/*', './');
            }
            if (common.currentRepo === 'ej2-pdfviewer-library' && fs.existsSync('./src/pdfviewer/ej2-pdfviewer-lib/')) {
                if (!fs.existsSync('./dist/ej2-pdfviewer-lib/')) {
                    shelljs.mkdir('-p', './dist/ej2-pdfviewer-lib/');
                }
                shelljs.mv('./src/pdfviewer/ej2-pdfviewer-lib/*', './dist/ej2-pdfviewer-lib/');
            }
            if (common.currentRepo === 'ej2-pdf-data-extract' && fs.existsSync('./src/pdf-data-extract/core/ej2-pdf-lib/')) {
                if (!fs.existsSync('./dist/ej2-pdf-lib/')) {
                    shelljs.mkdir('-p', './dist/ej2-pdf-lib/');
                }
                shelljs.mv('./src/pdf-data-extract/core/ej2-pdf-lib/*', './dist/ej2-pdf-lib/');
            }
            /* jshint ignore:start */
            if (common.currentRepo === 'ej2-angular-base') {
                shelljs.rm('-rf', './schematics');
                shelljs.cp('-rf', './node_modules/@syncfusion/ej2-build-test/templates/schematics', './');
            }
            var nexusBranch = common.isHotfixBranch ? 'ej2-angular-hotfix' : 'ej2-angular-release';
            var npmrc = fs.readFileSync('./.npmrc', 'utf8');
            if (common.isReleaseBranch) {
                npmrc = npmrc.replace(/\/ej2-release/g, '/' + nexusBranch);
            } else if (common.isHotfixBranch) {
                npmrc = npmrc.replace(/\/ej2-hotfix-new/g, '/' + nexusBranch);
            }
            fs.writeFileSync('./.npmrc', npmrc);
            console.log('npmrc file updated: \n', npmrc);
            var srcPublish = shelljs.exec(`npm publish --registry https://nexus.syncfusioninternal.com/repository/${nexusBranch}/`);
            if (common.isReleaseBranch) {
                npmrc = npmrc.replace(/\/ej2-angular-release/g, '/ej2-release');
            } else if (common.isHotfixBranch) {
                npmrc = npmrc.replace(/\/ej2-angular-hotfix/g, '/ej2-hotfix-new');
            }
            console.log('npmrc file updated: \n', npmrc);
            fs.writeFileSync('./.npmrc', npmrc);
            /* jshint ignore:end */
            shelljs.exec('npm publish');
            if (common.isMasterBranch) {
                var user = 'SyncfusionAutomation';
                var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
                var origin = 'http://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/' + common.currentRepo + '.git';
                shelljs.exec('git remote set-url origin ' + origin + ' && git pull origin master');
                if (fs.existsSync(path.resolve('./current-api.json'))) {
                    let apipath = path.resolve('./api.json');
                    let json = JSON.stringify(require(path.resolve('./current-api.json')), null, '\t');
                    fs.writeFileSync(apipath, json, 'utf-8');
                }
                shelljs.exec('git add -f api.json ');
                shelljs.exec('git commit -m \"config(EJ2-000): api json included" --no-verify');
                shelljs.exec('git branch -f master HEAD && git checkout master', shellDone);
                shelljs.exec('git push -f --set-upstream origin master --no-verify', { silent: true }, function (exitCode) {
                    done();
                    shellDone(exitCode);
                });
            }
            else {
                done();
            }
        });
});

function shellDone(exitCode) {
    if (exitCode !== 0) {
        process.exit(1);
    }
}

/**
 * Create npmignore at root for production packages
 */
gulp.task('production-ignore', function (done) {
    publish.createNpmIgnore(common.currentRepo, true);
    done();
});
