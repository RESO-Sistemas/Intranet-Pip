'use strict';

class releaseNotes {

    constructor() {
        this.fs = global.fs = global.fs || require('fs');
        this.path = global.path = global.path || require('path');
        this.common = global.config = global.config || require('../utils/common.js');
        this.mdConverter = require('md-2-json');
    }

    generateReleaseNotes(mdstring) {
        let localUnreleased = this.mdConverter.parse(mdstring).Changelog;
        if (!this.fs.existsSync('./ej2-docs/src/release-notes')) {
            this.fs.mkdirSync('./ej2-docs/src/release-notes');
        }
        let rNPath = './ej2-docs/src/release-notes/';
        let isreleased = this.generateNotes(this.path.resolve(rNPath + 'unreleased.md'), localUnreleased['[Unreleased]']);
        if(isreleased){
            this.changeIndexSummary();
        }
        if (this.common.isMasterBranch) {
            for (let release of Object.keys(localUnreleased)) {
                if (release === '[Unreleased]') {
                    continue;
                }
                let rVersion = /^\d{1,2}\.\d{1,2}\.\d{1,2}/.exec(release);
                let nPath = this.path.resolve(`${rNPath}${rVersion ? rVersion[0] : release}.md`);
                isreleased = this.generateNotes(nPath, localUnreleased[release]);
            }
        }
        return isreleased;
    }

    generateNotes(path, notesObj) {
        if (this.fs.existsSync(path)) {
            let docMDStr = this.fs.readFileSync(path, 'utf-8');
            let isHeader1 = /^#\s\S+/.test(docMDStr.trimLeft());
            let docUnreleased = isHeader1 ? this.mdConverter.parse(docMDStr) : this.mdConverter.parse('# releasenotes \n' + docMDStr);
            docUnreleased = isHeader1 ? { 'releasenotes': docUnreleased } : docUnreleased;
            Object.assign(docUnreleased.releasenotes, notesObj);
            docUnreleased = this.sortObject(docUnreleased.releasenotes);
            this.fs.writeFileSync(path, this.mdConverter.toMd({ 'releasenotes': docUnreleased }).replace('# releasenotes', ''), 'utf-8');
            return true;
        }
        else {
            let markDownObj = this.sortObject(notesObj);
            markDownObj = { 'releasenotes': markDownObj };
            this.fs.writeFileSync(path, this.mdConverter.toMd(markDownObj).replace('# releasenotes', ''), 'utf-8');
            return true;
        }
        return false;
    }

    changeIndexSummary(){
        let indexPath = './ej2-docs/src/release-notes/index.md';
        let summaryPath = './ej2-docs/src/release-notes/summary.md';
        if(this.fs.existsSync(indexPath)){
            let indexMD = this.fs.readFileSync(indexPath, 'utf-8');
            if(!/\* \[unreleased\]\(unreleased\.md\)/.test(indexMD)){
                let replaceText = '# Release Notes\r\n* [unreleased](unreleased.md)\r\n';
                this.fs.writeFileSync(indexPath, indexMD.replace(/# Release Notes\r\n/, replaceText), 'utf-8');
            }
        }
        if(this.fs.existsSync(summaryPath)){
            let summaryMD = this.fs.readFileSync(summaryPath, 'utf-8');
            if(!/\* \[unreleased\]\(release-notes\/unreleased\.md\)/.test(summaryMD)){
                summaryMD = '* [unreleased](release-notes/unreleased.md)\r\n' + summaryMD;
                this.fs.writeFileSync(summaryPath, summaryMD, 'utf-8');
            }
        }
    }

    sortObject(obj) {
        return Object.keys(obj).sort().reduce(function (sObj, key) {
            if (Object.keys(obj[key]).length !== 0) {
                sObj[key] = obj[key];
            }
            return sObj;
        }, Object.create(null));
    }

}

module.exports = releaseNotes;
