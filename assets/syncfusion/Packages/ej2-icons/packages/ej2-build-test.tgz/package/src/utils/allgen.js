'use strict';

var fs, mkdirp, getDirName, common, destPath;

class allFileGen {

    constructor(dest) {
        // Import required files
        fs = global.fs || require('fs');
        mkdirp = require('mkdirp');
        getDirName = (global.path || require('path')).dirname;
        common = require('./common');
        destPath = dest;
    }

    //method invoke from the webpack
    apply(compiler) {
        // hook done function to webpack and callback will trigger after complete.
        compiler.plugin('done', this.createAllFile.bind(this));
    }

    // method to generate merged files
    createAllFile(params) {
        var filesData = [];
        var assets = params.compilation.assets;
        var dir = destPath.split('./')[1].split('/').join('\\');
        if (common.currentPackage === 'ej2') {
            filesData.push(assets[dir + 'common\\common.js']._cachedSource);
        }
        Object.keys(params.compilation.entrypoints).forEach(function(key) {
            if (common.currentPackage === 'ej2') {
                filesData.push(assets[dir + key + '\\' + key + '.js']._cachedSource);
            }
            else {
                filesData.push(assets[dir + key + '.js']._cachedSource);
            }
        });
        this.writeFile(destPath + common.currentPackage + '.js', filesData.join('\n'), 'utf8');
    }

    //used to write file even if folder does not exist
    writeFile(path, contents, cb) {
        mkdirp(getDirName(path), function(err) {
            if (err) { return; }
            fs.writeFile(path, contents, cb);
        });
    }
}

module.exports = allFileGen;