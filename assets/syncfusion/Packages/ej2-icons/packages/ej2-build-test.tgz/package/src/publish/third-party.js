'use strict';

var shelljs = global.shelljs = global.shelljs || require('shelljs');
var common = global.config = global.config || require('../utils/common.js');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');
var gulp = global.gulp = global.gulp || require('gulp');
var base = require('./base.js');
var platformList = [];
var fs = global.fs = global.fs || require('fs');
// check master or development branch
var isMaster = common.isMasterBranch;
var registry = isMaster ? 'production-registry' : 'dev-registry';
registry = common.isReleaseBranch ? 'release-registry' : registry;
registry = common.isHotfixBranch ? 'hotfix-registry' : registry;
var ignore = isMaster ? 'production-ignore' : 'npmignore';

function publish(platform, execution, done) {
    var localRegistry;
    if (common.isRemoteServer) {
        localRegistry = registry;
    } else {
        localRegistry = isMaster ? 'local-production-registry' : 'local-dev-registry';
    }

    // traverse through third party platform
    shelljs.cd('./third-party/' + platform + '/');
    shelljs.exec('gulp ' + localRegistry);
    // execute required tasks
    shelljs.exec(execution, function (exitCode) {
        base.shellDone(exitCode);
        platformList.push(platform);
        shelljs.cd('../../');
        done();
    });
}
exports.publish = publish;


gulp.task('third-party-build', function (done) {
    if (common.isProtectedBranch) {
        console.log('third-party-build protected branch');
        runSequence('blazor-build','blazor-publish', 'aspcore-build', 'asp-generate-projectfile', 'aspcore-publish',
        'angular-build', 'angular-publish', 'react-build', 'react-publish', 'vue-build', 'vue-publish', done);
    } else {
        console.log('third-party-build private branch');
        runSequence('angular-build', 'react-build', 'vue-build', done)
    }
    //runSequence('aspcore-build', 'asp-generate-projectfile', 'aspcore-publish',
    //    'angular-build', 'angular-publish', 'react-build', 'react-publish', 'vue-build', 'vue-publish', done);
    // 'aspcore-publish',
    // runSequence('ng-build', 'ng-publish', 'react-build', 'react-publish', 'vue-build', 'vue-publish', done);
});

gulp.task('third-party-publish', gulp.series('third-party-build', function (done) {
    for (var i = 0; i < platformList.length; i++) {
        console.log(platformList[i] + ' package publishing started...');
        shelljs.cd('./third-party/' + platformList[i]);
        if (platformList[i] === 'angular') {
            // For styles shiping
            shelljs.cp('-R', 'styles/', 'dist/styles');
            // publish src inside the dist folder only for angular package
            shelljs.cd('./dist');
            shelljs.exec('gulp ' + registry);
            var nexusBranch = common.isReleaseBranch ? 'ej2-angular-release' : 'ej2-angular-development';
            nexusBranch = common.isHotfixBranch ? 'ej2-angular-hotfix' : nexusBranch;
            var npmrcContent = fs.readFileSync('./.npmrc', 'utf8').replace(/ej2-(development|release|hotfix-new)/g, nexusBranch);
            fs.writeFileSync('./.npmrc', npmrcContent);
            console.log('third-party npmrc : ',npmrcContent);
            shelljs.exec('gulp ' + ignore);
            shelljs.exec('npm publish', base.shellDone);
            // for angular cdn publish
            shelljs.cd('../');
            shelljs.exec('gulp angular-umd-deploy');
        } else {
            shelljs.exec('gulp ' + registry);
            shelljs.exec('gulp ' + ignore);
            shelljs.exec('npm publish', base.shellDone);
            shelljs.exec('gulp umd-deploy');
        }
        shelljs.exec('gulp publish-github-source');
        shelljs.exec('gulp publish-typedoc');
        shelljs.cd('../../');
        console.log(platformList[i] + '  Published');
    }
    runSequence('publish-ej2-vue', 'trigger-ci', done);
}));
