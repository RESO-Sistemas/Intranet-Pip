'use strict';

var fs = require('fs');

function createGlobalFileContext(baseClass, dynamicModules) {
    var context = 'import * as index from \'./index\'; \n';
    context = context + 'index.' + baseClass + '.Inject( index.' + dynamicModules.join(', index.') + '); \n';
    context = context + 'export * from \'./index\'; \n';
    return context;
}

function writeFile(path, content) {
    fs.writeFileSync(path + '/index-all.ts', content);

}

exports.generateInjectedFiles = function(entryPoint) {
    var thirdPartyConfig = require('../../../../../third-party/config.json');
    for (var i = 0; i < thirdPartyConfig.components.length; i++) {
        var curComponent = thirdPartyConfig.components[i];
        if (curComponent.dynamicModules && curComponent.dynamicModules.length) {
            var value = entryPoint[curComponent.directoryName];
            if (value) {
                entryPoint[curComponent.directoryName] = value + 'index-all.js';
            }
            var fileContent = createGlobalFileContext(curComponent.baseClass, curComponent.dynamicModules);
            writeFile('./src/' + curComponent.directoryName, fileContent);
        }
    }
};