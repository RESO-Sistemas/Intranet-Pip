'use strict';
var fs = global.fs = global.fs || require('fs');
var md2json = require('md-2-json');
function changelog(sourcePath, destPath) {
    var mdContent = '';
    if (fs.existsSync(destPath)) {
        var source = md2json.parse(fs.readFileSync(sourcePath, 'utf8'));
        var dest = md2json.parse(fs.readFileSync(destPath, 'utf8'));
        var changelog = mergeChangelog(source, dest);
        mdContent = (md2json.toMd(changelog));
    } else if(fs.existsSync(sourcePath)) {
        mdContent = fs.readFileSync(sourcePath,'utf8');
    }
    return mdContent;
}
exports.changelog = changelog;

function mergeChangelog(source, dest) {
    for (var item in dest) {
        if (typeof source[item] !== 'object') {
            if (typeof dest[item] === 'object') {
                source[item] = dest[item];
            } else {
                if (source[item] !== dest[item]) {
                    source[item] = source[item] + dest[item];
                } else {
                    source[item] = dest[item];
                }
            }

        } else if (typeof dest[item] === 'object') {
            source[item] = mergeChangelog(source[item], dest[item]);

        }
    }
    return source;
}
exports.mergeChangelog = mergeChangelog;