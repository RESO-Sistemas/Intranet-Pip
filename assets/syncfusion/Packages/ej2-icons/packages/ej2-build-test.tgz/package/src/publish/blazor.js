'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var fs = global.fs = global.fs || require('fs');
var common = global.config = global.config || require('../utils/common.js');
var simpleGit = global.simpleGit = global.simpleGit || require('simple-git');
var currentPackage = common.currentPackage;

gulp.task('blazor-publish', function (done) {
    if (fs.existsSync('./third-party/blazor')) {
        var user = 'SyncfusionAutomation';
        var token = process.env.GiteaBuildAutomation_Autocommit_PrivateToken;
        var stageBranch = common.isMasterBranch ? 'master' : 'development';
        stageBranch = common.isReleaseBranch ? process.env.githubSourceBranch : stageBranch;
        stageBranch = common.isHotfixBranch ? process.env.githubSourceBranch : stageBranch;
        var ej2aspRepo = 'https://' + user + ':' + token + '@gitea.syncfusion.com/essential-studio/ej2-blazor-source.git';
        done();
        simpleGit('./third-party/blazor').init()
            .add('.')
            .commit('(EJ2-000): ' + currentPackage + ' blazor properties published')
            .push(ej2aspRepo, stageBranch, function () {
                console.log(currentPackage + ' - compiled scripts published in ej2-blazor-source github repo');
                console.log('Commit Message -> (EJ2-000): ' + currentPackage + ' blazor properties published.');
                done();
            });

    } else {
        done();
    }
});
