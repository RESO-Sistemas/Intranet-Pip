'use strict';

var gulp = global.gulp = global.gulp || require('gulp');
var thirdParty = global.thirdParty = global.thirdParty || require('./third-party.js');

gulp.task('angular-publish', function (done) {
    thirdParty.publish('angular', 
    'npm install && gulp angular-root-file && npm run scripts && gulp aot-scripts styles-all angular-api', done);
});

gulp.task('angular-root-file', function (done) {
    var build = require('../tasks/build');
    // generate root files
    build.generateRootFiles('./src');
    done();
});
