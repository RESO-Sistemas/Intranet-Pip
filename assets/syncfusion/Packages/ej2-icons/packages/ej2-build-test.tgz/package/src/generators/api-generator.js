'use strict';

//Global variables
var fs = global.fs = global.fs || require('fs');
var apicollection = {};
var indexCollection = {};
var switchconfig = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
var common = global.config || require('../utils/common.js');
var config = common.config();
var extRef = {};
var overviewTemplate =`* [Overview]({{:compFolder}}/overview)\n`;
exports.overviewTemplate = overviewTemplate;
var h3PropTemplate = `
<h3 class="doc-prop-wrapper" id="{{id}}" data-Path="{{id}}-{{:property}}">
<a href="#{{id}}" aria-hidden="true" class="anchor">
<svg aria-hidden="true" height="16" version="1.1" viewBox="0 0 16 16" width="16">
<path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 
3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 
4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 
1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z">
</path>
</svg>
</a><span class='doc-prop-name'>{{:property}}</span>

<span class="doc-prop-type">{{:prop-type}}
</span>

</h3>


`;
var reference = fs.existsSync('../ref-api.json') ? JSON.parse(fs.readFileSync('../ref-api.json')) : {};
var h1 = '# ';
var h3 = '\n### ';
var globalReference = {};
var funcString = 'Function';
var functions = {};
var functionReference = {};
var typeAliasColl = [];
var glob = require('glob');
var groupMatch = ['Classes', 'Enumerations', 'Interfaces', 'Type aliases'];
var tagText = {
    default: '\n\nDefaults to *',
    angulartype: '*',
    reacttype: '*',
    vuetype: '*'
};
var curPath = '';
var thead = '| Parameter | Type | Description |\n|------|------|-------------|\n';
var eventhead = '| Paramter Name | Type |\n|------|------|\n';
var apiThead = '\n| Name | Description |\n|------|-------------|';
var typeMatcher = ['Enumeration', 'Interface', 'Class', 'Function', 'Type alias'];
var isBaseComponent = false;
var baseName = '';
var curModuleName;
var isUpdated = false;
var compBase = config.baseMapping || [];
var compName = '', compBaseApi = {};
var switchApi = config.switchApiLocation || {};
var switchApiNames = {};
var nameAlias = {
    'floating-action-button': 'fab',
    'chips': 'chipList',
    'chipscomponent': 'chipListComponent',
    'floating-action-buttoncomponent': 'fabComponent'
};
var sourceFileName = '';
var platform;
function replaceSubLimeText(str) {
    return str.replace(/-(.)/g,function(ss){
        return ss.replace('-','').toUpperCase();
    });
}
exports.replaceSubLimeText= replaceSubLimeText;
function toInitCap(str) {
    return str.replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1);
    });
}
exports.toInitCap = toInitCap;
function generateApi(path, platformName) {
    curPath = path;
    var apiJson;
    var children;
    if (platformName) {
        config = JSON.parse(fs.readFileSync('../../config.json'));
        compBase = config.baseMapping || [];
        switchApi = config.switchApiLocation || {};
        apiJson = JSON.parse(fs.readFileSync('../../public/api/file.json'));
        children = apiJson.children;
        platform = platformName;
    } else {
        apiJson = JSON.parse(fs.readFileSync('./public/api/file.json'));
        children = apiJson.children;
    }
    if (!config.components.length) {
        isBaseComponent = true;
        baseName = common.currentPackage.split('ej2-')[1];
    }
    preProcessChild(children);
    for (var i = 0; i < children.length; i++) {
        var curChild = children[i];
        var singleApi = [];
        if (!(getCurrentModuleName(curChild) instanceof Array)) {
            singleApi.push(getCurrentModuleName(curChild));
            curModuleName = singleApi;
        }
        else{
        curModuleName = getCurrentModuleName(curChild);
        }
        if (curModuleName[0].length) {
            for (var curModuleNameList of curModuleName) {
                if (!apicollection[curModuleNameList]) {
                    apicollection[curModuleNameList] = { Class: '', Enumeration: '', Interface: '', Function: '', 'Type alias': '' };
                    indexCollection[curModuleNameList] = '';
                }
                if (!functions[curModuleNameList]) {
                    functions[curModuleNameList] = '';
                }
            }
            processChildren(curChild.children || []);
        }
    }
    for (var func in functions) {
        if (functions[func].length) {
            var subText = replaceSubLimeText(func);
            compName = isBaseComponent ? 'Base Library' : (subText.charAt(0).toUpperCase() +
                subText.slice(1) + ' Component');
            apicollection[func][funcString] += '\n| [Static Functions]' +
                '(./staticFunctions)| Root static functions of ' + compName + '|';
            functions[func] = h1 + 'Static Functions\n\nRoot static functions of ' +
                compName + '\n\n' + functions[func];
            indexCollection[func] += '\n* [Static Functions](' +
                func + '/staticFunctions)';
            generateFile(func, 'staticFunctions', functions[func]);
        }
    }
    if (Object.keys(extRef).length !== 0 && fs.existsSync('./third-party/')) {
        fs.writeFileSync('./third-party/ref-api.json', JSON.stringify({ 'ref': extRef }), 'utf8');
    }
    if (switchApiNames) {
        var names = Object.keys(switchApiNames);
        for (var x = 0; x < names.length; x++) {
            for (var y = 0; y < switchApiNames[names[x]].length; y++) {
                var name = switchApiNames[names[x]][y];
                var apiName = convertToLower(name);
                indexCollection[names[x]] += '\n* [' + name + '](' + names[x] + '/' + apiName + ')';
            }
        }
    }
    for (var api in apicollection) {
        var content = '';
        var switchKeys = Object.keys(switchApi);
        if(switchKeys.indexOf(api) !== -1){
            continue;
        }
        var collection = apicollection[api];
        for (var type in collection) {
            if (collection[type].length) {
                content += collection[type];
            }
        }
        if (content.length) {
            content = '# Overview\n' + '\n' + apiThead + content + '\n';
            generateFile(api, 'overview', content, true);
            console.log(api);
            generateFile(api, 'summary',overviewTemplate.replace(/{{:compFolder}}/,api) + indexCollection[api].slice(1), true);
        }
    }
    return isUpdated;
}

exports.generateApi = generateApi;

function processChildren(child) {
    for (var curProp of child) {
        var name = curProp.name;
        var kindString = curProp.kindString;
        if (typeMatcher.indexOf(kindString) !== -1 && curProp.flags.isExported &&
            !curProp.flags.isPrivate && createTypeReference(curProp, name, kindString)) {
            var lname = convertToLower(name);
            var shortText = getMessageText(curProp, true);
            var curText = getTableText(shortText);
            for (var curModuleNameList of curModuleName) {
                if (curText.length && name.indexOf('Model') === -1) {
                    var moduleName = isCurrentModuleFile(curModuleNameList, lname) ? '' : (lname +'/');
                    apicollection[curModuleNameList][kindString] += '\n| [' + name + '](./' +
                        moduleName + ')| ' + curText + '|';
                }
                if(!isCurrentModuleFile(curModuleNameList,name)){
                    indexCollection[curModuleNameList] += '\n* [' + name + '](' + curModuleNameList + '/' + lname + ')';
                }
            }
        }
    }
}

function createTypeReference(obj, propName, kind) {
    var canIncluded = false;
    var topMessage = getMessageText(obj);
    // //var descripton = topMessage.split('.');
    // if(descripton.length){
    //     descripton = descripton[0] +'.';
    // } else {
    //     descripton = '';
    // }
    var toplevelComment = h1 + propName + '\n' + (topMessage.length ? '\n' + topMessage + '\n' : '');
    var content = '';
    var methods = '';
    var properties = '';
    var events = '';
    var property = obj.children || [];
    for (var curObj of property) {
        var curComment;
        var isClass = kind === 'Class';
        var isInterface = kind === 'Interface';
        var isExported = curObj.flags.isExported && !(curObj.flags.isPrivate);
        if ((curObj.flags.isPublic || isExported) && !curObj.flags.isProtected) {
            var kString = curObj.kindString;
            if (kString === 'Method') {
                for (var i = 0; i < curObj.signatures.length; i++) {
                    curComment = getMessageText(curObj.signatures[i]);
                    if (curComment.length) {
                        curObj.signNo = i;
                        var mOptions = getMethodType(curObj);
                        if (mOptions.flag) {
                            var ret = 'Returns *void*';
                            if (curObj.signatures[i].type) {
                                var actRet = getType(curObj.signatures[i].type);
                                actRet = actRet.replace(/`/g, '*');
                                if (actRet) {
                                    ret = 'Returns' + actRet;
                                }
                            }
                            methods += h3 + '' + curObj.name + '\n\n' + curComment + '\n' + (mOptions.content || '') + '\n' + ret + '\n';
                        }
                    }
                }
            } else if (kString === 'Enumeration member') {
                content += '\n* `' + curObj.name + '`' + (curObj.comment && curObj.comment.shortText ? ' - ' + curObj.comment.shortText : '');
            } else if (kString === 'Event' || kString === 'Property') {
                curComment = getMessageText(curObj);
                var propType = getPropertyWithType(curObj);
                if (curComment.length && propType.length) {
                    var propheader =  generateHeaderTemplate(curObj.name, propType);
                    //    h3PropTemplate.replace(/{{id}}/g,curObj.name.toLowerCase())
                    //       .replace(/{{:property}}/g,curObj.name)
                    //       .replace(/{{:prop-type}}/g, propType );
                    var temp = propheader + curComment;
                    if (isClass || isInterface) {
                        if (kString === 'Property') {
                            properties += temp + (isClass ? getTagValue(curObj.comment, 'default') : '') + '\n';
                        } else {
                            events +=  temp + '\n';
                        }
                    } else {
                        properties +=  temp + '\n';
                    }

                }
            } else if (kString === 'Accessor') {
                if (curObj.getSignature) {
                    var getSignature = curObj.getSignature.length ? curObj.getSignature[0] : curObj.getSignature;
                    var acComment = getMessageText(getSignature);
                    var acType = getPropertyWithType(getSignature);
                    if (acComment.length && acType.length) {
                        properties += h3 + 'Get ' + curObj.name + acType + '\n\n' + acComment + '\n';
                    }
                }
                if (curObj.setSignature) {
                    var setSignature = curObj.setSignature.length ? curObj.setSignature[0] : curObj.setSignature;
                    var acComment = getMessageText(setSignature);
                    var acType = getPropertyWithType(setSignature);
                    if (acComment.length && acType.length) {
                        var paramInfo = '';
                        if (setSignature.parameters && setSignature.parameters.length > 0) {
                            var param = setSignature.parameters[0];
                            var paramComment = getMessageText(setSignature.parameters[0]).split('\n')[0];
                            var paramType = getPropertyWithType(param, true);
                            if (paramComment.length && paramType.length) {
                                paramInfo = '\n' + thead + '| ' + param.name + ' | ' + paramType + ' | ' + paramComment[0].toUpperCase() + paramComment.slice(1) + ' |\n';
                            } else {
                                paramInfo = '\nParameters: ' + param.name + ':' + paramType;
                            }
                        }
                        properties += h3 + 'Set ' + curObj.name + acType + '\n\n' + acComment + '\n' + paramInfo + '\n';
                    }
                }
            } 
        }
    }
    if (obj.kindString === 'Interface') {
        for (var signatures of Object.keys(obj).filter(key => (key.toLowerCase()).includes('signature'))) {
            if (Array.isArray(obj[signatures])) {
                for (var signature of obj[signatures]) {
                    properties += getSignatureProps(signature) + '\n';
                }
            } else {
                properties += getSignatureProps(obj[signatures]) + '\n';
            }
        }
    }
    for (var curModuleNameList of curModuleName) {
        if (kind === 'Function' && functionReference[curModuleNameList].indexOf(obj.id) !== -1) {
            if (obj.flags.isExported && !obj.flags.isPrivate) {
                var fComment = getMessageText(obj.signatures[0]);
                if (fComment.length) {
                    var fOptions = getMethodType(obj);
                    if (fOptions.flag) {
                        var rtn = 'Returns *void*';
                        if (obj.signatures[0].type) {
                            var actRtn = getType(obj.signatures[0].type);
                            actRtn = actRtn.replace(/`/g, '*');
                            if (actRtn) {
                                rtn = 'Returns' + actRtn;
                            }
                        }
                        functions[curModuleNameList] += '## ' + obj.name + '\n\n' +
                            fComment + '\n' + (fOptions.content || '') + '\n' + rtn + '\n\n';
                    }
                }
            }
        }
    }
    if (obj.kindString === 'Type alias') {
        if (obj.type.type === 'union') {
            toplevelComment = h1 + propName;
            var splitMsg = topMessage.split('\n');
            content = (topMessage) ? '\n\n' + splitMsg[0] : '';
            var hasTypeDesc = false;
            var typeContent = '';
            for (var typeDef of splitMsg.splice(1)) {
                if (typeDef === '```props') {
                    typeContent = typeDef;
                } else if (typeDef === '```') {
                    typeContent = typeDef;
                }
                if (typeContent === '```props' && typeDef !== '```props') {
                    hasTypeDesc = true;
                    var splitChar = typeDef.split(':-');
                    if (splitChar.length > 1) {
                        content += '\n* `' + splitChar[0].replace('*', '').trim() + '` - ' + splitChar[1].trim();
                    } else {
                        content += '\n* ' + typeDef;
                    }
                } else if (typeDef !== '```props' && typeDef !== '```'){
                    content += '\n' + typeDef;
                }
            }
            if (!hasTypeDesc) {
                var objValue = obj.type.types || [];
                for (var value of objValue) {
                    content += ((value.value) ?  ('\n* '+ value.value) :(value.name)?  ('\n* ' + value.name):'');
                }
            }
        } else if (obj.type.type === 'reflection' && obj.type.declaration.signatures) {
            content = reflectionType(obj);
        }
    }

    content += getClassContent([properties, methods, events]);
    if (content.length) {
        for (var curModuleNameLists of curModuleName) {
            if (compBase.indexOf(curModuleNameLists) !== -1) {
                compBaseApi[propName] = toplevelComment + content;
            }
            canIncluded = true;
            generateFile(curModuleNameLists, propName, toplevelComment + content,false);
        }
    }
    return canIncluded;
}

function getSignatureProps(signature) {
    var signString = '';
    if (signature.comment && signature.comment.shortText) {
        var splitMsg = signature.comment.shortText.split('\n');
        var typeContent = '';
        var signComment = '';
        var signPropName = '';
        var signPropType = '';
        for (var typeDef of splitMsg) {
            if (typeDef === '```props') {
                typeContent = typeDef;
            } else if (typeDef === '```') {
                typeContent = typeDef;
            }
            if (typeContent === '```props' && typeDef !== '```props') {
                var splitChar = typeDef.split(':-');
                if (splitChar.length > 1) {
                    signPropName = splitChar[0].trim();
                    signPropType = ' `' + splitChar[1].trim() + '`';
                }
            } else if (typeDef !== '```props' && typeDef !== '```'){
                signComment += typeDef + '\n';
            }
        }
        if (signComment.length && signPropType.length) {
            var signPropheader = generateHeaderTemplate(signPropName, signPropType);
            signString = signPropheader + signComment;
        }
    }
    return signString;
}

function generateHeaderTemplate(propName, propType) {
    return h3PropTemplate.replace(/{{id}}/g, propName.toLowerCase())
        .replace(/{{:property}}/g, propName)
        .replace(/{{:prop-type}}/g, propType );
}
exports.generateHeaderTemplate = generateHeaderTemplate;
function reflectionType(obj) {
    var content = getMethodType(obj.type.declaration, true).content;
    return content;
}

function getPropertyWithType(obj, flag, curName, platformName) {
    if (platformName) {
        platform = platformName;
    }
    var rejectList = ['constructor'];
    var name = obj.name;
    var type;
    if (!flag && rejectList.indexOf(name) !== -1) {
        return '';
    }
    if (obj.sources && obj.sources.length) {
        sourceFileName = obj.sources[0].fileName
                        .split('/')[obj.sources[0].fileName.split('/').length - 1]
                        .split('.')[0].replace('-model','');
    }
    if (platform && obj.comment && obj.comment.tags) {
        for (var typeTag of obj.comment.tags) {
            if (typeTag.tag === platform + 'type') {
                var platformTypes = getTagValue(obj.comment, typeTag.tag).replace(/\*/g, '`').split('|').map((str) => { return str.trim(); });
                return ' ' + platformTypes.join('` | `');
            }
        }
    }
    type = getType(obj.type, obj.kindString === 'Event', curName);
    return type || '';
}
exports.getPropertyWithType = getPropertyWithType;
function getMethodType(mObj, excludeMsg, curName) {
    var ret = { flag: true, content: '' };
    var curObj = mObj.signatures[mObj.signNo || 0] || {};
    var typeCollection = [];
    var tbody = '';
    var params = curObj.parameters;
    if (params && params.length) {
        for (var cur of params) {
            var message = getMessageText(cur);
            var type = getPropertyWithType(cur, true, curName);
            // adding hyperlink for other component repository interfaces used as paramater for methods
            var typeParam = type.replace(/`/g, '').replace(/^\s+/, '');
            if (typeParam.indexOf('[]') !== -1) {
                typeParam = typeParam.replace('[]', '');
            }
            if (config.dependentAPI && config.dependentAPI[curModuleName] &&
                config.dependentAPI[curModuleName][typeParam]) {
                var dependentType = config.dependentAPI[curModuleName][typeParam];
                type = ' [`' + typeParam + '`](../' + dependentType + ')';
            }
            if (type.length && (excludeMsg || message.length)) {
                var name = cur.name;
                if (cur.flags && cur.flags.isOptional) {
                    name += ' (*optional*)';
                }
                typeCollection.push(name);
                tbody += '| ' + name + ' | ' + type + (!excludeMsg ? (' | ' + getTableText(message)) : '') + ' |\n';
            }
        }
        if (typeCollection.length === params.length) {
            ret.flag = true;
            ret.content = '\n' + (excludeMsg ? eventhead : thead) + tbody;
        }
    }
    return ret;
}
exports.getMethodType = getMethodType;
function getMessageText(msgObject, shortText) {
    if (!msgObject.comment) {
        return '';
    }
    var msgText = (msgObject.comment.shortText || '') +
        ((msgObject.comment.shortText && msgObject.comment.text) ?
            ('\n' + msgObject.comment.text) : (msgObject.comment.text || ''));
    var ret = msgText;
    var sampleIndex = msgText.indexOf('```');
    if (sampleIndex !== -1) {
        ret = msgText.substr(0, sampleIndex - 1);
        if (!shortText) {
            ret = msgText;
        }
    }
    return ret;

}
exports.getMessageText = getMessageText;
function getTagValue(cur, key) {
    var tags = cur.tags;
    if (cur.tags) {
        for (var i = 0, len = tags.length; i < len; i++) {
            var tag = tags[i];
            if (tag.tag === key) {
                var text = tag.text.replace(/\n/g, '');
                if (!text) {
                    return '';
                }
                return tagText[key] + text + '*';
            }
        }
    }
    return '';
}
exports.getTagValue = getTagValue;
function processUnionObject(obj, curName) {
    var types = obj.types;
    var typeString = [];
    for (var k = 0; k < types.length; k++) {
        var name = getType(types[k], false, curName);
        if (name) {
            typeString.push(name);
        }
    }
    return typeString.join(' &#124; ');
}

function getType(type, isEvent, curName) {
    var iType = '', isArray, decl, intType, id;
    var isUnion = false;
    if (!type) {
        return '';
    }
    iType = type.name || (type.elementType ? (type.elementType.name ? type.elementType.name : type.elementType.type === 'array' ? getType(type.elementType, false, curName) : '') : '');
    intType = type.type;
    id = type.id;
    if (type.type === 'array' && !id && type.elementType) {
        id = type.elementType.id;
    }
    isArray = type.isArray || type.type === 'array';
    decl = type.declaration || (type.elementType ? (type.elementType.declaration ? type.elementType.declaration : '') : '');
    if (!iType) {
        if (intType === 'union') {
            isUnion = true;
            iType = processUnionObject(type, curName);
        } else if (decl) {
            if (isEvent) {
                return getMethodType(decl, true).content || '`Object`';
            } else {
                iType = getReflectionType(type);
            }

        }
    } else if (iType === 'EmitType') {
        var typeArguments = type.typeArguments;
        if (typeArguments && typeArguments.length) {
            var etype = getType(typeArguments[0], false, curName);
            etype = etype.replace(/ /g, '');
            var hindex = etype.indexOf('[');
            var lindex = etype.indexOf(']');
            if (hindex !== -1) {
                if (hindex !== etype.lastIndexOf('[')) {
                    return '  `EmitType<`' + etype + '`>`';
                } else {
                    return ' [`EmitType<' + etype.substring(hindex + 2, lindex - 1) + '>' + etype.substring(lindex - 1);
                }
            } else {
                etype = etype.replace(/&#124;/g, '|');
                return '  `EmitType<' + etype.replace(/`/g, '') + '>`';
            }
        }
        return '  `EmitType`';
    } else if (id && curModuleName) {
        if (typeAliasColl.indexOf(id) !== -1) {
            if (!extRef.typealias) { extRef.typealias = []; }
            extRef.typealias = extRef.typealias.concat(iType);
            iType = ' [`' + (type.name || type.elementType.name) + '`](./' + convertToLower(type.name || type.elementType.name) + ')';
        } else
        {
            let curType = '';
            for (var curModuleNameList of curModuleName) {
                if (globalReference[curModuleNameList || curName] && globalReference[curModuleNameList || curName].indexOf(id) !== -1) {
                    if (!extRef[curModuleNameList || curName]) { extRef[curModuleNameList || curName] = []; }
                    extRef[curModuleNameList || curName] = extRef[curModuleNameList || curName].concat(iType);
            var linkval = iType;
            if(isCurrentModuleFile((curModuleNameList || curName),iType)){
                linkval = '';
            }
            curType = ' [`' + iType + '`](./' + convertToLower(linkval) + ')';
                } else {
                    if (!extRef[curModuleNameList || curName]) { extRef[curModuleNameList || curName] = []; }
                    extRef[curModuleNameList || curName] = extRef[curModuleNameList || curName].concat(iType);
                    for (var i = 0; i < config.components.length; i++) {
                        var curText = config.components[i];
                        if ((curText !== curModuleNameList || curText !== curName) && compBase) {
                            if (compBase.indexOf(curText) !== -1 && globalReference[curText].indexOf(id) !== -1 && compBaseApi[iType]) {
                                var apName = convertToLower(iType);
                                generateFile(curModuleNameList || curName, iType, compBaseApi[iType]);
                                if (!indexCollection[curModuleNameList || curName]) {
                                    indexCollection[curModuleNameList || curName] = '';
                                }
                                // collection variable is used to check whether the API name is already appended on the indexCollection object or not.
                                let collection = '\n* [' + iType + '](' +
                                    (curModuleNameList || curName) + '/' + apName + ')';
                                indexCollection[curModuleNameList || curName] += !indexCollection[curModuleNameList || curName].includes(collection) ? collection : '';
                                curType = ' [`' + iType + '`](./' +  apName + ')';
                            } else if (switchconfig.switchApiLocation && 
                                Object.keys(switchconfig.switchApiLocation).indexOf(curText) !== -1 && switchconfig.switchApiLocation.common &&
                                (switchconfig.switchApiLocation.common).indexOf(curModuleNameList) !== -1) {
                                // To create anchor link for api navigation from one page to another
                                curType = ' [`' + iType + '`](./' + convertToLower(iType) + ')';
                            }
                        } else if ((curText !== curModuleNameList || curText !== curName) && globalReference[curText].indexOf(id) !== -1) {
                            var lowerText = convertToLower(iType);
                            curType = ' [`' + iType + '`]("../' + curText + '/' + lowerText + ')';
                        }
                    }
                }
            }
            iType = curType !== '' ? curType : iType;
        }
    } else if (curName && reference.ref) {
            if (reference.ref[curName] && reference.ref[curName].indexOf(iType) !== -1) {
                iType = ' [`' + iType + '`](./' + convertToLower(iType) + ')';
            }
            else if (reference.ref.typealias && reference.ref.typealias.indexOf(iType) !== -1) {
                iType = ' [`' + (type.name || type.elementType.name) + '`](./' + convertToLower(type.name || type.elementType.name) + ')';
            }
    }
    if (!isUnion && iType && iType.indexOf('[') === -1) {
        if (type.type === 'reference' && !type.id && config.dependentAPI && config.dependentAPI[curModuleName] &&
            (config.dependentAPI[curModuleName][iType] || config.dependentAPI[curModuleName][`${sourceFileName}/${iType}`])) {
            var dependentType = config.dependentAPI[curModuleName][`${sourceFileName}/${iType}`] ? 
                                `${config.dependentAPI[curModuleName][`${sourceFileName}/${iType}`]}` : 
                                config.dependentAPI[curModuleName][iType];
            iType = ' [`' + iType + '`](../' + dependentType + ')';
        } else {
            iType = ' `' + iType + '`';
        }
    }
    if (type.type === 'intersection' && type.types && type.types.length) {
        var typesArray = [];
        for (var intersectionType of type.types) {
            typesArray.push(getType(intersectionType).trim());
        }
        iType = ` ${typesArray.join(' &amp; ')}`;
    }
    var bindex = iType.lastIndexOf('`');
    return (isArray ? iType.slice(0, bindex) + '[]' + iType.slice(bindex) : iType);
}
function  createFrontMatter() {
    return '';
}
exports.createFrontMatter = createFrontMatter;
exports.getType = getType;
// function generate the Object expanded type if it is provided or return `Object`.
function getReflectionType(obj) {
    var typeArray = '';
    if (obj.type === 'reflection' && obj.declaration.indexSignature) {
        var indexSignature = obj.declaration.indexSignature.length ? obj.declaration.indexSignature[0] : obj.declaration.indexSignature;
        if (indexSignature.parameters) {
            for (let types of indexSignature.parameters) {
                typeArray += typeArray.length > 0 ? ', ' : '';
                typeArray += types.name + ':' + (getType(types.type).replace(/`/g, ''));
                typeArray = '[' + typeArray + ']';
            }
        }
        typeArray = ' `{ ' + typeArray + ':' + getType(indexSignature.type).replace(/`/g, '') + ' }`';
    } else if (obj.type === 'array' && obj.elementType.type === 'reflection') {
        typeArray = getReflectionType(obj.elementType);
    } else {
        typeArray = 'Object';
    }
    return typeArray;
}
function generateFile(moduleName, fileName, content, prevChange) {
    var modulePath = curPath + moduleName;
    // code for front matetr automation.
    // var frontMatter = '';
    // var ComponentName = toInitCap(replaceSubLimeText(moduleName));
    // if (fileName.indexOf('summary') === -1) {
    //     frontMatter = createFrontMatter({
    //         component: ComponentName || '', title: fileName || ''
    //     });
    // }
    var currModuleFile = isCurrentModuleFile(moduleName, fileName);
    if (switchApi[moduleName]) {
        modulePath = curPath + switchApi[moduleName];
        if (!switchApiNames[switchApi[moduleName]]) {
            switchApiNames[switchApi[moduleName]] = [];
        }
        if (!currModuleFile) {
            switchApiNames[switchApi[moduleName]] = switchApiNames[switchApi[moduleName]].concat(fileName);
        }
    }
    if (!fs.existsSync(modulePath)) {
        return;
    }
    isUpdated = true;
    if(currModuleFile){
        fileName = 'index';
       // content = content.replace(/\.\.\//g,'');
    }
    if (!(switchApi[moduleName] && currModuleFile)) {
        fs.writeFileSync(modulePath + '/' + convertToLower(fileName, prevChange) + '.md', content, 'utf8');
    }
}

function isCurrentModuleFile(moduleName,fileName) {
    // This Condition is to avoid the breaking change of the Fab and Chip component.
    if (nameAlias[moduleName]) { return replaceSubLimeText(nameAlias[moduleName]).toLowerCase() === fileName.toLowerCase(); }
    return replaceSubLimeText(moduleName).toLowerCase() === fileName.toLowerCase();
}
exports.isCurrentModuleFile = isCurrentModuleFile;
function convertToLower(text, prevChange) {
    return (prevChange ? '' : '') + text.substr(0, 1).toLowerCase() + text.substr(1);
}
exports.convertToLower = convertToLower;

function getClassContent(parts, isInterface) {
    var match = ['Properties', 'Methods', 'Events'];
    var ret = '';
    var index = 1;
    for (var i = 0, len = parts.length; i < len; i++) {
        var curStr = parts[i];
        if (curStr.length) {
            ret += (isInterface ? '' : '\n' + (index === 1 ? '## ' : '## ') + match[i] + '\n') + curStr;
            index++;
        }
    }
    return ret;
}

exports.getClassContent = getClassContent;

function preProcessChild(childs) {
    for (var child of childs) {
        var curNameList;
        var switchString = [];
        if (!(getCurrentModuleName(child) instanceof Array)) {
            switchString.push(getCurrentModuleName(child));
            curNameList = switchString;
        }
        else
        {
            curNameList = getCurrentModuleName(child);
        }
        for (var curName of curNameList) {
            var groups = child.groups;
            var glen;
            if (!globalReference[curName]) {
                globalReference[curName] = [];
            }
            if (!functionReference[curName]) {
                functionReference[curName] = [];
            }
            if (groups && (glen = groups.length)) {
                for (var i = 0; i < glen; i++) {
                    var group = groups[i];
                    var title = group.title;
                    if (title === 'Type aliases') {
                        typeAliasColl = typeAliasColl.concat(group.children);
                    } else if (!curName.length) {
                        continue;
                    } else if (groupMatch.indexOf(title) !== -1) {
                        globalReference[curName] = globalReference[curName].concat(group.children);
                    } else if (title === 'Functions') {
                        functionReference[curName] = functionReference[curName].concat(group.children);
                    }
                }
            }
        }
    }
    if (compBase.length > 0) {
        for (var count = 0; count < childs.length; count++) {
            var curChildren = childs[count];
            var singleApi = [];
            if (!(getCurrentModuleName(curChildren) instanceof Array)) {
                singleApi.push(getCurrentModuleName(curChildren));
                curModuleName = singleApi;
            }
            else{
                curModuleName = getCurrentModuleName(curChildren);
            }
            if (compBase.indexOf(curModuleName[0]) !== -1 && curChildren.children) {
                for (var curProp of curChildren.children) {
                    createTypeReference(curProp, curProp.name, curProp.kindString);
                }
            }
        }
    }
}

function getCurrentModuleName(mChild) {
    if (isBaseComponent) {
        return baseName;
    }
    var name = mChild.name.replace(/"/g, '').split('/')[0];
    var switchName = '';
    if(Object.keys(switchApi).length ){
        switchName = switchApi[name] || '';
    }
    return (config.components.indexOf(name) !== -1 ? name : getName(switchName) ? switchName : '');
}

function getName(switchName) {
    if (switchName instanceof Array) {
        for (var switchT of switchName) {
            if (config.components.indexOf(switchT) !== -1) {
                return true;
            }
        }
    }
    else
        if (config.components.indexOf(switchName) !== -1) {
            return true;
        }
}

function getTableText(text) {
    return text.replace(/\n/g, '<br>');
}
exports.getTableText = getTableText;

function clearComponentFolder(path) {
    var components = config.components;
    if (!components.length) {
        components = [common.currentPackage.split('ej2-')[1]];
    }
    for (var comp of components) {
        var curFolders = path + comp;
        if (fs.existsSync(curFolders)) {
            var files = glob.sync(curFolders + '/*.md', { silent: true });
            for (var i = 0; i < files.length; i++)  {
                fs.unlinkSync(files[i]);
            }
        } else {
            console.log(path + comp);
            if(!fs.existsSync(path)) {
                fs.mkdirSync(path);
            }
            fs.mkdirSync(path+comp);
        }
    }

}
exports.clearComponentFolder = clearComponentFolder;
