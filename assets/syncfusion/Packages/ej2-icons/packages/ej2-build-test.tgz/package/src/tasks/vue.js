'use strict';

var common = global.config = global.config || require('../utils/common.js');
var shelljs = global.shelljs = global.shelljs || require('shelljs');
var gulp = global.gulp = global.gulp || require('gulp');
var changelogObj = require('../../src/third-party/changelog.js');
var fs = global.fs = global.fs || require('fs');
var runSequence = global.runSequence = global.runSequence || require('gulp4-run-sequence');

gulp.task('vue-checkout', function (done) {
    common.checkout('vue', 'vue', done);
});

gulp.task('vue-generate', function (done) {
    var srcGen = require('../third-party/vue/src-generator.js');
    var propGen = require('../third-party/vue/property-reader');
    var propCollection = propGen(JSON.parse(fs.readFileSync('./public/api/file.json')));
    shelljs.cp('./third-party/readme/vue.md', './third-party/vue/README.md');
    if (fs.existsSync('./CHANGELOG.md')) {
        var mdContent = changelogObj.changelog('./CHANGELOG.md', './third-party/changelog/vue.md');
        fs.writeFileSync('./third-party/vue/CHANGELOG.md', mdContent);
    }
    var themesList = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
    themesList = themesList.themes;
    var thirdpartyConfig = JSON.parse(fs.readFileSync('./third-party/vue/config.json', 'utf8'));
    thirdpartyConfig.themes = themesList;
    fs.writeFileSync('./third-party/vue/config.json', JSON.stringify(thirdpartyConfig), 'utf8');
    srcGen(JSON.parse(fs.readFileSync('./third-party/config.json')), propCollection, done);
});

gulp.task('vue-configure', function (done) {
    common.thridPartyConfigure('vue', 'vue');
    done();
});

gulp.task('copy-vue-code-block', function (done) {
    if (fs.existsSync('./api-code-blocks/vue/')) {
        shelljs.mkdir('-p',`./third-party/vue/api-code-blocks`);
        shelljs.cp('-r', `./api-code-blocks/vue`, `./third-party/vue/api-code-blocks`);
        done();
    }
    else {
        done();
    }
});

gulp.task('vue-build', function (done) {
    runSequence('vue-checkout', 'vue-configure', 'vue-generate', 'copy-vue-code-block', done);
});