# TypeScript

Pure JavaScript components which are written using TypeScript.

# How to run the sample

Run the commands sequentially 

```
npm install -g gulp
npm install

gulp watch
``` 

# Implemented Gulp build commands

Test - Run all tests once 

```
gulp test
```

TDD - Run all tests then watch for file changes. On each file save on source or specs, test cases will run again

```
gulp tdd
```

Lint - tslint and sass-lint source files

```
gulp lint
```

Build - Compile typescript and SCSS files

```
gulp build
```

Coverage - Run all tests with Istanbul coverage and validate the source coverage to 90%

```
gulp coverage
```

Spell Check - Check all public API naming - spell, abbreviation, singular, plural formats

```
gulp spell-check
```

# API Generation Gulp commands

### Pre-config:

Before running API Generation gulp command, create directory structure as follows in the component source,

 ./ej2-docs / src / component-name ( component name as in config.json )

## TypeScript API Generation

Creates API files for TypeScript Components.

```
gulp local-api
```

## Angular API Generation

Creates API files for Angular Components.

```
gulp local-angular-api
```


## React API Generation

Creates API files for React Components.

```
gulp local-react-api
```

## CI Testing
