var gulp = require("gulp");
require('require-dir')('src/tasks');
require('require-dir')('src/utils');
require('require-dir')('src/release');
require('require-dir')('src/publish');
require('require-dir')('src/generators');
module.exports = gulp;